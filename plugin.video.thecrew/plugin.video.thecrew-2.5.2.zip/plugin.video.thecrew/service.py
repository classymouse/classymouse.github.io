# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file service.py
 * @package plugin.video.thecrew
 *
 * @copyright (c) 2023 - 2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''



# CM - 06/07/2021
# cm - 06/20/2023
# cm - 10/19/2024 - conversion check and fix from module v. 1.x to v. > 2.0.0
# cm - 11/01/2024 - added TraktMonitor for scrobble
# cm - 02/20/2026 - added CrewMonitor for global player monitoring (TV Evening playlist)
# cm - 02/22/2026 - added conversion check and fix for bookmarks file
# cm - 02/28/2026 - v22.26 ZERO-THREAD-GROWTH: CrewMonitor persistent worker thread for infinite episodes

import os
import re
import traceback
import glob
import queue
import threading

from threading import Thread
from shutil import rmtree
from resources.lib.modules import control
from resources.lib.modules import trakt
from resources.lib.modules import workers

from resources.lib.modules.crewruntime import c

import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon

QUARTERLY = 60 * 15
HALF_HOUR = 60 * 30
HOURLY = 60 * 60
FIVE_MINUTES = 60 * 5

def conversion():

    # cm - 10/19/2024 Removed dialogs as being obsolete and not needed
    conversionFile = os.path.join(control.dataPath, 'conversion.v')
    bookmarkFile = control.bookmarksFile
    curVersion = c.moduleversion
    version = c.pluginversion

    if not os.path.exists(conversionFile):
        f_path = xbmcvfs.translatePath('special://home/addons/script.thecrew.metadata')
        rmtree(f_path, ignore_errors=True)

        if os.path.isfile(bookmarkFile):
            os.remove(bookmarkFile)
            c.log(f'removing {str(bookmarkFile)}')

        if not os.path.isfile(bookmarkFile):
            #write the conversion.v file
            with open(conversionFile, 'w', encoding="utf8") as fh:
                fh.write(curVersion)
            if c.devmode:
                c.log(f'File written, Conversion successful, version = {curVersion}')



def readProviders(scraper_path_fill, msg1, catnr):
    addon_name = c.name
    addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
    addon_path = xbmcvfs.translatePath('special://home/addons/plugin.video.thecrew')
    module_path = xbmcvfs.translatePath('special://home/addons/script.module.thecrew')


    xbmc.log(f"[ plugin.video.thecrew ] service - checking {msg1} providers started", 1)

    if c.has_silent_boot:
        if c.devmode:
            c.log(f"Preparing {msg1} Providers")
    else:
        xbmcgui.Dialog().notification(addon_name, f"Preparing {msg1} Providers", addon_icon)

    settings_xml_path = os.path.join(addon_path, 'resources/settings.xml')
    scraper_path = os.path.join(
        module_path, f'lib/resources/lib/sources/{scraper_path_fill}'
    )
    try:
        xml = openfile(settings_xml_path)
    except (OSError, IOError) as e:
        c.log(f"The Crew Service - Exception: {e}")
        return

    new_settings = '\n'
    #for file in glob.glob("%s/*.py" % (scraper_path)):
    for file in glob.glob(f"{scraper_path}/*.py"):
        file = os.path.basename(file)
        if '__init__' not in file:
            file = file.replace('.py', '')
            # Old format (pre-v19)
            new_settings += f'        <setting id="provider.{file.lower()}" type="bool" label="{file.upper()}" default="true" />\n'
        new_settings += '    '

    # Old format pattern matching
    #pattern = ('<category label="{}">').format(str(catnr)) + '([\s\S]*?)<\/category>'
    pattern = f'<category label="{str(catnr)}">' + r'([\s\S]*?)<\/category>'
    found = re.findall(pattern, xml, flags=re.DOTALL)
    xml = xml.replace(found[0], new_settings)
    savefile(settings_xml_path, xml)
    if c.has_silent_boot:
        if c.devmode:
            c.log(f"{msg1} Providers Updated")
    else:
        xbmcgui.Dialog().notification(addon_name, f"{msg1} Providers Updated", addon_icon)


def openfile(path_to_the_file):
    try:
        with open(path_to_the_file, 'r', encoding="utf8") as fh:
            contents = fh.read()
        return contents

    except (OSError, IOError) as e:
        c.log(f"Service Open File Exception - {path_to_the_file}: {e}")
        return None


def savefile(path_to_the_file, content):
    try:
        with open(path_to_the_file, 'w', encoding="utf8") as fh:
            fh.write(content)
        fh.close()
    except (OSError, IOError) as e:
        c.log(f"Service Save File Exception - {path_to_the_file}: {e}")





def syncTraktLibrary():
    control.execute('RunPlugin(plugin://plugin.video.thecrew/?action=tvshowsToLibrarySilent&url=traktcollection')
    control.execute('RunPlugin(plugin://plugin.video.thecrew/?action=moviesToLibrarySilent&url=traktcollection')

def syncTrakt():
    #control.execute('RunPlugin(plugin://plugin.video.thecrew/?action=syncTrakt')
    trakt.syncTrakt()

def main():
    """
    Run one-time startup tasks.
    This executes once when Kodi starts, NOT continuously.
    Scheduled/continuous tasks should be in TraktMonitor.
    """
    try:
        # cm - Rotate log file BEFORE any logging to prevent massive log files
        try:
            import os
            log_dir = xbmcvfs.translatePath('special://logpath')
            log_path = os.path.join(log_dir, 'the_crew.log')
            old_log_path = os.path.join(log_dir, 'the_crew.old.log')
            if os.path.exists(log_path) and os.path.getsize(log_path) > 0:
                try:
                    if os.path.exists(old_log_path):
                        os.remove(old_log_path)
                except:
                    pass
                try:
                    os.rename(log_path, old_log_path)
                except:
                    pass
        except Exception as e:
            pass  # Don't fail startup if log rotation fails

        c.log_boot_option()

        # cm -conversion check and fix from module v. 1.x to v. > 2.0.0
        c.initialize_all()
        conversion()
        syncTrakt()

        # cm - Comprehensive startup maintenance (database checks, cache cleanup, version tracking, stale session cleanup)
        control.startupMaintenance()

        #cm - checking the version
        module_version = xbmcaddon.Addon('script.module.thecrew').getAddonInfo('version')
        plugin_version = xbmcaddon.Addon('plugin.video.thecrew').getAddonInfo('version')
        #updated = xbmcaddon.Addon('plugin.video.thecrew').getSetting('module_base') or '0'
        xbmcaddon.Addon('plugin.video.thecrew').setSetting('module_base', module_version)
        xbmcaddon.Addon('plugin.video.thecrew').setSetting('plugin_base', plugin_version)


        checks = ['en|Free|32345','en_de|Debrid|90004','en_tor|Torrent|90005']
        for check in checks:
            items = check.split('|')
            scraper_path_fill = items[0]
            msg1 = items[1]
            catnr = items[2]
            readProviders(scraper_path_fill, msg1, catnr)

        if c.devmode:
            c.log('Providers done')

        if control.setting('autoTraktOnStart') == 'true':
            if c.devmode:
                c.log('autoTraktOnStart Enabled: synctraktlib started')
            syncTraktLibrary()

        # Note: Scheduled Trakt sync is handled by TraktMonitor, not here
        # This function returns immediately after startup tasks complete

    except Exception as e:
        failure = traceback.format_exc()
        c.log(f'Traceback:: {str(failure)}')
        c.log(f'Exception raised: {str(e)}')






class TraktMonitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    def run(self):
        if c.devmode:
            c.log('[TraktMonitor] Service starting')
        xbmc.log('[ plugin.video.thecrew ] TraktMonitor Service Starting', 2)

        # Clear any stale window properties left over from a previous Kodi session or crash.
        # thecrew.trakt_refreshing_token is a mutex guard - if it was left set it causes
        # every subsequent Trakt call to spin-wait 30 seconds before timing out.
        import xbmcgui as _xbmcgui
        _win = _xbmcgui.Window(10000)
        _win.clearProperty('thecrew.trakt_refreshing_token')
        _win.clearProperty('thecrew.trakt_auth_failed')
        _win.clearProperty('thecrew.trakt_auth_notified')
        _win.clearProperty('thecrew.trakt_token_logged')
        if c.devmode:
            c.log('[TraktMonitor] Cleared stale Trakt window properties')

        # Flush any scrobbles that were queued before Kodi was closed last time
        try:
            trakt.process_scrobble_queue()
            if c.devmode:
                c.log('[TraktMonitor] Processed startup scrobble queue')
        except Exception as e:
            c.log(f'[TraktMonitor] Error processing startup scrobble queue: {e}')

        # Counter for scrobble queue processing (every 5 minutes)
        scrobble_counter = 0

        # Counter for Trakt token proactive refresh (every hour)
        token_check_counter = 0

        # Counter for scheduled Trakt sync (based on user setting)
        trakt_sync_counter = 0
        trakt_sync_interval = int(control.setting('schedTraktTime')) * 3600  # Convert hours to seconds

        if c.devmode and trakt_sync_interval > 0:
            c.log(f'[TraktMonitor] Scheduled Trakt sync enabled: every {trakt_sync_interval // 3600} hours')

        while not self.abortRequested():
            # Wait for 1 minute intervals to check scrobble queue more frequently
            if self.waitForAbort(60):
                break

            scrobble_counter += 60
            trakt_sync_counter += 60
            token_check_counter += 60

            # Proactively check and refresh Trakt token every hour
            # This keeps the token alive even when Kodi is idle
            if token_check_counter >= HOURLY:
                try:
                    trakt.check_and_refresh_token()
                except Exception as e:
                    c.log(f'[TraktMonitor] Error in proactive token check: {e}')
                token_check_counter = 0

            # Process scrobble queue every 5 minutes
            if scrobble_counter >= FIVE_MINUTES:
                if c.devmode:
                    c.log('[TraktMonitor] Processing scrobble queue')
                try:
                    trakt.process_scrobble_queue()
                except Exception as e:
                    c.log(f'[TraktMonitor] Error processing scrobble queue: {e}')
                scrobble_counter = 0

            # Scheduled Trakt sync if enabled
            if trakt_sync_interval > 0 and trakt_sync_counter >= trakt_sync_interval:
                if c.devmode:
                    c.log(f'[TraktMonitor] Running scheduled Trakt sync (every {trakt_sync_interval // 3600} hours)')
                try:
                    syncTrakt()
                    syncTraktLibrary()
                except Exception as e:
                    c.log(f'[TraktMonitor] Error in scheduled Trakt sync: {e}')
                trakt_sync_counter = 0

        # Process remaining queue items before exit
        if c.devmode:
            c.log('[TraktMonitor] Processing final scrobble queue before exit')
        try:
            trakt.process_scrobble_queue()
        except Exception as e:
            c.log(f'[TraktMonitor] Error processing final scrobble queue: {e}')

        if c.devmode:
            c.log('[TraktMonitor] Service finished')
        xbmc.log('[ plugin.video.thecrew ] TraktMonitor Service Finished', 2)

# v22.26: Module-level shutdown event for worker thread
# CRITICAL: Must be module-level so it survives instance deletion during module reloads
# Worker thread checks this instead of self.abortRequested() to avoid thread death from deleted instance
_worker_shutdown_event = threading.Event()

class CrewMonitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.crew_player = None  # Will hold global crewPlayer instance

        # v22.26: ZERO-THREAD-GROWTH - Simple dict-based approach
        # ONE worker thread polls a persistent dict for episode data
        # Initialize episode counter from previous instance if it exists
        old_instance = getattr(queue, '_thecrew_crewmonitor_singleton', None)
        self.episodes_processed = old_instance.episodes_processed if old_instance else 0

        # Store reference globally
        global _crewmonitor_instance
        _crewmonitor_instance = self
        setattr(queue, '_thecrew_crewmonitor_singleton', self)

        # Initialize upnext flag (using Window properties for cross-addon communication)
        if not control.window.getProperty('thecrew.upnext.ready'):
            control.window.setProperty('thecrew.upnext.ready', 'true')
            if c.devmode:
                c.log("[CrewMonitor] Initialized upnext window properties")

        self.startServices()

    @classmethod
    def get_or_create_instance(cls):
        """Always create new instance - worker thread persists independently."""
        if c.devmode:
            c.log("[CrewMonitor] Creating instance")
        return cls()

    def _persistent_monitoring_worker(self):
        """
        v22.26: Simple Window property-polling approach.

        ONE worker thread for ENTIRE Kodi session:
        - Polls thecrew.upnext.active Window property every second
        - When property is 'true': monitor playback and trigger UpNext
        - Thread persists across module reloads (non-daemon)
        - Only exits when Kodi shuts down
        """
        c.log("[CrewMonitor-Worker] UpNext monitoring started")
        if c.devmode:
            c.log("[CrewMonitor-Worker] Polling window properties for episode triggers")

        import time
        episodes_handled = 0

        global _worker_shutdown_event
        while not _worker_shutdown_event.is_set():
            try:
                # Poll the upnext window property
                upnext_active = control.window.getProperty('thecrew.upnext.active')

                # Check if flag is 'true'
                if upnext_active == 'true':
                    episodes_handled += 1

                    # Get metadata from window properties
                    title = control.window.getProperty('thecrew.upnext.title')
                    year = control.window.getProperty('thecrew.upnext.year')
                    season = control.window.getProperty('thecrew.upnext.season')
                    episode = control.window.getProperty('thecrew.upnext.episode')
                    imdb = control.window.getProperty('thecrew.upnext.imdb')
                    tmdb = control.window.getProperty('thecrew.upnext.tmdb')

                    c.log(f"[CrewMonitor-Worker] Episode {episodes_handled}: {title} S{season}E{episode}")

                    # Get player instance
                    player = xbmc.Player()

                    # Wait for playback to start (up to 240 seconds)
                    if c.devmode:
                        c.log(f"[CrewMonitor-Worker] Waiting for playback to start...")
                    for _ in range(240):
                        if player.isPlayingVideo():
                            break
                        time.sleep(1)

                    if not player.isPlayingVideo():
                        c.log(f"[CrewMonitor-Worker] ⚠ Playback timeout for episode {episodes_handled}")
                        control.window.clearProperty('thecrew.upnext.active')
                        continue

                    if c.devmode:
                        c.log(f"[CrewMonitor-Worker] Playback active, monitoring for UpNext trigger")
                    upnext_triggered = False

                    # Monitor while playing
                    while player.isPlayingVideo():
                        try:
                            totalTime = player.getTotalTime()
                            currentTime = player.getTime()

                            # Guard against invalid times
                            if totalTime <= 0:
                                time.sleep(2)
                                continue

                            # Calculate percentage
                            percent = currentTime / totalTime

                            # Trigger UpNext at 92% (or user preference if available)
                            trigger_percent = 0.92  # Default
                            if not upnext_triggered and percent >= trigger_percent:
                                # v22.26.12: Skip UpNext if TV Evening is controlling the playlist
                                tv_evening_active = control.window.getProperty('thecrew.tvevening.monitor.active') == 'true'
                                if tv_evening_active:
                                    if c.devmode:
                                        c.log(f"[CrewMonitor-Worker] Skipping UpNext - TV Evening playlist is active")
                                    upnext_triggered = True  # Mark as triggered to prevent repeated checks
                                    continue

                                if c.devmode:
                                    c.log(f"[CrewMonitor-Worker] UpNext trigger at {percent*100:.1f}% ({currentTime:.0f}s/{totalTime:.0f}s)")
                                upnext_triggered = True

                                # Trigger actual UpNext dialog
                                try:
                                    # Import from script.module.thecrew (not local resources)
                                    import sys
                                    import xbmcaddon
                                    crew_addon = xbmcaddon.Addon('script.module.thecrew')
                                    crew_path = crew_addon.getAddonInfo('path')
                                    lib_path = os.path.join(crew_path, 'lib')
                                    if lib_path not in sys.path:
                                        sys.path.insert(0, lib_path)

                                    from resources.lib.modules import upnext
                                    if c.devmode:
                                        c.log(f"[CrewMonitor-Worker] Showing UpNext dialog for {title} S{season}E{episode}")
                                    # Pass current episode metadata - upnext will calculate next episode
                                    result = upnext.show_upnext_dialog(
                                        current_title=title,
                                        current_year=year,
                                        current_imdb=imdb,
                                        current_tmdb=tmdb,
                                        current_season=int(season),
                                        current_episode=int(episode)
                                    )
                                    if c.devmode:
                                        c.log(f"[CrewMonitor-Worker] UpNext result: {result}")
                                except Exception as e:
                                    c.log(f"[CrewMonitor-Worker] ⚠ UpNext error: {e}")
                                    if c.devmode:
                                        import traceback
                                        c.log(f"[CrewMonitor-Worker] Traceback: {traceback.format_exc()}")

                            time.sleep(2)

                        except Exception as e:
                            c.log(f"[CrewMonitor-Worker] ⚠ Error checking playback: {e}")
                            break

                    # Playback ended, clear all properties
                    control.window.clearProperty('thecrew.upnext.active')
                    control.window.clearProperty('thecrew.upnext.title')
                    control.window.clearProperty('thecrew.upnext.year')
                    control.window.clearProperty('thecrew.upnext.season')
                    control.window.clearProperty('thecrew.upnext.episode')
                    control.window.clearProperty('thecrew.upnext.imdb')
                    control.window.clearProperty('thecrew.upnext.tmdb')
                    if c.devmode:
                        c.log(f"[CrewMonitor-Worker] Episode {episodes_handled} finished")
                else:
                    # Property not active — check for widget refresh requests from
                    # background populate threads (they can't call executebuiltin safely).
                    if control.window.getProperty('crew.widget.needs_refresh'):
                        refresh_url = control.window.getProperty('crew.widget.refresh_url') or ''
                        control.window.clearProperty('crew.widget.needs_refresh')
                        control.window.clearProperty('crew.widget.refresh_url')
                        # Flag the next plugin run as a widget-context refresh so
                        # is_widget_listing() can correctly return True even though
                        # Container.PluginName now contains the plugin name.
                        control.window.setProperty('crew.widget.context', '1')
                        if refresh_url:
                            c.log(f"[CrewMonitor-Worker] Widget refresh requested - calling Container.Refresh({refresh_url})")
                            xbmc.executebuiltin(f'Container.Refresh({refresh_url})')
                        else:
                            c.log("[CrewMonitor-Worker] Widget refresh requested - calling Container.Refresh")
                            xbmc.executebuiltin('Container.Refresh')
                    time.sleep(1)

            except Exception as e:
                c.log(f"[CrewMonitor-Worker] ✗ Error: {e}")
                if c.devmode:
                    import traceback
                    c.log(f"[CrewMonitor-Worker] Traceback: {traceback.format_exc()}")
                time.sleep(1)

        c.log(f"[CrewMonitor-Worker] Shutdown (handled {episodes_handled} episodes)")

    def __del__(self):
        c.log('[CrewMonitor] Instance being deleted (module reload)')
        # v22.26: Do NOT send poison pill - let worker thread survive for reuse!
        # The worker thread should persist across module reloads so we can find and reuse it.
        # Old behavior: self.episode_queue.put(None) would kill the thread, preventing reuse
        #stopping threads is highly unrecommended due to the nature.
        #It is better to let the (a) thread(s) die on their own
        if self.crew_player:
            del self.crew_player
        del self

    def startServices(self):
        xbmc.log('[script.module.thecrew][CrewMonitor] Service Starting', 2)
        Thread(target=TraktMonitor().run).start()

        # v22.26: Start persistent monitoring worker thread
        # ONLY start if not already running (check global flag)
        if not hasattr(queue, '_thecrew_worker_started'):
            worker_thread = threading.Thread(
                target=self._persistent_monitoring_worker,
                name="CrewMonitor-Worker",
                daemon=False  # Must survive module reloads
            )
            worker_thread.start()
            setattr(queue, '_thecrew_worker_started', True)
            if c.devmode:
                c.log("[CrewMonitor] Started persistent monitoring worker")
        else:
            if c.devmode:
                c.log("[CrewMonitor] Worker thread already running")

        # Create global crewPlayer instance to monitor all playback
        # This enables TV Evening database-backed playlist monitoring
        try:
            # Import from script.module.thecrew (not local resources)
            import sys
            import xbmcaddon
            crew_addon = xbmcaddon.Addon('script.module.thecrew')
            crew_path = crew_addon.getAddonInfo('path')
            lib_path = os.path.join(crew_path, 'lib')
            if lib_path not in sys.path:
                sys.path.insert(0, lib_path)

            from resources.lib.modules.player import player as crewPlayer, register_global_player
            self.crew_player = crewPlayer()
            register_global_player(self.crew_player)  # v22: Register for use by sources.py
            xbmc.log('[script.module.thecrew][CrewMonitor] Global crewPlayer instance created and registered', xbmc.LOGINFO)
        except Exception as e:
            import traceback
            xbmc.log(f'[script.module.thecrew][CrewMonitor] Error creating global crewPlayer: {e}', xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)














control.execute('RunPlugin(plugin://%s)' % control.get_plugin_url({'action': 'service'}))

# v22.26: Module-level monitor reference so player.py can access the episode queue
# Instance is actually managed via CrewMonitor.get_or_create_instance()
monitor = None
_crewmonitor_instance = None  # Will be set when get_or_create_instance() runs

def get_crew_monitor():
    """
    Get the CrewMonitor instance.
    Called from player.py to access the persistent monitoring queue.

    v22.26: Uses sys.modules hack - __main__ is registered as 'service' module,
    so when player.py imports service, it gets the same module instance.
    This allows direct access to _crewmonitor_instance across contexts.

    Returns CrewMonitor instance or None if not running.
    """
    global _crewmonitor_instance
    return _crewmonitor_instance

# v22.26: CROSS-CONTEXT BRIDGE - Force module contexts to merge
# Kodi loads service.py as a module (not __main__), so bridge it here
import sys
sys.modules['service'] = sys.modules[__name__]
if c.devmode:
    c.log(f"[Service] (ok) Cross-context bridge: {__name__} registered as 'service' module")

# Run main() to handle startup tasks (conversion, sync, maintenance, providers, version announcement)
# This must run BEFORE monitor creation to ensure all startup tasks complete
main()

# v22.26: Get or create singleton CrewMonitor instance
# Uses global registry in queue module (system module that survives reloads)
monitor = CrewMonitor.get_or_create_instance()
_crewmonitor_instance = monitor  # Update module-level reference too

# Note: No waitForAbort() here! Kodi manages service lifecycle.
# The CrewMonitor thread runs autonomously and checks abortRequested() internally.
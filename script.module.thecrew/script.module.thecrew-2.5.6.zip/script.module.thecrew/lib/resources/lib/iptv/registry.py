# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file registry.py
* @package script.module.thecrew
*
* IPTV Provider Registry and Discovery
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import os
import importlib
from ..modules.crewruntime import c


def discover_providers():
    """
    Discover and load all IPTV providers from the providers directory.

    Automatically imports all .py files in lib/resources/lib/iptv/providers/
    which triggers provider registration in BaseIPTVProvider._providers

    Returns:
        List of provider instances
    """
    try:
        c.log('[IPTV] Discovering providers...')

        # Get providers directory path
        providers_dir = os.path.join(
            os.path.dirname(__file__),
            'providers'
        )

        if not os.path.exists(providers_dir):
            c.log(f'[IPTV] Providers directory not found: {providers_dir}')
            return []

        # Import all provider modules
        provider_count = 0
        for filename in os.listdir(providers_dir):
            if filename.endswith('.py') and not filename.startswith('__'):
                module_name = filename[:-3]  # Remove .py extension

                try:
                    # Import the provider module (triggers registration)
                    importlib.import_module(f'.providers.{module_name}', package='resources.lib.iptv')
                    provider_count += 1
                    c.log(f'[IPTV] Loaded provider module: {module_name}')

                except Exception as e:
                    c.log(f'[IPTV] Failed to load provider {module_name}: {e}')

        # Get all registered providers from base class
        from .base import BaseIPTVProvider
        all_providers = BaseIPTVProvider.get_all_providers()

        c.log(f'[IPTV] Discovery complete: {provider_count} modules loaded, {len(all_providers)} providers registered')

        # Log provider summary
        for provider in sorted(all_providers, key=lambda p: p.priority):
            status = '(OK) ENABLED' if provider.enabled else '(X) DISABLED'
            geo = f' [GEO: {provider.geo_region}]' if provider.geo_blocked else ''
            c.log(f'[IPTV]   {status} {provider.title} (priority={provider.priority}){geo}')

        return all_providers

    except Exception as e:
        c.log(f'[IPTV] Provider discovery failed: {e}')
        import traceback
        c.log(traceback.format_exc())
        return []


def get_provider(name):
    """
    Get a specific provider by name.

    Args:
        name: Provider name (e.g., 'ustream', 'yoursports')

    Returns:
        Provider instance or None
    """
    from .base import BaseIPTVProvider
    return BaseIPTVProvider.get_provider(name)


def get_all_providers():
    """
    Get all registered providers.

    Returns:
        List of all provider instances
    """
    from .base import BaseIPTVProvider
    return BaseIPTVProvider.get_all_providers()


def get_enabled_providers():
    """
    Get only enabled providers, sorted by priority.

    Returns:
        List of enabled provider instances (sorted)
    """
    from .base import BaseIPTVProvider
    return BaseIPTVProvider.get_enabled_providers()


def get_all_channels():
    """
    Get channels from all enabled providers.

    Returns:
        List of channel dicts with 'provider' key added
    """
    channels = []

    for provider in get_enabled_providers():
        try:
            c.log(f'[IPTV] Getting channels from {provider.title}...')
            provider_channels = provider.get_channels()

            if not provider_channels:
                c.log(f'[IPTV] {provider.title} returned no channels')
                continue

            # Add provider metadata to each channel
            for channel in provider_channels:
                channel['provider'] = provider.name
                channel['provider_title'] = provider.title

            channels.extend(provider_channels)
            c.log(f'[IPTV] {provider.title} contributed {len(provider_channels)} channels')

        except NotImplementedError:
            c.log(f'[IPTV] {provider.title} has not implemented get_channels()')
        except Exception as e:
            c.log(f'[IPTV] Error getting channels from {provider.title}: {e}')

    c.log(f'[IPTV] Total channels from all providers: {len(channels)}')
    return channels


def resolve_stream(provider_name, url):
    """
    Resolve a channel URL using the specified provider.

    Args:
        provider_name: Provider name
        url: Channel URL

    Returns:
        Playable stream URL or None
    """
    provider = get_provider(provider_name)

    if not provider:
        c.log(f'[IPTV] Provider not found: {provider_name}')
        return None

    if not provider.enabled:
        c.log(f'[IPTV] Provider disabled: {provider_name}')
        return None

    try:
        c.log(f'[IPTV] Resolving stream with {provider.title}...')
        stream_url = provider.resolve_stream(url)

        if stream_url:
            c.log(f'[IPTV] (OK) Stream resolved: {stream_url[:80]}...')
        else:
            c.log(f'[IPTV] (X) Stream resolution failed')

        return stream_url

    except NotImplementedError:
        c.log(f'[IPTV] {provider.title} has not implemented resolve_stream()')
        return None
    except Exception as e:
        c.log(f'[IPTV] Error resolving stream with {provider.title}: {e}')
        import traceback
        c.log(traceback.format_exc())
        return None

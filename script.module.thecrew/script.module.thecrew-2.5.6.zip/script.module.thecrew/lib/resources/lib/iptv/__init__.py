# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @package script.module.thecrew
* IPTV Provider System
*
* Modern provider-based IPTV architecture
* Replaces legacy XML-based dynamic code execution
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

from .base import BaseIPTVProvider
from .registry import get_provider, get_all_providers, discover_providers

__all__ = ['BaseIPTVProvider', 'get_provider', 'get_all_providers', 'discover_providers']

# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file base.py
* @package script.module.thecrew
*
* Base class for IPTV providers
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import re
from ..modules import client
from ..modules.crewruntime import c


class BaseIPTVProvider:
    """
    Base class for IPTV channel providers.

    Providers inherit from this class and implement:
    - get_channels(): Return list of available channels
    - resolve_stream(url): Resolve channel URL to playable stream
    """

    # Class-level registry of all provider instances
    _providers = {}

    # Provider metadata (override in subclass)
    name = "base"               # Unique identifier (lowercase, no spaces)
    title = "Base Provider"     # Display name
    enabled = True              # Whether provider is active
    priority = 50               # Lower = higher priority (0-100)

    # Geographic restrictions
    geo_blocked = False         # Whether content is geo-restricted
    geo_region = None           # Region code (e.g., 'US', 'UK', 'EU')

    # Capabilities
    supports_search = False     # Whether provider supports search
    supports_categories = False # Whether provider has categories

    def __init__(self):
        """Initialize provider and register in global registry"""
        # Register this provider instance
        BaseIPTVProvider._providers[self.name] = self
        c.log(f'[IPTV] Registered provider: {self.title} ({self.name})')

    @classmethod
    def get_provider(cls, name):
        """Get a registered provider by name"""
        return cls._providers.get(name)

    @classmethod
    def get_all_providers(cls):
        """Get all registered providers"""
        return list(cls._providers.values())

    @classmethod
    def get_enabled_providers(cls):
        """Get only enabled providers, sorted by priority"""
        enabled = [p for p in cls._providers.values() if p.enabled]
        return sorted(enabled, key=lambda p: p.priority)

    def get_channels(self):
        """
        Get list of available channels from this provider.

        Returns:
            List of dicts with keys:
                - title: Channel name (str)
                - url: Channel URL or identifier (str)
                - icon: Channel icon URL (str, optional)
                - plot: Channel description (str, optional)

        Raises:
            NotImplementedError: If subclass doesn't implement this
        """
        raise NotImplementedError(f'{self.title} must implement get_channels()')

    def resolve_stream(self, url):
        """
        Resolve a channel URL to a playable stream URL.

        Args:
            url: Channel URL or identifier from get_channels()

        Returns:
            Playable stream URL (str) or None if resolution fails
            Can include headers: 'http://stream.m3u8|User-Agent=...'

        Raises:
            NotImplementedError: If subclass doesn't implement this
        """
        raise NotImplementedError(f'{self.title} must implement resolve_stream()')

    def get_categories(self):
        """
        Get channel categories (if supported).

        Returns:
            List of dicts with keys:
                - title: Category name
                - url: Category URL/identifier
        """
        return []

    def search(self, keyword):
        """
        Search for channels by keyword (if supported).

        Args:
            keyword: Search term

        Returns:
            List of channel dicts (same format as get_channels())
        """
        return []

    def _safe_request(self, url, timeout=10, headers=None):
        """
        Wrapper around client.request() with error handling.

        Args:
            url: URL to request
            timeout: Request timeout in seconds
            headers: Optional headers dict

        Returns:
            Response body (str) or None on failure
        """
        try:
            c.log(f'[IPTV.{self.name}] Requesting: {url[:80]}...')
            response = client.request(url, timeout=str(timeout), headers=headers, redirect=True, verify=True, error=True)

            # If error=True, response might be an HTTPError object
            if hasattr(response, 'code'):
                c.log(f'[IPTV.{self.name}] (X) HTTP Error {response.code}: {getattr(response, "reason", "Unknown")}')
                return None

            if response is None:
                c.log(f'[IPTV.{self.name}] (X) Request returned None (network error or blocked)')
                return None

            if not response:
                c.log(f'[IPTV.{self.name}] (X) Request returned empty string')
                return None

            c.log(f'[IPTV.{self.name}] (OK) Request successful ({len(response)} bytes)')
            return response

        except Exception as e:
            c.log(f'[IPTV.{self.name}] (X) Request exception: {e}')
            return None

    def _extract_iframe_src(self, html):
        """
        Extract iframe src from HTML.

        Args:
            html: HTML content

        Returns:
            Iframe src URL or None
        """
        if not html:
            return None

        match = re.search(r'<iframe[^>]*src=["\']([^"\']+)["\']', html, re.IGNORECASE)
        if match:
            return match.group(1)

        return None

    def _extract_m3u8_url(self, content):
        """
        Extract m3u8 URL from content.

        Args:
            content: HTML or JS content

        Returns:
            m3u8 URL or None
        """
        if not content:
            return None

        # Common m3u8 patterns
        patterns = [
            r'https?://[^\s"\'>]+\.m3u8[^\s"\'>]*',
            r'["\']([^"\']*\.m3u8[^"\']*)["\']',
            r'file\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
        ]

        for pattern in patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                url = match.group(1) if match.lastindex else match.group(0)
                c.log(f'[IPTV.{self.name}] Found m3u8 URL: {url[:80]}...')
                return url

        return None

    def _build_stream_url(self, url, user_agent=None, referer=None):
        """
        Build stream URL with headers appended.

        Args:
            url: Base stream URL
            user_agent: Optional User-Agent header
            referer: Optional Referer header

        Returns:
            URL with headers appended (Kodi format)
        """
        if not url:
            return None

        headers = []

        if user_agent:
            headers.append(f'User-Agent={user_agent}')

        if referer:
            headers.append(f'Referer={referer}')

        if headers:
            return f'{url}|{"&".join(headers)}'

        return url

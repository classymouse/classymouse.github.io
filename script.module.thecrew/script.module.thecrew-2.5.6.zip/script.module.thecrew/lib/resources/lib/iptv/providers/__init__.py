# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* IPTV Providers Package
*
* Individual provider implementations
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

# Provider modules are auto-discovered by registry.discover_providers()
# No explicit imports needed here

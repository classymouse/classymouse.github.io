# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file ustvnow.py
* @package script.module.thecrew
*
* USTVNow Free Channels Provider
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import re
import json
import uuid
from urllib.parse import quote_plus
from ..base import BaseIPTVProvider
from ...modules.crewruntime import c
from ...modules.http_client import HTTPClient
from ...modules import client


class USTVNowProvider(BaseIPTVProvider):
    """
    Provider for USTVNow free channels.

    Free FAST (Free Ad-Supported Streaming TV) channels and
    Free LIVE channels from https://www.ustvnow.com/freetowatch
    """

    name = "ustvnow"
    title = "USTVNow Free"
    enabled = True  # Enable by default
    priority = 40   # Medium priority

    geo_blocked = True   # US geo-blocked
    geo_region = 'US'
    supports_categories = True  # FAST vs LIVE channels

    base_url = "https://www.ustvnow.com"
    free_url = f"{base_url}/freetowatch"
    api_base = "https://teleupapi.revlet.net/service/api/v1"
    api_url = f"{api_base}/page/content"

    def get_channels(self):
        """Get list of free FAST and LIVE channels from USTVNow"""
        try:
            c.log(f'[IPTV.{self.name}] Fetching channel list from API')

            # Create a session to maintain cookies across requests
            session = HTTPClient.get_session(api_type='ustvnow')

            # Generate fresh UUIDs for box-id and session-id
            # The API seems to accept any valid UUIDs (mimics browser behavior)
            box_id = str(uuid.uuid4())
            session_id = str(uuid.uuid4())

            c.log(f'[IPTV.{self.name}] Generated box-id: {box_id}')
            c.log(f'[IPTV.{self.name}] Generated session-id: {session_id}')

            # Common headers for all API requests
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
                'Referer': f'{self.base_url}/',
                'Origin': self.base_url,
                'Accept': 'application/json, text/plain, */*',
                'box-id': box_id,
                'session-id': session_id,
                'tenant-code': 'ustvnow',
            }

            # Step 1: Initialize session by calling /system/config
            config_url = f"{self.api_base}/system/config"
            c.log(f'[IPTV.{self.name}] Initializing session: {config_url}')

            try:
                config_response = session.get(config_url, headers=headers, timeout=15)
                config_response.raise_for_status()
                c.log(f'[IPTV.{self.name}] (OK) Session initialized ({len(config_response.text)} bytes)')
                c.log(f'[IPTV.{self.name}] Config response: {config_response.text[:500]}')

                # Check if config call succeeded
                try:
                    config_data = config_response.json()
                    if not config_data.get('status', False):
                        c.log(f'[IPTV.{self.name}] Config initialization failed: {config_response.text}')
                        c.log(f'[IPTV.{self.name}] Falling back to static channel list')
                        return self._get_static_channels()
                except:
                    pass

            except Exception as e:
                c.log(f'[IPTV.{self.name}] Failed to initialize session: {e}')
                c.log(f'[IPTV.{self.name}] Falling back to static channel list')
                return self._get_static_channels()

            # Step 2: Now fetch the channel content with the same headers
            api_url = f"{self.api_url}?path=freetowatch&count=40"
            c.log(f'[IPTV.{self.name}] Fetching channels: {api_url}')

            try:
                api_response = session.get(api_url, headers=headers, timeout=15)
                api_response.raise_for_status()

                c.log(f'[IPTV.{self.name}] (OK) API request successful ({len(api_response.text)} bytes)')
                c.log(f'[IPTV.{self.name}] API response preview: {api_response.text[:200]}')

                # Parse the JSON response
                data = api_response.json()
                channels = self._parse_api_response(data)
                c.log(f'[IPTV.{self.name}] Found {len(channels)} channels from API')
                return channels

            except Exception as e:
                c.log(f'[IPTV.{self.name}] API request failed: {e}')
                if hasattr(api_response, 'text'):
                    c.log(f'[IPTV.{self.name}] Response: {api_response.text[:500]}')
                return []

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            c.log(f'[IPTV.{self.name}] Falling back to static channel list')
            return self._get_static_channels()

    def _parse_api_response(self, data):
        """Parse the API response to extract channel information"""
        channels = []

        try:
            # USTVNow structure: response.data -> array of sections -> section.sectionData.data
            if not isinstance(data, dict):
                c.log(f'[IPTV.{self.name}] Invalid API response: not a dict')
                return []

            # Check for status
            if not data.get('status'):
                c.log(f'[IPTV.{self.name}] API returned status=false')
                return []

            # Get response wrapper
            response = data.get('response', {})
            if not response:
                c.log(f'[IPTV.{self.name}] No response object in API data')
                return []

            sections = response.get('data', [])
            c.log(f'[IPTV.{self.name}] Found {len(sections)} sections in response')

            for section in sections:
                try:
                    pane_type = section.get('paneType')
                    content_code = section.get('contentCode', '')

                    # We want FAST channels and Free LIVE channels (skip movie sections)
                    if pane_type != 'section':
                        continue

                    # Only process live channel sections
                    if content_code not in ['fast_channels', 'free_live_channels']:
                        c.log(f'[IPTV.{self.name}] Skipping non-live section: {content_code}')
                        continue

                    section_data = section.get('section', {}).get('sectionData', {})
                    section_name = section.get('section', {}).get('sectionInfo', {}).get('name', content_code)
                    channel_items = section_data.get('data', [])

                    c.log(f'[IPTV.{self.name}] Section "{section_name}" ({content_code}): {len(channel_items)} items')

                    # Parse each channel in this section
                    for item in channel_items:
                        channel = self._parse_channel_item(item, section_name)
                        if channel:
                            channels.append(channel)

                except Exception as e:
                    c.log(f'[IPTV.{self.name}] Error parsing section: {e}')
                    continue

            c.log(f'[IPTV.{self.name}] Total channels parsed: {len(channels)}')

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error parsing API response: {e}')
            import traceback
            c.log(traceback.format_exc())

        return channels

    def _parse_channel_item(self, item, section_name=''):
        """Parse a single channel item from the API"""
        try:
            # USTVNow structure
            display = item.get('display', {})
            target = item.get('target', {})
            metadata = item.get('metadata', {})

            # Skip non-EPG items (movies, etc)
            content_type = metadata.get('contentType', {}).get('value', '')
            if content_type != 'epg':
                return None

            # Get channel info
            # display.title = current program name
            # display.parentName = actual channel name
            program_title = display.get('title', '')
            channel_name = display.get('parentName', '')

            # Use channel name as main title, with program as subtitle
            if channel_name:
                title = channel_name
                if program_title and program_title != channel_name:
                    title = f"{channel_name} - {program_title}"
            else:
                title = program_title

            if not title:
                return None

            # Get channel path/URL
            path = target.get('path', '')
            if not path:
                return None

            # Build full URL
            channel_url = f"{self.base_url}/{path.lstrip('/')}"

            # Get thumbnail - handle different formats
            icon = display.get('imageUrl', '')
            parent_icon = display.get('parentIcon', '') or icon

            # Use parent icon (channel logo) if available
            if parent_icon:
                if parent_icon.startswith('gracenoteepg,'):
                    # Format: "gracenoteepg,assets/p23682091_b_h9_ab.jpg?w=360"
                    icon_path = parent_icon.split(',', 1)[1]
                    icon = f"https://tmsimg.com/{icon_path}"
                elif parent_icon.startswith('logo,'):
                    # Format: "logo,channel/logos/niihie.png"
                    icon_path = parent_icon.split(',', 1)[1]
                    icon = f"{self.base_url}/{icon_path.lstrip('/')}"
                elif parent_icon.startswith('common,'):
                    # Format: "common,movie/images/nqbudi.jpeg"
                    icon_path = parent_icon.split(',', 1)[1]
                    icon = f"{self.base_url}/{icon_path.lstrip('/')}"
                elif not parent_icon.startswith('http'):
                    icon = f"{self.base_url}/{parent_icon.lstrip('/')}"
                else:
                    icon = parent_icon
            elif icon:
                # Fallback to imageUrl if no parentIcon
                if icon.startswith('http'):
                    pass  # Already a full URL
                elif icon.startswith(('gracenoteepg,', 'logo,', 'common,')):
                    icon_path = icon.split(',', 1)[1] if ',' in icon else icon
                    if icon.startswith('gracenoteepg,'):
                        icon = f"https://tmsimg.com/{icon_path}"
                    else:
                        icon = f"{self.base_url}/{icon_path.lstrip('/')}"
                else:
                    icon = f"{self.base_url}/{icon.lstrip('/')}"

            # Get channel ID and code
            channel_id = metadata.get('id', {}).get('value', '')
            channel_code = metadata.get('code', {}).get('value', '')

            # Get channel ID from target.pageAttributes if available
            page_attrs = target.get('pageAttributes', {})
            if not channel_id and 'channelId' in page_attrs:
                channel_id = page_attrs.get('channelId', '')

            # Build plot/description
            plot_parts = []
            if section_name:
                plot_parts.append(section_name)
            if program_title and program_title != channel_name:
                plot_parts.append(f"Now: {program_title}")
            plot_parts.append('USTVNow Free')
            plot = ' | '.join(plot_parts)

            return {
                'title': title,
                'url': channel_url,
                'icon': icon,
                'plot': plot,
                'channel_id': channel_id,
                'channel_code': channel_code,
                'program': program_title,
                'channel': channel_name,
                'path': path,  # Store path for stream resolution
            }
        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error parsing channel item: {e}')
            import traceback
            c.log(traceback.format_exc())

        return None

    def _get_static_channels(self):
        """
        Fallback static channel list for when API is unavailable.
        Since streams use Amagi CDN without authentication, we can provide
        a basic channel list even when the API fails.
        """
        c.log(f'[IPTV.{self.name}] Using static fallback channel list')

        # Static list of known working channels (verified yesterday)
        # Format: (name, slug, category)
        static_channels = [
            ('Surfer', 'surfer', 'FAST Channels'),
            ('Judge Nosey', 'judge-nosey', 'FAST Channels'),
            ('Slick Slime Sam', 'slick-slime-sam', 'FAST Channels'),
            ('Smart Healthy Green Living', 'smart-healthy-green-living', 'FAST Channels'),
            ('NTD TV', 'ntd-tv', 'FAST Channels'),
            ('Reuters Now', 'reuters-now', 'FAST Channels'),
            ('Introuble', 'introuble', 'FAST Channels'),
            ('Gusto Espanol', 'gusto-espanol', 'FAST Channels'),
            ('InFast Lifestyle', 'infast---lifestyle--', 'FAST Channels'),
        ]

        channels = []
        for name, slug, category in static_channels:
            channel = {
                'id': f'ustvnow_{slug}',
                'title': name,
                'name': name,
                'url': f'{self.base_url}/channel/live/{slug}',
                'icon': '',  # No icon in static list
                'fanart': '',
                'category': category,
                'provider': self.name,
                'type': 'live'
            }
            channels.append(channel)

        c.log(f'[IPTV.{self.name}] Returning {len(channels)} static channels')
        return channels


    def resolve_stream(self, url):
        """Resolve channel URL to playable stream using Amagi CDN"""
        try:
            c.log(f'[IPTV.{self.name}] Resolving stream: {url}')

            # If it's already a direct stream URL (m3u8, etc), return it
            if any(ext in url.lower() for ext in ['.m3u8', '.ts', '.mpd']):
                return self._build_stream_url(url, referer=self.base_url)

            # Extract channel slug from URL
            # URL format: https://www.ustvnow.com/channel/live/surfer
            # Extract "surfer" from path
            path_parts = url.replace(self.base_url, '').strip('/').split('/')
            if len(path_parts) >= 3 and path_parts[0] == 'channel' and path_parts[1] == 'live':
                channel_slug = path_parts[2]
                c.log(f'[IPTV.{self.name}] Channel slug: {channel_slug}')
            else:
                c.log(f'[IPTV.{self.name}] Invalid channel URL format')
                return None

            # Method 1: Try constructing Amagi CDN URL directly
            # USTVNow uses Amagi for streaming - URLs don't require authentication
            # Pattern: https://amg13231-actve-amg13231c4-teleup-international-1408.playouts.now.amagi.tv/playlist/amg13231-actvefast-{channel}-teleupinternational/playlist.m3u8
            stream_url = self._try_amagi_url(channel_slug, url)
            if stream_url:
                return stream_url

            # Method 2: Fallback to HTML scraping (extract m3u8 from page JavaScript)
            c.log(f'[IPTV.{self.name}] Amagi URL construction failed, trying HTML scraping')
            return self._resolve_stream_html(url)

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Resolve failed: {e}')
            import traceback
            c.log(traceback.format_exc())
            return None

    def _try_amagi_url(self, channel_slug, referer_url):
        """
        Try to construct Amagi CDN URL for the channel.
        USTVNow uses Amagi for streaming - URLs don't require authentication.

        Pattern: https://amg13231-actve-amg13231c4-teleup-international-1408.playouts.now.amagi.tv/playlist/amg13231-actvefast-{channel}-teleupinternational/playlist.m3u8
        """
        try:
            # Amagi URL pattern for USTVNow
            base_domain = "amg13231-actve-amg13231c4-teleup-international-1408.playouts.now.amagi.tv"
            playlist_id = f"amg13231-actvefast-{channel_slug}-teleupinternational"

            # Build the m3u8 URL
            stream_url = f"https://{base_domain}/playlist/{playlist_id}/playlist.m3u8"

            # Add standard query parameters (seen in browser)
            query_params = (
                "?app_bundle=USTVnow"
                "&app_name=USTVnow"
                "&app_store_url=https://www.ustvnow.com/"
                "&us_privacy=1YNN"
                "&dnt=0"
                "&gdpr=1"
                "&gdpr_consent=true"
                "&url=https://www.ustvnow.com/"
                "&ifa_type=0"
                "&content_livestream=0"
            )

            stream_url += query_params

            c.log(f'[IPTV.{self.name}] Constructed Amagi URL: {stream_url}')

            # Test if URL is accessible (HEAD request to check)
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Origin': self.base_url,
                'Referer': referer_url,
                'Accept': '*/*'
            }

            # Quick HEAD request to verify URL exists
            session = HTTPClient.get_session(api_type='ustvnow')
            try:
                test_response = session.head(stream_url, headers=headers, timeout=5)
                if test_response and test_response.status_code in [200, 302, 303]:
                    c.log(f'[IPTV.{self.name}] (OK) Amagi URL verified (status: {test_response.status_code})')
                else:
                    c.log(f'[IPTV.{self.name}] Amagi URL HEAD request returned: {test_response.status_code if test_response else "None"}')
                    c.log(f'[IPTV.{self.name}] Attempting to use URL anyway (HEAD requests might not be supported)')
            except Exception as e:
                c.log(f'[IPTV.{self.name}] Amagi URL HEAD request failed: {e}')
                c.log(f'[IPTV.{self.name}] Attempting to use URL anyway despite HEAD request failure')

            # Return the stream URL regardless of HEAD request result
            # The player will show a better error if the stream doesn't work
            return self._build_stream_url(stream_url, referer=referer_url)

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Amagi URL construction failed: {e}')
            return None

    def _resolve_stream_html(self, url):
        """Fallback HTML scraping method (original resolve_stream logic)"""
        try:
            c.log(f'[IPTV.{self.name}] Trying HTML scraping for: {url}')

            # Fetch the channel page with proper headers
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': self.free_url,
                'Origin': self.base_url,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            }

            html = self._safe_request(url, timeout=20, headers=headers)
            if not html:
                c.log(f'[IPTV.{self.name}] Failed to fetch channel page')
                return None

            # Look for embedded player URL, iframe, or video element
            stream_url = None

            # Method 1: Look for m3u8 in the HTML
            stream_url = self._extract_m3u8_url(html)
            if stream_url:
                c.log(f'[IPTV.{self.name}] Found m3u8 stream in page')
                if not stream_url.startswith('http'):
                    stream_url = self.base_url + stream_url if stream_url.startswith('/') else f"{self.base_url}/{stream_url}"
                return self._build_stream_url(stream_url, referer=url)

            # Method 2: Look for player API endpoint
            # Pattern: playerApiUrl, streamUrl, etc in JavaScript
            api_match = re.search(r'(?:streamUrl|playerUrl|videoUrl|mediaUrl)["\']?\s*:\s*["\']([^"\']+)["\']', html)
            if api_match:
                stream_url = api_match.group(1)
                c.log(f'[IPTV.{self.name}] Found stream URL in JS: {stream_url}')
                if not stream_url.startswith('http'):
                    stream_url = self.base_url + stream_url if stream_url.startswith('/') else f"{self.base_url}/{stream_url}"
                return self._build_stream_url(stream_url, referer=url)

            # Method 3: Look for iframe (Layer 2)
            iframe = self._extract_iframe_src(html)
            if iframe:
                c.log(f'[IPTV.{self.name}] Found iframe (Layer 2), fetching: {iframe}')
                if not iframe.startswith('http'):
                    iframe = self.base_url + iframe if iframe.startswith('/') else f"{self.base_url}/{iframe}"

                iframe_html = self._safe_request(iframe, timeout=15, headers={'Referer': url})
                if iframe_html:
                    stream_url = self._extract_m3u8_url(iframe_html)
                    if stream_url:
                        if not stream_url.startswith('http'):
                            # Try to build from iframe base
                            from urllib.parse import urljoin
                            stream_url = urljoin(iframe, stream_url)
                        c.log(f'[IPTV.{self.name}] Found m3u8 in iframe')
                        return self._build_stream_url(stream_url, referer=iframe)

            # Method 4: Look for video source tags
            video_src = re.search(r'<(?:source|video)[^>]*src=[\'"]([^\'\"]+)[\'"]', html)
            if video_src:
                stream_url = video_src.group(1)
                if not stream_url.startswith('http'):
                    stream_url = self.base_url + stream_url if stream_url.startswith('/') else f"{self.base_url}/{stream_url}"
                c.log(f'[IPTV.{self.name}] Found video source tag')
                return self._build_stream_url(stream_url, referer=url)

            # Method 5: Skip external resolver for IPTV providers
            # (external resolver/crewstreamer is for sports streaming sites, not IPTV)

            c.log(f'[IPTV.{self.name}] No stream found via HTML scraping')
            return None

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Resolve failed: {e}')
            import traceback
            c.log(traceback.format_exc())
            return None


    def _build_stream_url(self, url, referer=None):
        """
        Build stream URL with proper headers for playback.

        Args:
            url: Stream URL (m3u8, mpd, etc)
            referer: Referer header value

        Returns:
            str: URL with headers appended in Kodi format
        """
        if not url:
            return None

        # If URL is already a full URL, use it
        if not url.startswith('http'):
            # Try to make it absolute
            if url.startswith('/'):
                url = f"{self.base_url}{url}"
            else:
                url = f"{self.base_url}/{url}"

        # Build headers for stream playback
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }

        if referer:
            headers['Referer'] = referer

        # Kodi format: URL|Header1=value1&Header2=value2
        header_str = '&'.join([f'{k}={v}' for k, v in headers.items()])
        return f'{url}|{header_str}'


# Auto-register on import
USTVNowProvider()

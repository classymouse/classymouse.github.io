# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file ustream.py
* @package script.module.thecrew
*
* UStream.to IPTV Provider
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import re
from ..base import BaseIPTVProvider
from ...modules.crewruntime import c


class UStreamProvider(BaseIPTVProvider):
    """
    Provider for ustream.to live channels.

    Note: This provider is often blocked by anti-bot measures.
    Disabled by default due to unreliability.
    """

    name = "ustream"
    title = "UStream.to"
    enabled = False  # Disabled by default (frequently blocked)
    priority = 80    # Low priority (unreliable)

    geo_blocked = False
    geo_region = None

    base_url = "https://www.ustream.to"
    channels_url = f"{base_url}/index.html"

    def get_channels(self):
        """Get list of live channels from ustream.to"""
        try:
            c.log(f'[IPTV.{self.name}] Fetching channel list from {self.channels_url}')

            # Request channel listing page
            html = self._safe_request(self.channels_url, timeout=15)

            if not html:
                c.log(f'[IPTV.{self.name}] Failed to fetch channel page (likely blocked)')
                return []

            # Extract channel links
            # Pattern: <a href="/channel-name-live">Channel Name</a>
            pattern = r'(?s)onmouseover="vidPlay(?:[^"]*)"(?:[^"]*)"(?:[^"]*)" href="([^"]*)(?:[^>]*)>([^<]*)'
            matches = re.findall(pattern, html)

            if not matches:
                c.log(f'[IPTV.{self.name}] No channels found (page structure may have changed)')
                return []

            # Filter for live channels only (URL contains '-live')
            channels = []
            for url_path, title in matches:
                if '-live' in url_path:
                    channel = {
                        'title': title.strip(),
                        'url': f'{self.base_url}{url_path}' if not url_path.startswith('http') else url_path,
                        'icon': '',
                        'plot': f'Live channel from {self.title}'
                    }
                    channels.append(channel)

            c.log(f'[IPTV.{self.name}] Found {len(channels)} live channels')
            return channels

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def resolve_stream(self, url):
        """
        Resolve ustream.to channel URL to playable stream.

        This is complex multi-step resolution:
        1. Get channel page
        2. Extract iframe src
        3. Get iframe content
        4. Unpack eval() obfuscated JavaScript
        5. Decode base64 stream URL
        6. Get final m3u8 URL

        Note: Often fails due to anti-bot measures.
        """
        try:
            c.log(f'[IPTV.{self.name}] Resolving stream for: {url}')

            # Step 1: Get channel page
            page_html = self._safe_request(url, timeout=15)
            if not page_html:
                return None

            # Step 2: Extract iframe src
            iframe_match = re.search(r'value=\'<iframe.*?src="([^"]*)', page_html)
            if not iframe_match:
                c.log(f'[IPTV.{self.name}] No iframe found on channel page')
                return None

            iframe_url = iframe_match.group(1)
            c.log(f'[IPTV.{self.name}] Found iframe: {iframe_url[:80]}...')

            # Step 3: Get iframe content
            iframe_html = self._safe_request(iframe_url, timeout=15)
            if not iframe_html:
                return None

            # Step 4: Look for eval() obfuscated code containing 'ustream'
            eval_match = re.search(r'(eval.*ustream.*)', iframe_html)
            if not eval_match:
                c.log(f'[IPTV.{self.name}] No eval code found in iframe')
                # Try direct m3u8 extraction as fallback
                m3u8_url = self._extract_m3u8_url(iframe_html)
                if m3u8_url:
                    return self._build_stream_url(
                        m3u8_url,
                        user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0',
                        referer='https://www.ustream.to/'
                    )
                return None

            # NOTE: Full JavaScript unpacking would require jsunpack module
            # For now, try direct m3u8 extraction
            c.log(f'[IPTV.{self.name}] Found obfuscated code (jsunpack required for full resolution)')

            # Try simple m3u8 pattern match as fallback
            m3u8_url = self._extract_m3u8_url(iframe_html)
            if m3u8_url:
                return self._build_stream_url(
                    m3u8_url,
                    user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0',
                    referer='https://www.ustream.to/'
                )

            c.log(f'[IPTV.{self.name}] Could not extract stream URL (complex obfuscation)')
            return None

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Stream resolution failed: {e}')
            import traceback
            c.log(traceback.format_exc())
            return None


# Auto-register provider on module import
UStreamProvider()

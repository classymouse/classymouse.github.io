# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file daddylive.py
* @package script.module.thecrew
*
* DaddyLive IPTV Provider
*
* Scrapes 24/7 live channels from DaddyLive.
* Uses external config for URL (site changes domains frequently).
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import re
import requests
import urllib3

# Disable SSL warnings (needed for streaming sites with certificate issues)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ..base import BaseIPTVProvider
from ...modules import client, control
from ...modules.crewruntime import c


class DaddyLiveProvider(BaseIPTVProvider):
    """DaddyLive - Free 24/7 sports and entertainment channels"""

    # Provider metadata
    name = "daddylive"
    title = "DaddyLive"
    enabled = True
    priority = 25  # Medium priority

    # Capabilities
    supports_categories = False

    def __init__(self):
        super().__init__()
        # URL will be loaded from external config
        self.base_url = None

    def _get_config_url(self):
        """
        Load DaddyLive URL from external configuration.
        This allows updating the URL without addon updates.

        Priority:
        1. Local config file (editable by user)
        2. Remote config from GitHub (auto-updates)
        3. Hardcoded fallback

        Returns:
            str: Base URL for DaddyLive
        """
        import os

        try:
            # First try local config file
            # Use CrewRuntime to get addon path
            addon_path = c.addonInfo('path')
            local_config = os.path.join(addon_path, 'config', 'iptv', 'daddylive.txt')

            if os.path.exists(local_config):
                c.log(f'[IPTV.{self.name}] Loading config from local file: {local_config}')
                try:
                    with open(local_config, 'r', encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if line and not line.startswith('#'):
                                c.log(f'[IPTV.{self.name}] Loaded URL from local config: {line}')
                                return line
                except Exception as e:
                    c.log(f'[IPTV.{self.name}] Error reading local config: {e}')

            # Try remote config from GitHub
            config_url = 'https://raw.githubusercontent.com/classymouse/thecrew-config/main/iptv/daddylive.txt'

            c.log(f'[IPTV.{self.name}] Loading config from remote: {config_url}')
            response = self._safe_request(config_url, timeout=10)

            if response:
                # Config format: one URL per line, use first non-comment line
                for line in response.split('\n'):
                    line = line.strip()
                    if line and not line.startswith('#'):
                        c.log(f'[IPTV.{self.name}] Loaded URL from remote config: {line}')
                        return line

            # Fallback to default URL if all configs fail
            fallback = 'https://dlstreams.top'  # Use actual domain (daddyhd.com redirects here)
            c.log(f'[IPTV.{self.name}] All configs failed, using fallback: {fallback}')
            return fallback

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error loading config: {e}')
            import traceback
            c.log(traceback.format_exc())
            return 'https://dlstreams.top'  # Use actual domain

    def get_channels(self):
        """
        Scrape channel list from DaddyLive.

        Returns:
            List of dicts with channel information
        """
        c.log(f'[IPTV.{self.name}] Fetching channel list from {self.title}')

        try:
            # Get current base URL from config
            if not self.base_url:
                self.base_url = self._get_config_url()

            # Construct channels page URL
            channels_url = f'{self.base_url}/24-7-channels.php'

            c.log(f'[IPTV.{self.name}] Scraping: {channels_url}')

            # Fetch page
            response = self._safe_request(channels_url, timeout=15)
            if not response:
                c.log(f'[IPTV.{self.name}] Failed to fetch channel list')
                return []

            # Extract channel links using new regex pattern for current site structure
            # Current structure (as of 2026-03):
            # <a class="card" href="/watch.php?id=51" data-title="abc usa">
            #    <div class="card__title">ABC USA</div>
            #    <div class="">ID: 51</div>
            # </a>

            # Pattern matches: full href and <div class="card__title">NAME</div>
            # Capture the actual href instead of just the ID
            # More specific pattern to avoid matching navigation links
            # HTML structure: href="/watch.php?id=51" ... <div class="card__title">ABC USA</div>
            channel_matches = re.findall(
                r'href="(/watch\.php\?id=\d+)"[^>]*>[\s\S]*?<div class="card__title"[^>]*>([^<]+)</div>',
                response,
                re.DOTALL
            )

            channels = []

            # Filter out unwanted channels
            excluded = ['Polsat', 'Eleven Sports 1', 'Eleven Sports 2', 'Eleven Sports 3']

            for href, name in channel_matches:
                # Clean up name (decode HTML entities if needed)
                name = name.strip()
                name = name.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')

                # Skip excluded channels
                if any(exc in name for exc in excluded):
                    continue

                if not name or not href:
                    continue

                # Build full URL from captured href
                # Handle relative and absolute URLs
                if href.startswith('http'):
                    channel_url = href
                elif href.startswith('/'):
                    channel_url = f'{self.base_url}{href}'
                else:
                    channel_url = f'{self.base_url}/{href}'

                # Log first few URLs to see what we're getting
                if len(channels) < 5:
                    c.log(f'[IPTV.{self.name}] Sample URL: {channel_url}')

                channel_dict = {
                    'title': name,
                    'url': channel_url,
                    'icon': None,
                    'plot': f'{name} - DaddyLive 24/7 Channel',
                    'category': 'Live Channels'
                }

                channels.append(channel_dict)

            # Sort by channel name
            channels = sorted(channels, key=lambda x: x['title'])

            c.log(f'[IPTV.{self.name}] Successfully scraped {len(channels)} channels')
            return channels

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def get_menu(self):
        """
        Get main menu for DaddyLive provider.

        Returns menu with:
        - 24/7 Live Channels
        - Sports Schedule (upcoming events)
        """
        import sys
        from urllib.parse import quote_plus

        menu = [
            {
                'title': '[B][COLOR gold]24/7 Live Channels[/COLOR][/B]',
                'url': f"{sys.argv[0]}?action=iptv_channels&provider={quote_plus(self.name)}&section=channels",
                'plot': 'Watch 24/7 live sports and entertainment channels',
                'is_folder': True
            },
            {
                'title': '[B][COLOR gold]Sports Schedule[/COLOR][/B]',
                'url': f"{sys.argv[0]}?action=iptv_schedule&provider={quote_plus(self.name)}",
                'plot': 'Browse upcoming sports events by category',
                'is_folder': True
            }
        ]

        return menu

    def get_channels_by_section(self, section):
        """
        Get channels for a specific section.

        Args:
            section: Section name ('channels', 'schedule', etc.)

        Returns:
            List of channel dicts
        """
        if section == 'channels':
            # Return 24/7 channels
            return self.get_channels()
        else:
            c.log(f'[IPTV.{self.name}] Unknown section: {section}')
            return []

    def get_schedule_categories(self):
        """
        Get sports schedule categories from DaddyLive.

        Scrapes from /index.php to get filter categories.
        """
        c.log(f'[IPTV.{self.name}] Fetching schedule categories')

        try:
            if not self.base_url:
                self.base_url = self._get_config_url()

            schedule_url = f'{self.base_url}/index.php'
            html = self._safe_request(schedule_url, timeout=15)

            if not html:
                c.log(f'[IPTV.{self.name}] Failed to fetch schedule page')
                return []

            # Look for the filters div
            filters_match = re.search(r'<div[^>]+class="filters"[^>]*>(.*?)</div>', html, re.IGNORECASE | re.DOTALL)
            if not filters_match:
                c.log(f'[IPTV.{self.name}] No filters block found')
                return []

            filters_html = filters_match.group(1)

            # Extract category links
            # Format: <a href="/index.php?cat=Football">Football</a>
            categories = []
            seen = set()

            for match in re.finditer(r'<a[^>]+href="[^"]*\?cat=([^"]+)"[^>]*>(.*?)</a>', filters_html, re.IGNORECASE | re.DOTALL):
                cat_name = match.group(1).strip()
                cat_title = match.group(2).strip()

                # HTML decode
                cat_title = cat_title.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')

                # Skip 'All' category
                if cat_name.lower() == 'all' or cat_title.lower() == 'all':
                    continue

                # Skip duplicates
                if cat_name in seen:
                    continue
                seen.add(cat_name)

                categories.append({
                    'name': cat_name,
                    'title': cat_title,
                    'plot': f'Browse {cat_title} events'
                })

            c.log(f'[IPTV.{self.name}] Found {len(categories)} schedule categories')
            return categories

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching schedule categories: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def get_schedule_events(self, category):
        """
        Get scheduled events for a category.

        Args:
            category: Category name (e.g., 'Football', 'Basketball')

        Returns:
            List of event dicts with time, title, and player channels
        """
        c.log(f'[IPTV.{self.name}] Fetching schedule events for category: {category}')

        try:
            if not self.base_url:
                self.base_url = self._get_config_url()

            from urllib.parse import quote_plus
            category_url = f'{self.base_url}/index.php?cat={quote_plus(category)}'
            html = self._safe_request(category_url, timeout=15)

            if not html:
                c.log(f'[IPTV.{self.name}] Failed to fetch category page')
                return []

            # Parse events from schedule__event divs
            # Format:
            #   <div class="schedule__event">
            #     <div class="schedule__eventHeader">
            #       <span class="schedule__time" data-time="14:00">14:00</span>
            #       <span class="schedule__eventTitle">Man Utd vs Arsenal</span>
            #     </div>
            #     <div class="schedule__channels">
            #       <a href="/watch.php?id=123" title="Sky Sports">Player 1</a>
            #       <a href="/watch.php?id=456" title="BT Sport">Player 2</a>
            #     </div>
            #   </div>

            events = []

            for event_match in re.finditer(
                r'<div\s+class="schedule__event">.*?'
                r'<span\s+class="schedule__time"[^>]*data-time="([^"]+)"[^>]*>.*?</span>\s*'
                r'<span\s+class="schedule__eventTitle">\s*([^<]+)\s*</span>.*?'
                r'<div\s+class="schedule__channels">(.*?)</div>',
                html,
                re.IGNORECASE | re.DOTALL
            ):
                time_str = event_match.group(1).strip()
                event_title = event_match.group(2).strip()
                channels_html = event_match.group(3)

                # HTML decode event title
                event_title = event_title.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')

                # TODO: Convert time to local timezone
                # For now, just use the time as-is
                display_title = f'[COLOR gold]{time_str}[/COLOR] {event_title}'

                # Parse player channels
                channels = []
                for channel_match in re.finditer(
                    r'<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"[^>]*>(.*?)</a>',
                    channels_html,
                    re.IGNORECASE | re.DOTALL
                ):
                    href = channel_match.group(1).strip()
                    title_attr = channel_match.group(2).strip()
                    link_text = channel_match.group(3).strip()

                    # Get channel ID from URL
                    # /watch.php?id=123 or /watchs2watch.php?id=456|789
                    channel_id = None
                    if '?id=' in href:
                        channel_id = href.split('?id=')[1].split('&')[0]

                    if channel_id:
                        # Build full watch URL
                        if href.startswith('http'):
                            watch_url = href
                        elif href.startswith('/'):
                            watch_url = f'{self.base_url}{href}'
                        else:
                            watch_url = f'{self.base_url}/{href}'

                        channel_name = title_attr or link_text
                        channel_name = channel_name.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')

                        channels.append({
                            'channel_name': channel_name,
                            'channel_id': channel_id,
                            'url': watch_url
                        })

                if channels:
                    events.append({
                        'id': f'{category}_{time_str}_{event_title}',  # Unique ID
                        'title': display_title,
                        'plot': f'{event_title} - {len(channels)} stream(s) available',
                        'time': time_str,
                        'event_name': event_title,
                        'channels': channels  # Multiple player options
                    })

            c.log(f'[IPTV.{self.name}] Found {len(events)} events for {category}')
            return events

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching schedule events: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def _safe_request(self, url, timeout=10, headers=None, max_retries=2):
        """
        Override base _safe_request to use requests library directly.
        DaddyLive URLs fail with client.request() for unknown reason,
        but work fine with requests library.

        Includes retry logic for unreliable servers.
        """
        import time

        # Increase timeout for ksohls.ru (known to be slow)
        if 'ksohls.ru' in url:
            timeout = 15
            max_retries = 3

        for attempt in range(max_retries + 1):
            try:
                if attempt > 0:
                    c.log(f'[IPTV.{self.name}] Retry {attempt}/{max_retries}...')
                    time.sleep(1 * attempt)  # Backoff: 1s, 2s, 3s

                c.log(f'[IPTV.{self.name}] Requesting: {url[:80]}...')

                # Use requests library directly
                # Note: verify=False needed for sites with SSL certificate issues
                response = requests.get(
                    url,
                    headers=headers or {},
                    timeout=timeout,
                    allow_redirects=True,
                    verify=False  # Disable SSL verification for streaming sites
                )

                response.raise_for_status()  # Raise exception for 4xx/5xx

                content = response.text
                c.log(f'[IPTV.{self.name}] (OK) Request successful ({len(content)} bytes)')
                return content

            except requests.exceptions.HTTPError as e:
                c.log(f'[IPTV.{self.name}] (X) HTTP Error {e.response.status_code}: {e}')
                # Don't retry on 404, 403, etc - these won't change
                return None
            except requests.exceptions.Timeout:
                c.log(f'[IPTV.{self.name}] (X) Request timed out after {timeout}s')
                if attempt == max_retries:
                    return None
                # Otherwise retry
            except (requests.exceptions.RequestException, ConnectionError) as e:
                c.log(f'[IPTV.{self.name}] (X) Request failed: {e}')
                if attempt == max_retries:
                    return None
                # Otherwise retry
            except Exception as e:
                c.log(f'[IPTV.{self.name}] (X) Unexpected error: {e}')
                return None

        # All retries exhausted
        return None

    def resolve_stream(self, channel_url):
        """
        Resolve DaddyLive channel URL to playable stream.

        Implements internal stream resolution based on original plugin.video.daddylive logic:
        1. Fetch watch.php page
        2. Extract iframe (PLAYER 2 preferred)
        3. Extract CHANNEL_KEY and auth tokens from iframe JavaScript
        4. Call server_lookup.js to get server key
        5. Construct m3u8 URL with authentication headers

        Args:
            channel_url: Channel URL from get_channels() (e.g., https://dlstreams.top/watch.php?id=51)

        Returns:
            Playable stream URL with piped headers
        """
        c.log(f'[IPTV.{self.name}] Resolving stream: {channel_url[:80]}...')

        if not channel_url or not channel_url.startswith('http'):
            c.log(f'[IPTV.{self.name}] Invalid stream URL')
            return None

        try:
            import base64
            import json
            from urllib.parse import quote_plus, urljoin, urlparse

            UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

            def _origin(url):
                try:
                    p = urlparse(url)
                    return f'{p.scheme}://{p.netloc}'
                except:
                    return ''

            # Step 1: Fetch the watch.php page
            c.log(f'[IPTV.{self.name}] Fetching watch page...')

            headers = {
                'User-Agent': UA,
                'Referer': self.base_url,
                'Origin': _origin(self.base_url)
            }

            html1 = self._safe_request(channel_url, headers=headers, timeout=15)
            if not html1:
                c.log(f'[IPTV.{self.name}] Failed to fetch watch page')
                return None

            # Step 2: Find PLAYER 2 iframe (or fallback to first iframe)
            c.log(f'[IPTV.{self.name}] Looking for player iframe...')

            # Try PLAYER 2 first
            m = re.search(r'data-url="([^"]+)"\s+title="PLAYER 2"', html1, re.I)
            if m:
                iframe_url = urljoin(channel_url, m.group(1).replace('//cast', '/cast'))
            else:
                # Fallback to first iframe - flexible pattern for any attributes before src
                m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html1, re.I)
                if not m:
                    c.log(f'[IPTV.{self.name}] No iframe found')
                    return None
                iframe_url = urljoin(channel_url, m.group(1))

            # Step 3: Fetch iframe page
            c.log(f'[IPTV.{self.name}] Fetching iframe: {iframe_url[:60]}...')

            iframe_headers = {
                'User-Agent': UA,
                'Referer': channel_url,
                'Origin': _origin(channel_url)
            }

            iframe_html = self._safe_request(iframe_url, headers=iframe_headers, timeout=15)
            if not iframe_html:
                c.log(f'[IPTV.{self.name}] Failed to fetch iframe')
                return None

            # Check for nested iframe
            m_nested = re.search(r'iframe\s+src="([^"]+)"', iframe_html, re.I)
            if m_nested:
                nested_url = urljoin(iframe_url, m_nested.group(1))
                c.log(f'[IPTV.{self.name}] Found nested iframe')
                nested_html = self._safe_request(nested_url, headers={'User-Agent': UA, 'Referer': iframe_url}, timeout=15)
                if nested_html:
                    iframe_html = nested_html
                    iframe_url = nested_url

            # Step 4: Extract CHANNEL_KEY
            c.log(f'[IPTV.{self.name}] Extracting CHANNEL_KEY...')

            channel_key = None

            # Try to find CHANNEL_KEY in inline JavaScript
            m_ck = re.search(
                r'const\s+(?:CHANNEL_KEY|CHANNEL_ID|CH(?:ANNEL)?_?KEY?)\s*=\s*["\']([^"\']+)["\']',
                iframe_html,
                re.I
            )
            if m_ck:
                channel_key = m_ck.group(1).strip()
                c.log(f'[IPTV.{self.name}] Found CHANNEL_KEY in HTML: {channel_key}')

            # If not found in HTML, derive from URL
            # CHANNEL_KEY is likely set dynamically by external JS based on the ID parameter
            if not channel_key:
                c.log(f'[IPTV.{self.name}] CHANNEL_KEY not in HTML, deriving from URL...')

                # Extract ID from various URL patterns:
                # - /watch.php?id=517
                # - /cast/stream-517.php
                # - daddyhd.php?id=517

                # Try query parameter first
                m_id = re.search(r'[?&]id=(\d+)', channel_url)
                if not m_id:
                    # Try stream-XXX pattern from iframe URL
                    m_id = re.search(r'stream-(\d+)\.php', iframe_url)

                if m_id:
                    stream_id = m_id.group(1)
                    # Try different possible formats
                    # Based on iframe URL pattern (/cast/stream-517.php) we expect "stream-XXX"
                    channel_key = f'stream-{stream_id}'
                    c.log(f'[IPTV.{self.name}] Derived CHANNEL_KEY: {channel_key} (from ID: {stream_id})')
                else:
                    c.log(f'[IPTV.{self.name}] Could not derive CHANNEL_KEY from URL')
                    return None

            if not channel_key:
                c.log(f'[IPTV.{self.name}] CHANNEL_KEY extraction failed')
                return None

            # Extract AUTH_TOKEN (optional)
            auth_token = ''
            m_tok = re.search(r'const\s+AUTH_TOKEN\s*=\s*"([^"]+)"', iframe_html)
            if m_tok:
                auth_token = m_tok.group(1).strip()
                c.log(f'[IPTV.{self.name}] AUTH_TOKEN found (len={len(auth_token)})')

            # Extract AUTH_COUNTRY and AUTH_TS for CLIENT_TOKEN
            auth_country = ''
            auth_ts = ''
            m_cty = re.search(r'const\s+AUTH_COUNTRY\s*=\s*"([^"]+)"', iframe_html)
            if m_cty:
                auth_country = m_cty.group(1).strip()

            m_ts = re.search(r'const\s+AUTH_TS\s*=\s*"([^"]+)"', iframe_html)
            if m_ts:
                auth_ts = m_ts.group(1).strip()

            # Determine base domain from heartbeat URL
            base_domain = 'giokko.ru'
            m_hb = re.search(r"https://([^/]+)/heartbeat", iframe_html)
            if m_hb:
                heartbeat_host = m_hb.group(1).strip()
                m_dom = re.search(r"\.([A-Za-z0-9-]+\.[A-Za-z]{2,})$", heartbeat_host)
                if m_dom:
                    base_domain = m_dom.group(1).lower()
                c.log(f'[IPTV.{self.name}] Base domain: {base_domain}')

            # Generate CLIENT_TOKEN if we have AUTH_COUNTRY and AUTH_TS
            client_token = ''
            if auth_country and auth_ts:
                try:
                    lang = 'en'
                    screen = '1920x1080'
                    tz = 'UTC'
                    fingerprint = f'{UA}|{screen}|{tz}|{lang}'
                    sign_data = f'{channel_key}|{auth_country}|{auth_ts}|{UA}|{fingerprint}'
                    client_token = base64.b64encode(sign_data.encode('utf-8')).decode('ascii')
                    c.log(f'[IPTV.{self.name}] CLIENT_TOKEN generated')
                except Exception as e:
                    c.log(f'[IPTV.{self.name}] CLIENT_TOKEN generation failed: {e}')

            # Step 5: Call server_lookup to get server_key
            c.log(f'[IPTV.{self.name}] Calling server_lookup...')

            # Extract server_lookup URL from JavaScript
            # Pattern: fetchWithRetry('https://DOMAIN/server_lookup?channel_id='
            server_lookup_base = None
            m_lookup = re.search(r'fetchWithRetry\(["\']([^"\']+)/server_lookup\?', iframe_html)
            if m_lookup:
                server_lookup_base = m_lookup.group(1)
                c.log(f'[IPTV.{self.name}] Found server_lookup domain: {server_lookup_base}')
            else:
                # Fallback to common patterns seen in the wild
                server_lookup_base = 'https://chevy.vovlacosa.sbs'
                c.log(f'[IPTV.{self.name}] Using fallback server_lookup domain: {server_lookup_base}')

            server_lookup_url = f'{server_lookup_base}/server_lookup?channel_id={quote_plus(channel_key)}'

            lookup_headers = {
                'User-Agent': UA,
                'Referer': iframe_url,
                'Origin': _origin(iframe_url),
                'X-User-Agent': UA
            }
            if auth_token:
                lookup_headers['Authorization'] = f'Bearer {auth_token}'
                lookup_headers['X-Channel-Key'] = channel_key
            if client_token:
                lookup_headers['X-Client-Token'] = client_token

            lookup_response = self._safe_request(server_lookup_url, headers=lookup_headers, timeout=10)
            if not lookup_response:
                c.log(f'[IPTV.{self.name}] server_lookup failed')
                return None

            try:
                lookup_data = json.loads(lookup_response)
                server_key = lookup_data.get('server_key', '').strip()
                c.log(f'[IPTV.{self.name}] server_key: {server_key}')
            except Exception as e:
                c.log(f'[IPTV.{self.name}] server_lookup JSON parse error: {e}')
                return None

            if not server_key:
                c.log(f'[IPTV.{self.name}] No server_key returned')
                return None

            # Step 6: Construct final m3u8 URL
            # Extract m3u8 URL base from JavaScript (look for actual domain, not template vars)
            m3u8_base = None

            # Pattern: ? `https://DOMAIN/proxy/top1/cdn/${CHANNEL_KEY}/mono.css`
            #        : `https://DOMAIN/proxy/${sk}/${CHANNEL_KEY}/mono.css`;
            m_proxy = re.search(r'`(https://[^/]+/proxy)/\$\{', iframe_html)
            if m_proxy:
                m3u8_base = m_proxy.group(1)
                c.log(f'[IPTV.{self.name}] Found proxy base URL: {m3u8_base}')

            if not m3u8_base:
                # Try alternate pattern without /proxy
                m_direct = re.search(r'`(https://[^/]+\.[^/]+)/(?:top1/cdn|\$\{sk\})/\$\{(?:CHANNEL_KEY|channel_key)\}', iframe_html)
                if m_direct:
                    m3u8_base = m_direct.group(1)
                    c.log(f'[IPTV.{self.name}] Found direct base URL: {m3u8_base}')

            if not m3u8_base:
                # Fallback to common proxy pattern
                m3u8_base = 'https://go.ai-chatx.site/proxy'
                c.log(f'[IPTV.{self.name}] Using fallback proxy URL: {m3u8_base}')

            # Construct final URL based on server_key
            if server_key == 'top1/cdn':
                hls_url = f'{m3u8_base}/top1/cdn/{channel_key}/mono.css'
            else:
                hls_url = f'{m3u8_base}/{server_key}/{channel_key}/mono.css'

            # Build header string for piped URL
            iframe_origin = _origin(iframe_url)
            cookie_val = 'access=true'
            if auth_token:
                cookie_val = f'access=true; eplayer_session={auth_token}'

            header_dict = {
                'Referer': f'{iframe_origin}/',
                'Origin': iframe_origin,
                'Connection': 'Keep-Alive',
                'User-Agent': UA,
                'Cookie': cookie_val,
            }
            if auth_token:
                header_dict['Authorization'] = f'Bearer {auth_token}'
                header_dict['X-Channel-Key'] = channel_key
            if client_token:
                header_dict['X-Client-Token'] = client_token
            header_dict['X-User-Agent'] = UA

            header_str = '&'.join(f'{k}={quote_plus(v)}' for k, v in header_dict.items())
            m3u8_with_headers = f'{hls_url}|{header_str}'

            c.log(f'[IPTV.{self.name}] Stream resolved: {hls_url[:60]}...')
            return m3u8_with_headers

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error resolving stream: {e}')
            import traceback
            c.log(traceback.format_exc())
            return None


# Auto-register provider on import
DaddyLiveProvider()

# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file plutotv.py
* @package script.module.thecrew
*
* Pluto TV IPTV Provider
*
* Provides access to 250+ free live TV channels from Pluto TV.
* No authentication required - completely open access.
*
* API: http://api.pluto.tv/v2/channels
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import json
from ..base import BaseIPTVProvider
from ...modules import client
from ...modules.crewruntime import c


class PlutoTVProvider(BaseIPTVProvider):
    """Pluto TV - 250+ free channels, no auth required"""

    # Provider metadata
    name = "plutotv"
    title = "Pluto TV"
    enabled = False  # Disabled - API now requires authentication
    priority = 10  # High priority - reliable and free

    # Geographic restrictions
    geo_blocked = True
    geo_region = "US"  # Primary region, but also available in other countries

    # Capabilities
    supports_categories = True

    def __init__(self):
        super().__init__()
        self.base_url = "http://api.pluto.tv"

    def get_channels(self):
        """
        Fetch all available Pluto TV channels.

        Returns:
            List of dicts with channel information
        """
        c.log(f'[IPTV.{self.name}] Fetching channel list from {self.title}')

        try:
            # Pluto TV API endpoint
            url = f'{self.base_url}/v2/channels'
            params = {
                'appName': 'web',
                'appVersion': 'na',
                'deviceVersion': 'na',
                'deviceModel': 'web',
                'deviceMake': 'web',
                'deviceType': 'web',
                'clientID': 'web'
            }

            # Build URL with query params
            param_str = '&'.join([f'{k}={v}' for k, v in params.items()])
            full_url = f'{url}?{param_str}'

            # Fetch channel data
            response = self._safe_request(full_url, timeout=15)
            if not response:
                c.log(f'[IPTV.{self.name}] Failed to fetch channel list')
                return []

            # Parse JSON
            try:
                data = json.loads(response)
            except Exception as e:
                c.log(f'[IPTV.{self.name}] Failed to parse JSON: {e}')
                return []

            channels = []

            for channel in data:
                try:
                    # Extract channel info
                    name = channel.get('name', 'Unknown')
                    slug = channel.get('slug', '')
                    number = channel.get('number', '')

                    # Get category
                    category = 'General'
                    if channel.get('category'):
                        category = channel.get('category')
                    elif channel.get('categories') and len(channel['categories']) > 0:
                        category = channel['categories'][0].get('name', 'General')

                    # Get stream URL - Pluto provides direct m3u8 links
                    stream_url = None
                    if channel.get('stitched') and channel['stitched'].get('urls'):
                        # Get the first HLS stream
                        for url_obj in channel['stitched']['urls']:
                            if url_obj.get('type') == 'hls':
                                stream_url = url_obj.get('url')
                                break

                    if not stream_url:
                        continue

                    # Format channel name with number
                    if number:
                        display_name = f'{number} - {name}'
                    else:
                        display_name = name

                    # Get icon
                    icon = None
                    if channel.get('images'):
                        # Try to get logo first, fall back to other images
                        for img in channel['images']:
                            if img.get('type') == 'logo' and img.get('url'):
                                icon = img['url']
                                break
                        if not icon and len(channel['images']) > 0:
                            icon = channel['images'][0].get('url')

                    # Get description
                    plot = channel.get('summary', '') or channel.get('description', '')

                    channel_dict = {
                        'title': display_name,
                        'url': stream_url,
                        'icon': icon,
                        'plot': plot,
                        'category': category
                    }

                    channels.append(channel_dict)

                except Exception as e:
                    c.log(f'[IPTV.{self.name}] Error parsing channel: {e}')
                    continue

            c.log(f'[IPTV.{self.name}] Successfully fetched {len(channels)} channels')
            return channels

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def resolve_stream(self, channel_url):
        """
        Resolve stream URL for playback.

        For Pluto TV, the channel_url is already a direct m3u8 URL.

        Args:
            channel_url: Stream URL from get_channels()

        Returns:
            Playable stream URL
        """
        c.log(f'[IPTV.{self.name}] Resolving stream: {channel_url[:80]}...')

        # Pluto TV URLs are direct m3u8 - no resolution needed
        if not channel_url or not channel_url.startswith('http'):
            c.log(f'[IPTV.{self.name}] Invalid stream URL')
            return None

        c.log(f'[IPTV.{self.name}] Stream URL ready')
        return channel_url


# Auto-register provider on import
PlutoTVProvider()

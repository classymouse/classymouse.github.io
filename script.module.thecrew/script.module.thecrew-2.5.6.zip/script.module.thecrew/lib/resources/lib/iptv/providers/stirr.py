# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file stirr.py
* @package script.module.thecrew
*
* Stirr IPTV Provider
*
* Provides access to 100+ free local news and entertainment channels.
* No authentication required - completely open access.
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import json
import re
from ..base import BaseIPTVProvider
from ...modules import client
from ...modules.crewruntime import c


class StirrProvider(BaseIPTVProvider):
    """Stirr - 100+ free local news & entertainment channels"""

    # Provider metadata
    name = "stirr"
    title = "Stirr"
    enabled = False  # Disabled - API endpoint not accessible
    priority = 15  # High priority - reliable and free

    # Geographic restrictions
    geo_blocked = True
    geo_region = "US"

    # Capabilities
    supports_categories = True

    def __init__(self):
        super().__init__()
        self.base_url = "https://ott-channels.stir.com/v1"

    def get_channels(self):
        """
        Fetch all available Stirr channels.

        Returns:
            List of dicts with channel information
        """
        c.log(f'[IPTV.{self.name}] Fetching channel list from {self.title}')

        try:
            # Stirr channels endpoint
            url = f'{self.base_url}/ott-channels/secure-oakley'

            # Fetch channel data
            response = self._safe_request(url, timeout=15)
            if not response:
                c.log(f'[IPTV.{self.name}] Failed to fetch channel list')
                return []

            # Parse JSON
            try:
                data = json.loads(response)
            except Exception as e:
                c.log(f'[IPTV.{self.name}] Failed to parse JSON: {e}')
                return []

            channels = []
            channel_data = data.get('data', {}).get('channels', [])

            for channel in channel_data:
                try:
                    # Extract channel info
                    name = channel.get('name', 'Unknown')
                    channel_id = channel.get('id', '')
                    number = channel.get('channelNumber', '')

                    # Get category
                    category = channel.get('category', {}).get('name', 'General')

                    # Get stream URL
                    stream_url = None
                    if channel.get('streamUrl'):
                        stream_url = channel['streamUrl']
                    elif channel.get('liveStreamUrl'):
                        stream_url = channel['liveStreamUrl']

                    if not stream_url:
                        continue

                    # Format channel name with number
                    if number:
                        display_name = f'{number} - {name}'
                    else:
                        display_name = name

                    # Get icon/logo
                    icon = None
                    if channel.get('logo'):
                        icon = channel['logo']
                    elif channel.get('thumbnail'):
                        icon = channel['thumbnail']

                    # Get description
                    plot = channel.get('description', '') or channel.get('shortDescription', '')

                    channel_dict = {
                        'title': display_name,
                        'url': stream_url,
                        'icon': icon,
                        'plot': plot,
                        'category': category
                    }

                    channels.append(channel_dict)

                except Exception as e:
                    c.log(f'[IPTV.{self.name}] Error parsing channel: {e}')
                    continue

            c.log(f'[IPTV.{self.name}] Successfully fetched {len(channels)} channels')
            return channels

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def resolve_stream(self, channel_url):
        """
        Resolve stream URL for playback.

        Stirr URLs are direct m3u8 links.

        Args:
            channel_url: Stream URL from get_channels()

        Returns:
            Playable stream URL
        """
        c.log(f'[IPTV.{self.name}] Resolving stream: {channel_url[:80]}...')

        # Stirr URLs are direct m3u8 - no resolution needed
        if not channel_url or not channel_url.startswith('http'):
            c.log(f'[IPTV.{self.name}] Invalid stream URL')
            return None

        c.log(f'[IPTV.{self.name}] Stream URL ready')
        return channel_url


# Auto-register provider on import
StirrProvider()

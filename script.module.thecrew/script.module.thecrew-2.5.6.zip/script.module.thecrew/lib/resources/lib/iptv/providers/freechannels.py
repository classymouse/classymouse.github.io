# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file freechannels.py
* @package script.module.thecrew
*
* Free Channels IPTV Provider
*
* Uses community-maintained M3U playlists from iptv-org project
* 100% free and open channels from around the world.
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import re
from ..base import BaseIPTVProvider
from ...modules import client
from ...modules.crewruntime import c


class FreeChannelsProvider(BaseIPTVProvider):
    """Free Channels - Community curated free IPTV streams"""

    # Provider metadata
    name = "freechannels"
    title = "Free Channels"
    enabled = False  # Disabled - too many broken streams
    priority = 20  # Medium priority

    # Capabilities
    supports_categories = True

    def __init__(self):
        super().__init__()
        # Use iptv-org GitHub - curated free channels
        self.m3u_url = "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8"

    def get_channels(self):
        """
        Parse M3U playlist and return channel list.

        Returns:
            List of dicts with channel information
        """
        c.log(f'[IPTV.{self.name}] Fetching M3U playlist from {self.title}')

        try:
            # Fetch M3U content
            response = self._safe_request(self.m3u_url, timeout=20)
            if not response:
                c.log(f'[IPTV.{self.name}] Failed to fetch M3U playlist')
                return []

            channels = self._parse_m3u(response)

            c.log(f'[IPTV.{self.name}] Successfully parsed {len(channels)} channels')
            return channels

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def _parse_m3u(self, m3u_content):
        """
        Parse M3U content and extract channel information.

        M3U format:
            #EXTM3U
            #EXTINF:-1 tvg-id="channel1" tvg-logo="http://logo.png" group-title="News",Channel Name
            http://stream.url/playlist.m3u8

        Args:
            m3u_content: Raw M3U file content

        Returns:
            List of channel dicts
        """
        channels = []
        lines = m3u_content.split('\n')

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Look for #EXTINF lines
            if line.startswith('#EXTINF'):
                # Extract channel metadata using regex
                # Pattern: #EXTINF:-1 tvg-id="..." tvg-logo="..."  group-title="..." tvg-name="...",Channel Name

                # Extract channel name (after last comma)
                name_match = re.search(r',(.+)$', line)
                name = name_match.group(1).strip() if name_match else 'Unknown Channel'

                # Extract logo
                logo_match = re.search(r'tvg-logo="([^"]*)"', line)
                logo = logo_match.group(1) if logo_match else None

                # Extract category/group
                group_match = re.search(r'group-title="([^"]*)"', line)
                category = group_match.group(1) if group_match else 'General'

                # Extract tvg-id (optional)
                id_match = re.search(r'tvg-id="([^"]*)"', line)
                tvg_id = id_match.group(1) if id_match else None

                # Next non-empty line should be the stream URL
                stream_url = None
                for j in range(i + 1, min(i + 5, len(lines))):
                    potential_url = lines[j].strip()
                    if potential_url and not potential_url.startswith('#'):
                        stream_url = potential_url
                        i = j  # Skip ahead
                        break

                if stream_url and stream_url.startswith('http'):
                    channel_dict = {
                        'title': name,
                        'url': stream_url,
                        'icon': logo,
                        'plot': f'{name} - {category}' if category != 'General' else name,
                        'category': category
                    }
                    channels.append(channel_dict)

            i += 1

        return channels

    def resolve_stream(self, channel_url):
        """
        Resolve stream URL for playback.

        M3U URLs are typically direct streams.

        Args:
            channel_url: Stream URL from get_channels()

        Returns:
            Playable stream URL
        """
        c.log(f'[IPTV.{self.name}] Resolving stream: {channel_url[:80]}...')

        if not channel_url or not channel_url.startswith('http'):
            c.log(f'[IPTV.{self.name}] Invalid stream URL')
            return None

        c.log(f'[IPTV.{self.name}] Stream URL ready')
        return channel_url


# Auto-register provider on import
FreeChannelsProvider()

# -*- coding: utf-8 -*-

'''
*****************************************************
* The Crew Add-on
*
* @file yoursports.py
* @package script.module.thecrew
*
* YourSports.to IPTV Provider
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*****************************************************
'''

import re
from urllib.parse import quote_plus
from ..base import BaseIPTVProvider
from ...modules.crewruntime import c
from ...modules import client


class YourSportsProvider(BaseIPTVProvider):
    """
    Provider for yoursports.to live sports channels.

    Provides access to live sports streams.
    """

    name = "yoursports"
    title = "YourSports"
    enabled = True  # Enabled by default
    priority = 30   # Higher priority (more reliable)

    geo_blocked = False
    geo_region = None
    supports_categories = True

    base_url = "http://yoursports.to"
    games_js_url = f"{base_url}/games.js?x=1578846031"

    def get_channels(self):
        """Get list of live sports channels from yoursports.to"""
        try:
            c.log(f'[IPTV.{self.name}] Fetching channel list from {self.games_js_url}')

            # Check if this is actually plugin.video.thecrew
            # (Some providers check this for licensing/rate limiting)
            from ...modules import control
            try:
                plugin_name = control.infoLabel('Container.PluginName')
                if plugin_name != 'plugin.video.thecrew':
                    c.log(f'[IPTV.{self.name}] Not running in plugin.video.thecrew context, skipping')
                    return []
            except Exception:
                pass

            # Request games JavaScript file
            js_content = self._safe_request(self.games_js_url, timeout=15)

            if not js_content:
                c.log(f'[IPTV.{self.name}] Failed to fetch games.js')
                return []

            # Extract channel data from JavaScript
            # Looking for: chan:'Channel Name',url:'video_id'
            # Split by 'scope.tv=' to isolate channel data
            if 'scope.tv=' in js_content:
                data_section = js_content.split('scope.tv=', 1)[-1]
            else:
                c.log(f'[IPTV.{self.name}] games.js format unexpected (no scope.tv=)')
                return []

            # Pattern: chan:'NAME',url:'ID'
            pattern = r"chan:'(.+?)',url:'(.+?)'"
            matches = re.findall(pattern, data_section)

            if not matches:
                c.log(f'[IPTV.{self.name}] No channels found in games.js')
                return []

            # Build channel list
            channels = []
            for channel_name, video_id in matches:
                channel = {
                    'title': channel_name.strip(),
                    'url': f'{self.base_url}/live?v={video_id}',
                    'icon': '',
                    'plot': f'Live sports from {self.title}'
                }
                channels.append(channel)

            # Sort channels alphabetically
            channels = sorted(channels, key=lambda c: c['title'].lower())

            c.log(f'[IPTV.{self.name}] Found {len(channels)} channels')
            return channels

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Error fetching channels: {e}')
            import traceback
            c.log(traceback.format_exc())
            return []

    def resolve_stream(self, url):
        """
        Resolve yoursports.to channel URL to playable stream.

        Uses client.external() helper which handles yoursports.to URLs.
        """
        try:
            c.log(f'[IPTV.{self.name}] Resolving stream: {url}')

            # Use existing client.external() method which knows how to handle
            # yoursports and other external stream URLs
            stream_url = client.external(url)

            if stream_url:
                c.log(f'[IPTV.{self.name}] (OK) Stream resolved via client.external()')
                return stream_url
            else:
                c.log(f'[IPTV.{self.name}] (X) client.external() returned None')
                return None

        except Exception as e:
            c.log(f'[IPTV.{self.name}] Stream resolution failed: {e}')
            import traceback
            c.log(traceback.format_exc())
            return None


# Auto-register provider on module import
YourSportsProvider()

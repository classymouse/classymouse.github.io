# -*- coding: utf-8 -*-

import re, json, base64, requests, time, random, math, xbmcgui,xbmc

try:
    from Crypto.Cipher import AES
    from Crypto.Util import Counter
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

from urllib.parse import urlencode, quote_plus, urlparse, urljoin

from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import workers
from resources.lib.modules import jsunpack
from resources.lib.modules import hunter

UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36'


class streamer:
    def dodgycodes(s):
        return re.sub(r'&#(\d+);', '', s)

    def resolve(self, url):
        try:
            if 'epicmartial' in url: u = self.epicmartial(url)
            elif 'castweb' in url: u = self.epicmartial(url)
            elif 'elixx.xyz' in url: u = self.elixx(url)
            elif 'eddensports.com' in url: u = self.solaris(url)
            elif 'redsoccer.info' in url: u = self.solaris(url)
            elif 'worldstreams.net' in url: u = self.worldstreams(url)
            elif 'papahd' in url: u = self.papahd(url)
            elif 'bfst.xyz' in url: u = self.beast(url)
            elif 'fightpass.site' in url: u = self.fightpass(url)
            elif 'allsportsmedia.live' in url: u = self.fightpass(url)
            elif 'nbaweb.site' in url: u = self.helena(url)
            elif 'nbaweb.xyz' in url: u = self.skuanet(url)
            elif 'sportsnest.co' in url: u = self.sportsnest(url)
            elif 'dofusports' in url: u = self.sportsnest(url)
            elif 'bestreamsports.org' in url: u = self.sportsnest(url)
            elif 'telechargementfilmhd.com' in url: u = self.nbahdreplay(url)
            elif 'volokit' in url: u = self.volokit(url)
            elif 'playoffsstream' in url: u = self.playoff(url)
            elif '720pstream' in url: u = self.seventwenty(url)
            elif 'watchkobestreams' in url: u = self.watchkobestreams(url)
            elif 'crackstreams' in url: u = self.crackstreams(url)
            elif 'streameast.gl' in url: u = self.givemereddit(url)
            elif 'givemereddit' in url: u = self.givemereddit(url)
            elif 'givemenflstreams' in url: u = self.givemereddit(url)
            elif 'givemenbastreams' in url: u = self.givemereddit(url)
            elif 'givememmastreams' in url: u = self.givemereddit(url)
            elif 'givemeredditstreams' in url: u = self.givemereddit(url)
            elif 'gameshdlive' in url: u = self.solaris(url)
            elif 'gamehdlive' in url: u = self.solaris(url)
            elif 'nflsportz.com' in url: u = self.nflsportz(url)
            elif 'istreameast.app' in url: u = self.streameast(url)
            elif 'streameast.ga' in url: u = self.streameast_ga(url)
            elif 'ertech.work' in url: u = self.skuanet(url)
            elif 'chimxoan.net' in url: u = self.skuanet(url)
            elif 'skuanet' in url: u = self.skuanet(url)
            elif 'harumu.me/' in url: u = self.skuanet(url)
            elif 'viafb.site/' in url: u = self.skuanet(url)
            elif 'fnew.tech' in url: u = self.skuanet(url)
            elif 'psm.wtf' in url: u = self.skuanet(url)
            elif 'fabtech.work' in url: u = self.skuanet(url)
            elif 'ruapa.com/' in url: u = self.skuanet(url)
            elif 'gardener101.work' in url: u = self.skuanet(url)
            elif 'jmutech.xyz' in url: u = self.skuanet(url)
            elif 'aas.works' in url: u = self.skuanet(url)
            elif 'kimta' in url: u = self.skuanet(url)
            elif 'sagoad.com/' in url: u = self.skuanet(url)
            elif 'anhdepmoingay.com/' in url: u = self.skuanet(url)
            elif 'ustvgo.cc' in url: u = self.skuanet(url)
            elif 'hinhnenhd.info' in url: u = self.skuanet(url)
            elif 'bubofitness.com' in url: u = self.skuanet(url)
            elif 'midcoastplanning.org' in url: u = self.skuanet(url)
            elif 'fxmagicmusic' in url: u = self.skuanet(url)
            elif 'ftheanh.tech' in url: u = self.skuanet(url)
            elif 'azulitostreams.com' in url: u = self.skuanet(url)
            elif 'banknotewiki.com' in url: u = self.skuanet(url)
            elif 'sportnews.to' in url: u = self.sportnews(url)
            elif 'mysports.to' in url: u = self.sportnews(url)
            elif 'footy.to' in url: u = self.sportnews(url)
            elif 'wpstream.tv' in url: u = self.weakspell(url)
            elif 'weakspell' in url: u = self.weakspell(url)
            elif 'liveonscore.tv' in url: u = self.weakspell(url)
            elif 'liveonscore.to' in url: u = self.weakspell(url)
            elif 'weakstreams' in url: u = self.weakspell(url)
            elif 'weakstream.org' in url: u = self.weakspell(url)
            elif 'ufckhabib.com' in url: u = self.ufckhabib(url)
            elif 'ovostreams' in url: u = self.ovostreams(url)
            elif 'ovogoaal' in url: u = self.ovostreams(url)
            elif 'ovogoal' in url: u = self.ovostreams(url)
            elif 'ovo-gola' in url: u = self.ovostreams(url)
            elif 'techoreels.com' in url: u = self.techno(url)
            elif 'techclips.net' in url: u = self.techno(url)
            elif 'torridplay.com' in url: u = self.skuanet(url)
            elif 'sportinglive.co' in url: u = self.skuanet(url)
            elif 'dubsstreamz.com' in url: u = self.dubsstreamz(url)
            elif 'dubzstreams.com' in url: u = self.dubsstreamz(url)
            elif 'summerlivestream.com' in url: u = self.summerlivestream(url)
            elif 'streaming4u.org/' in url: u = self.summerlivestream(url)
            elif 'basketball-video' in url: u = self.basketballvideo(url)
            elif 'nfl-video' in url: u = self.nflvideo(url)
            elif 'naughtyblog' in url: u = self.naughtyblog(url)
            elif 'fsportshd' in url: u = self.fsportshd(url)
            elif 'methstreams' in url: u = self.meth(url)
            elif 'roxiestreams' in url: u = self.roxie(url)
            elif 'trendy47' in url: u = self.trendy(url)
            elif 'embedsports.top' in url: u = self.embedsports(url)
            elif 'streambtw' in url: u = self.streambtw(url)
            else: u = self.generic(url)

            return u
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            pass

    def generic(self, url):
        try:
            r = client.request(url)
            r = r.replace('\\', '')

            s = re.findall(r"[0-9_']+:\s\'([^']+)", r) + re.findall(r"\s*=\s*\"(http.+?)\"", r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r"\(\w+\(\"([^\"]*)", r) + re.findall(r"\(\w+\(\'([^\']*)", r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\"\w+\":"([^"]*)', r) + re.findall(r'\'\w+\':\'([^\']*)', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\s*=\s*\'(http.+?)\'', r) + re.findall(r'\s*=\s*\"(http.+?)\"', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\s*:\s*\"(http.+?)\"', r) + re.findall(r'\s*:\s*\'(http.+?)\'', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\s*\(\s*\"(http.+?)\"', r) + re.findall(r'\s*\(\s*\'(http.+?)\'', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s:s = re.findall(r'\s*:\s*\"(//.+?)\"', r) + re.findall(r'\s*:\s*\'(//.+?)\'', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s:s = re.findall(r'\:\"(\.+?)\"', r) + re.findall(r'\:\'(\.+?)\'', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\s*\(\s*\"(//.+?)\"', r) + re.findall(r'\s*\(\s*\'(//.+?)\'', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\s*=\s*\'(//.+?)\'', r) + re.findall(r'\s*=\s*\"(//.+?)\"', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\w*:\s*\"(http.+?)\"', r) + re.findall(r'\w*:\s*\'(http.+?)\'', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\w*=\'([^\']*)', r) + re.findall(r'\w*=\"([^\"]*)', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall(r'\w*\s*=\s*\'([^\']*)', r) + re.findall(r'\w*\s*=\s*\"([^\"]*)', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = re.findall('(?s)<file>([^<]*)', r)
            s = [i for i in s if (urlparse(i).path).strip('/').split('/')[-1].split('.')[-1] in ['mp4', 'flv', 'm3u8']]

            if not s: s = client.parseDOM(r, 'source', ret='src', attrs = {'type': 'video.+?'})
            s = ['http:' + i if i.startswith('//') else i for i in s]
            s = [urljoin(url, i) if not i.startswith('http') else i for i in s]
            s = [x for y,x in enumerate(s) if x not in s[:y]]

            self.u = []
            def request(i):
                try:
                    i = i.replace(' ','%20')
                    c = client.request(i, output='headers')
                    checks = ['video','mpegurl','html','octet-stream']
                    if any(f for f in checks if f in c['Content-Type']): self.u.append((i, int(c['Content-Length'])))
                except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
                    pass
            threads = []
            for i in s: threads.append(workers.Thread(request, i))
            [i.start() for i in threads] ; [i.join() for i in threads]
            u = sorted(self.u, key=lambda x: x[1])[::-1]
            u = client.request(u[0][0], output='geturl', Referer=url)
            return u
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            pass

    def weakspell(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            m = re.search(r'(?is)iframe[^>]*frameborder.*?src="([^"]+)', page_data)
            iframe_url = m[1]
            p = requests.get(iframe_url).text
            m = re.search(r'url:\s*"([^"]+)"', p)
            base_url = m[1]
            m = re.search(r'data:\s*\{\s*"([^"]+)"', p)
            data_key = m[1]
            m = re.search(r'var\s+vidgstream\s*=\s*"([^"]+)"', p)
            vidgstream = m[1]
            m = re.search(r'gethlsUrl\(vidgstream,\s*([^,]+)', p)
            server_id = m[1].strip()
            m = re.search(r'gethlsUrl\(vidgstream,(?:[^,]+),\s*([^)]+)\)', p)
            cid = m[1].strip()
            hat = f'{base_url}?{data_key}={vidgstream}&serverid={server_id}&cid={cid}'
            the = requests.get(hat).text
            m = re.search(r'{"rawUrl":"([^"]+)"', the)
            raw_url = m[1].replace('\\', '')
            return (
                f'{raw_url}?&connection=keepalive'
                f'|User-Agent={UA}'
                f'&Referer=https://methstreams.to/'
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def crackstreams(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url, headers={"Referer": url, "User-Agent": UA}).text
            h = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
            if 'givemereddit' in h:
                gr = requests.get(h, headers={'User-Agent': UA, 'Referer': url}).text
                i = re.compile(
                    r'decodeURIComponent\(escape\(r\)\)}\("([^"]*)",([^,]*),"([^"]*)",([^,]*),([^,]*),([^\)]*)'
                ).findall(gr)[0]
                t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
                e = re.findall(r'source:\s*\'([^\']*)', t)[0]
                e = e.replace('\\', '')
                return (
                    e
                    + '|Referer=https://givemereddit.link/'
                    + '&Origin=https://givemereddit.link'
                    + '&User-Agent=' + UA
                    + '&Accept=application/x-mpegURL,*/*'
                )
            else:
                x = requests.get(h).text
                w = re.findall(r'(?s)atob\(\'([^\']*)', x)[0]
                w = base64.b64decode(w).decode('utf-8')
                u = re.findall(r'initURL\s*=\s*"([^"]*)', w)[0]
                return (
                    u
                    + '|User-Agent=' + UA
                    + '&Referer=' + h
                )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def givemereddit(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_html = requests.get(url, headers={'User-Agent': UA}, timeout=10).text
            m = re.search(r'(?is)iframe\s+class="embed-responsive-item"\s+src="([^"]+)"', page_html)
            iframe_url = m[1]
            iframe_html = requests.get(iframe_url,headers={'Referer': iframe_url, 'User-Agent': UA},timeout=10).text
            m = re.search(r'decodeURIComponent\(escape\(r\)\)}\("([^"]*)",([^,]*),"([^"]*)",([^,]*),([^,]*),([^)]+)\)',iframe_html)
            arg0 = m[1]
            arg1 = int(m[2])
            arg2 = m[3]
            arg3 = int(m[4])
            arg4 = int(m[5])
            arg5 = int(m[6])
            t = hunter.hunter(arg0, arg1, arg2, arg3, arg4, arg5)
            m = re.search(r'streamSrc =\s*"([^"]*)', t)
            src = m[1].replace('\\', '')
            return (
                f"{src}"
                f"|Referer=https://givemereddit.zip/"
                f"&Origin=https://givemereddit.zip"
                f"&User-Agent={UA}"
                f"&Accept=application/x-mpegURL,*/*"
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def streameast(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            m = re.search(r'(?is)<iframe[^>]+src="([^"]+)', page_data)
            iframe_url = m[1]
            headers = {'User-Agent': UA,'Referer': url}
            iframe_html = requests.get(iframe_url, headers=headers, timeout=10).text
            m = re.search(r"atob\('([^']+)", iframe_html)
            encoded = m[1]
            decoded = base64.b64decode(encoded).decode('utf-8', 'ignore')
            referer = 'https://gooz.aapmains.net/'
            origin = 'https://gooz.aapmains.net'
            return (
                f"{decoded}"
                f"|User-Agent={UA}"
                f"&Referer={referer}"
                f"&Origin={origin}"
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def skuanet(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            r = re.findall('<source src="([^"]*)', page_data)[0]
            return (
                r
                + '?&connection=keepalive'
                + '|User-Agent=' + UA
                + '&Referer=' + url
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def playoff(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            iframe_source_url = re.findall(r"embed-responsive-item\" src='([^']*)", page_data)[0]
            iframe_data = requests.get(iframe_source_url, headers={'User-Agent': UA, 'Referer': url}).text
            pdettxt = re.findall('pdettxt = "([^"]*)', iframe_data)[0]
            zmid = re.findall('zmid = "([^"]*)', iframe_data)[0]
            pid = re.findall("pid = ([0-9])", iframe_data)[0]
            edm = re.findall('edm = "([^"]*)', iframe_data)[0]
            embed_script_url = re.findall(r'<script\\W*async\\W*src="([^"]*)', iframe_data)[0]
            url = "https://" + edm + "/sd0embed?v=" + zmid
            embed_source_data = requests.post(
                url,
                headers={
                    "Origin": "https://embedstream.me",
                    "Referer": "https://embedstream.me/",
                    "User-Agent": UA
                }
            ).text
            i = re.compile(
                r'decodeURIComponent\(escape.*\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)'
            ).findall(embed_source_data)[0]
            t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
            m3u8 = re.findall(r'const vdoUrl = \'([^\']*)', t)[0]
            m3u8 = base64.b64decode(m3u8).decode("UTF-8")
            unique_id = re.findall(r"const unqiueId = \'([^\']*)", t)[0]
            scode = re.findall(r'sCode = \'([^\']*)', t)[0]
            ts = re.findall(r'Ts = ([0-9]{10})', t)[0]
            key = 'https://key.seckeyserv.me/?stream=' + unique_id + '&scode=' + scode + '&expires=' + ts
            authUrl = {'User-Agent': UA, 'Origin': 'https://www.nolive.me', 'Referer': 'https://www.nolive.me/sd0embed'}
            return m3u8 + '|{0}'.format(urlencode(authUrl))
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def seventwenty(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            iframe_source_url = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
            iframe_data = requests.get(iframe_source_url, headers={'User-Agent': UA, 'Referer': url}).text
            pdettxt = re.findall('pdettxt = "([^"]*)', iframe_data)[0]
            zmid = re.findall('zmid = "([^"]*)', iframe_data)[0]
            pid = re.findall("pid = ([0-9])", iframe_data)[0]
            edm = re.findall('edm = "([^"]*)', iframe_data)[0]
            embed_script_url = re.findall(r'<script\\W*async\\W*src="([^"]*)', iframe_data)[0]
            url = "https://" + edm + "/sd0embed?v=" + zmid
            embed_source_data = requests.post(
                url,
                headers={
                    "Origin": "https://embedstream.me",
                    "Referer": "https://embedstream.me/",
                    "User-Agent": UA
                }
            ).text
            i = re.compile(
                r'decodeURIComponent\(escape.*\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)'
            ).findall(embed_source_data)[0]
            t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
            m3u8 = re.findall(r'const vdoUrl = \'([^\']*)', t)[0]
            m3u8 = base64.b64decode(m3u8).decode("UTF-8")
            unique_id = re.findall(r"const unqiueId = \'([^\']*)", t)[0]
            scode = re.findall(r'sCode = \'([^\']*)', t)[0]
            ts = re.findall(r'Ts = ([0-9]{10})', t)[0]
            authUrl = {'User-Agent': UA, 'Origin': 'https://www.nolive.me', 'Referer': 'https://www.nolive.me/sd0embed'}
            return m3u8 + '|{0}'.format(urlencode(authUrl))
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def watchkobestreams(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url, headers={'User-Agent': UA}).text
            iframe_source_url = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
            embed_r = requests.get(iframe_source_url, headers={'User-Agent': UA, 'Referer': url}).text
            embed_stream = re.findall('(?s)<iframe.*?src="([^"]*)', embed_r)[0]
            iframe_data = requests.get(embed_stream, headers={'User-Agent': UA, 'Referer': iframe_source_url}).text
            pdettxt = re.findall('pdettxt = "([^"]*)', iframe_data)[0]
            zmid = re.findall('zmid = "([^"]*)', iframe_data)[0]
            pid = re.findall("pid = ([0-9])", iframe_data)[0]
            edm = re.findall('edm = "([^"]*)', iframe_data)[0]
            embed_script_url = re.findall(r'<script\\W*async\\W*src="([^"]*)', iframe_data)[0]
            url = "https://" + edm + "/sd0embed?v=" + zmid
            embed_source_data = requests.post(
                url,
                headers={
                    "Origin": "https://embedstream.me",
                    "Referer": "https://embedstream.me/",
                    "User-Agent": UA
                }
            ).text
            i = re.compile( r'decodeURIComponent\(escape.*\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)').findall(embed_source_data)[0]
            t = hunter.hunter(i[0], int(i[1]), i[2], int(i[3]), int(i[4]), int(i[5]))
            m3u8 = re.findall(r'const vdoUrl = \'([^\']*)', t)[0]
            m3u8 = base64.b64decode(m3u8).decode("UTF-8")
            unique_id = re.findall(r"const unqiueId = \'([^\']*)", t)[0]
            scode = re.findall(r'sCode = \'([^\']*)', t)[0]
            ts = re.findall(r'Ts = ([0-9]{10})', t)[0]
            authUrl = {'User-Agent': UA, 'Origin': 'https://www.nolive.me', 'Referer': 'https://www.nolive.me/sd0embed'}
            return m3u8 + '|{0}'.format(urlencode(authUrl))
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def nbahdreplay(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            r = re.findall('iframe(?:.*?src=")([^"]*)', page_data)[0]
            r = r.replace('//', 'https://')
            return r
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def helena(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            w = re.findall('source: "([^"]*)', page_data)[0]
            return w + '|Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def papahd(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            r1 = re.findall('(?s)<iframe src="([^"]*)', page_data)[0]
            u2 = requests.get(r1, headers={'User-Agent': UA, 'Referer': url}).text
            fid = re.findall('fid="([^"]*)', u2)[0]
            r3 = re.findall('(?s)fid.*?src="([^"]*)', u2)[0]
            u3 = requests.get('https:' + r3, headers={'User-Agent': UA, 'Referer': r1}).text
            embedded = re.findall('(?s)embedded .*?: "([^"]*)', u3)[0]
            link = re.findall('(?s).*?src="([^=]*)', u3)[0]
            final_link = link + '=' + embedded + '&live=' + fid
            return final_link + '|User-Agent=' + UA + '&Referer=' + r1
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def fightpass(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            x = re.findall(r'(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
            return x + '|User-Agent=' + UA + '&Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def solaris(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            r = re.findall(r'(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
            return r + '|User-Agent=' + UA + '&Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def sportnews(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            l = re.findall(r'atob\(\'([^\']*)', page_data)[0]
            l = base64.b64decode(l).decode('utf-8')
            return l + '|User-Agent=' + UA + '&Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def sportsnest(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            # Missing function in upstream - fallback to generic resolver
            xbmc.log('[Sportsnest] Using generic resolver (function missing in upstream)', xbmc.LOGWARNING)
            return self.generic(url)
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def beast(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            white = re.findall('(?s)<iframe.*?src="([^"]*)', page_data)[0]
            hat = requests.get(white, headers={'User-Agent': UA, 'Referer': url}).text
            items = re.findall(r'=\\s*(\\[[^;]+)', hat)[0]
            items = re.findall('"(.+?)"', items)
            subitem = int(re.findall(r'atob.+?-\\s*(\\d+)', hat)[0])
            srp = ''
            for item in items:
                srp += chr(int(re.sub(r'[^\\d]', '', base64.b64decode(item).decode('utf-8'))) - subitem)
            link = re.findall("source: '([^']*)", srp)[0]
            return link + '|User-Agent=' + UA + '&Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def elixx(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            w = re.findall(r'(?s)iframe-wrapper">\s*<iframe src="([^"]*)', page_data)[0]
            h = 'http://elixx.xyz' + w
            i = requests.get(h, headers={'User-Agent': UA, 'Referer': url}).text
            t = re.findall('<iframe src="([^"]*)', i)[0]
            white = 'https:' + t
            e = requests.get(white, headers={'User-Agent': UA, 'Referer': t}).text
            z = re.findall('(?s)<iframe.*?src="([^"]*)', e)[0]
            hat = 'https:' + z
            pink = requests.get(hat, headers={'User-Agent': UA, 'Referer': t}).text
            find = re.findall(r'eval\(function(.+?m3u8.+)', pink)[0]
            the = jsunpack.unpack(find)
            crew = re.findall(r'src=\s*"([^"]*)', the)[0]
            return crew + '|User-Agent=' + UA + '&Referer=' + h
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def worldstreams(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            w = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
            h = requests.get(w, headers={'User-Agent': UA, 'Referer': url}).text
            i = re.findall('<iframe src="([^"]*)', h)[0]
            e = requests.get(i, headers={'User-Agent': UA, 'Referer': i}).text
            crew = re.findall(r'(?:source|src|file):\s*[\'"]([^\'"]+)', e)[0]
            return crew + '|User-Agent=' + UA + '&Referer=' + i
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def nflsportz(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            src = re.findall('iframe.*?src="([^"]*)', page_data)[0]
            src = 'http:' + src if src.startswith('//') else src
            fu = requests.get(src, headers={'User-Agent': UA, 'Referer': url}).text
            hat = re.findall(r'eval\(function(.+?m3u8.+)', fu)[0]
            the = jsunpack.unpack(hat)
            crew = re.findall(r'var\s*src="([^"]*)', the)[0]
            return crew + '|User-Agent=' + UA + '&Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def blacktienba(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            if 'm3u8' in page_data:
                link = re.findall(r'(?:source|src|file):\s*[\'"]([^\'"]+)', page_data)[0]
                return (
                    link
                    + '|User-Agent=' + UA
                    + '&Origin=http://blacktiesports.net'
                    + '&Referer=' + url
                )
            elif 'php' in page_data:
                r = re.findall('(?s)<iframe id="stream.*?src="([^"]*)', page_data)[0]
                u = client.request(r)
                items = re.findall(r'<script>var.*?=\s*(\[[^;]+)', u)[0]
                items = re.findall('"(.+?)"', items)
                subitem = int(re.findall(r'\(atob.+?-\s*(\d+)', u)[0])
                srp = ''
                for item in items:
                    srp += chr(int(re.sub(r'[^\d]', '', base64.b64decode(item).decode('utf-8'))) - subitem)
                link = re.findall(r'atob\(\'([^\']*)', srp)[0]
                link = link.replace(' ', '')
                link = base64.b64decode(link).decode('utf-8')
                return (
                    link
                    + '|User-Agent=' + UA
                    + '&Origin=http://blacktiesports.net'
                    + '&Referer=' + r
                )
            else:
                items = re.findall(r'<script>var.*?=\s*(\[[^;]+)', page_data)[0]
                items = re.findall('"(.+?)"', items)
                subitem = int(re.findall(r'\(atob.+?-\s*(\d+)', page_data)[0])
                srp = ''
                for item in items:
                    srp += chr(int(re.sub(r'[^\d]', '', base64.b64decode(item).decode('utf-8'))) - subitem)
                link = re.findall(r'(?:source|src|file):\s*[\'"]([^\'"]+)', srp)[0]
                link = link.replace(' ', '')
                return (
                    link
                    + '|User-Agent=' + UA
                    + '&Origin=http://blacktiesports.net'
                    + '&Referer=' + url
                )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def ufckhabib(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            t = re.findall('(?s)iframe f.*?src="([^"]*)', page_data)[0]
            fu = requests.get(t, headers={'User-Agent': UA, 'Referer': url}).text
            w = re.findall(r'atob\(\'([^\']*)', fu)[0]
            s = base64.b64decode(w).decode('utf-8')
            return s + '|User-Agent=' + UA + '&Referer=' + t
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def ovostreams(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            hat = re.findall(r'(?s)player-box">\s*<iframe.*?src="([^"]*)', page_data)[0]
            h = requests.get(
                hat,
                headers={
                    'User-Agent': UA,
                    'Referer': 'https://sportstvnow.org/'
                }
            ).text
            s = re.findall(r'source\s*[:=]\s*[\'"]([^\'"]+)', h)[0]
            return s + '|User-Agent=' + UA + '&Referer=' + hat
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def techno(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            w = re.findall(r'iframe\ssrc="([^"]*)', page_data)[0]
            h = client.request(w)
            i = re.findall(r'source:.*?\'.*?\'\'([^\']*)', h)[0]
            return 'https://reels2watch.com/hls/' + i + '|Referer=' + url
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def dubsstreamz(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            if 'm3u8' in page_data:
                t = re.findall(r'var source = \'([^\']*)', page_data)[0]
                return t + '|User-Agent=' + UA + '&Referer=' + url
            else:
                r = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
                u = client.request(r, headers={'User-Agent': UA, 'Referer': 'http://www.dubsstreamz.com'})
                x = re.findall(r'atob\(\'([^\']*)', u)[0]
                t = base64.b64decode(x).decode('utf-8')
                return t + '|User-Agent=' + UA + '&Referer=' + r
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def summerlivestream(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            r = re.findall('<iframe.*?src="([^"]*)', page_data)[0]
            murl = r
            now = int((int(time.time()) + 86400) * 1000)
            source = requests.get(
                murl,
                headers={
                    'User-Agent': UA,
                    'Referer': 'https://sportsbay.org/',
                    'accept': '*/*'
                }
            ).text
            if 'm3u8' in source:
                strurl = (
                    re.findall(
                        r'Clappr.Player[\\w\\W]*?(?:source|src|file)(?:\\s*|):(?:\\s*|)[\'"]([^\'"]+)',
                        source
                    )[0]
                    + '|User-Agent=' + UA
                    + '&Origin=https://freefeds.com'
                    + '&Referer=https://freefeds.com/'
                )
                return strurl
            else:
                teleID = re.findall(r'embed/(\\d+)\\.', source)[0]
                r = requests.get(
                    'https://teleriumtv.com/streams/%s/%s.json' % (teleID, now),
                    headers={
                        'User-Agent': UA,
                        'Referer': 'https://teleriumtv.com/embed/%s.html' % teleID,
                        'accept': '*/*'
                    },
                    cookies={'volume': '0'}
                ).json()
                strurl = r.get('url')
                netloc = 'https://teleriumtv.com'
                headers = {
                    'User-Agent': UA,
                    'Origin': netloc,
                    'Referer': 'https://teleriumtv.com/embed/%s.html' % teleID
                }
                if r.get('tokenurl'):
                    strurl += requests.get(netloc + r.get('tokenurl'), headers=headers).json()[10][::-1]
                strurl = strurl if strurl.startswith('http') else 'https:' + strurl
                return strurl + '|{0}'.format(urlencode(headers))
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def epicmartial(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            headers = {
                "Referer": "https://castweb.xyz",
                "User-Agent": UA
            }
            page_data = requests.get(url, headers=headers).text
            fid = re.findall(r'fid\s*=\s*"([^"]+)"', page_data)[0]
            x = 'https://processbigger.com/maestrohd1.php?player=mobile&live=' + fid
            r = requests.get(x, headers=headers).text
            match = re.search(r'return\(\[([^\]]+)\]\.join\(""\)', r)
            array_content = match[1]
            chars = re.findall(r'"([^"]+)"', array_content)
            joined = ''.join(chars).replace(r'\/', '/')
            joined = joined.replace('https://///', 'https://').replace('https:////', 'https://').replace('https:///', 'https://')
            return (
                joined
                + '|Referer=https://processbigger.com/'
                + '&Origin=https://processbigger.com'
                + '&User-Agent=' + UA
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def volokit(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            m = re.search(r'(?s)<iframe[^>]*allow=[\'"]encrypted-media[^>]*src=[\'"]([^\'"]+)',page_data)
            iframe_url = m[1]
            if 'wikisport' in iframe_url:
                page_data = requests.get(iframe_url).text
                m = re.search(r'fid\s*=\s*"([^"]+)"', page_data)
                fid = m[1]
                headers = {"Referer": "https://wikisport.club/","User-Agent": UA,}
                api_url = 'https://stellarthread.com/wiki.php?player=mobile&live=' + fid
                r = requests.get(api_url, headers=headers).text
                m = re.search(r'return\(\[([^\]]+)\]\.join\(""\)', r)
                array_content = m[1]
                chars = re.findall(r'"([^"]+)"', array_content)
                joined = ''.join(chars).replace(r'\/', '/')
                for _ in range(3):
                    joined = joined.replace('https://///', 'https://')
                    joined = joined.replace('https:////', 'https://')
                    joined = joined.replace('https:///', 'https://')
                final_url = joined
                return (
                    final_url
                    + '|Referer=https://stellarthread.com/'
                    + '&Origin=https://stellarthread.com'
                    + '&User-Agent=' + UA
                )
            else:
                iframe_url = m[1]
                iframe_html = client.request(iframe_url)
                if not iframe_html:
                    return
                m = re.search(r'source\s*[:=]\s*[\'"]([^\'"]+)', iframe_html)
                if not m:
                    return
                src = m[1]
                u = urlparse(url)
                origin = f'{u.scheme}://{u.netloc}'
                return (
                    f"{src}"
                    f"|User-Agent={UA}"
                    f"&Referer={origin}/"
                    f"&Origin={origin}"
                )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return


    def basketballvideo(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            x = re.findall('(?s)style-default" href="([^"]*)', page_data)[0]
            f = client.request(x)
            s = re.findall('(?s)<iframe.*?src="([^"]*)', f)[0]
            return s
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def nflvideo(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            x = re.findall('(?s)Full Game Replay.*?<iframe.*?src="([^"]*)', page_data)[0]
            return x
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def naughtyblog(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            html = requests.get(url).text
            if not html:
                return
            part = html.split('<strong>Download:', 1)
            if len(part) < 2:
                return
            segment = part[1]
            part = segment.split('<strong>Watch online:', 1)
            if len(part) > 1:
                segment = part[0]
            links = re.findall(
                r'(?is)<a\s+href="([^"]+)"[^>]*>([^<]+)</a>',
                segment
            )
            hosts = ['Rapidgator']
            results = []
            for href, label in links:
                if any(h in href for h in hosts):
                    clean_url = href.strip()
                    clean_label = label.replace('Direct Link', '').strip()
                    results.append((clean_url, clean_label))
            return results or None
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return


    def fsportshd(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            headers = {"Referer": "https://fsportshd1.xyz/","User-Agent": UA,}
            page_data = requests.get(url, headers=headers).text
            m = re.search(r'fid\s*=\s*"([^"]+)"', page_data)
            fid = m[1]
            api_url = 'https://stellarthread.com/footy.php?player=mobile&live=' + fid
            r = requests.get(api_url, headers=headers).text
            m = re.search(r'return\(\[([^\]]+)\]\.join\(""\)', r)
            array_content = m[1]
            chars = re.findall(r'"([^"]+)"', array_content)
            joined = ''.join(chars).replace(r'\/', '/')
            for _ in range(3):
                joined = joined.replace('https://///', 'https://')
                joined = joined.replace('https:////', 'https://')
                joined = joined.replace('https:///', 'https://')
            final_url = joined
            return (
                final_url
                + '|Referer=https://stellarthread.com/'
                + '&Origin=https://stellarthread.com'
                + '&User-Agent=' + UA
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def meth(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            page_data = requests.get(url).text
            m = re.search(r'const allStreams.*?ue":"([^"]+)', page_data, re.S)
            json_url = m[1].replace('\\', '')
            json_data = requests.get(json_url, headers={'User-Agent': UA, 'Referer': url}).text
            m = re.search(r"fetch\('([^']+)", json_data)
            fetch_path = m[1]
            api_url = 'https://sharkstreams.net/' + fetch_path
            api_data = requests.get(api_url, headers={'User-Agent': UA, 'Referer': json_url}).text
            m = re.search(r'\["([^"]+)', api_data)
            final_url = m[1].replace('\\', '')
            refer = api_url + '/'
            origin = api_url.split('/', 3)[:3]
            origin = '/'.join(origin)
            return f"{final_url}|User-Agent={UA}&Referer={refer}&Origin={origin}"
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def roxie(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            headers = {"Referer": "https://roxiestreams.info/","User-Agent": UA,}
            page_data = requests.get(url, headers=headers).text
            if not page_data:
                return
            if 'getRandomStream' in page_data:
                pattern = r"getRandomStream\(\s*'([^']+)'\s*,\s*'([^']+)'\s*\)"
                stream_calls = set(re.findall(pattern, page_data))
                if not stream_calls:
                    return
                try:
                    domain_text = client.request('https://roxiestreams.info/domains.txt')
                    domains = [d.strip() for d in domain_text.splitlines() if d.strip()]
                except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
                    domains = ['shadow-ran.online']
                m3u8_list = []
                for stream_path, subdomain in stream_calls:
                    domain = random.choice(domains)
                    m3u8_list.append(f'https://{subdomain}.{domain}/{stream_path}')
                if not m3u8_list:
                    return
            else:
                m3u8_list = re.findall(
                    r'https?://[^\s\'"]+\.m3u8',
                    page_data,
                    re.DOTALL
                )
                if not m3u8_list:
                    return
            if len(m3u8_list) == 1:
                stream_url = m3u8_list[0]
            else:
                labels = [f'Stream {i+1}' for i in range(len(m3u8_list))]
                choice = xbmcgui.Dialog().select('Select Stream', labels)
                if choice == -1:
                    return
                stream_url = m3u8_list[choice]
            u = urlparse(url)
            origin = f'{u.scheme}://{u.netloc}'
            return (
                stream_url
                + '|User-Agent=' + UA
                + '&Referer=' + url
                + '&Origin=' + origin
            )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def streameast_ga(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            html = requests.get(url, headers={"User-Agent": UA}).text
            def get_iframe_src(data):
                m = re.search(r'<iframe[^>]+(?:src|data-src)=["\']([^"\']+)', data, re.I)
                if not m:
                    return None
                src = m[1].strip()
                return "https:" + src if src.startswith("//") else src
            iframe1 = get_iframe_src(html)
            if not iframe1:
                return
            iframe1_html = requests.get(
                iframe1,
                headers={"Referer": url, "User-Agent": UA}
            ).text
            if 'embedhd' in iframe1:
                fid = re.search(r'fid\s*=\s*"([^"]+)"', iframe1_html)[1]
                player = "https://exposestrat.com/maestrohd1.php?player=embedded&live=" + fid
                player_html = requests.get(
                    player,
                    headers={"Referer": iframe1, "User-Agent": UA}
                ).text
                m3u8 = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', player_html)[1]
                return (
                    f"{m3u8}"
                    f"|Referer={iframe1}"
                    f"&User-Agent={UA}"
                )
            else:
                iframe2 = get_iframe_src(iframe1_html)
                if not iframe2:
                    return
                iframe2_html = requests.get(
                    iframe2,
                    headers={"Referer": iframe1, "User-Agent": UA}
                ).text
                m = re.search(r'input:\s*"([^"]+)"', iframe2_html)
                if not m:
                    return
                token = m[1]
                decrypt_url = "https://streams.center/embed/decrypt.php"
                hls_url = requests.post(
                    decrypt_url,
                    data={"input": token},
                    headers={
                        "User-Agent": UA,
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Referer": iframe2
                    },
                    timeout=10
                ).text.strip()
                return (
                    f"{hls_url}"
                    f"|Referer=https://streams.center/"
                    f"&User-Agent={UA}"
                )
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def topstreams(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            headers = {"User-Agent": UA, "Referer": url}
            html = client.request(url, headers=headers)
            m = re.search(r'src=["\'](/js/[a-z0-9]+\.js)["\']', html)
            if not m:
                return None
            js_url = urljoin(url, m[1])
            js = requests.get(js_url, headers=headers).text
            g = re.search(r'globalurl\s*=\s*[\'"]([^\'"]+)', js)
            if not g:
                return None
            manifest = g[1].replace(r'\/','/')
            import uuid
            guid = str(uuid.uuid4())
            manifest = manifest + "&sessionId=" + guid
            clearkeys = {}
            ck = re.search(r'masterinf\s*=\s*\{([^}]+)\}', js)
            if ck:
                pairs = re.findall(
                    r'"([0-9a-fA-F]{32})"\s*:\s*"([0-9a-fA-F]{32})"',
                    ck[1]
                )
                for kid, key in pairs:
                    clearkeys[kid.lower()] = key.lower()
            drm = None
            if clearkeys:
                drm = {"type": "clearkey", "keys": clearkeys}
            return {
                "url": manifest,
                "drm": drm
            }
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

    def trendy(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            headers = {
                "User-Agent": UA,
                "Referer": url
            }
            page_data = requests.get(url, headers=headers, timeout=10).text
            m = re.search(r'<iframe[^>]+src=["\']([^"\']+)', page_data, re.I)
            if not m:
                return
            iframe = m[1].strip()
            if iframe.startswith('//'):
                iframe = 'https:' + iframe
            if not iframe.startswith('http'):
                iframe = urljoin(url, iframe)
            iframe = iframe.split('#')[0]
            return self.embedsports(iframe)
        except Exception as e:
            xbmc.log(f"[Trendy Resolver Error] {e}", xbmc.LOGINFO)
            return

    def embedsports(self, url):
        try:
            if control.infoLabel('Container.PluginName') != 'plugin.video.thecrew': return
            parts = url.rstrip('/').split('/')
            if 'embed' in parts:
                idx = parts.index('embed')
                stream_sc = parts[idx + 1]
                stream_id = parts[idx + 2] if len(parts) > idx + 2 else '1'
                stream_no = '1'
            else:
                if len(parts) < 3:
                    return
                stream_sc, stream_id, stream_no = parts[-3:]
            payload = bytes([
                0x0A, len(stream_sc), *stream_sc.encode("utf-8"),
                0x12, len(stream_id), *stream_id.encode("utf-8"),
                0x1A, len(stream_no), *stream_no.encode("utf-8")
            ])
            fetch = requests.post(
                "https://embedsports.top/fetch",
                data=payload,
                headers={"Content-Type": "application/octet-stream"},
                timeout=10
            )
            if not fetch.content:
                return
            cipher_len = fetch.content[1]
            cipher = fetch.content[-cipher_len:]
            decoded = bytes([x - 47 if x >= 0x50 else x + 47 for x in cipher])
            b64 = base64.b64decode(decoded)
            aes_key = fetch.headers.get("What")
            if not aes_key:
                return
            if not CRYPTO_AVAILABLE:
                xbmc.log("[Embedsports] pycryptodome not available - install 'pycryptodome' package", xbmc.LOGWARNING)
                return
            aes_key = aes_key.encode("utf-8")
            aes_iv = b"STOPSTOPSTOPSTOP"
            aes_counter = Counter.new(
                128,
                initial_value=int.from_bytes(aes_iv, "big")
            )
            aes = AES.new(aes_key, AES.MODE_CTR, counter=aes_counter)
            decrypted = aes.decrypt(b64).decode("utf-8")
            xbmc.log(f"[Embedsports] Stream URL: {decrypted}", xbmc.LOGINFO)
            headers = (
                f'User-Agent={UA}'
                f'&Referer={url}'
                f'&Origin=https://embedsports.top'
            )
            return decrypted + "|" + headers
        except Exception as e:
            xbmc.log(f"[Embedsports Resolver Error] {e}", xbmc.LOGINFO)
            return

    def streambtw(self, url):
        try:
            html = requests.get(url, headers={'User-Agent': UA}).text
            encoded = re.search(r'encoded\s*=\s*"([^"]+)"', html)[1]
            stream = base64.b64decode(encoded).decode()
            return stream
        except (requests.RequestException, IndexError, AttributeError, TypeError, ValueError, KeyError):
            return

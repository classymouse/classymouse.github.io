# -*- coding: utf-8 -*-

'''
 *******************************************************cm**
 * The Crew Add-on - Progress Indexer
 *
 * @package script.module.thecrew
 *
 * Clean implementation of Trakt progress features using new model classes.
 * Provides three main features:
 *   1. In Progress Shows - TV shows you're watching (alphabetical, show posters)
 *   2. Next Episodes - Next unwatched episodes to watch (auto-advance)
 *   3. In Progress Episodes - Episodes with resume points (partially watched)
 *
 * @copyright (c) 2025-2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 *******************************************************cm**
'''

import concurrent.futures
import threading
import traceback
from contextlib import suppress

from ..models.tvshow import TVShow
from ..models.episode import Episode
from ..modules import trakt
from ..modules import cache
from ..modules import control
from ..modules import workers
from ..modules import keys
from ..modules.crewruntime import c


class Progress:
    """
    Indexer for Trakt progress features.
    Uses clean model classes (TVShow, Episode) instead of monolithic approach.
    """

    def __init__(self):
        self.list = []
        self.trakt_user = c.get_setting('trakt.username').strip()
        self.lang = control.apiLanguage()['trakt']
        self.hidecinema = c.get_setting('hidecinema') == 'true'

        # Trakt API endpoints
        self.progress_link = 'https://api.trakt.tv/sync/watched/shows'
        self.trakthistory_link = 'https://api.trakt.tv/sync/history/episodes?limit=25'

    def get_in_progress_shows(self):
        """
        Get list of TV shows user is currently watching.
        Returns show-level objects (not episodes) alphabetically sorted.

        Filters out:
        - Shows that are both ended AND fully watched
        - Shows hidden from calendar via Trakt

        When set to ICONS view, shows TV show posters (like Gears).
        User can select show to see seasons/episodes.

        Returns:
            list: List of TVShow objects as dicts
        """
        try:
            c.log("[Progress] Fetching In Progress Shows")

            # Get hidden shows from Trakt (to filter them out)
            hidden_shows = set()
            try:
                hidden_url = "https://api.trakt.tv/users/hidden/calendar?type=show&limit=1000"
                hidden_result = trakt.getTraktAsJson(hidden_url)
                if hidden_result:
                    hidden_shows = {
                        str(item.get('show', {}).get('ids', {}).get('trakt'))
                        for item in hidden_result
                        if item.get('show', {}).get('ids', {}).get('trakt')
                    }
                    c.log(f"[Progress] Found {len(hidden_shows)} hidden shows")
            except Exception as e:
                c.log(f"[Progress] Could not fetch hidden shows: {e}")

            # Get progress from Trakt
            url = f"{self.progress_link}?extended=full"
            result = trakt.getTraktAsJson(url)

            if not result:
                c.log("[Progress] No Trakt progress data")
                self.list = []
                self.shows_directory(self.list)
                return self.list

            shows = []

            # Thread-safe counter for filtered ended/fully watched shows
            filtered_ended_count = {'count': 0}
            filtered_ended_lock = threading.Lock()

            def process_show(item):
                """Process single show from Trakt progress."""
                try:
                    # Get show data for filtering
                    show_data = item.get('show', {})
                    status = show_data.get('status', '').lower()
                    aired_episodes = int(show_data.get('aired_episodes', 0))

                    # Get show IDs
                    show_ids = show_data.get('ids', {})
                    trakt_id = str(show_ids.get('trakt', '0'))

                    # FILTER 1: Exclude hidden shows
                    if trakt_id in hidden_shows:
                        c.log(f"[Progress] Filtering out hidden show: {show_data.get('title')}")
                        return None

                    # Calculate what episode user is on
                    seasons = item.get('seasons', [])
                    if isinstance(seasons, dict):
                        seasons = list(seasons.values())

                    # Count watched episodes (excluding specials - season 0)
                    watched_count = sum(
                        len(s.get('episodes', []))
                        for s in seasons
                        if s.get('number', 0) > 0
                    )

                    # FILTER 2: Exclude shows that are BOTH ended AND fully watched
                    if status in ['ended', 'canceled'] and watched_count >= aired_episodes and aired_episodes > 0:
                        with filtered_ended_lock:
                            filtered_ended_count['count'] += 1
                        return None

                    # Create TVShow from Trakt data
                    show = TVShow.from_trakt_progress(item)
                    if not show:
                        return None

                    # Find last watched episode
                    last_season = 0
                    last_episode = 0
                    last_timestamp = None

                    sorted_seasons = sorted(
                        [s for s in seasons if s.get('number', 0) > 0],
                        key=lambda s: s.get('number', 0)
                    )

                    for s in sorted_seasons:
                        season_num = s.get('number')
                        eps = s.get('episodes') or []

                        for e in eps:
                            if e.get('last_watched_at'):
                                if last_timestamp is None or e.get('last_watched_at') > last_timestamp:
                                    last_season = season_num
                                    last_episode = e.get('number')
                                    last_timestamp = e.get('last_watched_at')

                    show.last_watched_season = last_season
                    show.last_watched_episode = last_episode
                    show.last_watched_at = last_timestamp

                    # Fetch metadata from TMDB (includes season poster fallback)
                    fetch_success = show.fetch_tmdb_metadata(extended=True)
                    if not fetch_success:
                        c.log(f"[Progress] TMDB metadata fetch failed for: {show.tvshowtitle} (TMDB: {show.tmdb}, IMDB: {show.imdb})")

                    return show

                except Exception as e:
                    c.log(f"[Progress] Error processing show: {e}")
                    return None

            # Process shows in parallel
            max_threads = c.get_max_threads(len(result))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = [executor.submit(process_show, item) for item in result]

                for future in concurrent.futures.as_completed(futures):
                    with suppress(Exception):
                        show = future.result()
                        if show:
                            shows.append(show.to_dict())

            # Sort by last_watched_at (most recent first)
            shows.sort(
                key=lambda x: x.get('last_watched_at') or '1900-01-01T00:00:00.000Z',
                reverse=True
            )

            # Log summary of filtered shows
            if filtered_ended_count['count'] > 0:
                c.log(f"[Progress] Filtered out {filtered_ended_count['count']} ended and fully watched shows")

            c.log(f"[Progress] Returning {len(shows)} In Progress Shows (sorted by most recent)")
            self.list = shows
            self.shows_directory(self.list)
            return self.list

        except Exception as e:
            c.log(f"[Progress] Error in get_in_progress_shows: {e}")
            self.list = []
            self.shows_directory(self.list)
            return self.list

    def get_next_episodes(self):
        """
        Get next unwatched episodes user should watch.
        Auto-advances to first unwatched episode of each show.

        Returns episode-level objects with episode stills (like Gears).

        Returns:
            list: List of Episode objects as dicts
        """
        try:
            c.log("[Progress] Fetching Next Episodes")

            # Get progress from Trakt (with ETag-based caching, 5 min TTL)
            url = f"{self.progress_link}?extended=full"

            def fetch_progress_data(conditional_headers=None):
                """Fetch Trakt progress data with conditional headers."""
                result = trakt.get_trakt(url, conditional_headers=conditional_headers)
                return result  # Returns (text, headers, status_code)

            cache_key = f"trakt_next_episodes_{hash(url)}"
            result = cache.get_with_etag(cache_key, fetch_progress_data, ttl_seconds=300, namespace='trakt')

            if not result:
                c.log("[Progress] No Trakt progress data - check Trakt authentication")
                # Show user-friendly message instead of empty widget
                from resources.lib.modules import control
                control.infoDialog("Please check Trakt authentication in The Crew settings", heading="Next Episodes Unavailable")
                self.list = []
                self.episodes_directory(self.list)
                return self.list

            # Detect if we're loading in a widget to optimize performance
            is_widget = c.is_widget_listing()

            # Widget fast-path requires warm cache - check cache availability first
            if is_widget:
                # Sample first few shows to check if cache has artwork
                cache_hits = 0
                cache_checks = 0
                from ..modules import http_client

                for item in result[:min(5, len(result))]:  # Check first 5 shows
                    show_data = item.get('show', {})
                    show_ids = show_data.get('ids', {})
                    show_tmdb = str(show_ids.get('tmdb', '0'))

                    if show_tmdb and show_tmdb != '0':
                        cache_checks += 1
                        try:
                            url_artwork = f"https://api.themoviedb.org/3/tv/{show_tmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"
                            key = cache._hash_function(http_client.tmdb_get_json, url_artwork)
                            cached = cache.cache_get(key, timeout=None)

                            if cached:
                                import json
                                response = json.loads(cached['value']) if isinstance(cached['value'], str) else cached['value']
                                if response and isinstance(response, dict) and (response.get('poster_path') or response.get('backdrop_path')):
                                    cache_hits += 1
                        except:
                            pass

                # Only use widget fast-path if cache is warm (>60% hit rate)
                if cache_checks > 0:
                    cache_hit_rate = cache_hits / cache_checks
                    if cache_hit_rate < 0.6:
                        c.log(f"[Progress] Cache cold ({cache_hits}/{cache_checks} hits = {cache_hit_rate:.0%}) - using normal fetch for quality")
                        is_widget = False  # Force normal path with proper artwork
                    else:
                        c.log(f"[Progress] Cache warm ({cache_hits}/{cache_checks} hits = {cache_hit_rate:.0%}) - using fast widget path")
                else:
                    c.log("[Progress] Cannot determine cache warmth - using normal fetch")
                    is_widget = False

            if is_widget:
                c.log("[Progress] Widget fast-path enabled - using cached artwork only")

            episodes = []

            # Shared artwork cache for all episodes (avoids redundant fetches for same show)
            # Key: show_tmdb_id, Value: {poster, fanart, banner, clearlogo, etc.}
            artwork_cache = {}

            # Track shows missing artwork in widget mode (for background population)
            shows_needing_artwork = set()

            # In widget mode: Skip artwork pre-fetch entirely for instant load
            # Artwork will be fetched on-demand from cache during episode processing
            if not is_widget:
                # Normal mode: Pre-populate show artwork (fast, parallel, ~1-2 seconds)
                unique_show_ids = set()
                for item in result:
                    show_data = item.get('show', {})
                    show_ids = show_data.get('ids', {})
                    show_tmdb = str(show_ids.get('tmdb', '0'))
                    if show_tmdb and show_tmdb != '0':
                        unique_show_ids.add(show_tmdb)

                c.log(f"[Progress] Pre-fetching artwork for {len(unique_show_ids)} unique shows")

                def fetch_show_artwork(show_tmdb):
                    """Fetch and cache show artwork."""
                    # Skip if show_tmdb is invalid
                    if not show_tmdb or show_tmdb in ('None', '0'):
                        c.log(f"[Progress] Skipping artwork fetch for invalid show_tmdb: {show_tmdb}")
                        return show_tmdb, {}

                    try:
                        from ..modules import http_client
                        url = f"https://api.themoviedb.org/3/tv/{show_tmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"
                        response = cache.get(http_client.tmdb_get_json, 24, url, 16)

                        if response:
                            artwork = {}
                            if poster_path := response.get('poster_path'):
                                artwork['poster'] = f"https://image.tmdb.org/t/p/{c.tmdb_postersize}{poster_path}"
                            if backdrop_path := response.get('backdrop_path'):
                                artwork['fanart'] = f"https://image.tmdb.org/t/p/{c.tmdb_fanartsize}{backdrop_path}"
                            return show_tmdb, artwork
                    except Exception as e:
                        c.log(f"[Progress] Error fetching artwork for show {show_tmdb}: {e}")
                    return show_tmdb, {}

                # Fetch artwork for all unique shows in parallel
                with concurrent.futures.ThreadPoolExecutor(max_workers=min(10, len(unique_show_ids))) as executor:
                    futures = [executor.submit(fetch_show_artwork, sid) for sid in unique_show_ids]
                    for future in concurrent.futures.as_completed(futures):
                        with suppress(Exception):
                            show_id, artwork = future.result()
                            if artwork:
                                artwork_cache[show_id] = artwork

                c.log(f"[Progress] Artwork cache populated: {len(artwork_cache)} shows")
                if artwork_cache:
                    sample_id = list(artwork_cache.keys())[0]
                    c.log(f"[Progress] Sample artwork cache entry: {sample_id} -> {artwork_cache[sample_id]}")
            else:
                c.log("[Progress] Widget mode - skipping artwork pre-fetch for instant load")

            # Batch load episode cache for all shows (10-50x faster than individual queries per episode)
            episode_cache_dict = {}
            if unique_show_ids:
                # Filter out invalid IDs (None, 'None', '0') before converting to int
                valid_show_ids = [int(sid) for sid in unique_show_ids if sid and sid != 'None' and sid != '0']
                if valid_show_ids:
                    episode_cache_dict = trakt.batch_load_episode_cache_for_shows(valid_show_ids)

            def process_show(item):
                """Find next unwatched episode for show."""
                try:
                    show_data = item.get('show', {})
                    seasons = item.get('seasons', [])

                    if isinstance(seasons, dict):
                        seasons = list(seasons.values())

                    # Check if all episodes watched
                    num_watched = sum(
                        len(s.get('episodes', []))
                        for s in seasons
                        if s.get('number', 0) > 0
                    )
                    aired_episodes = int(show_data.get('aired_episodes', 0))

                    if num_watched >= aired_episodes and aired_episodes > 0:
                        # All watched, skip
                        return None

                    # Find the highest watched episode
                    sorted_seasons = sorted(
                        [s for s in seasons if s.get('number', 0) > 0],
                        key=lambda s: s.get('number', 0)
                    )

                    next_season = None
                    next_episode_num = None

                    # Find highest watched episode across all seasons
                    # Also capture the most recent watch timestamp for sorting
                    max_season = 0
                    max_episode = 0
                    last_watched_at = None

                    for s in sorted_seasons:
                        season_num = s.get('number')
                        eps = s.get('episodes') or []

                        if eps:
                            max_ep_in_season = max(e.get('number', 0) for e in eps)
                            if season_num > max_season or (season_num == max_season and max_ep_in_season > max_episode):
                                max_season = season_num
                                max_episode = max_ep_in_season
                                # Get the most recent watch timestamp from this episode
                                for ep in eps:
                                    if ep.get('number') == max_ep_in_season:
                                        ep_timestamp = ep.get('last_watched_at')
                                        if ep_timestamp:
                                            last_watched_at = ep_timestamp
                                        break

                    if max_season == 0:
                        # No watched episodes, start at S01E01
                        next_season = 1
                        next_episode_num = 1
                    else:
                        # Try next episode in same season first
                        next_season = max_season
                        next_episode_num = max_episode + 1

                    # Create episode and validate it exists
                    episode = Episode.from_trakt_progress(
                        show_data,
                        next_season,
                        next_episode_num
                    )

                    if episode:
                        # Fetch episode metadata from TMDB to validate it exists
                        # Skip in widgets for instant load (use show backdrop fallback)
                        if is_widget:
                            success = True  # Assume exists, use fallback artwork
                            # Per-episode metadata skip log commented out for performance
                            # c.log(f"[Progress] Widget mode - skipping metadata fetch for {episode.tvshowtitle} S{next_season:02d}E{next_episode_num:02d}")
                        else:
                            success = episode.fetch_tmdb_metadata(episode_cache_dict=episode_cache_dict)

                            # If episode doesn't exist (404), try next season episode 1
                            if not success and next_episode_num > 1:
                                c.log(f"[Progress] S{next_season:02d}E{next_episode_num:02d} doesn't exist, trying S{next_season+1:02d}E01")
                                episode = Episode.from_trakt_progress(
                                    show_data,
                                    next_season + 1,
                                    1
                                )
                                if episode:
                                    success = episode.fetch_tmdb_metadata(episode_cache_dict=episode_cache_dict)

                        if success and episode:
                            # Apply show artwork
                            # In widget mode: artwork_cache is empty, fetch from DB cache on-demand
                            # In normal mode: artwork_cache is pre-populated
                            cached_artwork = None

                            if episode.showtmdb in artwork_cache:
                                cached_artwork = artwork_cache[episode.showtmdb]
                            elif is_widget and episode.showtmdb and episode.showtmdb != '0':
                                # Widget mode: Fetch from cache on-demand (no API call)
                                # IMPORTANT: Only use cached data if it contains valid artwork URLs
                                # Don't use empty/None cached responses (they pollute cache)
                                try:
                                    from ..modules import http_client
                                    url = f"https://api.themoviedb.org/3/tv/{episode.showtmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"

                                    # Check cache directly without triggering API call
                                    # Note: timeout is NOT part of cache key, only function + url
                                    key = cache._hash_function(http_client.tmdb_get_json, url)
                                    # Widget mode: ignore TTL, use stale data (better than fallbacks)
                                    # Background fetch will update cache with fresh data
                                    cached = cache.cache_get(key, timeout=None)  # Ignore expiration

                                    if cached:
                                        import json
                                        response = json.loads(cached['value']) if isinstance(cached['value'], str) else cached['value']

                                        # Validate cached response contains actual artwork data
                                        # If cache contains None/empty/error response, skip it
                                        if response and isinstance(response, dict) and (response.get('poster_path') or response.get('backdrop_path')):
                                            cached_artwork = {}
                                            if poster_path := response.get('poster_path'):
                                                cached_artwork['poster'] = f"https://image.tmdb.org/t/p/{c.tmdb_postersize}{poster_path}"
                                            if backdrop_path := response.get('backdrop_path'):
                                                cached_artwork['fanart'] = f"https://image.tmdb.org/t/p/{c.tmdb_fanartsize}{backdrop_path}"
                                            # Store in artwork_cache for other episodes from same show
                                            artwork_cache[episode.showtmdb] = cached_artwork
                                        else:
                                            c.log(f"[Progress] Widget cache invalid for {episode.tvshowtitle} - cached response empty or malformed")
                                            # Track for background population
                                            shows_needing_artwork.add(episode.showtmdb)
                                except Exception as e:
                                    c.log(f"[Progress] Widget cache read error for {episode.tvshowtitle}: {e}")
                                    # Track for background population
                                    shows_needing_artwork.add(episode.showtmdb)

                            if cached_artwork:
                                if 'poster' in cached_artwork and cached_artwork['poster']:
                                    episode.poster = cached_artwork['poster']
                                if 'fanart' in cached_artwork and cached_artwork['fanart']:
                                    episode.fanart = cached_artwork['fanart']

                                    # Use show backdrop as episode thumb if still is missing
                                    # (same dimensions, better than default Crew art, already cached)
                                    if not episode.thumb or episode.thumb == '0':
                                        episode.thumb = episode.fanart

                                # Per-episode artwork logs commented out for performance (200+ episodes)
                                # c.log(f"[Progress] Applied cached artwork for {episode.tvshowtitle}")
                            else:
                                # c.log(f"[Progress] No valid artwork in cache for {episode.tvshowtitle} - using defaults")
                                pass
                                # Track for background population in widget mode
                                if is_widget and episode.showtmdb and episode.showtmdb != '0':
                                    shows_needing_artwork.add(episode.showtmdb)

                            # Store last_watched_at for sorting
                            episode.last_watched_at = last_watched_at

                            return episode

                    return None

                except Exception as e:
                    c.log(f"[Progress] Error processing show for next episode: {e}")
                    return None

            # Process shows in parallel
            max_threads = c.get_max_threads(len(result))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = [executor.submit(process_show, item) for item in result]

                for future in concurrent.futures.as_completed(futures):
                    with suppress(Exception):
                        episode = future.result()
                        if episode:
                            episodes.append(episode.to_dict())

            # Sort by last_watched_at (most recent first)
            episodes.sort(
                key=lambda x: x.get('last_watched_at') or '1900-01-01T00:00:00.000Z',
                reverse=True
            )

            # Summary log instead of per-episode logs (performance optimization)
            cached_count = len(artwork_cache)
            total_shows = len(set(ep.get('showid') or ep.get('tmdb') or '0' for ep in episodes if (ep.get('showid') or ep.get('tmdb'))))
            c.log(f"[Progress] Applied cached artwork for {cached_count}/{total_shows} unique shows in Next Episodes")
            if is_widget:
                c.log(f"[Progress] Widget mode - skipped metadata fetch for {len(episodes)} episodes (instant load)")
            c.log(f"[Progress] Returning {len(episodes)} Next Episodes (sorted by last watched)")

            # Background artwork population for widgets (instant load + auto-refresh)
            if is_widget and shows_needing_artwork:
                c.log(f"[Progress] Starting background artwork fetch for {len(shows_needing_artwork)} shows")

                def populate_widget_cache():
                    """Background thread to populate artwork cache for next widget load."""
                    try:
                        from ..modules import http_client
                        fetched_count = 0

                        # Fetch artwork for shows that had cache misses
                        for show_tmdb in shows_needing_artwork:
                            try:
                                url = f"https://api.themoviedb.org/3/tv/{show_tmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"
                                response = cache.get(http_client.tmdb_get_json, 24, url, 16)
                                if response and (response.get('poster_path') or response.get('backdrop_path')):
                                    fetched_count += 1
                            except Exception as e:
                                c.log(f"[Progress] Background fetch error for show {show_tmdb}: {e}")

                        c.log(f"[Progress] Background fetch complete: {fetched_count}/{len(shows_needing_artwork)} shows cached")
                        c.log("[Progress] Artwork cached silently - will appear on next widget refresh (navigate/F5/timer)")

                    except Exception as e:
                        c.log(f"[Progress] Background population error: {e}")

                # Start background thread (daemon so it doesn't block Kodi shutdown)
                import threading
                bg_thread = threading.Thread(target=populate_widget_cache, daemon=True, name="CrewWidgetArtwork")
                bg_thread.start()

            self.list = episodes
            self.episodes_directory(self.list)
            return self.list

        except Exception as e:
            c.log(f"[Progress] Error in get_next_episodes: {e}")
            self.list = []
            self.episodes_directory(self.list)
            return self.list

    def get_in_progress_episodes(self):
        """
        Get episodes with resume points (partially watched).
        Shows episodes user started but hasn't finished (resume_point > 0%).

        Returns episode-level objects with episode stills (like Gears).

        Returns:
            list: List of Episode objects as dicts
        """
        try:
            c.log("[Progress] Fetching In Progress Episodes")

            # Get playback progress from Trakt (with ETag-based caching, 5 min TTL)
            url = "https://api.trakt.tv/sync/playback/episodes?extended=full"

            def fetch_playback_data(conditional_headers=None):
                """Fetch Trakt playback data with conditional headers."""
                result = trakt.get_trakt(url, conditional_headers=conditional_headers)
                return result  # Returns (text, headers, status_code)

            cache_key = f"trakt_playback_episodes_{hash(url)}"
            result = cache.get_with_etag(cache_key, fetch_playback_data, ttl_seconds=300, namespace='trakt')

            if not result:
                c.log("[Progress] No Trakt playback progress data")
                self.list = []
                self.episodes_directory(self.list)
                return self.list

            # Detect if we're loading in a widget to optimize performance
            is_widget = c.is_widget_listing()

            # Widget fast-path requires warm cache - check cache availability first
            if is_widget:
                # Sample first few shows to check if cache has artwork
                cache_hits = 0
                cache_checks = 0
                from ..modules import http_client

                for item in result[:min(5, len(result))]:  # Check first 5 shows
                    show_data = item.get('show', {})
                    show_ids = show_data.get('ids', {})
                    show_tmdb = str(show_ids.get('tmdb', '0'))

                    if show_tmdb and show_tmdb != '0':
                        cache_checks += 1
                        try:
                            url_artwork = f"https://api.themoviedb.org/3/tv/{show_tmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"
                            key = cache._hash_function(http_client.tmdb_get_json, url_artwork)
                            cached = cache.cache_get(key, timeout=None)

                            if cached:
                                import json
                                response = json.loads(cached['value']) if isinstance(cached['value'], str) else cached['value']
                                if response and isinstance(response, dict) and (response.get('poster_path') or response.get('backdrop_path')):
                                    cache_hits += 1
                        except:
                            pass

                # Only use widget fast-path if cache is warm (>60% hit rate)
                if cache_checks > 0:
                    cache_hit_rate = cache_hits / cache_checks
                    if cache_hit_rate < 0.6:
                        c.log(f"[Progress] Cache cold ({cache_hits}/{cache_checks} hits = {cache_hit_rate:.0%}) - using normal fetch for quality")
                        is_widget = False  # Force normal path with proper artwork
                    else:
                        c.log(f"[Progress] Cache warm ({cache_hits}/{cache_checks} hits = {cache_hit_rate:.0%}) - using fast widget path")
                else:
                    c.log("[Progress] Cannot determine cache warmth - using normal fetch")
                    is_widget = False

            if is_widget:
                c.log("[Progress] Widget fast-path enabled - using cached artwork only")

            episodes = []
            artwork_cache = {}  # Cache show-level artwork for performance

            # Track shows missing artwork in widget mode (for background population)
            shows_needing_artwork = set()

            # In widget mode: Skip artwork pre-fetch entirely for instant load
            # Artwork will be fetched on-demand from cache during episode processing
            if not is_widget:
                # Normal mode: Pre-populate show artwork (fast, parallel, ~1-2 seconds)
                unique_show_ids = set()
                for item in result:
                    show_data = item.get('show', {})
                    show_ids = show_data.get('ids', {})
                    show_tmdb = str(show_ids.get('tmdb', '0'))
                    if show_tmdb and show_tmdb != '0':
                        unique_show_ids.add(show_tmdb)

                c.log(f"[Progress] Pre-fetching artwork for {len(unique_show_ids)} unique shows")

                def fetch_show_artwork(show_tmdb):
                    """Fetch and cache show artwork."""
                    # Skip if show_tmdb is invalid
                    if not show_tmdb or show_tmdb in ('None', '0'):
                        c.log(f"[Progress] Skipping artwork fetch for invalid show_tmdb: {show_tmdb}")
                        return show_tmdb, {}

                    try:
                        from ..modules import http_client
                        url = f"https://api.themoviedb.org/3/tv/{show_tmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"
                        response = cache.get(http_client.tmdb_get_json, 24, url, 16)

                        if response:
                            artwork = {}
                            if poster_path := response.get('poster_path'):
                                artwork['poster'] = f"https://image.tmdb.org/t/p/{c.tmdb_postersize}{poster_path}"
                            if backdrop_path := response.get('backdrop_path'):
                                artwork['fanart'] = f"https://image.tmdb.org/t/p/{c.tmdb_fanartsize}{backdrop_path}"
                            return show_tmdb, artwork
                    except Exception as e:
                        c.log(f"[Progress] Error fetching artwork for show {show_tmdb}: {e}")
                    return show_tmdb, {}

                # Fetch artwork for all unique shows in parallel
                with concurrent.futures.ThreadPoolExecutor(max_workers=min(10, len(unique_show_ids))) as executor:
                    futures = [executor.submit(fetch_show_artwork, sid) for sid in unique_show_ids]
                    for future in concurrent.futures.as_completed(futures):
                        with suppress(Exception):
                            show_id, artwork = future.result()
                            if artwork:
                                artwork_cache[show_id] = artwork

                c.log(f"[Progress] Artwork cache populated: {len(artwork_cache)} shows")
                if artwork_cache:
                    sample_id = list(artwork_cache.keys())[0]
                    c.log(f"[Progress] Sample artwork cache entry: {sample_id} -> {artwork_cache[sample_id]}")
            else:
                c.log("[Progress] Widget mode - skipping artwork pre-fetch for instant load")

            def process_episode(item):
                """Process single episode with resume point."""
                try:
                    progress = float(item.get('progress', 0))

                    # Only include if between 0% and 92% (not fully watched)
                    if progress <= 0 or progress >= 92:
                        return None

                    episode_data = item.get('episode', {})
                    show_data = item.get('show', {})

                    season_num = episode_data.get('season')
                    episode_num = episode_data.get('number')

                    if not season_num or not episode_num:
                        return None

                    # Create Episode object
                    episode = Episode.from_trakt_progress(
                        show_data,
                        season_num,
                        episode_num,
                        episode_data
                    )

                    if episode:
                        # Calculate resume point in seconds
                        # Trakt gives progress as percentage and paused_at timestamp
                        episode.resume_point = progress  # Store percentage

                        # Store paused_at for sorting
                        paused_at = item.get('paused_at')
                        if paused_at:
                            episode.last_watched_at = paused_at  # Use for sorting

                        # Fetch episode metadata (includes title, plot, aired date)
                        # Skip in widgets for instant load (use show backdrop fallback)
                        if not is_widget:
                            episode.fetch_tmdb_metadata()
                        else:
                            # Per-episode metadata skip log commented out for performance
                            # c.log(f"[Progress] Widget mode - skipping metadata fetch for {episode.tvshowtitle} S{season_num:02d}E{episode_num:02d}")
                            pass

                        # Apply show artwork
                        # In widget mode: artwork_cache is empty, fetch from DB cache on-demand
                        # In normal mode: artwork_cache is pre-populated
                        cached_artwork = None

                        if episode.showtmdb in artwork_cache:
                            cached_artwork = artwork_cache[episode.showtmdb]
                        elif is_widget and episode.showtmdb and episode.showtmdb != '0':
                            # Widget mode: Fetch from cache on-demand (no API call)
                            # IMPORTANT: Only use cached data if it contains valid artwork URLs
                            # Don't use empty/None cached responses (they pollute cache)
                            try:
                                from ..modules import http_client
                                url = f"https://api.themoviedb.org/3/tv/{episode.showtmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"

                                # Check cache directly without triggering API call
                                # Note: timeout is NOT part of cache key, only function + url
                                key = cache._hash_function(http_client.tmdb_get_json, url)
                                # Widget mode: ignore TTL, use stale data (better than fallbacks)
                                # Background fetch will update cache with fresh data
                                cached = cache.cache_get(key, timeout=None)  # Ignore expiration

                                if cached:
                                    import json
                                    response = json.loads(cached['value']) if isinstance(cached['value'], str) else cached['value']

                                    # Validate cached response contains actual artwork data
                                    # If cache contains None/empty/error response, skip it
                                    if response and isinstance(response, dict) and (response.get('poster_path') or response.get('backdrop_path')):
                                        cached_artwork = {}
                                        if poster_path := response.get('poster_path'):
                                            cached_artwork['poster'] = f"https://image.tmdb.org/t/p/{c.tmdb_postersize}{poster_path}"
                                        if backdrop_path := response.get('backdrop_path'):
                                            cached_artwork['fanart'] = f"https://image.tmdb.org/t/p/{c.tmdb_fanartsize}{backdrop_path}"
                                        # Store in artwork_cache for other episodes from same show
                                        artwork_cache[episode.showtmdb] = cached_artwork
                                    else:
                                        c.log(f"[Progress] Widget cache invalid for {episode.tvshowtitle} - cached response empty or malformed")
                                        # Track for background population
                                        shows_needing_artwork.add(episode.showtmdb)
                            except Exception as e:
                                c.log(f"[Progress] Widget cache read error for {episode.tvshowtitle}: {e}")
                                # Track for background population
                                shows_needing_artwork.add(episode.showtmdb)

                        if cached_artwork:
                            if 'poster' in cached_artwork and cached_artwork['poster']:
                                episode.poster = cached_artwork['poster']
                            if 'fanart' in cached_artwork and cached_artwork['fanart']:
                                episode.fanart = cached_artwork['fanart']

                                # Use show backdrop as episode thumb if still is missing
                                # (same dimensions, better than default Crew art, already cached)
                                if not episode.thumb or episode.thumb == '0':
                                    episode.thumb = episode.fanart

                            # Per-episode artwork logs commented out for performance (200+ episodes)
                            # c.log(f"[Progress] Applied cached artwork for {episode.tvshowtitle}")
                        else:
                            # c.log(f"[Progress] No valid artwork in cache for {episode.tvshowtitle} - using defaults")
                            pass
                            # Track for background population in widget mode
                            if is_widget and episode.showtmdb and episode.showtmdb != '0':
                                shows_needing_artwork.add(episode.showtmdb)

                    return episode

                except Exception as e:
                    c.log(f"[Progress] Error processing episode: {e}")
                    return None

            # Process episodes in parallel
            max_threads = c.get_max_threads(len(result))
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = [executor.submit(process_episode, item) for item in result]

                for future in concurrent.futures.as_completed(futures):
                    with suppress(Exception):
                        episode = future.result()
                        if episode:
                            episodes.append(episode.to_dict())

            # Sort by paused_at (most recent first)
            episodes.sort(
                key=lambda x: x.get('last_watched_at') or x.get('paused_at') or '1900-01-01T00:00:00.000Z',
                reverse=True
            )

            # Summary log instead of per-episode logs (performance optimization)
            cached_count = len(artwork_cache)
            total_shows = len(set(ep.get('showid') or ep.get('tmdb') or '0' for ep in episodes if (ep.get('showid') or ep.get('tmdb'))))
            c.log(f"[Progress] Applied cached artwork for {cached_count}/{total_shows} unique shows in In Progress Episodes")
            if is_widget:
                c.log(f"[Progress] Widget mode - skipped metadata fetch for {len(episodes)} episodes (instant load)")
            c.log(f"[Progress] Returning {len(episodes)} In Progress Episodes (sorted by most recent)")

            # Background artwork population for widgets (instant load + auto-refresh)
            if is_widget and shows_needing_artwork:
                c.log(f"[Progress] Starting background artwork fetch for {len(shows_needing_artwork)} shows")

                def populate_widget_cache():
                    """Background thread to populate artwork cache for next widget load."""
                    try:
                        from ..modules import http_client
                        fetched_count = 0

                        # Fetch artwork for shows that had cache misses
                        for show_tmdb in shows_needing_artwork:
                            try:
                                url = f"https://api.themoviedb.org/3/tv/{show_tmdb}?api_key={keys.tmdb_key}&language={self.lang}&append_to_response=external_ids"
                                response = cache.get(http_client.tmdb_get_json, 24, url, 16)
                                if response and (response.get('poster_path') or response.get('backdrop_path')):
                                    fetched_count += 1
                            except Exception as e:
                                c.log(f"[Progress] Background fetch error for show {show_tmdb}: {e}")

                        c.log(f"[Progress] Background fetch complete: {fetched_count}/{len(shows_needing_artwork)} shows cached")
                        c.log("[Progress] Artwork cached silently - will appear on next widget refresh (navigate/F5/timer)")

                    except Exception as e:
                        c.log(f"[Progress] Background population error: {e}")

                # Start background thread (daemon so it doesn't block Kodi shutdown)
                import threading
                bg_thread = threading.Thread(target=populate_widget_cache, daemon=True, name="CrewWidgetArtwork")
                bg_thread.start()

            self.list = episodes
            self.episodes_directory(self.list)
            return self.list

        except Exception as e:
            c.log(f"[Progress] Error in get_in_progress_episodes: {e}")
            self.list = []
            self.episodes_directory(self.list)
            return self.list

    def shows_directory(self, items):
        """
        Create Kodi directory listing for TV shows.
        Shows show posters in ICONS view.

        Args:
            items (list): List of show dictionaries
        """
        if not items:
            control.idle()
            control.infoDialog(c.lang(32500), sound=False, icon='INFO')
            return

        from ..indexers import tvshows
        from ..modules import playcount
        from ..modules.listitem import ListItemInfoTag
        import sys
        import json
        from urllib.parse import quote_plus

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        trakt_credentials = trakt.get_trakt_credentials_info()
        indicators = playcount.get_tvshow_indicators()
        addon_poster = c.addon_poster()

        for i in items:
            try:
                label = i.get('tvshowtitle', i.get('title', ''))
                imdb = i.get('imdb', '')
                tmdb = i.get('tmdb', '')
                tvdb = i.get('tvdb', '')
                year = i.get('year', '')

                # Use addon poster/fanart as fallback for missing artwork ('0' means not found)
                poster = i.get('poster', addon_poster)
                if poster in ['0', '', None]:
                    poster = addon_poster

                fanart = i.get('fanart', c.addon_fanart())
                if fanart in ['0', '', None]:
                    fanart = c.addon_fanart()

                systitle = quote_plus(label)

                # URL to open seasons list
                url = f'{sysaddon}?action=seasons&tvshowtitle={systitle}&year={year}&imdb={imdb}&tmdb={tmdb}&tvdb={tvdb}'

                # Create listitem
                try:
                    listitem = control.item(label=label, offscreen=True)
                except:
                    listitem = control.item(label=label)

                # Set artwork
                listitem.setArt({
                    'icon': poster,
                    'thumb': poster,
                    'poster': poster,
                    'tvshow.poster': poster,
                    'fanart': fanart
                })

                # Set info using InfoTag
                info_tag = ListItemInfoTag(listitem, 'video')

                infodata = {
                    'title': label,
                    'tvshowtitle': label,
                    'year': year,
                    'plot': i.get('plot', ''),
                    'mediatype': 'tvshow'
                }

                info_tag.set_info(control.tagdataClean(infodata))
                info_tag.set_unique_ids({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})

                # Add to directory
                control.addItem(handle=syshandle, url=url, listitem=listitem, isFolder=True)

            except Exception as e:
                c.log(f"[Progress] Error adding show to directory: {e}")
                continue

        control.content(syshandle, 'tvshows')
        control.directory(syshandle, cacheToDisc=True)

    def episodes_directory(self, items):
        """
        Create Kodi directory listing for episodes.
        Shows episode stills in ICONS view.

        Args:
            items (list): List of episode dictionaries
        """
        if not items:
            control.idle()
            control.infoDialog(c.lang(32500), sound=False, icon='INFO')
            return

        from ..modules import playcount
        from ..modules import bookmarks
        from ..modules.listitem import ListItemInfoTag
        import sys
        import json
        from urllib.parse import quote_plus

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        indicators = playcount.get_tvshow_indicators()
        is_playable = 'plugin' not in control.infoLabel('Container.PluginName')

        # Check Trakt credentials
        trakt_credentials = trakt.get_trakt_credentials_info()

        # Context menu labels (language strings)
        playback_menu = control.lang(32063) if control.setting('hosts.mode') == '2' else control.lang(32064)
        watched_menu = control.lang(32068) if trakt_credentials else control.lang(32066)
        unwatched_menu = control.lang(32069) if trakt_credentials else control.lang(32067)
        queue_menu = control.lang(32065)
        trakt_manager_menu = control.lang(32515)
        add_to_library = control.lang(32551)
        clear_resume_menu = control.lang(90237)
        clear_providers = control.lang(32098)
        infoMenu = control.lang(32101)

        for i in items:
            try:
                label = i.get('title', i.get('label', ''))
                season = str(i.get('season', 0)).zfill(2)
                episode = str(i.get('episode', 0)).zfill(2)
                tvshowtitle = i.get('tvshowtitle', '')

                # Build episode label with TV show title (includes show name for multi-show views)
                ep_label = f'{tvshowtitle} (S{season}E{episode}) : {label}'

                # For episode playback, we need SHOW IDs (episodes don't have their own IMDB/TMDB IDs)
                # If episode-level IDs are missing/invalid, use show-level IDs
                imdb = i.get('imdb', '0')
                if imdb in ['0', '', None]:
                    imdb = i.get('showimdb', '0')

                # Ensure we never pass invalid imdb (use empty string for URL param consistency)
                if imdb in ['0', '', None]:
                    imdb = ''

                tmdb = i.get('tmdb', '0')
                if tmdb in ['0', '', None]:
                    tmdb = i.get('showtmdb', '0')

                # Ensure valid tmdb (should always be available from Trakt)
                if tmdb in ['0', '', None]:
                    tmdb = ''

                tvdb = i.get('tvdb', '0')
                if tvdb in ['0', '', None]:
                    tvdb = i.get('showtvdb', '0')

                year = i.get('year', '')
                duration = i.get('duration', 45) or 45  # minutes, handle empty string

                # Convert to int if string
                try:
                    duration = int(duration)
                except (ValueError, TypeError):
                    duration = 45

                # Get artwork (use addon defaults for missing artwork - '0' means not found)
                thumb = i.get('thumb', c.addon_thumb())
                if thumb in ['0', '', None]:
                    thumb = c.addon_thumb()

                poster = i.get('poster', c.addon_poster())
                if poster in ['0', '', None]:
                    poster = c.addon_poster()

                fanart = i.get('fanart', c.addon_fanart())
                if fanart in ['0', '', None]:
                    fanart = c.addon_fanart()

                # Build playback URL (match existing episodes.py format)
                systitle = quote_plus(label)
                systvshowtitle = quote_plus(tvshowtitle)

                premiered = i.get('premiered', i.get('first_aired', ''))
                syspremiered = quote_plus(premiered) if premiered else '0'

                # Build meta dict - keep required artwork fields even if '0' for old episodes.py compatibility
                required_fields = {'banner', 'clearlogo', 'clearart', 'landscape'}
                meta = {
                    k: v for k, v in i.items()
                    if v not in [None, ''] or k in required_fields
                }
                # Ensure required fields exist with '0' default
                for field in required_fields:
                    if field not in meta:
                        meta[field] = '0'

                sysmeta = quote_plus(json.dumps(meta))

                # Import time for unique cache-busting parameter
                import time
                systime = str(int(time.time()))

                url = (f'{sysaddon}?action=play&title={systitle}&year={year}&imdb={imdb}&tmdb={tmdb}'
                       f'&season={i.get("season")}&episode={i.get("episode")}'
                       f'&tvshowtitle={systvshowtitle}&premiered={syspremiered}&meta={sysmeta}&t={systime}')

                # Create listitem
                try:
                    listitem = control.item(label=ep_label, offscreen=True)
                except:
                    listitem = control.item(label=ep_label)

                if is_playable:
                    listitem.setProperty('IsPlayable', 'true')

                # Set artwork
                listitem.setArt({
                    'icon': thumb,
                    'thumb': thumb,
                    'poster': poster,
                    'tvshow.poster': poster,
                    'season.poster': poster,
                    'fanart': fanart
                })

                # Get watch status
                try:
                    overlay = int(playcount.get_episode_overlay(indicators, imdb, tmdb, i.get('season'), i.get('episode')))
                except:
                    overlay = 6

                # Prepare comprehensive metadata for InfoTag
                infodata = {
                    'title': label,
                    'tvshowtitle': tvshowtitle,
                    'season': i.get('season'),
                    'episode': i.get('episode'),
                    'year': year,
                    'plot': i.get('plot', ''),
                    'duration': str(int(duration) * 60),  # convert to seconds
                    'mediatype': 'episode',
                    'playcount': 1 if overlay == 7 else 0,
                    'overlay': overlay,
                    'rating': i.get('rating', '0'),
                    'votes': i.get('votes', '0'),
                    'premiered': i.get('premiered', ''),
                    'aired': i.get('first_aired', i.get('premiered', '')),
                    'mpaa': i.get('mpaa', ''),
                }

                # Add lists (genre, studio, director, writer)
                if genre := i.get('genre'):
                    infodata['genre'] = c.string_split_to_list(genre)
                if studio := i.get('studio'):
                    infodata['studio'] = c.string_split_to_list(studio)
                if director := i.get('director'):
                    infodata['director'] = c.string_split_to_list(director)
                if writer := i.get('writer'):
                    infodata['writer'] = c.string_split_to_list(writer)

                # Build trailer URL for episode (uses show's IDs)
                trailer = i.get('trailer', '')
                if not trailer or trailer in ('0', '', None):
                    # Build trailer plugin URL from show TMDB/IMDB with metadata for poster display
                    trailer = f'{sysaddon}?action=trailer&name={quote_plus(tvshowtitle)}&imdb={imdb}&tmdb={tmdb}&mediatype=episode&season={i.get("season")}&episode={i.get("episode")}&meta={sysmeta}'
                infodata['trailer'] = trailer

                info_tag = ListItemInfoTag(listitem, 'video')
                info_tag.set_info(control.tagdataClean(infodata))
                info_tag.set_unique_ids({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})

                # Set trailer explicitly on InfoTag for information dialog
                if trailer and trailer not in ('0', '', None):
                    # c.log(f"[CM Debug @ progress.py] Setting trailer on InfoTag: {trailer}")
                    info_tag._info_tag.setTrailer(trailer)

                # Set cast separately (required format: list of dicts with name, role, thumbnail)
                if castwiththumb := i.get('castwiththumb'):
                    if castwiththumb and castwiththumb != '0':
                        info_tag.set_cast(castwiththumb)

                # Get resume point early (needed for context menu)
                resume_point = i.get('resume_point')
                has_resume = resume_point is not None and resume_point > 0

                # Build context menu in logical order (matching episodes.py)
                cm = []

                # 1. Queue
                cm.append((queue_menu, f'RunPlugin({sysaddon}?action=queueItem)'))

                # 2. Browse Series (all seasons)
                browse_series_label = control.lang(32071)
                browse_series_url = f'ActivateWindow(Videos,{sysaddon}?action=seasons&tvshowtitle={systvshowtitle}&year={year}&imdb={imdb}&tmdb={tmdb}&meta={sysmeta},return)'
                cm.append((browse_series_label, browse_series_url))

                # 3. Browse Season (all episodes in this season)
                browse_season_label = f'Browse Season {i.get("season")}'
                browse_season_url = f'ActivateWindow(Videos,{sysaddon}?action=episodes&tvshowtitle={systvshowtitle}&year={year}&imdb={imdb}&tmdb={tmdb}&meta={sysmeta}&season={i.get("season")},return)'
                cm.append((browse_season_label, browse_season_url))

                # 4. Information (replaces system "Information" menu)
                cm.append((infoMenu, 'Action(Info)'))

                # 5. Watch status (watched/unwatched) - use already calculated overlay
                if overlay == 7:
                    cm.append((unwatched_menu, f'RunPlugin({sysaddon}?action=episodePlaycount&imdb={imdb}&tmdb={tmdb}&season={i.get("season")}&episode={i.get("episode")}&query=6)'))
                else:
                    cm.append((watched_menu, f'RunPlugin({sysaddon}?action=episodePlaycount&imdb={imdb}&tmdb={tmdb}&season={i.get("season")}&episode={i.get("episode")}&query=7)'))

                # 6. Clear Resume Point (if there's a resume point)
                if has_resume:
                    # Pass current container URL so clear_resume_point can refresh the correct list
                    current_container = sysaddon + sys.argv[2]  # e.g., plugin://plugin.video.thecrew/?action=progress_in_progress_episodes
                    cm.append((clear_resume_menu, f'RunPlugin({sysaddon}?action=episodeClearBookmark&imdb={imdb}&tmdb={tmdb}&season={i.get("season")}&episode={i.get("episode")}&redirect={quote_plus(current_container)})'))

                # 7. Trakt Manager (if Trakt is enabled)
                if trakt_credentials:
                    cm.append((trakt_manager_menu, f'RunPlugin({sysaddon}?action=traktManager&name={systvshowtitle}&tmdb={tmdb}&content=tvshow)'))

                # 8. Playback Menu (Alter Sources)
                cm.append((playback_menu, f'RunPlugin({sysaddon}?action=alterSources&url={quote_plus(url)}&meta={sysmeta})'))

                # 9. Add to Library
                cm.append((add_to_library, f'RunPlugin({sysaddon}?action=tvshowToLibrary&tvshowtitle={systvshowtitle}&year={year}&imdb={imdb}&tmdb={tmdb})'))

                # 10. Clear Providers Cache
                cm.append((clear_providers, f'RunPlugin({sysaddon}?action=clearSources)'))

                # Note: System context menus cannot be removed (Kodi API limitation since v17/2016)
                listitem.addContextMenuItems(cm, replaceItems=True)

                # Handle resume point if present (for In Progress Episodes)
                if has_resume:
                    # resume_point is a percentage (0-100)
                    duration_seconds = int(duration) * 60

                    # Skip if duration is 0 or invalid (prevents division by zero)
                    if duration_seconds > 0:
                        # Convert percentage to seconds
                        resume_seconds = (duration_seconds * resume_point) / 100.0

                        # Calculate remaining time in minutes
                        remaining_seconds = duration_seconds - resume_seconds
                        remaining_minutes = int(remaining_seconds / 60)

                        # Add remaining time to label in gold
                        if remaining_minutes > 0:
                            ep_label = f'{ep_label} [COLOR gold]({remaining_minutes} mins left)[/COLOR]'
                            listitem.setLabel(ep_label)

                        # Set resume point using InfoTag (Kodi v19+ method)
                        # This automatically sets the overlay indicator (arrow vs checkmark)
                        try:
                            infodata['offset'] = resume_seconds
                            info_tag.set_resume_point(infodata, 'offset', 'duration', False)
                        except Exception as e:
                            c.log(f"[Progress] Error setting resume point: {e}")


                # Add to directory
                control.addItem(handle=syshandle, url=url, listitem=listitem, isFolder=False)

            except Exception as e:
                c.log(f"[Progress] Error adding episode to directory: {e}")

                c.log(f"[Progress] Traceback: {traceback.format_exc()}")
                continue

        control.content(syshandle, 'episodes')
        control.directory(syshandle, cacheToDisc=True)

#!/usr/bin/env python3
"""
Move unused images to modern/unused/ subdirectory.
Keeps dev tools (bugs.png, dev.png, waste.png) in main folder.
"""

import os
import shutil

# Base paths
artwork_path = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.thecrew.artwork\resources\media\modern"
unused_dir = os.path.join(artwork_path, "unused")

# Create unused directory if it doesn't exist
os.makedirs(unused_dir, exist_ok=True)

# List of 99 unused images (excluding dev tools: bugs.png, dev.png, waste.png)
unused_images = [
    '1add_addon.png',
    '247_movies.png',
    '247_tvshows.png',
    '4k_releases.png',
    'action_hero.png',
    'add_addon.png',
    'aew.png',
    'arconai.png',
    'argentina.png',
    'argentina2.png',
    'basque.png',
    'bee.png',
    'bp.png',
    'brazil.png',
    'bumble.png',
    'calendar2.png',
    'canelo.png',
    'castellano.png',
    'cbs_sports.png',
    'cctv.png',
    'chile.png',
    'chile2.png',
    'colombia.png',
    'colombia2.png',
    'dc_marvel.png',
    'distro.png',
    'espn2.png',
    'eyecandy.png',
    'eyecandy2.png',
    'faith.png',
    'favourites.png',
    'favourites2.png',
    'featured.png',
    'fhd_releases.png',
    'gratis.png',
    'greek.png',
    'imdb2.png',
    'india.png',
    'india2.png',
    'international2.png',
    'kiddo.png',
    'kids_trending.png',
    'latino.png',
    'latino2.png',
    'library_update.png',
    'local.png',
    'lust.png',
    'main_blackhat.png',
    'main_goldenhat.png',
    'main_redhat.png',
    'main_whitehat.png',
    'main_yellowhat.png',
    'man_city.png',
    'man_utd.png',
    'nbc_boston.png',
    'nbc_california.png',
    'nbc_chicago.png',
    'nbc_philadelphia.png',
    'nbc_washington.png',
    'netflix_boxsets.png',
    'networks2.png',
    'nxt.png',
    'popular_tv.png',
    'portugal.png',
    'pluto.png',
    'recent_tv.png',
    'retribution.png',
    'romanian.png',
    'spanish.png',
    'sports24.png',
    'sportsbay.png',
    'stan.png',
    'stratus.png',
    'titan.png',
    'top_10.png',
    'trakt2.png',
    'tubi.png',
    'turkish.png',
    'wwe_raw.png',
    'wwe_smackdown.png',
    'xumo.png',
    'yss.png',
    # Additional duplicates and variants
    'absolution.png',
    'base.png',
    'boxing2.png',
    'bumble2.png',
    'calendar3.png',
    'featured2.png',
    'greenhat2.png',
    'local2.png',
    'purplehat2.png',
    'recent2.png',
    'sports242.png',
    'top_102.png',
    'trakt3.png',
    'trending2.png',
    'wwe_network2.png'
]

# Move images
moved_count = 0
not_found = []

for image in unused_images:
    src = os.path.join(artwork_path, image)
    dst = os.path.join(unused_dir, image)
    
    if os.path.exists(src):
        shutil.move(src, dst)
        print(f"✓ Moved: {image}")
        moved_count += 1
    else:
        not_found.append(image)
        print(f"✗ Not found: {image}")

print(f"\n{'='*60}")
print(f"Summary:")
print(f"  Moved: {moved_count} images")
print(f"  Not found: {len(not_found)} images")
print(f"\nDev tools kept in main folder:")
print(f"  - bugs.png")
print(f"  - dev.png")
print(f"  - waste.png")

if not_found:
    print(f"\nImages not found (may have been deleted or renamed):")
    for img in not_found:
        print(f"  - {img}")

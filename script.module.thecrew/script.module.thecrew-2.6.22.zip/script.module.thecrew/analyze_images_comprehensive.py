#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Comprehensive image usage analyzer for The Crew
Checks: Python files, external XML files, and dynamic references
"""
import re
import requests
from pathlib import Path
from urllib.parse import urlparse

print("=" * 70)
print("COMPREHENSIVE IMAGE USAGE ANALYSIS")
print("=" * 70)

# Get all .py files
py_files = list(Path('lib').rglob('*.py'))

# Track all PNG references
used_pngs = set()
external_xml_urls = []

print(f"\n[1/4] Scanning {len(py_files)} Python files...")

for py_file in py_files:
    try:
        content = py_file.read_text(encoding='utf-8', errors='ignore')
        
        # Find icon references in dictionaries
        matches = re.findall(r"'icon':\s*'([^']+\.png)'", content)
        used_pngs.update(m.lower() for m in matches)
        
        # Also check for standalone image references  
        matches = re.findall(r"'([a-z0-9_]+\.png)'", content)
        used_pngs.update(m.lower() for m in matches)
        
        # Find external XML URLs
        xml_matches = re.findall(r'https://[^\s\'"]+\.xml', content)
        external_xml_urls.extend(xml_matches)
        
    except Exception as e:
        print(f"  Error reading {py_file}: {e}")

print(f"  Found {len(used_pngs)} image references in Python files")
print(f"  Found {len(external_xml_urls)} external XML URLs")

# Download and check external XML files
print(f"\n[2/4] Checking {len(set(external_xml_urls))} unique external XMLs...")

for xml_url in set(external_xml_urls):
    try:
        print(f"  Fetching: {xml_url}")
        response = requests.get(xml_url, timeout=10)
        if response.status_code == 200:
            xml_content = response.text
            # Find PNG references in XML
            xml_pngs = re.findall(r'<thumbnail>([^<]+\.png)</thumbnail>', xml_content)
            xml_pngs += re.findall(r'<icon>([^<]+\.png)</icon>', xml_content)
            xml_pngs += re.findall(r'icon="([^"]+\.png)"', xml_content)
            
            # Extract just the filename (not full URLs)
            for png in xml_pngs:
                filename = Path(urlparse(png).path).name.lower()
                if filename:
                    used_pngs.add(filename)
            
            if xml_pngs:
                print(f"    Found {len(xml_pngs)} image references")
    except Exception as e:
        print(f"    Error: {e}")

# Check for adult-related icons
print(f"\n[3/4] Checking for adult section icons...")
adult_icons = ['adult.png', 'xxx.png', '18+.png', 'adult_pin.png']
for icon in adult_icons:
    # Check if referenced anywhere
    found = False
    for py_file in py_files:
        try:
            content = py_file.read_text(encoding='utf-8', errors='ignore')
            if icon in content.lower():
                used_pngs.add(icon.lower())
                print(f"  Found '{icon}' in {py_file.name}")
                found = True
                break
        except:
            pass
    if not found:
        print(f"  '{icon}' not found in code")

# Get all images in modern directory
print(f"\n[4/4] Scanning artwork directory...")
artwork_path = Path(r'c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.thecrew.artwork\resources\media\modern')
existing_pngs = set()

if artwork_path.exists():
    for img in artwork_path.glob('*.png'):
        existing_pngs.add(img.name.lower())
else:
    print("  ERROR: Artwork path not found!")

# Find unused images
unused = existing_pngs - used_pngs

print("\n" + "=" * 70)
print("RESULTS")
print("=" * 70)
print(f'Total images in modern/:           {len(existing_pngs)}')
print(f'Total images referenced:            {len(used_pngs)}')
print(f'UNUSED images:                      {len(unused)}')
print(f'Coverage:                           {len(used_pngs) / len(existing_pngs) * 100:.1f}%')

# Categorize unused images
print("\n" + "=" * 70)
print("UNUSED IMAGES BY CATEGORY")
print("=" * 70)

# Categorize
dev_related = [img for img in unused if any(x in img for x in ['dev', 'bug', 'waste', 'test'])]
duplicates = [img for img in unused if '2' in img or 'add_addon' in img]
sports = [img for img in unused if any(x in img for x in ['espn', 'nbc', 'fox', 'cbs', 'wwe', 'aew', 'nxt'])]
general = [img for img in unused if img not in dev_related + duplicates + sports]

if dev_related:
    print("\n🔧 Development/Debug related:")
    for img in sorted(dev_related):
        print(f"  {img}")

if duplicates:
    print("\n📋 Duplicates/Variants:")
    for img in sorted(duplicates):
        print(f"  {img}")

if sports:
    print("\n🏈 Sports networks/brands:")
    for img in sorted(sports):
        print(f"  {img}")

if general:
    print("\n📦 Other unused:")
    for img in sorted(general):
        print(f"  {img}")

# Save detailed report
with open('image_analysis_detailed.txt', 'w') as f:
    f.write('=' * 70 + '\n')
    f.write('COMPREHENSIVE IMAGE USAGE REPORT\n')
    f.write('=' * 70 + '\n\n')
    f.write(f'Total images in modern/:           {len(existing_pngs)}\n')
    f.write(f'Total images referenced:            {len(used_pngs)}\n')
    f.write(f'UNUSED images:                      {len(unused)}\n')
    f.write(f'Coverage:                           {len(used_pngs) / len(existing_pngs) * 100:.1f}%\n\n')
    
    f.write('=' * 70 + '\n')
    f.write('USED IMAGES\n')
    f.write('=' * 70 + '\n')
    for img in sorted(used_pngs):
        f.write(f'{img}\n')
    
    f.write('\n' + '=' * 70 + '\n')
    f.write('UNUSED IMAGES\n')
    f.write('=' * 70 + '\n')
    for img in sorted(unused):
        f.write(f'{img}\n')

print("\n" + "=" * 70)
print("Detailed report saved to: image_analysis_detailed.txt")
print("=" * 70)

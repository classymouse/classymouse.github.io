#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re
from pathlib import Path

# Get all .py files
py_files = list(Path('lib').rglob('*.py'))

# Extract all .png references
used_pngs = set()
for py_file in py_files:
    try:
        content = py_file.read_text(encoding='utf-8', errors='ignore')
        # Find icon references in dictionaries
        matches = re.findall(r"'icon':\s*'([^']+\.png)'", content)
        used_pngs.update(m.lower() for m in matches)
        # Also check for standalone image references
        matches = re.findall(r"'([a-z0-9_]+\.png)'", content)
        used_pngs.update(m.lower() for m in matches)
    except Exception:
        pass

# Get all images in modern directory
artwork_path = Path(r'c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.thecrew.artwork\resources\media\modern')
existing_pngs = set()
if artwork_path.exists():
    for img in artwork_path.glob('*.png'):
        existing_pngs.add(img.name.lower())

# Find unused images
unused = existing_pngs - used_pngs

print(f'\nTotal images in modern/: {len(existing_pngs)}')
print(f'Total images referenced in code: {len(used_pngs)}')
print(f'Unused images: {len(unused)}')
print('\n=== UNUSED IMAGES ===')
for img in sorted(unused):
    print(f'  {img}')

# Save to file for reference
with open('unused_images.txt', 'w') as f:
    f.write(f'Total images in modern/: {len(existing_pngs)}\n')
    f.write(f'Total images referenced in code: {len(used_pngs)}\n')
    f.write(f'Unused images: {len(unused)}\n\n')
    f.write('=== UNUSED IMAGES ===\n')
    for img in sorted(unused):
        f.write(f'{img}\n')
print('\nResults also saved to: unused_images.txt')

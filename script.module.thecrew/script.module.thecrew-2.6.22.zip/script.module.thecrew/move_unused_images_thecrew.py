#!/usr/bin/env python3
"""
Move unused images to thecrew/unused/ subdirectory.
Based on comprehensive analysis results.
"""

import os
import shutil

# Base paths
artwork_path = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.thecrew.artwork\resources\media\thecrew"
unused_dir = os.path.join(artwork_path, "unused")

# Create unused directory if it doesn't exist
os.makedirs(unused_dir, exist_ok=True)

# List of 61 unused images (all hat colors ARE used in thecrew!)
unused_images = [
    '247_shows.png',
    'abc_sports.png',
    'accn.png',
    'affliction.png',
    'back.png',
    'bareknuckle.png',
    'btn.png',
    'certificates1.png',
    'certificates2.png',
    'channels.png',
    'clearart_old.png',
    'collections.png',
    'combat.png',
    'combatgo.png',
    'darts.png',
    'dirtypistol.png',
    'e_sports.png',
    'enterprise_adult.png',
    'espn_news.png',
    'espn_u.png',
    'fightbox.png',
    'food.png',
    'fox_sports1.png',
    'fox_sports2.png',
    'handball.png',
    'imdb.png',
    'imdb_color.png',
    'info.png',
    'languages.png',
    'live.png',
    'longhorn.png',
    'mlb_network.png',
    'mma.png',
    'most-popular2.png',
    'mymovies2.png',
    'mytvshows2.png',
    'nbatv.png',
    'nbc_cali.png',
    'nbc_nw.png',
    'nbc_philly.png',
    'nbc_sports.png',
    'next2.png',
    'nfl_network.png',
    'nfl_redzone.png',
    'nrl.png',
    'pac12.png',
    'people-watching.png',
    'people-watching2.png',
    'playlist.png',
    'pride.png',
    'radio.png',
    'sec.png',
    'snooker.png',
    'sports_replays2.png',
    'sports_schannels.png',
    'swift.png',
    'tabletennis.png',
    'tvshows2.png',
    'userlists2.png',
    'valor.png',
    'volleyball.png'
]

# Move images
moved_count = 0
not_found = []

for image in unused_images:
    src = os.path.join(artwork_path, image)
    dst = os.path.join(unused_dir, image)
    
    if os.path.exists(src):
        shutil.move(src, dst)
        print(f"✓ Moved: {image}")
        moved_count += 1
    else:
        not_found.append(image)
        print(f"✗ Not found: {image}")

print(f"\n{'='*60}")
print(f"Summary:")
print(f"  Moved: {moved_count} images")
print(f"  Not found: {len(not_found)} images")
print(f"\nAll hat colors preserved in main folder (all used)!")
print(f"All dev tools preserved in main folder (all used)!")

if not_found:
    print(f"\nImages not found:")
    for img in not_found:
        print(f"  - {img}")

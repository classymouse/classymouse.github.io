#!/usr/bin/env python3
"""
Comprehensive image usage analysis for THECREW skin.
Checks Python code, XML files, and external XML feeds.
"""

import os
import re
import requests
from collections import defaultdict

# Paths
ARTWORK_PATH = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.thecrew.artwork\resources\media\thecrew"
SCRIPT_MODULE_PATH = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.module.thecrew"
PLUGIN_PATH = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\plugin.video.thecrew"

# External XML URLs from lists.py
EXTERNAL_XMLS = [
    'https://raw.githubusercontent.com/posadka/xmls2/main/kids/greyhat_main.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/kids/debridkids.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/kids/disney_years/main.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/kids/learning.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/kids/songs.xml',
    'http://thechains24.com/GREENHAT/green.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ncaa/ncaa.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ncaa/ncaab.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/lfl/lfl.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/mlb/mlb.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nfl/nfl.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nhl/nhl.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nba/nba.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ufc_mma/ufc.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/motor/motogp.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/boxing/boxing.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/fifa/fifa.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/wwe/wwe.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/channels/channels.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/replays/replays.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/misc/misc_sports.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/tennis/tennis.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/motor/f1.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/pga/pga.xml',
    'https://raw.githubusercontent.com/classymouse/cc/main/CCcinema.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nascar/nascar.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/cricket/cricket.xml',
    'https://raw.githubusercontent.com/posadka/xmls2/main/sports/xfl/xfl.xml',
]

def get_all_images():
    """Get all PNG files in thecrew media directory."""
    if not os.path.exists(ARTWORK_PATH):
        print(f"ERROR: Path not found: {ARTWORK_PATH}")
        return []
    
    images = []
    for file in os.listdir(ARTWORK_PATH):
        if file.endswith('.png'):
            images.append(file)
    return sorted(images)

def search_python_files(image_name):
    """Search for image usage in Python files."""
    found_in = []
    
    for root_path in [SCRIPT_MODULE_PATH, PLUGIN_PATH]:
        if not os.path.exists(root_path):
            continue
            
        for root, dirs, files in os.walk(root_path):
            # Skip virtual environments and cache directories
            if 'venv' in root or '__pycache__' in root or '.git' in root:
                continue
                
            for file in files:
                if file.endswith('.py'):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            # Search for the image name
                            if image_name in content:
                                found_in.append(filepath)
                    except Exception:
                        pass
    
    return found_in

def search_xml_files(image_name):
    """Search for image usage in local XML files."""
    found_in = []
    
    # Check script.thecrew.artwork XML files
    artwork_xml_path = r"c:\Users\fvanb\AppData\Roaming\Kodi\addons\script.thecrew.artwork\resources\skins"
    if os.path.exists(artwork_xml_path):
        for root, dirs, files in os.walk(artwork_xml_path):
            for file in files:
                if file.endswith('.xml'):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            if image_name in content:
                                found_in.append(filepath)
                    except Exception:
                        pass
    
    return found_in

def search_external_xmls(image_name):
    """Search for image usage in external XML feeds."""
    found_in = []
    
    for url in EXTERNAL_XMLS:
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                content = response.text
                # Check for image name in various XML tag formats
                patterns = [
                    f'<thumbnail>{image_name}</thumbnail>',
                    f'<icon>{image_name}</icon>',
                    f'thumbnail="{image_name}"',
                    f'icon="{image_name}"',
                    f"thumbnail='{image_name}'",
                    f"icon='{image_name}'",
                    image_name  # Also check for bare filename
                ]
                
                for pattern in patterns:
                    if pattern in content:
                        found_in.append(url)
                        break
        except Exception as e:
            print(f"  Warning: Could not fetch {url}: {e}")
    
    return found_in

def main():
    print("="*70)
    print("THECREW SKIN - Image Usage Analysis")
    print("="*70)
    
    images = get_all_images()
    if not images:
        print("No images found!")
        return
    
    print(f"\nTotal images in thecrew/: {len(images)}")
    print("\nAnalyzing usage (this may take a minute)...\n")
    
    used_images = {}
    unused_images = []
    
    for i, image in enumerate(images, 1):
        print(f"[{i}/{len(images)}] Checking {image}...", end=' ')
        
        # Search in all locations
        python_refs = search_python_files(image)
        xml_refs = search_xml_files(image)
        external_refs = search_external_xmls(image)
        
        all_refs = python_refs + xml_refs + external_refs
        
        if all_refs:
            used_images[image] = {
                'python': python_refs,
                'xml': xml_refs,
                'external': external_refs
            }
            print("USED")
        else:
            unused_images.append(image)
            print("unused")
    
    # Generate report
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    print(f"Total images:              {len(images)}")
    print(f"Images referenced:         {len(used_images)}")
    print(f"UNUSED images:             {len(unused_images)}")
    print(f"Coverage:                  {len(used_images)/len(images)*100:.1f}%")
    
    # Categorize unused images
    if unused_images:
        print("\n" + "="*70)
        print("UNUSED IMAGES BREAKDOWN")
        print("="*70)
        
        dev_related = [img for img in unused_images if any(x in img.lower() for x in ['dev', 'bug', 'waste', 'test'])]
        duplicates = [img for img in unused_images if '2' in img or '1add' in img.lower()]
        sports = [img for img in unused_images if any(x in img.lower() for x in ['wwe', 'nfl', 'nba', 'mlb', 'ufc', 'espn', 'nbc', 'cbs'])]
        hats = [img for img in unused_images if 'hat' in img.lower()]
        
        print(f"\nDev/Debug tools: {len(dev_related)}")
        if dev_related:
            for img in dev_related[:10]:
                print(f"  - {img}")
        
        print(f"\nDuplicates: {len(duplicates)}")
        if duplicates:
            for img in duplicates[:10]:
                print(f"  - {img}")
                
        print(f"\nSports related: {len(sports)}")
        if sports:
            for img in sports[:10]:
                print(f"  - {img}")
                
        print(f"\nHat colors: {len(hats)}")
        if hats:
            for img in hats[:10]:
                print(f"  - {img}")
        
        print(f"\nOther: {len(unused_images) - len(dev_related) - len(duplicates) - len(sports) - len(hats)}")
    
    # Save detailed report
    report_file = os.path.join(SCRIPT_MODULE_PATH, 'image_analysis_thecrew_detailed.txt')
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("THECREW SKIN - Detailed Image Usage Report\n")
        f.write("="*70 + "\n\n")
        
        f.write(f"Total images: {len(images)}\n")
        f.write(f"Used: {len(used_images)}\n")
        f.write(f"Unused: {len(unused_images)}\n\n")
        
        f.write("USED IMAGES:\n")
        f.write("-"*70 + "\n")
        for img, refs in sorted(used_images.items()):
            f.write(f"\n{img}:\n")
            if refs['python']:
                f.write(f"  Python files: {len(refs['python'])}\n")
                for ref in refs['python'][:3]:
                    f.write(f"    - {ref}\n")
            if refs['xml']:
                f.write(f"  XML files: {len(refs['xml'])}\n")
                for ref in refs['xml'][:3]:
                    f.write(f"    - {ref}\n")
            if refs['external']:
                f.write(f"  External XMLs: {len(refs['external'])}\n")
                for ref in refs['external'][:3]:
                    f.write(f"    - {ref}\n")
        
        f.write("\n\nUNUSED IMAGES:\n")
        f.write("-"*70 + "\n")
        for img in sorted(unused_images):
            f.write(f"{img}\n")
    
    print(f"\nDetailed report saved to: {report_file}")

if __name__ == '__main__':
    main()

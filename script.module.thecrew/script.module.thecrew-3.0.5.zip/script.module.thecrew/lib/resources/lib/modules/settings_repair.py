# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file settings_repair.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Repair plugin.video.thecrew userdata settings.xml when it contains setting IDs
that no longer exist in resources/settings.xml (Kodi 21 rejects the file).

'''

from __future__ import annotations

import os
import re
import shutil
import threading
import xml.etree.ElementTree as ET
from typing import Set

_SCHEMA_VERSION = '3.0.5'
_repair_lock = threading.Lock()
_repair_attempted = False


def _schema_path() -> str:
    module_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    addons_dir = os.path.dirname(module_root)
    return os.path.join(addons_dir, 'plugin.video.thecrew', 'resources', 'settings.xml')


def _userdata_path(profile_path: str | None = None) -> str:
    if profile_path:
        base = profile_path
    else:
        appdata = os.environ.get('APPDATA') or os.path.expanduser('~')
        base = os.path.join(appdata, 'Kodi', 'userdata')
    return os.path.join(base, 'addon_data', 'plugin.video.thecrew', 'settings.xml')


def load_schema_ids(schema_path: str | None = None) -> Set[str]:
    path = schema_path or _schema_path()
    if not os.path.isfile(path):
        return set()
    text = open(path, 'r', encoding='utf-8').read()
    return set(re.findall(r'<setting id="([^"]+)"', text))


def _setting_line(setting: ET.Element) -> str:
    attrs = ''.join(f' {k}="{v}"' for k, v in sorted(setting.attrib.items()))
    text = setting.text or ''
    if text or len(setting) == 0:
        if text:
            return f'    <setting{attrs}>{_xml_escape(text)}</setting>'
        return f'    <setting{attrs} />'
    # Should not happen in Kodi userdata; keep element text if present.
    return f'    <setting{attrs}>{_xml_escape(text)}</setting>'


def _xml_escape(value: str) -> str:
    return (
        value.replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
        .replace("'", '&apos;')
    )


def repair_user_settings(
    userdata_path: str | None = None,
    schema_path: str | None = None,
    profile_path: str | None = None,
    log=None,
) -> bool:
    """
    Drop orphan setting elements from userdata settings.xml.
    Returns True when the file was modified.
    """
    user_path = userdata_path or _userdata_path(profile_path)
    if not os.path.isfile(user_path):
        return False

    schema_ids = load_schema_ids(schema_path)
    if not schema_ids:
        if log:
            log('[settings_repair] Schema IDs unavailable — skip')
        return False

    with open(user_path, 'r', encoding='utf-8') as fh:
        raw = fh.read()
    needs_header = not raw.lstrip().startswith('<?xml')

    tree = ET.parse(user_path)
    root = tree.getroot()
    removed = 0
    kept = []
    for setting in list(root):
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        if not sid or sid not in schema_ids or re.match(r'^label\d+$', sid or ''):
            root.remove(setting)
            removed += 1
        else:
            kept.append(setting)

    if removed == 0 and not needs_header:
        return False

    backup = user_path + '.bak'
    try:
        shutil.copy2(user_path, backup)
    except OSError:
        backup = None

    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<settings version="2">',
    ]
    lines.extend(_setting_line(s) for s in kept)
    lines.append('</settings>')
    new_xml = '\n'.join(lines) + '\n'

    with open(user_path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(new_xml)

    if log:
        parts = []
        if removed:
            parts.append(f'removed {removed} orphan(s)')
        if needs_header:
            parts.append('added XML header')
        log(f'[settings_repair] Repaired userdata settings.xml ({", ".join(parts)})')
        if backup:
            log(f'[settings_repair] Backup: {backup}')
    return True


def userdata_missing_header(userdata_path: str | None = None) -> bool:
    """True when userdata exists but lacks the XML declaration Kodi 21 expects."""
    user_path = userdata_path or _userdata_path()
    if not os.path.isfile(user_path):
        return False
    try:
        with open(user_path, 'r', encoding='utf-8') as fh:
            raw = fh.read(256)
    except OSError:
        return False
    return not raw.lstrip().startswith('<?xml')


def repair_if_needed(log=None) -> bool:
    """
    Repair userdata settings when needed.

    Kodi strips the XML header when saving from the native Settings UI; re-check
    on every entry so the next addon load sees a valid file. Orphan pruning still
    runs at most once per Python process (reuselanguageinvoker-safe).
    """
    global _repair_attempted
    if not os.path.isfile(_userdata_path()):
        return False

    if userdata_missing_header():
        with _repair_lock:
            try:
                return repair_user_settings(log=log)
            except Exception as exc:
                if log:
                    log(f'[settings_repair] Failed: {exc}')
                return False

    with _repair_lock:
        try:
            repaired = repair_user_settings(log=log)
            if repaired:
                _repair_attempted = True
            return repaired
        except Exception as exc:
            if log:
                log(f'[settings_repair] Failed: {exc}')
            return False

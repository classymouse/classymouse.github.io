# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file settings_repair.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Repair plugin.video.thecrew userdata settings.xml when it contains setting IDs
that no longer exist in resources/settings.xml (Kodi 21 rejects the file).

'''

from __future__ import annotations

import os
import re
import threading
import xml.etree.ElementTree as ET
from typing import Set

_SCHEMA_VERSION = '3.0.7'
_repair_lock = threading.Lock()
_repair_attempted = False
_repair_in_progress = False
_synced_this_process = False


def _use_vfs_io() -> bool:
    """Android/macOS Kodi sandboxes Python open(); use xbmcvfs for userdata I/O."""
    try:
        import platform as _platform
        import xbmc
        kodi_platform = (xbmc.getInfoLabel('System.Platform.OS') or '').lower()
        if kodi_platform in ('android', 'ios', 'osx', 'darwin'):
            return True
        return _platform.system().lower() in ('darwin', 'android')
    except Exception:
        return False


def _file_exists(path: str) -> bool:
    if not path:
        return False
    if _use_vfs_io():
        try:
            import xbmcvfs
            return bool(xbmcvfs.exists(path))
        except Exception:
            pass
    return os.path.isfile(path)


def _read_text(path: str, limit: int | None = None) -> str:
    if not _file_exists(path):
        raise OSError(f'missing: {path}')
    if _use_vfs_io():
        import xbmcvfs
        handle = xbmcvfs.File(path)
        if not handle:
            raise OSError(f'xbmcvfs read failed: {path}')
        try:
            raw = handle.read() or ''
        finally:
            handle.close()
        return raw[:limit] if limit is not None else raw
    with open(path, 'r', encoding='utf-8') as fh:
        return fh.read(limit) if limit is not None else fh.read()


def _write_text(path: str, content: str) -> None:
    from .crewruntime import crew_file_write
    crew_file_write(path, content, mode='w')


def _copy_file(src: str, dst: str) -> None:
    _write_text(dst, _read_text(src))


def _parse_xml_file(path: str) -> ET.ElementTree:
    raw = _read_text(path)
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw
    return ET.ElementTree(ET.fromstring(raw))


def _schema_path() -> str:
    module_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    addons_dir = os.path.dirname(module_root)
    return os.path.join(addons_dir, 'plugin.video.thecrew', 'resources', 'settings.xml')


def _userdata_path(profile_path: str | None = None) -> str:
    """Resolve plugin.video.thecrew userdata settings.xml on any platform."""
    if profile_path:
        return os.path.join(profile_path, 'settings.xml')
    try:
        import xbmcaddon
        import xbmcvfs
        profile = xbmcvfs.translatePath(
            xbmcaddon.Addon('plugin.video.thecrew').getAddonInfo('profile')
        )
        if profile:
            return os.path.join(profile, 'settings.xml')
    except Exception:
        pass
    appdata = os.environ.get('APPDATA')
    if appdata:
        base = os.path.join(appdata, 'Kodi', 'userdata')
    else:
        base = os.path.join(os.path.expanduser('~'), '.kodi', 'userdata')
    return os.path.join(base, 'addon_data', 'plugin.video.thecrew', 'settings.xml')


def load_schema_ids(schema_path: str | None = None) -> Set[str]:
    path = schema_path or _schema_path()
    if not _file_exists(path):
        return set()
    try:
        text = _read_text(path)
    except OSError:
        return set()
    return set(re.findall(r'<setting id="([^"]+)"', text))


def parse_userdata_settings(user_path: str) -> dict[str, str]:
    """Read setting id/value pairs from on-disk userdata (tolerates missing XML header)."""
    if not user_path or not _file_exists(user_path):
        return {}
    try:
        raw = _read_text(user_path)
    except OSError:
        return {}
    if not raw.strip():
        return {}
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return {}
    out: dict[str, str] = {}
    for setting in root:
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        if sid:
            out[sid] = setting.text if setting.text is not None else ''
    return out


def _setting_line(setting: ET.Element) -> str:
    attrs = dict(setting.attrib)
    text = setting.text or ''
    # Kodi treats default="true" as "use schema default" and ignores element text.
    if text.strip():
        attrs.pop('default', None)
    attrs_str = ''.join(f' {k}="{v}"' for k, v in sorted(attrs.items()))
    if text or len(setting) == 0:
        if text:
            return f'    <setting{attrs_str}>{_xml_escape(text)}</setting>'
        return f'    <setting{attrs_str} />'
    # Should not happen in Kodi userdata; keep element text if present.
    return f'    <setting{attrs_str}>{_xml_escape(text)}</setting>'


def _xml_escape(value: str) -> str:
    return (
        value.replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
        .replace("'", '&apos;')
    )


def settings_sync_in_progress() -> bool:
    """True while repair is pushing values via setSetting (ignore onSettingsChanged)."""
    return _repair_in_progress


def original_backup_path(userdata_path: str) -> str:
    """Path to the one-time preserved original userdata snapshot."""
    return userdata_path + '.bak'


def preserve_original_backup(userdata_path: str, log=None) -> str | None:
    """
    Copy userdata to settings.xml.bak only when .bak does not exist yet.

    The .bak file is the user's pre-repair original — never overwrite it on
    later repairs, Kodi saves, or reboots.
    """
    if not userdata_path or not _file_exists(userdata_path):
        return None
    backup = original_backup_path(userdata_path)
    if _file_exists(backup):
        return None
    try:
        _copy_file(userdata_path, backup)
    except OSError:
        return None
    if log:
        log(f'[settings_repair] Preserved original backup: {backup}')
    return backup


def restore_user_settings_from_backup(
    userdata_path: str | None = None,
    backup_path: str | None = None,
    profile_path: str | None = None,
    log=None,
) -> bool:
    """Restore settings.xml from the preserved .bak (adds XML header when missing)."""
    user_path = userdata_path or _userdata_path(profile_path)
    backup = backup_path or original_backup_path(user_path)
    if not _file_exists(backup):
        if log:
            log(f'[settings_repair] No backup to restore: {backup}')
        return False
    try:
        raw = _read_text(backup)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Backup read failed: {exc}')
        return False
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw.lstrip()
    try:
        _write_text(user_path, raw)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Restore write failed: {exc}')
        return False
    if log:
        log(f'[settings_repair] Restored settings from {os.path.basename(backup)}')
    _clear_runtime_settings_cache()
    _refresh_runtime_theme()
    return True


def health_backup_path(userdata_path: str, version: str | None = None) -> str:
    """Per-upgrade snapshot taken immediately before repair (overwritten each version)."""
    ver = version or _SCHEMA_VERSION
    return f'{userdata_path}.health_backup_{ver}'


def kodi_root_from_addons_home(home_path: str) -> str:
    """Parent of special://home — Kodi install root (sibling to userdata/, not inside it)."""
    home = (home_path or '').rstrip('\\/')
    if not home:
        return ''
    return os.path.dirname(home)


def _legacy_profile_settings_backup_path() -> str:
    """Old location under special://profile — kept for one-time import only."""
    try:
        import xbmcvfs
        profile = xbmcvfs.translatePath('special://profile')
    except Exception:
        profile = ''
    if not profile:
        return ''
    return os.path.join(profile.rstrip('\\/'), 'thecrew_settings_backup', 'settings.xml')


def external_settings_backup_dir() -> str:
    """
    KodiRoot/thecrew_settings_backup — outside userdata/ and addon_data/.

    Path is derived from special://home (parent of addons/) so it works on every
    platform Kodi supports, e.g.:
      Windows  …/AppData/Roaming/Kodi/thecrew_settings_backup
      Linux    ~/.kodi/thecrew_settings_backup
      macOS    ~/Library/Application Support/Kodi/thecrew_settings_backup
      Android  …/.kodi/thecrew_settings_backup (under Kodi app storage)

    Survives uninstall of plugin.video.thecrew (addon_data is wiped).
    """
    try:
        import xbmcvfs
        home = xbmcvfs.translatePath('special://home')
    except Exception:
        home = ''
    root = kodi_root_from_addons_home(home)
    if not root:
        return ''
    return os.path.join(root, 'thecrew_settings_backup')


def profile_settings_backup_path() -> str:
    """External settings snapshot path (not under userdata or addon_data)."""
    dest_dir = external_settings_backup_dir()
    if not dest_dir:
        return ''
    return os.path.join(dest_dir, 'settings.xml')


def _ensure_external_backup_dir(log=None) -> str:
    """Create backup dir via xbmcvfs (works on Android/macOS sandbox)."""
    dest_dir = external_settings_backup_dir()
    if not dest_dir:
        return ''
    try:
        import xbmcvfs
        xbmcvfs.mkdirs(dest_dir)
    except Exception:
        try:
            from . import control
            control.makeFile(dest_dir)
        except Exception as exc:
            if log:
                log(f'[settings_repair] Backup dir create failed: {exc}')
            return ''
    return dest_dir


def find_settings_backup_for_import() -> str:
    """Prefer external backup; fall back to legacy profile-folder copy."""
    for path in (profile_settings_backup_path(), _legacy_profile_settings_backup_path()):
        if path and _file_exists(path):
            return path
    return ''


def _settings_file_fingerprint(path: str) -> tuple[int, str] | None:
    try:
        text = _read_text(path)
    except OSError:
        return None
    import hashlib
    digest = hashlib.md5(text.encode('utf-8')).hexdigest()
    return len(text), digest


def maybe_export_settings_backup(
    userdata_path: str | None = None,
    force: bool = False,
    log=None,
) -> str | None:
    """
    Copy settings.xml to KodiRoot/thecrew_settings_backup when changed.

    Safe to call on every service boot and after settings saves.
    """
    user_path = userdata_path or _userdata_path()
    dest = profile_settings_backup_path()
    if not dest or not _file_exists(user_path):
        return None
    if not force and _file_exists(dest):
        src_fp = _settings_file_fingerprint(user_path)
        dst_fp = _settings_file_fingerprint(dest)
        if src_fp and dst_fp and src_fp == dst_fp:
            return dest
    return export_profile_settings_backup(user_path, log=log)


# Auth / identity keys: restore from backup whenever current is empty but backup has a value.
_SENSITIVE_SETTING_IDS = frozenset({
    'trakt.user', 'trakt.token', 'trakt.refresh', 'trakt.expires_at', 'trakt.auth',
    'trakt.client_id', 'trakt.client_secret',
    'tm.user', 'tm.personal_user',
    'personal.list', 'adult_pin', 'devmode.password',
})

# Never merge these from older backups — would revert forward-only markers.
_FORWARD_ONLY_SETTING_IDS = frozenset({
    'last_version_announcement',
    'settings.schema_version',
    'module_base',
    'plugin_base',
})


def load_schema_defaults(schema_path: str | None = None) -> dict[str, str]:
    """Default values from resources/settings.xml (default= attribute or element text)."""
    path = schema_path or _schema_path()
    if not _file_exists(path):
        return {}
    try:
        text = _read_text(path)
    except OSError:
        return {}
    defaults: dict[str, str] = {}
    for m in re.finditer(
        r'<setting id="([^"]+)"([^>]*?)(?:/>|>([^<]*)</setting>)',
        text,
        flags=re.DOTALL,
    ):
        sid = m.group(1)
        attrs = m.group(2) or ''
        body = m.group(3) or ''
        dm = re.search(r'default="([^"]*)"', attrs)
        defaults[sid] = dm.group(1) if dm is not None else body
    return defaults


def create_version_health_backup(
    userdata_path: str | None = None,
    version: str | None = None,
    log=None,
) -> str | None:
    """Snapshot current userdata before repair for this schema version."""
    user_path = userdata_path or _userdata_path()
    if not _file_exists(user_path):
        return None
    backup = health_backup_path(user_path, version)
    try:
        _copy_file(user_path, backup)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Health backup failed: {exc}')
        return None
    if log:
        log(f'[settings_repair] Health backup: {os.path.basename(backup)}')
    return backup


def export_profile_settings_backup(userdata_path: str | None = None, log=None) -> str | None:
    """Copy userdata to KodiRoot/thecrew_settings_backup/ (outside userdata/addon_data)."""
    user_path = userdata_path or _userdata_path()
    dest = profile_settings_backup_path()
    if not dest or not _file_exists(user_path):
        return None
    if not _ensure_external_backup_dir(log=log):
        return None
    try:
        _copy_file(user_path, dest)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Profile export failed: {exc}')
        return None
    if log:
        log(f'[settings_repair] Profile settings backup: {dest}')
    return dest


def import_userdata_from_profile_backup(
    userdata_path: str | None = None,
    log=None,
) -> bool:
    """
    Seed userdata from profile backup when missing or auth keys were wiped.

    Called before repair on fresh installs — addon_data is empty but profile backup remains.
    """
    user_path = userdata_path or _userdata_path()
    profile_backup = find_settings_backup_for_import()
    if not profile_backup or not _file_exists(profile_backup):
        return False

    needs_import = not _file_exists(user_path)
    if not needs_import:
        current = parse_userdata_settings(user_path)
        backup_vals = parse_userdata_settings(profile_backup)
        for sid in _SENSITIVE_SETTING_IDS:
            if backup_vals.get(sid) and not (current.get(sid) or '').strip():
                needs_import = True
                break

    if not needs_import:
        return False

    try:
        raw = _read_text(profile_backup)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Profile backup read failed: {exc}')
        return False
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw.lstrip()
    try:
        from . import control
        control.makeFile(os.path.dirname(user_path))
        _write_text(user_path, raw)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Profile import write failed: {exc}')
        return False
    if log:
        log('[settings_repair] Restored userdata from profile settings backup')
    return True


def _values_differ(current: str, backup: str, default: str) -> bool:
    """True when backup holds a user value that current lost (empty or reverted to default)."""
    if backup == current:
        return False
    if not backup.strip():
        return False
    if not current.strip() or current == default:
        return backup != default or bool(backup.strip())
    return False


def merge_user_values_from_backup(
    userdata_path: str,
    backup_path: str,
    schema_path: str | None = None,
    log=None,
) -> int:
    """
    Merge customized values from a backup into current userdata.

    Only restores keys still in the schema. Returns count of values merged.
    """
    if not _file_exists(userdata_path) or not _file_exists(backup_path):
        return 0

    schema_ids = load_schema_ids(schema_path)
    if not schema_ids:
        return 0

    defaults = load_schema_defaults(schema_path)
    backup_vals = parse_userdata_settings(backup_path)
    current_vals = parse_userdata_settings(userdata_path)
    if not backup_vals:
        return 0

    to_apply: dict[str, str] = {}
    for sid in schema_ids:
        if sid not in backup_vals:
            continue
        bval = backup_vals[sid]
        cval = current_vals.get(sid, '')
        dval = defaults.get(sid, '')
        if sid in _SENSITIVE_SETTING_IDS:
            if bval.strip() and not cval.strip():
                to_apply[sid] = bval
        elif sid in _FORWARD_ONLY_SETTING_IDS:
            continue
        elif _values_differ(cval, bval, dval):
            to_apply[sid] = bval

    if not to_apply:
        return 0

    try:
        tree = _parse_xml_file(userdata_path)
    except ET.ParseError as exc:
        if log:
            log(f'[settings_repair] Merge parse failed: {exc}')
        return 0

    root = tree.getroot()
    seen = set()
    for setting in root:
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        if sid in to_apply:
            setting.text = to_apply[sid]
            setting.attrib.pop('default', None)
            seen.add(sid)

    for sid, val in to_apply.items():
        if sid in seen:
            continue
        elem = ET.Element('setting', {'id': sid})
        elem.text = val
        root.append(elem)

    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<settings version="2">',
    ]
    for setting in root:
        if setting.tag == 'setting':
            lines.append(_setting_line(setting))
    lines.append('</settings>')
    try:
        _write_text(userdata_path, '\n'.join(lines) + '\n')
    except OSError as exc:
        if log:
            log(f'[settings_repair] Merge write failed: {exc}')
        return 0

    if log:
        log(f'[settings_repair] Merged {len(to_apply)} setting(s) from {os.path.basename(backup_path)}')
    return len(to_apply)


def persist_setting_on_disk(setting_id: str, value: str, log=None) -> bool:
    """Write one setting to userdata XML without Kodi setSetting (safe during boot races)."""
    user_path = _userdata_path()
    if not setting_id or not _file_exists(user_path):
        return False
    try:
        tree = _parse_xml_file(user_path)
    except ET.ParseError as exc:
        if log:
            log(f'[settings_repair] persist_setting_on_disk parse failed: {exc}')
        return False
    root = tree.getroot()
    seen = False
    for setting in root:
        if setting.tag != 'setting':
            continue
        if setting.attrib.get('id') == setting_id:
            setting.text = value
            setting.attrib.pop('default', None)
            seen = True
            break
    if not seen:
        elem = ET.Element('setting', {'id': setting_id})
        elem.text = value
        root.append(elem)
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<settings version="2">',
    ]
    lines.extend(_setting_line(s) for s in root if s.tag == 'setting')
    lines.append('</settings>')
    try:
        _write_text(user_path, '\n'.join(lines) + '\n')
    except OSError as exc:
        if log:
            log(f'[settings_repair] persist_setting_on_disk write failed: {exc}')
        return False
    if log:
        log(f'[settings_repair] Persisted {setting_id} on disk (no setSetting)')
    return True


def repair_user_settings_for_upgrade(
    userdata_path: str | None = None,
    schema_path: str | None = None,
    version: str | None = None,
    log=None,
    sync_kodi: bool = False,
) -> dict:
    """
    Full upgrade path: profile import -> health backup -> repair -> merge back.

    Returns summary dict with keys: imported, backup, repaired, merged, profile_export.
    """
    user_path = userdata_path or _userdata_path()
    ver = version or _SCHEMA_VERSION
    summary = {
        'imported': False,
        'backup': None,
        'repaired': False,
        'merged': 0,
        'profile_export': None,
    }

    summary['imported'] = import_userdata_from_profile_backup(user_path, log=log)
    summary['backup'] = create_version_health_backup(user_path, ver, log=log)

    summary['repaired'] = repair_user_settings(
        userdata_path=user_path,
        schema_path=schema_path,
        log=log,
        sync_kodi=sync_kodi,
    )

    backup = summary['backup'] or health_backup_path(user_path, ver)
    if _file_exists(backup):
        summary['merged'] = merge_user_values_from_backup(
            user_path, backup, schema_path=schema_path, log=log,
        )

    if _file_exists(user_path):
        summary['profile_export'] = export_profile_settings_backup(user_path, log=log)

    return summary


def ensure_settings_header(userdata_path: str, log=None) -> bool:
    """Prepend XML header only — no setSetting sync (safe from onSettingsChanged).

    Never prepend a header to an empty file: Kodi may have flushed blank userdata after
    a failed settings load; header-only XML looks valid but holds zero keys.
    """
    if not userdata_path or not _file_exists(userdata_path):
        return False
    try:
        raw = _read_text(userdata_path)
    except OSError:
        return False
    if raw.lstrip().startswith('<?xml'):
        return False
    body = raw.lstrip()
    if not body or '<setting' not in body:
        if log:
            log(
                '[settings_repair] Refusing to add XML header to empty settings body '
                f'({len(raw)} byte(s)) — restoring from .bak'
            )
        return restore_user_settings_from_backup(userdata_path, log=log)
    preserve_original_backup(userdata_path, log=log)
    try:
        _write_text(
            userdata_path,
            '<?xml version="1.0" encoding="utf-8"?>\n' + body,
        )
    except OSError as exc:
        if log:
            log(f'[settings_repair] Header write failed: {exc}')
        return False
    if log:
        log(f'[settings_repair] Added XML header to {os.path.basename(userdata_path)}')
    return True


def repair_all_known_headers(log=None) -> int:
    """Fix missing XML headers for Crew + common dependency addon userdata files."""
    fixed = 0
    targets = ['plugin.video.thecrew']
    try:
        import xbmc
        import xbmcaddon
        for addon_id in (
            'script.module.resolveurl',
            'script.module.cocoscrapers',
            'script.module.gearsscrapers',
            'script.module.viperscrapers',
        ):
            try:
                if not xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
                    continue
                xbmcaddon.Addon(addon_id)
                targets.append(addon_id)
            except Exception:
                pass
    except Exception:
        pass

    for addon_id in targets:
        try:
            if addon_id == 'plugin.video.thecrew':
                path = _userdata_path()
            else:
                import xbmcaddon
                import xbmcvfs
                profile = xbmcvfs.translatePath(
                    xbmcaddon.Addon(addon_id).getAddonInfo('profile')
                )
                path = os.path.join(profile, 'settings.xml')
            if ensure_settings_header(path, log=log):
                fixed += 1
        except Exception as exc:
            if log:
                log(f'[settings_repair] Header fix skipped for {addon_id}: {exc}')
    return fixed


def _sync_userdata_to_kodi(user_path: str, log=None) -> int:
    """
    Push on-disk settings into Kodi's in-memory addon settings.

    Kodi loads userdata once at addon start; if the file lacked an XML header
    it keeps defaults until restart. After we repair the file, sync values in-process.
    """
    global _repair_in_progress
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.thecrew')
    except Exception:
        return 0

    synced = 0
    _repair_in_progress = True
    try:
        tree = _parse_xml_file(user_path)
        for setting in tree.getroot():
            if setting.tag != 'setting':
                continue
            sid = setting.attrib.get('id')
            if not sid:
                continue
            val = setting.text if setting.text is not None else ''
            try:
                addon.setSetting(id=sid, value=val)
            except Exception:
                try:
                    addon.setSetting(sid, val)
                except Exception:
                    continue
            synced += 1
    except Exception as exc:
        if log:
            log(f'[settings_repair] Kodi sync skipped: {exc}')
        return 0
    finally:
        _repair_in_progress = False

    if log and synced:
        log(f'[settings_repair] Synced {synced} setting(s) into Kodi runtime')
    return synced


def _clear_runtime_settings_cache() -> None:
    try:
        from .crewruntime import c
        c._settings._cache.clear()
    except Exception:
        pass


def repair_user_settings(
    userdata_path: str | None = None,
    schema_path: str | None = None,
    profile_path: str | None = None,
    log=None,
    sync_kodi: bool = False,
) -> bool:
    """
    Drop orphan setting elements from userdata settings.xml.
    Returns True when the file was modified.
    """
    global _repair_in_progress
    if _repair_in_progress:
        return False

    user_path = userdata_path or _userdata_path(profile_path)
    if not _file_exists(user_path):
        return False

    schema_ids = load_schema_ids(schema_path)
    if not schema_ids:
        if log:
            log('[settings_repair] Schema IDs unavailable — skip')
        return False

    try:
        raw = _read_text(user_path)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Read failed: {exc}')
        return False
    needs_header = not raw.lstrip().startswith('<?xml')

    try:
        tree = _parse_xml_file(user_path)
    except ET.ParseError as exc:
        if log:
            log(f'[settings_repair] Parse failed: {exc}')
        return False
    root = tree.getroot()
    removed = 0
    kept = []
    for setting in list(root):
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        if not sid or sid not in schema_ids or re.match(r'^label\d+$', sid or ''):
            root.remove(setting)
            removed += 1
        else:
            kept.append(setting)

    if removed == 0 and not needs_header:
        return False

    if not kept:
        if log:
            log('[settings_repair] Refusing to write empty settings.xml — restoring from .bak')
        return restore_user_settings_from_backup(user_path, log=log)

    preserve_original_backup(user_path, log=log)

    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<settings version="2">',
    ]
    lines.extend(_setting_line(s) for s in kept)
    lines.append('</settings>')
    new_xml = '\n'.join(lines) + '\n'

    try:
        _write_text(user_path, new_xml)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Write failed: {exc}')
        return False

    if log:
        parts = []
        if removed:
            parts.append(f'removed {removed} orphan(s)')
        if needs_header:
            parts.append('added XML header')
        log(f'[settings_repair] Repaired userdata settings.xml ({", ".join(parts)})')

    if sync_kodi:
        global _synced_this_process
        if not _synced_this_process:
            _sync_userdata_to_kodi(user_path, log=log)
            _synced_this_process = True
        _clear_runtime_settings_cache()
        _refresh_runtime_theme()
    return True


def _refresh_runtime_theme() -> None:
    try:
        from .crewruntime import c
        c._theme = c.appearance()
        c.art = c.get_art_path()
    except Exception:
        pass


def userdata_missing_header(userdata_path: str | None = None) -> bool:
    """True when userdata exists but lacks the XML declaration Kodi 21 expects."""
    user_path = userdata_path or _userdata_path()
    if not _file_exists(user_path):
        return False
    try:
        raw = _read_text(user_path, limit=256)
    except OSError:
        return False
    return not raw.lstrip().startswith('<?xml')


def _userdata_is_header_only_corpse(user_path: str) -> bool:
    """True when file has XML header (or parses) but no setting elements."""
    if not user_path or not _file_exists(user_path):
        return False
    return len(parse_userdata_settings(user_path)) < 5


def repair_if_needed(log=None) -> bool:
    """
    Repair userdata settings when needed.

    Kodi strips the XML header when saving from the native Settings UI; re-check
    on every entry so the next addon load sees a valid file. Never sync via
    setSetting here — that triggers onSettingsChanged storms on Kodi 21.
    """
    global _repair_attempted
    user_path = _userdata_path()
    if not _file_exists(user_path):
        return False

    if _userdata_is_header_only_corpse(user_path):
        if log:
            log('[settings_repair] Header-only settings.xml detected — restoring from .bak')
        return restore_user_settings_from_backup(user_path, log=log)

    if userdata_missing_header():
        with _repair_lock:
            try:
                schema_ids = load_schema_ids()
                if schema_ids:
                    try:
                        tree = _parse_xml_file(_userdata_path())
                        orphans = sum(
                            1
                            for setting in tree.getroot()
                            if setting.tag == 'setting'
                            and (
                                not setting.attrib.get('id')
                                or setting.attrib.get('id') not in schema_ids
                                or re.match(r'^label\d+$', setting.attrib.get('id') or '')
                            )
                        )
                        if orphans == 0:
                            return ensure_settings_header(_userdata_path(), log=log)
                    except ET.ParseError:
                        pass
                return repair_user_settings(log=log, sync_kodi=False)
            except Exception as exc:
                if log:
                    log(f'[settings_repair] Failed: {exc}')
                return False

    if _repair_attempted:
        return False

    with _repair_lock:
        try:
            repaired = repair_user_settings(log=log, sync_kodi=False)
            if repaired:
                _repair_attempted = True
            return repaired
        except Exception as exc:
            if log:
                log(f'[settings_repair] Failed: {exc}')
            return False

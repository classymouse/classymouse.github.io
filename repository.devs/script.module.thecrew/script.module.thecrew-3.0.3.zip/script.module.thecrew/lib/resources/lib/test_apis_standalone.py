# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file test_apis_standalone.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2023-2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 * Standalone API test - Tests API endpoints directly without Kodi dependencies
 * This validates that our API keys and endpoints work correctly
 *
 * Run with: python test_apis_standalone.py
 *
 ********************************************************cm*
'''

import requests
import base64


# Decode protected API keys (same as keys.py)
def _x(data):
    """Simple XOR decoder for obfuscated keys"""
    key = b'thecrew'
    decoded = base64.b64decode(data)
    return ''.join(chr(decoded[i] ^ key[i % len(key)]) for i in range(len(decoded)))


# API Keys (from keys.py)
TMDB_KEY = _x(b'MlFZEVkPSwlbMQ9kZ1FFFk0ZQwkOEQEVF0EOWxEBBhA=')
TVDB_KEY = _x(b'A1VXFV0TSBJEXkVDQg1SRBheVgVbD0sGW1dcGEQZUFhGA1BWDhZIBFBeAkcSWA==')
FANART_KEY = _x(b'B1RXF14RQRpAAhMaEVgWUAdVVg==')


def test_tmdb_api():
    """Test TMDb API directly"""
    print("\n" + "="*80)
    print("TESTING TMDb API (Direct)")
    print("="*80)
    print(f"API Key: {TMDB_KEY[:8]}...")

    base_url = "https://api.themoviedb.org/3"

    # Test 1: Get popular movies
    print("\n[Test 1] Getting popular movies...")
    try:
        response = requests.get(
            f"{base_url}/movie/popular",
            params={'api_key': TMDB_KEY, 'language': 'en-US', 'page': 1},
            timeout=10
        )

        if response.status_code == 200:
            data = response.json()
            results = data.get('results', [])
            print(f"(OK) Success! Found {len(results)} popular movies")
            if results:
                first = results[0]
                print(f"  - First movie: {first.get('title', 'N/A')} ({first.get('release_date', 'N/A')[:4]})")
                print(f"  - Rating: {first.get('vote_average', 'N/A')}/10")
        else:
            print(f"(X) Failed - Status: {response.status_code}")
            print(f"  Response: {response.text[:200]}")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 2: Get specific movie (Fight Club - ID: 550)
    print("\n[Test 2] Getting movie details (Fight Club - ID: 550)...")
    try:
        response = requests.get(
            f"{base_url}/movie/550",
            params={'api_key': TMDB_KEY, 'language': 'en-US'},
            timeout=10
        )

        if response.status_code == 200:
            movie = response.json()
            print(f"(OK) Success!")
            print(f"  - Title: {movie.get('title', 'N/A')}")
            print(f"  - Release Date: {movie.get('release_date', 'N/A')}")
            print(f"  - Rating: {movie.get('vote_average', 'N/A')}/10")
            print(f"  - Genres: {', '.join([g['name'] for g in movie.get('genres', [])])}")
        else:
            print(f"(X) Failed - Status: {response.status_code}")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 3: Search for a movie
    print("\n[Test 3] Searching for 'The Matrix'...")
    try:
        response = requests.get(
            f"{base_url}/search/movie",
            params={'api_key': TMDB_KEY, 'query': 'The Matrix', 'language': 'en-US'},
            timeout=10
        )

        if response.status_code == 200:
            data = response.json()
            results = data.get('results', [])
            print(f"(OK) Success! Found {len(results)} results")
            if results:
                first = results[0]
                print(f"  - Top result: {first.get('title', 'N/A')} ({first.get('release_date', 'N/A')[:4]})")
        else:
            print(f"(X) Failed - Status: {response.status_code}")
    except Exception as e:
        print(f"(X) Error: {e}")

    print("\n" + "="*80)


def test_tvdb_api():
    """Test TVDb API directly"""
    print("\n" + "="*80)
    print("TESTING TVDb API (Direct)")
    print("="*80)
    print(f"API Key: {TVDB_KEY[:8]}...")

    base_url = "https://api4.thetvdb.com/v4"

    # Test 1: Authenticate
    print("\n[Test 1] Authenticating with TVDb...")
    try:
        response = requests.post(
            f"{base_url}/login",
            json={'apikey': TVDB_KEY},
            timeout=10
        )

        if response.status_code == 200:
            data = response.json()
            token = data.get('data', {}).get('token')
            print(f"(OK) Authentication successful!")
            print(f"  - Token: {token[:20]}...")

            # Test 2: Get series (Breaking Bad - ID: 81189)
            print("\n[Test 2] Getting series details (Breaking Bad - ID: 81189)...")
            headers = {'Authorization': f'Bearer {token}'}
            response = requests.get(
                f"{base_url}/series/81189",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                series = response.json().get('data', {})
                print(f"(OK) Success!")
                print(f"  - Name: {series.get('name', 'N/A')}")
                print(f"  - First Aired: {series.get('firstAired', 'N/A')}")
                print(f"  - Status: {series.get('status', {}).get('name', 'N/A')}")
            else:
                print(f"(X) Failed - Status: {response.status_code}")
        else:
            print(f"(X) Authentication failed - Status: {response.status_code}")
            print(f"  Response: {response.text[:200]}")
    except Exception as e:
        print(f"(X) Error: {e}")

    print("\n" + "="*80)


def test_fanart_api():
    """Test Fanart.tv API directly"""
    print("\n" + "="*80)
    print("TESTING Fanart.tv API (Direct)")
    print("="*80)
    print(f"API Key: {FANART_KEY[:8]}...")

    # Test 1: Get TV artwork (Breaking Bad - TVDb ID: 81189)
    print("\n[Test 1] Getting TV artwork (Breaking Bad - TVDb ID: 81189)...")
    try:
        response = requests.get(
            f"https://webservice.fanart.tv/v3/tv/81189",
            headers={'api-key': FANART_KEY},
            timeout=10
        )

        if response.status_code == 200:
            artwork = response.json()
            print(f"(OK) Success! Found artwork types:")
            for art_type, items in artwork.items():
                if isinstance(items, list) and items:
                    print(f"  - {art_type}: {len(items)} items")
        else:
            print(f"(X) Failed - Status: {response.status_code}")
            print(f"  Response: {response.text[:200]}")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 2: Get movie artwork (Fight Club - TMDb ID: 550)
    print("\n[Test 2] Getting movie artwork (Fight Club - TMDb ID: 550)...")
    try:
        response = requests.get(
            f"https://webservice.fanart.tv/v3/movies/550",
            headers={'api-key': FANART_KEY},
            timeout=10
        )

        if response.status_code == 200:
            artwork = response.json()
            print(f"(OK) Success! Found artwork types:")
            for art_type, items in artwork.items():
                if isinstance(items, list) and items:
                    print(f"  - {art_type}: {len(items)} items")
        else:
            print(f"(X) Failed - Status: {response.status_code}")
    except Exception as e:
        print(f"(X) Error: {e}")

    print("\n" + "="*80)


def main():
    """Run all API tests"""
    print("\n" + "="*80)
    print("STANDALONE API TEST SUITE")
    print("="*80)
    print("\nThis test validates API endpoints and keys directly.")
    print("It does NOT test the new API wrapper classes (requires Kodi).")
    print("\nTesting:")
    print("  • TMDb API  - The Movie Database")
    print("  • TVDb API  - TheTVDB")
    print("  • Fanart.tv - Artwork provider")
    print("")

    # Run tests
    test_tmdb_api()
    test_tvdb_api()
    test_fanart_api()

    # Summary
    print("\n" + "="*80)
    print("TEST SUITE COMPLETED")
    print("="*80)
    print("\nThese tests verify that:")
    print("  (OK) API keys are valid and properly decoded")
    print("  (OK) API endpoints are accessible")
    print("  (OK) Basic API calls return expected data")
    print("\nTo test the new TMDbAPI/TVDbAPI/FanartAPI wrapper classes,")
    print("run test_new_apis.py from within Kodi's Python environment.")
    print("")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n(X) Tests interrupted by user")
    except Exception as e:
        print(f"\n\n(X) Unexpected error: {e}")
        import traceback
        traceback.print_exc()

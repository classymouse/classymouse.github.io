# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file docu.py
* @package script.module.thecrew
*
* @copyright (c) 2025, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import os
import re
import sys
import time
import traceback

from urllib.parse import quote_plus, urlparse
import requests

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import resolveurl

from bs4 import BeautifulSoup as bs

from ..modules.listitem import ListItemInfoTag

from ..modules import cache
from ..modules import client
from ..modules import control
from ..modules.crewruntime import c
from ..modules import http_client

_handle = syshandle = int(sys.argv[1])

# artPath = control.artPath()
# addonFanart = control.addonFanart()

artPath = c.get_art_path()
addonFanart = c.addon_fanart()



class Documentary:
    def __init__(self):
        self.list = []
        self.docu_link = 'https://topdocumentaryfilms.com/'
        self.docu_all = 'https://topdocumentaryfilms.com/all/'
        self.docu_cat_list = 'https://topdocumentaryfilms.com/list/'
        self.docu_top100 = 'https://topdocumentaryfilms.com/top-100/'
        self.session = requests.Session()
        self.addon = xbmcaddon.Addon
        self.session.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Cache-Control": "max-age=0"
        }
        self.YOUTUBE_PLUGIN = "plugin://plugin.video.youtube/"
        self.VIMEO_PLUGIN = "plugin://plugin.video.vimeo/"

    def __del__(self):
        if hasattr(self, 'session'):
            try:
                self.session.close()
            except Exception:
                pass
        self.DAILYMOTION_PLUGIN = "plugin://plugin.video.dailymotion_com/"

    def get_html(self, url):
        """
        Fetch HTML from URL with multiple fallback strategies to bypass bot detection.
        """
        # Strategy 1: Use HTTPClient with proper session
        try:
            session = http_client.HTTPClient.get_session('documentary')

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept-Encoding": "gzip, deflate",
                "DNT": "1",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Referer": "https://topdocumentaryfilms.com/",
                "Cache-Control": "max-age=0"
            }

            response = session.get(url, headers=headers, timeout=15, allow_redirects=True)
            response.raise_for_status()
            c.log(f'[Docu Debug] Strategy 1 succeeded for {url} -> status={response.status_code} final_url={response.url}')
            return bs(response.text, "html.parser")
        except Exception as e:
            failure = traceback.format_exc()
            c.log(f'[Docu Debug] Strategy 1 failed for {url}: {e}')
            c.log(f'[Docu Debug] Strategy 1 traceback: {failure}')

        # Strategy 2: Use client.request with full headers for cloudflare bypass
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept-Encoding": "gzip, deflate",
                "DNT": "1",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1"
            }
            response = client.request(
                url,
                headers=headers,
                referer='https://topdocumentaryfilms.com/',
                timeout='15',
                redirect=True,
                verify=True
            )
            if response:
                c.log(f'[Docu Debug] Strategy 2 succeeded for {url} -> response_length={len(response)}')
                return bs(response, "html.parser")
            c.log(f'[Docu Debug] Strategy 2 returned empty response for {url}')
        except Exception as e2:
            failure = traceback.format_exc()
            c.log(f'[Docu Debug] Strategy 2 failed for {url}: {e2}')
            c.log(f'[Docu Debug] Strategy 2 traceback: {failure}')

        # Strategy 3: Simple requests fallback (original method)
        try:
            response = requests.get(url, timeout=15, allow_redirects=True)
            response.raise_for_status()
            c.log(f'[Docu Debug] Strategy 3 succeeded for {url} -> status={response.status_code} final_url={response.url}')
            return bs(response.text, "html.parser")
        except Exception as e3:
            failure = traceback.format_exc()
            c.log(f'[Docu Debug] Strategy 3 failed for {url}: {e3}')
            c.log(f'[Docu Debug] Strategy 3 traceback: {failure}')

        c.log(f'[Docu Debug] All get_html strategies failed for {url}')
        return None


    def get_json(self, url):
        page_response = self.session.get(url, timeout=15)
        json = page_response.json()
        return json

    def root(self):
        """
        This function creates the main documentary menu with three options:
        All Documentaries, Categories List, and Top 100.

        Returns:
            list: The list of documentary menu options.
        """
        try:
            cat_icon = c.addon_icon()

            # All Documentaries
            self.list.append({
                'name': 'All Documentaries',
                'url': self.docu_all,
                'image': cat_icon,
                'action': f'docuHeaven&docuCat={self.docu_all}'
            })

            # Categories List
            self.list.append({
                'name': 'Categories',
                'url': self.docu_cat_list,
                'image': cat_icon,
                'action': f'docuHeaven&docuCategories={self.docu_cat_list}'
            })

            # Top 100
            self.list.append({
                'name': 'Top 100 Documentaries',
                'url': self.docu_top100,
                'image': cat_icon,
                'action': f'docuHeaven&docuCat={self.docu_top100}'
            })
        except Exception as e:
            failure = traceback.format_exc()
            c.log(f'Exception in root: {failure}')

        self.addDirectory(self.list)
        return self.list

    def docu_categories(self, url):
        """
        Show documentary categories by scraping them from the categories list page.
        """
        try:
            soup = self.get_html(url)
            if soup is None:
                self.addDirectory(self.list)
                return self.list

            # Find the main content area
            main_content = soup.find('main') or soup.find('div', attrs={'id': 'content'}) or soup

            # Look for category links - they're usually in a list or specific container
            # Try multiple strategies to find categories
            category_links = []

            # Strategy 1: Look for links with /category/ in href
            all_links = main_content.find_all('a', href=True)

            seen_categories = set()
            for link in all_links:
                href = link.get('href', '')

                # Must contain /category/ and the domain
                if '/category/' not in href:
                    continue

                # Make URL absolute if needed
                if href.startswith('/'):
                    full_href = 'https://topdocumentaryfilms.com' + href
                else:
                    full_href = href

                # Extract category name from URL or link text
                title = link.get_text(strip=True)

                # Skip if no title or it's a generic navigation item
                if not title or len(title) < 2:
                    continue

                # Skip navigation/footer items
                skip_terms = ['home', 'about', 'contact', 'privacy', 'terms', 'subscribe',
                            'follow', 'login', 'register', 'search', 'menu', 'browse all']
                if any(skip in title.lower() for skip in skip_terms):
                    continue

                # Normalize the URL to avoid duplicates
                normalized_url = full_href.rstrip('/')

                # Skip if we've already seen this category URL
                if normalized_url in seen_categories:
                    continue

                seen_categories.add(normalized_url)

                # Clean up the title
                # Remove special characters that cause issues
                clean_title = title.replace('/', '').replace('\\', '')

                category_links.append((clean_title, normalized_url))

            # Sort categories alphabetically by title
            category_links.sort(key=lambda x: x[0].lower())

            # Add categories to list
            for title, href in category_links:
                docu_action = f'docuHeaven&docuCat={href}'
                self.list.append({
                    'name': title,
                    'url': href,
                    'image': c.addon_icon(),
                    'action': docu_action
                })

        except Exception as e:
            failure = traceback.format_exc()
            c.log(f'Exception in docu_categories: {failure}')

        self.addDirectory(self.list)
        return self.list

    def docu_list(self, url):
        try:
            soup = self.get_html(url)
            if soup is None:
                c.log(f'[Docu Debug] docu_list received no soup for {url}')
                self.addDirectory(self.list)
                return self.list

            import re

            page_title = ''
            try:
                page_title = soup.title.get_text(strip=True) if soup.title else ''
            except Exception:
                page_title = ''

            all_links = soup.find_all('a', href=True)
            html_text = str(soup)
            c.log(f'[Docu Debug] docu_list page title for {url}: {page_title}')
            c.log(f'[Docu Debug] docu_list counts for {url}: articles={len(soup.find_all("article"))} links={len(all_links)} html_length={len(html_text)}')
            c.log(f'[Docu Debug] docu_list markers for {url}: cf_challenge={"cf-challenge" in html_text.lower()} captcha={"captcha" in html_text.lower()} access_denied={"access denied" in html_text.lower()}')

            # The site uses standard WordPress <article> elements for each post.
            # Scraping <article> tags is reliable and immune to nav/sidebar noise.
            articles = soup.find_all('article')


            gambling_spam = [
                'casino', 'gambling', 'gamstop', 'payid', 'poker', 'bet',
                'slots', 'roulette', 'blackjack', 'sportsbook', 'offshore',
                'betting', 'pokies', 'withdrawal-casino', 'online-casino',
            ]

            documentary_items = []
            for article in articles:
                try:
                    # Title — prefer h2/h3 heading text, fall back to first link title
                    heading = article.find('h2') or article.find('h3') or article.find('h1')
                    docu_title = heading.get_text(strip=True) if heading else ''

                    # Link — first <a> with an absolute TDF href
                    link_el = article.find('a', href=True)
                    if not link_el:
                        continue
                    docu_url = str(link_el.get('href', ''))
                    if docu_url and docu_url.startswith('/'):
                        docu_url = f'https://topdocumentaryfilms.com{docu_url}'

                    if not docu_title or not docu_url:
                        continue
                    if 'topdocumentaryfilms.com' not in docu_url:
                        continue

                    # Skip gambling / spam articles
                    combined = (docu_url + ' ' + docu_title).lower()
                    if any(spam in combined for spam in gambling_spam):
                        continue

                    # Skip navigation / meta pages
                    skip_slugs = ['/category/', '/tag/', '/page/', '/list/', '/all/', '/top-100/',
                                  '/about', '/contact', '/privacy', '/terms', '/author/']
                    if any(s in docu_url.lower() for s in skip_slugs):
                        continue

                    # Thumbnail — prefer the largest src in the article's <img>
                    img_el = article.find('img')
                    if img_el:
                        # srcset may contain a larger image; take the first (widest) one
                        srcset = img_el.get('srcset', '')
                        if srcset:
                            # srcset format: "url1 205w, url2 150w, ..." — take the widest
                            candidates = [s.strip().split(' ') for s in srcset.split(',') if s.strip()]
                            try:
                                best = max(candidates, key=lambda x: int(x[1].rstrip('w')) if len(x) > 1 else 0)
                                docu_icon = best[0]
                            except Exception:
                                docu_icon = img_el.get('src') or c.addon_icon()
                        else:
                            docu_icon = img_el.get('src') or c.addon_icon()
                        if docu_icon and docu_icon.startswith('/'):
                            docu_icon = 'https://topdocumentaryfilms.com' + docu_icon
                    else:
                        docu_icon = c.addon_icon()

                    docu_action = f'docuHeaven&docuPlay={docu_url}'
                    documentary_items.append({
                        'name': docu_title,
                        'url': docu_url,
                        'image': docu_icon,
                        'action': docu_action,
                    })
                except Exception:
                    continue

                        # Sort alphabetically
            documentary_items.sort(key=lambda x: x['name'].lower())
            self.list.extend(documentary_items)
            c.log(f'[Docu Debug] docu_list built {len(documentary_items)} documentary items for {url}')


            # Pagination — find next page link inside nav.pagination
            try:
                nav = (soup.find('nav', class_='navigation') or
                       soup.find('nav', class_='pagination') or
                       soup.find('div', class_='pagination'))
                if nav:
                    page_links = nav.find_all('a', href=True)
                    # Find links with /page/N/ and pick the one with N > current
                    current_page_match = re.search(r'/page/(\d+)', url)
                    current_page = int(current_page_match.group(1)) if current_page_match else 1
                    next_url = None
                    next_page = None
                    for pl in page_links:
                        m = re.search(r'/page/(\d+)', pl.get('href', ''))
                        if m:
                            n = int(m.group(1))
                            if n > current_page and (next_page is None or n < next_page):
                                next_page = n
                                next_url = pl.get('href')
                    if next_url:
                        if next_url.startswith('/'):
                            next_url = 'https://topdocumentaryfilms.com' + next_url
                        self.list.append({
                            'name': f'Next Page ({next_page})',
                            'url': next_url,
                            'image': c.addon_next(),
                            'action': f'docuHeaven&docuCat={next_url}',
                        })
                        c.log(f'[Docu Debug] docu_list pagination next page for {url}: {next_url}')
                    else:
                        c.log(f'[Docu Debug] docu_list found no next page for {url}')
                else:
                    c.log(f'[Docu Debug] docu_list found no pagination container for {url}')
            except Exception:
                c.log(f'[Docu Debug] docu_list pagination parse failed for {url}: {traceback.format_exc()}')


        except Exception as e:
            failure = traceback.format_exc()
            c.log(f'Exception in docu_list: {failure}')

        self.addDirectory(self.list)
        return self.list

    def docu_play(self, url):
        """
        Retrieves the documentary video from the given URL and plays it.

        Args:
            url (str): The URL of the documentary video.

        Raises:
            Exception: If there is an error during the process.

        Returns:
            None
        """
        try:
            c.log(f'[Docu Debug] docu_play fetching page: {url}')
            soup = self.get_html(url)

            if soup is None:
                c.log(f'[Docu Debug] docu_play failed to fetch page: {url}')
                c.infoDialog("Failed to fetch page", sound=False, icon='ERROR')
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                return

            docu_page = str(soup)
            docu_item = None

            # Try embedUrl first (itemprop)
            if not docu_item:
                try:
                    result = soup.select_one('meta[itemprop="embedUrl"][content]')
                    if result:
                        docu_item = result.get('content')
                except Exception:
                    pass

            # Try contentUrl (itemprop)
            if not docu_item:
                try:
                    result = soup.select_one('meta[itemprop="contentUrl"][content]')
                    if result:
                        docu_item = result.get('content')
                except Exception:
                    pass

            # Try iframe src
            if not docu_item:
                try:
                    result = soup.select_one('iframe[src]')
                    if result:
                        docu_item = result.get('src')
                except Exception:
                    pass

            # Try og:video meta tag
            if not docu_item:
                try:
                    result = soup.select_one('meta[property="og:video"][content]')
                    if result:
                        docu_item = result.get('content')
                except Exception:
                    pass

            # Try og:video:url meta tag
            if not docu_item:
                try:
                    result = soup.select_one('meta[property="og:video:url"][content]')
                    if result:
                        docu_item = result.get('content')
                except Exception:
                    pass

            # Try common embedded video elements.
            if not docu_item:
                try:
                    result = soup.select_one('embed[src], video[src], source[src]')
                    if result:
                        docu_item = result.get('src')
                except Exception:
                    pass

            # Last resort: scan the raw markup for known video hosts.
            if not docu_item:
                try:
                    patterns = [
                        r'https?://(?:www\.)?youtube\.com/embed/[A-Za-z0-9_-]+[^"\'<\s]*',
                        r'https?://(?:www\.)?youtube\.com/watch\?v=[A-Za-z0-9_-]+[^"\'<\s]*',
                        r'https?://youtu\.be/[A-Za-z0-9_-]+[^"\'<\s]*',
                        r'https?://(?:www\.)?dailymotion\.com/embed/video/[A-Za-z0-9]+[^"\'<\s]*',
                        r'https?://(?:www\.)?dailymotion\.com/video/[A-Za-z0-9]+[^"\'<\s]*',
                    ]
                    for pattern in patterns:
                        match = re.search(pattern, docu_page, re.I)
                        if match:
                            docu_item = match.group(0)
                            break
                except Exception:
                    pass

            # If still not found, show error
            if not docu_item:
                c.log(
                    f'[Docu Debug] docu_play found no playable video for {url}: '
                    f'iframes={len(soup.find_all("iframe"))} '
                    f'videos={len(soup.find_all("video"))} '
                    f'embeds={len(soup.find_all("embed"))} '
                    f'html_length={len(docu_page)}'
                )
                c.infoDialog("This page doesn't have a playable video", sound=False, icon='ERROR')
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                return

            c.log(f'[Docu Debug] docu_play extracted video candidate for {url}: {docu_item}')

            if 'http:' not in docu_item and  'https:' not in docu_item:
                docu_item = f'https:{docu_item}'
            url = docu_item

            # Try to extract title
            try:
                title_meta = soup.select_one('meta[property="og:title"][content]')
                docu_title = title_meta.get('content').replace("&amp;","&").replace('&#39;',"'").replace('&quot;','"').replace('&#39;',"'").replace('&#8211;',' - ').replace('&#8217;',"'").replace('&#8216;',"'").replace('&#038;','&').replace('&acirc;','')
            except Exception:
                docu_title = "Documentary"

            lower_url = url.lower()
            if 'youtube' in lower_url or 'youtu.be' in lower_url:
                if 'videoseries' not in lower_url:
                    # Extract video ID from various YouTube URL formats
                    # Handle: /embed/VIDEO_ID?params, /v/VIDEO_ID, /watch?v=VIDEO_ID, youtu.be/VIDEO_ID
                    if '/embed/' in url or '/v/' in url:
                        # Format: https://www.youtube.com/embed/VIDEO_ID?params
                        video_id = url.split("/")[-1].split("?")[0]
                    elif 'v=' in url:
                        # Format: https://www.youtube.com/watch?v=VIDEO_ID&params
                        video_id = url.split('v=')[1].split('&')[0]
                    elif 'youtu.be/' in lower_url:
                        video_id = url.split("/")[-1].split("?")[0]
                    else:
                        # Fallback: assume last path segment
                        video_id = url.split("/")[-1].split("?")[0]

                    url = f'plugin://plugin.video.youtube/play/?video_id={video_id}'
                else: pass
            elif 'dailymotion' in lower_url:
                video_id = url.rstrip('/').split('/')[-1].split('?')[0]
                url = self.getDailyMotionStream(video_id)
            else:
                c.log(f'Play Documentary: Unknown Host: {url}', trace=1)
                c.infoDialog(message=f'Unknown Host - Report To Developer: {url}', heading='Unknown Host', icon='ERROR', time=3000, sound=False)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                return

            listitem = xbmcgui.ListItem(label=docu_title, offscreen=True)
            listitem.setProperty('IsPlayable', 'true')
            listitem.setInfo('video', {'Title': docu_title, 'Genre': 'docu', 'Plot': 'Plot created by Classy ;-)'})

            # YouTube plugin URLs don't need resolveurl, use directly
            if url and url.startswith('plugin://'):
                resolved = url
            else:
                hmf = resolveurl.HostedMediaFile(url)
                if hmf:
                    resolved = hmf.resolve()
                else:
                    resolved = url  # Fallback to original URL

            if not resolved:
                c.log(f'[Docu Debug] docu_play failed to resolve video for {url}')
                c.infoDialog("Failed to resolve video", sound=False, icon='ERROR')
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                return

            c.log(f'[Docu Debug] docu_play resolved video for {docu_title}: {resolved}')

            # Use setResolvedUrl for all URLs (including plugin URLs)
            # This is the standard method and matches how trailers work
            item = xbmcgui.ListItem(path=resolved)
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

        except Exception as e:
            failure = traceback.format_exc()
            c.log(f'Exception in docu_play: {failure}')




    def getDailyMotionStream(self, video_id):
        """
        Retrieves a playable URL for a given video id from DailyMotion.

        Parts of this Code was originally written by gujal, as part of the DailyMotion Addon in the official Kodi Repo.
        Modified to fit the needs here.

        Args:
            video_id (str): The video id to retrieve the URL for.

        Returns:
            str: A playable URL for the given video id.

        Raises:
            Exception: If there is an error during the process.

        Notes:
            The function will return the first playable URL found in the metadata response.
            If no playable URL is found, the function will return None.
        """
        headers = {'User-Agent':'Android'}
        cookie = {'Cookie':"lang=en_US; ff=off"}
        r = requests.get(f"http://www.dailymotion.com/player/metadata/video/{video_id}", headers=headers, cookies=cookie, timeout=10)
        content = r.json()
        if content.get('error') is not None:
            error = (content['error']['title'])
            xbmc.executebuiltin(f'XBMC.Notification(Info:,{error} ,5000)')
            return
        else:
            cc = content['qualities']
            cc = cc.items()
            cc = sorted(cc,key=self.sort_key,reverse=True)
            m_url = ''
            other_playable_url = []
            for source,json_source in cc:
                source = source.split("@")[0]
                for item in json_source:
                    if m_url := item.get('url', None):
                        if source == "auto" :
                            continue
                        elif  int(source) <= 2 :
                            if 'video' in item.get('type', None):
                                return m_url
                        elif '.mnft' in m_url:
                            continue
                        other_playable_url.append(m_url)
            if other_playable_url: # probably not needed, only for last resort
                for m_url in other_playable_url:
                    if '.m3u8?auth' in m_url:
                        rr = requests.get(m_url, cookies=r.cookies.get_dict() ,headers=headers, timeout=10)
                        if rr.headers.get('set-cookie'):
                            return (
                                re.findall(r'(http.+)', rr.text)[0].split('#cell')[
                                    0
                                ]
                                + '|Cookie='
                                + rr.headers['set-cookie']
                            )
                        else:
                            return re.findall(r'(http.+)', rr.text)[0].split('#cell')[0]

    def sort_key(self, item):
        """
        Sort key function for DailyMotion quality strings.
        Converts quality strings like '720' to integers for proper sorting.
        Returns 0 for 'auto' or non-numeric values to sort them to the bottom.
        """
        quality_str = item[0].split('@')[0]
        if quality_str == 'auto':
            return 0
        try:
            return int(quality_str)
        except ValueError:
            return 0

    def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, is_action=True, is_folder=True) -> None:
        try:
            name = c.lang(name)
        except Exception:
            pass
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        queueMenu = c.lang(32065)

        url = f'{sysaddon}?action={query}' if is_action is True else query
        thumb = os.path.join(artPath, thumb) if artPath is not None else icon
        cm = []
        if queue:
            cm.append((queueMenu, f'RunPlugin({sysaddon}?action=playlist_QueueItem)'))
        if context:
            cm.append((c.lang(context[0]), f'RunPlugin({sysaddon}?action={context[1]})'))
        try:
            item = control.item(label=name, offscreen=True)
        except Exception:
            item = control.item(label=name)



        item.setProperty('IsPlayable', 'true')
        infolabels={'title': name, 'plot': "Documentary"}
        info_tag = ListItemInfoTag(item, 'video')
        info_tag.set_info(infolabels)

        item.addContextMenuItems(cm)
        item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': addonFanart})
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=is_folder)

    def endDirectory(self):
        syshandle = int(sys.argv[1])
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)

    def _add_folder_item(self, items, title, url, icon_url, fanart_url,
                            sort_title="", isfolder=True, isplayable=False,
                            date=None, info=None, context_menu_items=None,
                            offscreen=True):

        if fanart_url is None:
            fanart_url = os.path.join(self.addon.media, "fanart_blur.jpg")

        if icon_url is None:
            icon_url = os.path.join(self.addon.media, "icon_trans.png")

        try:
            listitem = control.item(label=title, offscreen=offscreen)
        except Exception:
            listitem = control.item(label=title)
        list_item = ListItemInfoTag(listitem, 'video')
        listitem.setArt({"thumb": icon_url, "fanart": fanart_url})
        listitem.setInfo("video", {"title": title, "sorttitle": sort_title})

        if isplayable:
            listitem.setProperty("IsPlayable", "true")
        else:
            listitem.setProperty("IsPlayable", "false")

        if date is not None:
            listitem.setInfo("video", {"date": date})

        if info is not None:
            listitem.setInfo("video", {"plot": info})

        if context_menu_items is not None:
            listitem.addContextMenuItems(context_menu_items)

        items.append((url, listitem, isfolder))








    def addDirectory(self, items, queue=False, isFolder=True):
        if items is None or len(items) == 0:
            control.idle()
            c.infoDialog( 'No Documentaries Found', heading=f'{c.lang(32002)}', sound=True, )
            return
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        addonThumb = c.addon_thumb()
        artPath = c.get_art_path()
        queueMenu = c.lang(32065)
        playRandom = c.lang(32535)
        addToLibrary = c.lang(32551)
        for i in items:
            try:
                name = i['name']
                if i['image'].startswith('http'):
                    thumb = i['image']
                elif artPath:
                    thumb = os.path.join(artPath, i['image'])
                else:
                    thumb = addonThumb
                try:
                    item = control.item(label=name, offscreen=True)
                except Exception:
                    item = control.item(label=name)

                url = f'{sysaddon}?action={i["action"]}'
                if 'url' in i:
                    url += f'&url={quote_plus(str(i["url"]))}'

                # Check if this is a playable item (docuPlay) or a folder (docuCat)
                is_playable = 'docuPlay' in i.get('action', '')
                item_is_folder = isFolder and not is_playable

                if item_is_folder:
                    item.setProperty('IsPlayable', 'false')
                else:
                    item.setProperty('IsPlayable', 'true')

                item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': c.addon_fanart()})
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=item_is_folder)
            except Exception as e:
                failure = traceback.format_exc()
                c.log(f'Exception in addDirectory: {failure}')
                pass
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)

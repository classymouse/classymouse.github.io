# The Crew 3.0.5 — Soak Handoff (June 2026)

**Philosophy:** Fix on contact during soak ("hufter-proof"). No git commits unless explicitly requested. Restart Kodi after Python changes.

**Hufter-proof bar:** If you cannot break it in ~30 minutes of deliberate browsing, a typical user should not hit it either. Playback/scrobble signed off (extensively re-checked Jun 11). Trakt watchlist + custom list add/remove signed off. Dialog busy cursors (My Statistics, Scraper Maintenance, Changelog) signed off. **Remaining before Shield:** hufter-proof sweep items below (cold start, settings, widgets, etc.).

**User:** Windows dev soak → then NVIDIA Shield. Break things before users do.

---

## Signed off (Windows)

| Area | Result |
|------|--------|
| Trakt Manager — collection / custom lists / watchlist | OK — watchlist add/remove + custom list remove instant refresh (Jun 11) |
| My Statistics, Scraper Maintenance, Changelog — busy cursor on back | OK (Jun 11) |
| My Statistics, Clear All Cache, Changelog | OK |
| Scraper Maintenance — enable/disable, Test All (threaded), close | OK |
| Scraper Maintenance — Usenet tab uncheck → restores Direct | OK (fixed) |
| Playback resume ~30% (seek + short play) | OK — extensively re-checked (Jun 11) |
| Pause scrobble (movie) | OK — Scrooge: `scrobbleMovie action=pause` @ 35.1% |
| Devmode pause toast | OK — `[Devmode] Trakt: Scrobble, action = pause` |
| 93% watched (≥92% threshold) | OK — Scrooge @ 95.3%: checkmark, no “min remaining”, `action=stop` scrobble, History ✓ — extensively re-checked (Jun 11) |

**Scrooge soak movie:** *Scrooge: A Christmas Carol* (2022) — `tt20917338` / tmdb `1001865`, runtime ~6089s.

---

## Fixes this session (uncommitted)

1. **Scraper Maintenance Usenet tab** — `scraper_status_window.py`: unchecking empty Usenet restores Direct/Torrent.
2. **Pause scrobble (movies / tmdb-only)** — `player.py`, `bookmarks.py`, `trakt.py`, `crewservice.py`:
   - Service player syncs metadata from `player.run()` global store + `thecrew.upnext.*` window properties.
   - Movies no longer require `season` for sync.
   - `imdb=0` treated as missing; Trakt scrobble uses `tmdb` fallback.
   - Episode scrobble blocked without season/episode.
3. **Devmode scrobble toast on pause** — `bookmarks.py` `_notify_scrobble()`: devmode only, only after successful scrobble API call. Users stay silent (no `trakt.scrobble.notify` in settings.xml).
4. **Trakt Top 10 list empty** — giladg list returns 403; menu now uses Trakt `boxoffice`; `trakt_list` replacement fallback no longer returns `None` (TypeError on sort).
5. **Trakt curated lists soak (Jun 11)** — `'collection' in url` hijacked `*-collection` slugs (Quentin → your collection); lists fetched page 1 only (~10 default), sorted alphabetically not by rank. Fixed: paginate all pages, preserve rank, `/users/me/collection/` only. Dead giladg cinematography/stand-up → TMDb discover. **Still stale on Trakt itself:** movistapp lists (sexy/dance/halloween) last updated ~2010–2016 — content problem, not pagination. **Boxset:** user revisiting separately.

Earlier soak fixes (same branch, uncommitted): watchlist cache, Disney+ watch providers, caching tools busy cursor, episode widget stills, etc. — see `changelog.txt` 3.0.5 section.

---

## Still to soak

- [ ] **Hufter-proof sweep (~30 min, Windows)** — see checklist below (items 6 + playback path largely done). Fix on contact; log hits in this doc or `docs/todo.md`.
- [ ] **Shield** — widgets + startup health check (`health_check_3.0.5.done`). Only after Windows sweep passes.
- [ ] **Mac dev feedback** — 3.0.5 zips sent; awaiting open/log/GetDirectory report.

### Hufter-proof sweep (~30 min)

Work top to bottom. **Pass** = no crash, no stuck busy cursor, no blank list forever, no log spam. **Fail** = fix now, re-test that item.

| # | ~min | Area | What to do | 3.0.5 fix it exercises | Status |
|---|------|------|------------|-------------------------|--------|
| 1 | 3 | **Cold start** | Restart Kodi. Watch startup toasts. Open Crew root once. | Health check, settings repair, boot quiet / Trakt defer | |
| 2 | 3 | **Settings** | Crew Settings → browse tabs → back. Optional: tweak one toggle, back out; wait 10s (no Kodi 21 crash). | Stable setting IDs, orphan prune, `onSettingsChanged` | |
| 3 | 5 | **Home widgets** | Trending Movies, Next Episodes, In Progress — scroll, wait for art. | Widget fast path, episode stills, loading placeholder | |
| 4 | 3 | **Browse empty/small list** | Airing Today (or any thin list). Back out. | `endOfDirectory`, busy cursor dismissed | |
| 5 | 3 | **Disney+ movies** | Movies → Disney+ (or Networks). Spot-check titles look like Disney+, not random studios. | `with_watch_providers=337` | |
| 6 | 5 | **Trakt Manager** | Watchlist **add then remove** on one movie; custom list **remove** if you have one. Lists refresh without stale cache. | Watchlist live fetch, cache invalidation | **OK** Jun 11 |
| 7 | 5 | **Episode playback** | One TV episode: play ~2 min, pause, stop. Check log for season/episode scrobble (not movie path). | Episode identity guard, service metadata sync | |
| 8 | 2 | **Caching Tools** | Tools → Clear Cache (or Clear All) → **Cancel**. Back out. | Busy cursor `finally` / `idle()` | |
| 9 | 2 | **Scraper / resolve smoke** | Play any movie → source list → pick one → cancel or play 10s. | Directory closure, resolve overlay teardown | |
| 10 | 2 | **Log skim** | `%APPDATA%\Kodi\the_crew.log` tail — no repeating tracebacks or AllDebrid auth spam. | AD token session guard | |

**Also signed off (not in table):** My Statistics / Scraper Maintenance / Changelog — no stuck busy cursor on back out (Jun 11). Movie playback + scrobble path extensively re-checked (Jun 11).

**Not in 30 min (defer unless you hit it):** Documentaries full play, Adult, TV Evening session, debrid cloud browser, Personal List URL, favourites user report.

---

## Playback soak shortcuts

- No short movies needed: seek to target %, play 30–60s, pause or stop.
- **30%** = resume bookmark + pause scrobble test.
- **93%** = watched threshold test.

---

## Key paths

| What | Where |
|------|--------|
| Pause scrobble / player | `lib/resources/lib/modules/player.py` |
| Scrobble notify | `lib/resources/lib/modules/bookmarks.py` |
| Trakt API | `lib/resources/lib/modules/trakt.py` |
| Scraper Maintenance UI | `lib/resources/lib/windows/scraper_status_window.py` |
| Scraper skins | `script.thecrew.artwork/resources/skins/*/1080i/ScraperStatus.xml` |
| Changelog | `changelog.txt` |
| Log | `%APPDATA%\Kodi\the_crew.log` |

---

## Architecture notes (for next agent)

- **Two player instances:** ephemeral `player.run()` from `playItem` sets metadata; long-lived **service** `crewPlayer` receives `onPlayBackPaused` — must sync metadata before scrobble.
- **CrewMonitor worker** saves resume/scrobble on playback end via window properties (separate from pause path).
- **Thread cap** for scraper tests: ~5–10 workers (`scraper_test.py`).
- **`script.trakt` active** → Crew skips own scrobble (`trakt_official_status`).

---

## Open / deferred

- "Lost all favourites" user report — needs clarification (Kodi Favourites vs Trakt vs Personal List).
- `trakt.scrobble.notify` — code-only setting, not in `settings.xml`; effectively dead for users.

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file settings_repair.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Repair plugin.video.thecrew userdata settings.xml when it contains setting IDs
that no longer exist in resources/settings.xml (Kodi 21 rejects the file).

'''

from __future__ import annotations

import os
import re
import threading
import xml.etree.ElementTree as ET
from typing import Set

_SCHEMA_VERSION = '3.0.6'
_repair_lock = threading.Lock()
_repair_attempted = False
_repair_in_progress = False
_synced_this_process = False


def _use_vfs_io() -> bool:
    """Android/macOS Kodi sandboxes Python open(); use xbmcvfs for userdata I/O."""
    try:
        import platform as _platform
        import xbmc
        kodi_platform = (xbmc.getInfoLabel('System.Platform.OS') or '').lower()
        if kodi_platform in ('android', 'ios', 'osx', 'darwin'):
            return True
        return _platform.system().lower() in ('darwin', 'android')
    except Exception:
        return False


def _file_exists(path: str) -> bool:
    if not path:
        return False
    if _use_vfs_io():
        try:
            import xbmcvfs
            return bool(xbmcvfs.exists(path))
        except Exception:
            pass
    return os.path.isfile(path)


def _read_text(path: str, limit: int | None = None) -> str:
    if not _file_exists(path):
        raise OSError(f'missing: {path}')
    if _use_vfs_io():
        import xbmcvfs
        handle = xbmcvfs.File(path)
        if not handle:
            raise OSError(f'xbmcvfs read failed: {path}')
        try:
            raw = handle.read() or ''
        finally:
            handle.close()
        return raw[:limit] if limit is not None else raw
    with open(path, 'r', encoding='utf-8') as fh:
        return fh.read(limit) if limit is not None else fh.read()


def _write_text(path: str, content: str) -> None:
    from .crewruntime import crew_file_write
    crew_file_write(path, content, mode='w')


def _copy_file(src: str, dst: str) -> None:
    _write_text(dst, _read_text(src))


def _parse_xml_file(path: str) -> ET.ElementTree:
    raw = _read_text(path)
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw
    return ET.ElementTree(ET.fromstring(raw))


def _schema_path() -> str:
    module_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    addons_dir = os.path.dirname(module_root)
    return os.path.join(addons_dir, 'plugin.video.thecrew', 'resources', 'settings.xml')


def _userdata_path(profile_path: str | None = None) -> str:
    """Resolve plugin.video.thecrew userdata settings.xml on any platform."""
    if profile_path:
        return os.path.join(profile_path, 'settings.xml')
    try:
        import xbmcaddon
        import xbmcvfs
        profile = xbmcvfs.translatePath(
            xbmcaddon.Addon('plugin.video.thecrew').getAddonInfo('profile')
        )
        if profile:
            return os.path.join(profile, 'settings.xml')
    except Exception:
        pass
    appdata = os.environ.get('APPDATA')
    if appdata:
        base = os.path.join(appdata, 'Kodi', 'userdata')
    else:
        base = os.path.join(os.path.expanduser('~'), '.kodi', 'userdata')
    return os.path.join(base, 'addon_data', 'plugin.video.thecrew', 'settings.xml')


def load_schema_ids(schema_path: str | None = None) -> Set[str]:
    path = schema_path or _schema_path()
    if not _file_exists(path):
        return set()
    try:
        text = _read_text(path)
    except OSError:
        return set()
    return set(re.findall(r'<setting id="([^"]+)"', text))


def parse_userdata_settings(user_path: str) -> dict[str, str]:
    """Read setting id/value pairs from on-disk userdata (tolerates missing XML header)."""
    if not user_path or not _file_exists(user_path):
        return {}
    try:
        raw = _read_text(user_path)
    except OSError:
        return {}
    if not raw.strip():
        return {}
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return {}
    out: dict[str, str] = {}
    for setting in root:
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        if sid:
            out[sid] = setting.text if setting.text is not None else ''
    return out


def _setting_line(setting: ET.Element) -> str:
    attrs = dict(setting.attrib)
    text = setting.text or ''
    # Kodi treats default="true" as "use schema default" and ignores element text.
    if text.strip():
        attrs.pop('default', None)
    attrs_str = ''.join(f' {k}="{v}"' for k, v in sorted(attrs.items()))
    if text or len(setting) == 0:
        if text:
            return f'    <setting{attrs_str}>{_xml_escape(text)}</setting>'
        return f'    <setting{attrs_str} />'
    # Should not happen in Kodi userdata; keep element text if present.
    return f'    <setting{attrs_str}>{_xml_escape(text)}</setting>'


def _xml_escape(value: str) -> str:
    return (
        value.replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
        .replace("'", '&apos;')
    )


def settings_sync_in_progress() -> bool:
    """True while repair is pushing values via setSetting (ignore onSettingsChanged)."""
    return _repair_in_progress


def original_backup_path(userdata_path: str) -> str:
    """Path to the one-time preserved original userdata snapshot."""
    return userdata_path + '.bak'


def preserve_original_backup(userdata_path: str, log=None) -> str | None:
    """
    Copy userdata to settings.xml.bak only when .bak does not exist yet.

    The .bak file is the user's pre-repair original — never overwrite it on
    later repairs, Kodi saves, or reboots.
    """
    if not userdata_path or not _file_exists(userdata_path):
        return None
    backup = original_backup_path(userdata_path)
    if _file_exists(backup):
        return None
    try:
        _copy_file(userdata_path, backup)
    except OSError:
        return None
    if log:
        log(f'[settings_repair] Preserved original backup: {backup}')
    return backup


def restore_user_settings_from_backup(
    userdata_path: str | None = None,
    backup_path: str | None = None,
    profile_path: str | None = None,
    log=None,
) -> bool:
    """Restore settings.xml from the preserved .bak (adds XML header when missing)."""
    user_path = userdata_path or _userdata_path(profile_path)
    backup = backup_path or original_backup_path(user_path)
    if not _file_exists(backup):
        if log:
            log(f'[settings_repair] No backup to restore: {backup}')
        return False
    try:
        raw = _read_text(backup)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Backup read failed: {exc}')
        return False
    if not raw.lstrip().startswith('<?xml'):
        raw = '<?xml version="1.0" encoding="utf-8"?>\n' + raw.lstrip()
    try:
        _write_text(user_path, raw)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Restore write failed: {exc}')
        return False
    if log:
        log(f'[settings_repair] Restored settings from {os.path.basename(backup)}')
    _clear_runtime_settings_cache()
    _refresh_runtime_theme()
    return True


def ensure_settings_header(userdata_path: str, log=None) -> bool:
    """Prepend XML header only — no setSetting sync (safe from onSettingsChanged)."""
    if not userdata_path or not _file_exists(userdata_path):
        return False
    try:
        raw = _read_text(userdata_path)
    except OSError:
        return False
    if raw.lstrip().startswith('<?xml'):
        return False
    preserve_original_backup(userdata_path, log=log)
    try:
        _write_text(
            userdata_path,
            '<?xml version="1.0" encoding="utf-8"?>\n' + raw.lstrip(),
        )
    except OSError as exc:
        if log:
            log(f'[settings_repair] Header write failed: {exc}')
        return False
    if log:
        log(f'[settings_repair] Added XML header to {os.path.basename(userdata_path)}')
    return True


def repair_all_known_headers(log=None) -> int:
    """Fix missing XML headers for Crew + common dependency addon userdata files."""
    fixed = 0
    targets = ['plugin.video.thecrew']
    try:
        import xbmcaddon
        for addon_id in (
            'script.module.resolveurl',
            'script.module.cocoscrapers',
            'script.module.gearsscrapers',
            'script.module.chainscrapers',
            'script.module.viperscrapers',
        ):
            try:
                xbmcaddon.Addon(addon_id)
                targets.append(addon_id)
            except Exception:
                pass
    except Exception:
        pass

    for addon_id in targets:
        try:
            if addon_id == 'plugin.video.thecrew':
                path = _userdata_path()
            else:
                import xbmcaddon
                import xbmcvfs
                profile = xbmcvfs.translatePath(
                    xbmcaddon.Addon(addon_id).getAddonInfo('profile')
                )
                path = os.path.join(profile, 'settings.xml')
            if ensure_settings_header(path, log=log):
                fixed += 1
        except Exception as exc:
            if log:
                log(f'[settings_repair] Header fix skipped for {addon_id}: {exc}')
    return fixed


def _sync_userdata_to_kodi(user_path: str, log=None) -> int:
    """
    Push on-disk settings into Kodi's in-memory addon settings.

    Kodi loads userdata once at addon start; if the file lacked an XML header
    it keeps defaults until restart. After we repair the file, sync values in-process.
    """
    global _repair_in_progress
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.thecrew')
    except Exception:
        return 0

    synced = 0
    _repair_in_progress = True
    try:
        tree = _parse_xml_file(user_path)
        for setting in tree.getroot():
            if setting.tag != 'setting':
                continue
            sid = setting.attrib.get('id')
            if not sid:
                continue
            val = setting.text if setting.text is not None else ''
            try:
                addon.setSetting(id=sid, value=val)
            except Exception:
                try:
                    addon.setSetting(sid, val)
                except Exception:
                    continue
            synced += 1
    except Exception as exc:
        if log:
            log(f'[settings_repair] Kodi sync skipped: {exc}')
        return 0
    finally:
        _repair_in_progress = False

    if log and synced:
        log(f'[settings_repair] Synced {synced} setting(s) into Kodi runtime')
    return synced


def _clear_runtime_settings_cache() -> None:
    try:
        from .crewruntime import c
        c._settings._cache.clear()
    except Exception:
        pass


def repair_user_settings(
    userdata_path: str | None = None,
    schema_path: str | None = None,
    profile_path: str | None = None,
    log=None,
    sync_kodi: bool = False,
) -> bool:
    """
    Drop orphan setting elements from userdata settings.xml.
    Returns True when the file was modified.
    """
    global _repair_in_progress
    if _repair_in_progress:
        return False

    user_path = userdata_path or _userdata_path(profile_path)
    if not _file_exists(user_path):
        return False

    schema_ids = load_schema_ids(schema_path)
    if not schema_ids:
        if log:
            log('[settings_repair] Schema IDs unavailable — skip')
        return False

    try:
        raw = _read_text(user_path)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Read failed: {exc}')
        return False
    needs_header = not raw.lstrip().startswith('<?xml')

    try:
        tree = _parse_xml_file(user_path)
    except ET.ParseError as exc:
        if log:
            log(f'[settings_repair] Parse failed: {exc}')
        return False
    root = tree.getroot()
    removed = 0
    kept = []
    for setting in list(root):
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        if not sid or sid not in schema_ids or re.match(r'^label\d+$', sid or ''):
            root.remove(setting)
            removed += 1
        else:
            kept.append(setting)

    if removed == 0 and not needs_header:
        return False

    preserve_original_backup(user_path, log=log)

    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<settings version="2">',
    ]
    lines.extend(_setting_line(s) for s in kept)
    lines.append('</settings>')
    new_xml = '\n'.join(lines) + '\n'

    try:
        _write_text(user_path, new_xml)
    except OSError as exc:
        if log:
            log(f'[settings_repair] Write failed: {exc}')
        return False

    if log:
        parts = []
        if removed:
            parts.append(f'removed {removed} orphan(s)')
        if needs_header:
            parts.append('added XML header')
        log(f'[settings_repair] Repaired userdata settings.xml ({", ".join(parts)})')

    if sync_kodi:
        global _synced_this_process
        if not _synced_this_process:
            _sync_userdata_to_kodi(user_path, log=log)
            _synced_this_process = True
        _clear_runtime_settings_cache()
        _refresh_runtime_theme()
    return True


def _refresh_runtime_theme() -> None:
    try:
        from .crewruntime import c
        c._theme = c.appearance()
        c.art = c.get_art_path()
    except Exception:
        pass


def userdata_missing_header(userdata_path: str | None = None) -> bool:
    """True when userdata exists but lacks the XML declaration Kodi 21 expects."""
    user_path = userdata_path or _userdata_path()
    if not _file_exists(user_path):
        return False
    try:
        raw = _read_text(user_path, limit=256)
    except OSError:
        return False
    return not raw.lstrip().startswith('<?xml')


def repair_if_needed(log=None) -> bool:
    """
    Repair userdata settings when needed.

    Kodi strips the XML header when saving from the native Settings UI; re-check
    on every entry so the next addon load sees a valid file. Never sync via
    setSetting here — that triggers onSettingsChanged storms on Kodi 21.
    """
    global _repair_attempted
    if not _file_exists(_userdata_path()):
        return False

    if userdata_missing_header():
        with _repair_lock:
            try:
                schema_ids = load_schema_ids()
                if schema_ids:
                    try:
                        tree = _parse_xml_file(_userdata_path())
                        orphans = sum(
                            1
                            for setting in tree.getroot()
                            if setting.tag == 'setting'
                            and (
                                not setting.attrib.get('id')
                                or setting.attrib.get('id') not in schema_ids
                                or re.match(r'^label\d+$', setting.attrib.get('id') or '')
                            )
                        )
                        if orphans == 0:
                            return ensure_settings_header(_userdata_path(), log=log)
                    except ET.ParseError:
                        pass
                return repair_user_settings(log=log, sync_kodi=False)
            except Exception as exc:
                if log:
                    log(f'[settings_repair] Failed: {exc}')
                return False

    if _repair_attempted:
        return False

    with _repair_lock:
        try:
            repaired = repair_user_settings(log=log, sync_kodi=False)
            if repaired:
                _repair_attempted = True
            return repaired
        except Exception as exc:
            if log:
                log(f'[settings_repair] Failed: {exc}')
            return False

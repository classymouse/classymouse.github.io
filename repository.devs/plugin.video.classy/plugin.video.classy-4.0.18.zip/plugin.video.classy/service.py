# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file service.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy xbmc.service entry  -  thin boot only.

Heavy / periodic work: modules/monitor.py + modules/workers/* (background).
Widget routes: read SQLite caches; do not block on Trakt/TMDB when cache warm.'''

import os

import xbmcvfs

from resources.lib.modules import xbox_ssl  # Xbox UWP SSL  -  before any HTTP

from resources.lib.modules import brand_gate
from resources.lib.modules.classy import c
from resources.lib.modules.monitor import ClassyMonitor
from resources.lib.modules import settings_normalize
from resources.lib.playback.monitor import boot_service_player

LOG_FILENAME = 'classy.log'
OLD_LOG_FILENAME = 'classy.old.log'


def _rotate_session_log():
    try:
        log_dir = xbmcvfs.translatePath('special://logpath')
        log_path = os.path.join(log_dir, LOG_FILENAME)
        old_path = os.path.join(log_dir, OLD_LOG_FILENAME)
        if not xbmcvfs.exists(log_path):
            return
        if xbmcvfs.Stat(log_path).st_size() <= 0:
            return
        if xbmcvfs.exists(old_path):
            xbmcvfs.delete(old_path)
        xbmcvfs.rename(log_path, old_path)
    except Exception:
        pass


if __name__ == '__main__':
    import xbmc

    if not brand_gate.assert_identity():
        raise SystemExit(1)
    _rotate_session_log()
    settings_normalize.normalize_omega_text_settings(log=c.log)
    xbmc.log(f'[Classy] service started v.{c.version} (debug={c._debug_enabled()})', xbmc.LOGINFO)
    c.log('[Classy] service started')
    # B1: ResolveURL backup must follow intentional live debrid clear/reauth.
    # No watcher  -  boot reconcile only (+ Classy Tools scrub when we own clear).
    try:
        from resources.lib.modules import resolveurl_backup
        resolveurl_backup.reconcile_backup_with_live(log_label='boot')
    except Exception as exc:
        c.log(f'[Classy] ResolveURL backup reconcile skipped: {exc}', 1)
    try:
        from resources.lib.modules import segmentproxy
        segmentproxy.start()
    except Exception as exc:
        c.log(f'[Classy] segmentproxy start skipped: {exc}', 1)
    boot_service_player()
    try:
        from resources.lib.tvevening import session as evening_session
        evening_session.startup_check()
    except Exception as exc:
        c.log(f'[Classy] TV Evening startup_check failed: {exc}', 1)
    try:
        ClassyMonitor().run()
    finally:
        # SegmentProxy ThreadingHTTPServer otherwise keeps Kodi exit hung ~5s.
        try:
            from resources.lib.modules import segmentproxy
            segmentproxy.stop()
        except Exception as exc:
            c.log(f'[Classy] segmentproxy stop skipped: {exc}', 1)

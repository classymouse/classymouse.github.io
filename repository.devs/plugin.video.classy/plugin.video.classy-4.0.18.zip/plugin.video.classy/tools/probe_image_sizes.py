# -*- coding: utf-8 -*-

'''Offline  -  compare TMDB URL tokens for min vs medium vs max.'''

from __future__ import print_function

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'
sys.path.insert(0, str(LIB))

from metadata import image_sizes  # noqa: E402


SAMPLE = '/poster.jpg'


def urls_for(level):
    image_sizes.get_size_profile(level)  # noqa  -  use level directly
    from metadata import extract

    p = extract.poster_url(SAMPLE, size=image_sizes.poster_size(level))
    f = extract.fanart_url('/fanart.jpg', size=image_sizes.fanart_size(level))
    s = extract.still_url('/still.jpg', size=image_sizes.still_size(level))
    return p, f, s


def main():
    for level in ('min', 'medium', 'max', 'original'):
        poster, fanart, still = urls_for(level)
        fanart_tv = 'yes' if image_sizes.fanart_tv_fallback_enabled(level) else 'no'
        print('[%s] fanart.tv=%s' % (level, fanart_tv))
        print('  poster: %s' % poster)
        print('  fanart: %s' % fanart)
        print('  still:  %s' % still)
        print('')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

# -*- coding: utf-8 -*-

'''Offline probe  -  VideoLibrary id helpers + strm URL parsing (no Kodi RPC).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    profile = PROFILE
    profile.mkdir(parents=True, exist_ok=True)

    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1,
        LOGERROR=4,
        log=lambda *a, **k: None,
        getInfoLabel=lambda label: '21.2 (21.2.0)',
        executeJSONRPC=lambda *a, **k: '{}',
    )

    sys.modules['xbmcaddon'] = types.SimpleNamespace(
        Addon=lambda addon_id=None: types.SimpleNamespace(
            getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
            getSetting=lambda id='', **k: '',
            getLocalizedString=lambda i: str(i),
            setSetting=lambda *a, **k: None,
        ),
    )
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        translatePath=lambda p: str(profile),
        exists=lambda p: False,
        listdir=lambda p: ([], []),
        File=lambda *a, **k: types.SimpleNamespace(
            read=lambda: b'',
            close=lambda: None,
        ),
    )


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.kodi.videolibrary import (
        JsonRpcError,
        extract_unique_ids,
        movie_matches,
        normalize_imdb,
        normalize_tmdb,
        parse_library_total,
        parse_rpc_response,
        tvshow_matches,
    )
    from resources.lib.kodi.library_strm import (
        display_vfs_path,
        join_vfs_path,
        parse_strm_content,
        path_candidates,
        vfs_io_path,
    )

    assert normalize_imdb('tt1234567') == 'tt1234567'
    assert normalize_imdb('1234567') == 'tt1234567'
    assert normalize_tmdb('44006') == '44006'
    print('[OK] normalize ids')

    ids = extract_unique_ids({
        'imdbnumber': 'tt0816692',
        'uniqueid': {'imdb': 'tt0816692', 'tmdb': '157336'},
    })
    assert ids['imdb'] == 'tt0816692' and ids['tmdb'] == '157336'
    print('[OK] extract_unique_ids')

    movie = {
        'title': 'Interstellar',
        'year': 2014,
        'uniqueid': {'tmdb': '157336', 'imdb': 'tt0816692'},
    }
    assert movie_matches(movie, imdb='tt0816692')
    assert movie_matches(movie, tmdb='157336')
    assert movie_matches(movie, title='Interstellar', year=2014)
    assert not movie_matches(movie, imdb='tt0000000')
    print('[OK] movie_matches')

    show = {'title': 'The Rookie', 'year': 2018, 'uniqueid': {'tmdb': '79744'}}
    assert tvshow_matches(show, tmdb='79744')
    assert tvshow_matches(show, title='The Rookie', year=2018)
    print('[OK] tvshow_matches')

    ok = parse_rpc_response('{"jsonrpc":"2.0","id":1,"result":{"movies":[]}}')
    assert ok == {'movies': []}
    try:
        parse_rpc_response('{"jsonrpc":"2.0","id":1,"error":{"code":-32601,"message":"nope"}}')
        raise AssertionError('expected JsonRpcError')
    except JsonRpcError as exc:
        assert exc.code == -32601
    print('[OK] parse_rpc_response')

    total = parse_library_total({'limits': {'total': 46}, 'tvshows': []}, 'tvshows')
    assert total == 46
    total = parse_library_total({'tvshows': [{'tvshowid': 1}]}, 'tvshows')
    assert total == 1
    print('[OK] parse_library_total')

    assert vfs_io_path('special://userdata/addon_data/foo') == 'special://userdata/addon_data/foo'
    assert display_vfs_path('special://userdata/addon_data/foo').replace('\\', '/') == str(PROFILE).replace('\\', '/')
    assert join_vfs_path('special://tv', 'Show.strm') == 'special://tv/Show.strm'
    cands = path_candidates('special://userdata/addon_data/foo')
    assert cands[0] == 'special://userdata/addon_data/foo'
    assert str(PROFILE).replace('\\', '/') in [c.replace('\\', '/') for c in cands]
    print('[OK] vfs path helpers')

    movie_url = (
        'plugin://plugin.video.thecrew/?action=play&name=Interstellar&'
        'title=Interstellar&year=2014&imdb=tt0816692'
    )
    parsed = parse_strm_content(movie_url)
    assert parsed['kind'] == 'movie'
    assert parsed['imdb'] == 'tt0816692'
    assert parsed['year'] == '2014'
    print('[OK] parse_strm_content movie')

    ep_url = (
        'plugin://plugin.video.thecrew/?action=play&title=Pilot&year=2018&'
        'imdb=tt7587890&tmdb=79744&season=1&episode=1&tvshowtitle=The+Rookie&date=2018-10-16'
    )
    parsed = parse_strm_content(ep_url)
    assert parsed['kind'] == 'episode'
    assert parsed['season'] == 1 and parsed['episode'] == 1
    assert parsed['tmdb'] == '79744'
    print('[OK] parse_strm_content episode')

    print('All VideoLibrary offline probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

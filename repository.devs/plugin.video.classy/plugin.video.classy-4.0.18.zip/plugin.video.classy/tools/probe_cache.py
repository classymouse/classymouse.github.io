# -*- coding: utf-8 -*-

'''Offline probe  -  layered activity fingerprints + SQLite cache invalidation.'''

from __future__ import print_function

import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'
sys.path.insert(0, str(LIB))

PROGRESS_ACTIVITY_KEYS = ('episodes', 'shows')


def _canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'))


def _hash_blob(data):
    return hashlib.md5(_canonical_json(data).encode('utf-8')).hexdigest()


def build_fingerprints(payload):
    if not payload or not isinstance(payload, dict):
        return {}
    fps = {'all': _hash_blob(payload)}
    for key, value in payload.items():
        if value is not None:
            fps[key] = _hash_blob(value)
    return fps


def composite_fingerprint(fingerprints, *domains):
    if not fingerprints or not domains:
        return ''
    if len(domains) == 1:
        return str(fingerprints.get(domains[0]) or '')
    parts = {key: fingerprints[key] for key in sorted(domains) if key in fingerprints}
    if not parts:
        return ''
    return _hash_blob(parts)


SAMPLE = {
    'movies': {'watched_at': '2026-01-01T00:00:00.000Z'},
    'episodes': {'watched_at': '2026-01-02T00:00:00.000Z'},
    'shows': {'rated_at': '2026-01-01T00:00:00.000Z'},
}


def _run_cache_tests(tmpdir):
    import sqlite3
    import time as _time

    db_path = os.path.join(tmpdir, 'classy_cache.db')
    conn = sqlite3.connect(db_path)
    conn.execute(
        '''
        CREATE TABLE cache (
            namespace TEXT NOT NULL,
            cache_key TEXT NOT NULL,
            invalidation TEXT NOT NULL DEFAULT '',
            payload TEXT NOT NULL,
            updated_at REAL NOT NULL,
            expires_at REAL,
            PRIMARY KEY (namespace, cache_key)
        )
        '''
    )
    inv_a = composite_fingerprint(build_fingerprints(SAMPLE), 'episodes', 'shows')
    payload = json.dumps(['show-a'])
    conn.execute(
        'INSERT INTO cache(namespace, cache_key, invalidation, payload, updated_at) '
        'VALUES (?, ?, ?, ?, ?)',
        ('trakt', 'watched_shows', inv_a, payload, _time.time()),
    )
    conn.commit()
    row = conn.execute(
        'SELECT payload FROM cache WHERE namespace=? AND cache_key=? AND invalidation=?',
        ('trakt', 'watched_shows', inv_a),
    ).fetchone()
    miss = conn.execute(
        'SELECT payload FROM cache WHERE namespace=? AND cache_key=? AND invalidation=?',
        ('trakt', 'watched_shows', 'stale'),
    ).fetchone()
    conn.close()
    hit = json.loads(row[0]) if row else None
    return [
        ('cache_hit', hit == ['show-a'], None),
        ('cache_miss_wrong_inv', miss is None, None),
    ]


def main():
    checks = []
    fps = build_fingerprints(SAMPLE)
    checks.append(('has_all_key', 'all' in fps, None))
    checks.append(('has_episodes_key', 'episodes' in fps, None))

    movie_edit = dict(SAMPLE)
    movie_edit['movies'] = {'watched_at': '2026-06-01T00:00:00.000Z'}
    progress_inv_same = (
        composite_fingerprint(build_fingerprints(SAMPLE), *PROGRESS_ACTIVITY_KEYS)
        == composite_fingerprint(build_fingerprints(movie_edit), *PROGRESS_ACTIVITY_KEYS)
    )
    checks.append(('progress_inv_ignores_movies', progress_inv_same, None))

    ep_edit = dict(SAMPLE)
    ep_edit['episodes'] = {'watched_at': '2026-06-01T00:00:00.000Z'}
    progress_inv_changed = (
        composite_fingerprint(build_fingerprints(SAMPLE), *PROGRESS_ACTIVITY_KEYS)
        != composite_fingerprint(build_fingerprints(ep_edit), *PROGRESS_ACTIVITY_KEYS)
    )
    checks.append(('progress_inv_tracks_episodes', progress_inv_changed, None))

    tmpdir = tempfile.mkdtemp(prefix='classy_cache_probe_')
    checks.extend(_run_cache_tests(tmpdir))

    failed = 0
    for name, ok, detail in checks:
        status = 'OK' if ok else 'FAIL'
        extra = '' if detail is None else ' %r' % detail
        print('%s  %s%s' % (status, name, extra))
        if not ok:
            failed += 1
    if failed:
        print('\n%d check(s) failed' % failed)
        return 1
    print('\nAll passed (%d checks)' % len(checks))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

# Restart Kodi Clean — Classy v4
# Kills Kodi, clears .pyc/__pycache__ under addons, optionally clears profile caches + log

param(
    [switch]$ClearCache,      # Also clear Classy Trakt JSON + future SQLite + Kodi textures + classy.log
    [switch]$NoRestart,       # Don't restart Kodi after cleanup
    [switch]$Silent           # Minimal output
)

$ErrorActionPreference = "SilentlyContinue"

if (-not $Silent) {
    Write-Host "=== Kodi Restart & Clean ===" -ForegroundColor Cyan
    Write-Host ""
}

# Step 1: Kill Kodi process
Write-Host "[1/4] Stopping Kodi..." -ForegroundColor Yellow
$kodiProcess = Get-Process -Name "kodi" -ErrorAction SilentlyContinue

if ($kodiProcess) {
    Stop-Process -Name "kodi" -Force
    Start-Sleep -Seconds 2

    # Verify it's stopped
    $stillRunning = Get-Process -Name "kodi" -ErrorAction SilentlyContinue
    if ($stillRunning) {
        Write-Host "      WARNING: Kodi still running, waiting..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
    }
    Write-Host "      ✓ Kodi stopped" -ForegroundColor Green
} else {
    Write-Host "      ℹ Kodi not running" -ForegroundColor Gray
}

# Step 2: Clear .pyc files
Write-Host "[2/4] Clearing Python cache..." -ForegroundColor Yellow
$addonsPath = "$env:APPDATA\Kodi\addons"

$pycFiles = Get-ChildItem -Path $addonsPath -Filter "*.pyc" -Recurse -File -ErrorAction SilentlyContinue
$pycCount = ($pycFiles | Measure-Object).Count

if ($pycCount -gt 0) {
    $pycFiles | Remove-Item -Force -ErrorAction SilentlyContinue
}

$pycacheDirs = Get-ChildItem -Path $addonsPath -Filter "__pycache__" -Recurse -Directory -ErrorAction SilentlyContinue
$pycacheDirCount = ($pycacheDirs | Measure-Object).Count

if ($pycacheDirCount -gt 0) {
    $pycacheDirs | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "      ✓ Removed $pycCount .pyc files and $pycacheDirCount __pycache__ dirs" -ForegroundColor Green

# Repair Crew userdata settings before Kodi reads them (Kodi 21 rejects orphan IDs).
# $repairScript = Join-Path $addonsPath "script.module.thecrew\tools\repair_userdata_settings.py"
# if (Test-Path $repairScript) {
#     Write-Host "[2b/4] Repairing Crew userdata settings..." -ForegroundColor Yellow
#     $repairOut = python $repairScript 2>&1
#     if ($repairOut) {
#         $repairOut | ForEach-Object {
#             if ($_ -match 'Repaired') { Write-Host "      $_" -ForegroundColor Green }
#             else { Write-Host "      $_" -ForegroundColor Gray }
#         }
#     }
# }

# Step 3: Clear caches if requested
if ($ClearCache) {
    Write-Host "[3/4] Clearing caches..." -ForegroundColor Yellow

    $pluginData = "$env:APPDATA\Kodi\userdata\addon_data\plugin.video.classy"

    # Classy SQLite + legacy Trakt JSON
    $classyCacheDb = Join-Path $pluginData "classy_cache.db"
    foreach ($suffix in @('', '-wal', '-shm')) {
        $dbFile = "$classyCacheDb$suffix"
        if (Test-Path $dbFile) {
            Remove-Item $dbFile -Force
            Write-Host "      ✓ classy_cache.db cleared (plugin.video.classy)" -ForegroundColor Green
        }
    }

    $classyTraktFiles = @(
        'trakt_watched_shows.json',
        'trakt_next_episode_slots.json',
        'trakt_in_progress_show_slots.json',
        'trakt_state.json'
    )
    foreach ($name in $classyTraktFiles) {
        $file = Join-Path $pluginData $name
        if (Test-Path $file) {
            Remove-Item $file -Force
            Write-Host "      ✓ $name cleared (plugin.video.classy)" -ForegroundColor Green
        }
    }

    # Legacy cache.db name (if present from older experiments)
    $pluginCacheDb = Join-Path $pluginData "cache.db"
    if (Test-Path $pluginCacheDb) {
        Remove-Item $pluginCacheDb -Force
        Write-Host "      ✓ cache.db cleared (plugin.video.classy)" -ForegroundColor Green
    } else {
        Write-Host "      ℹ cache.db not found (plugin.video.classy)" -ForegroundColor Gray
    }

    # Metacache — poster/plot/rating enrichment (worker.super_info cold path)
    $metaCacheBase = Join-Path $pluginData "meta.5.db"
    $metaRemoved = $false
    foreach ($suffix in @('', '-wal', '-shm')) {
        $metaFile = "$metaCacheBase$suffix"
        if (Test-Path $metaFile) {
            Remove-Item $metaFile -Force
            $metaRemoved = $true
        }
    }
    if ($metaRemoved) {
        Write-Host "      ✓ meta.5.db cleared (plugin.video.classy)" -ForegroundColor Green
    } else {
        Write-Host "      ℹ meta.5.db not found (plugin.video.classy)" -ForegroundColor Gray
    }

    $providerCacheDb = Join-Path $pluginData "providers.13.db"
    if (Test-Path $providerCacheDb) {
        try {
            python -c "import sqlite3; db=r'$providerCacheDb'; c=sqlite3.connect(db); cur=c.cursor(); cur.execute('DELETE FROM source_cache'); c.commit(); c.close()" 2>$null
            Write-Host "      ✓ source_cache cleared (providers.13.db)" -ForegroundColor Green
        } catch {
            Write-Host "      ⚠ Could not clear source_cache in providers.13.db" -ForegroundColor Yellow
        }
    } else {
        Write-Host "      ℹ providers.13.db not found (plugin.video.classy)" -ForegroundColor Gray
    }

    # Legacy module profile cache (usually unused on current builds)
    $crewData = "$env:APPDATA\Kodi\userdata\addon_data\script.module.thecrew"
    $cacheDb  = Join-Path $crewData "cache.db"
    if (Test-Path $cacheDb) {
        Remove-Item $cacheDb -Force
        Write-Host "      ✓ cache.db cleared (script.module.thecrew)" -ForegroundColor Green
    }

    # Kodi texture index — Textures13.db etc. (Aeon Nox Silvo has no UI for this)
    $dbDir = "$env:APPDATA\Kodi\userdata\Database"
    $textureFiles = @()
    if (Test-Path $dbDir) {
        $textureFiles = Get-ChildItem -Path $dbDir -Filter "Textures*.db*" -File -ErrorAction SilentlyContinue
    }
    if ($textureFiles.Count -gt 0) {
        $textureFiles | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Host "      ✓ Texture index cleared ($($textureFiles.Count) file(s): Textures*.db)" -ForegroundColor Green
    } else {
        Write-Host "      ℹ No Textures*.db found in userdata\Database" -ForegroundColor Gray
    }

    # Kodi cached thumbnail image files (pairs with Textures*.db above)
    $thumbCache = "$env:APPDATA\Kodi\userdata\Thumbnails"
    if (Test-Path $thumbCache) {
        $thumbCount = (Get-ChildItem -Path $thumbCache -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count
        Get-ChildItem -Path $thumbCache -Recurse -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Host "      ✓ Thumbnails folder cleared ($thumbCount file(s))" -ForegroundColor Green
    } else {
        Write-Host "      ℹ Thumbnails folder not found" -ForegroundColor Gray
    }

    # Kodi temp dir
    $kodiTemp = "$env:APPDATA\Kodi\temp"
    if (Test-Path $kodiTemp) {
        Get-ChildItem -Path $kodiTemp -Recurse -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Host "      ✓ Kodi temp cleared" -ForegroundColor Green
    }

    # Truncate our own addon log
    $addonLog = "$env:APPDATA\Kodi\classy.log"
    if (Test-Path $addonLog) {
        Clear-Content $addonLog
        Write-Host "      ✓ classy.log truncated" -ForegroundColor Green
    }
} else {
    Write-Host "[3/4] Skipping cache clear (use -ClearCache to clear)" -ForegroundColor Gray
}

# Step 4: Restart Kodi
if (-not $NoRestart) {
    Write-Host "[4/4] Starting Kodi..." -ForegroundColor Yellow

    # Find Kodi executable
    $kodiPaths = @(
        "$env:ProgramFiles\Kodi\kodi.exe",
        "${env:ProgramFiles(x86)}\Kodi\kodi.exe",
        "$env:LOCALAPPDATA\Kodi\kodi.exe"
    )

    $kodiExe = $kodiPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if ($kodiExe) {
        Start-Process $kodiExe
        Write-Host "      ✓ Kodi started" -ForegroundColor Green
    } else {
        Write-Host "      ⚠ Could not find Kodi executable" -ForegroundColor Yellow
        Write-Host "      Please start Kodi manually" -ForegroundColor Yellow
    }
} else {
    Write-Host "[4/4] Skipping restart (use without -NoRestart to auto-start)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "✓ Done!" -ForegroundColor Green
Write-Host ""

# Show usage examples
if (-not $Silent) {
    Write-Host "Quick reference:" -ForegroundColor Cyan
    Write-Host "  .\restart_kodi_clean.ps1                    # Clean pyc and restart"
    Write-Host "  .\restart_kodi_clean.ps1 -ClearCache        # Also clear Trakt JSON + textures + classy.log"
    Write-Host "  .\restart_kodi_clean.ps1 -NoRestart         # Clean only, don't restart"
    Write-Host "  .\restart_kodi_clean.ps1 -Silent            # Minimal output"
    Write-Host ""
}

# -*- coding: utf-8 -*-

'''Print TMDB + Trakt status vocabulary and live TMDB samples (offline-friendly).'''

from __future__ import print_function

import json
import sys
import types
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'


def _get_json(url):
    with urllib.request.urlopen(url, timeout=15) as resp:
        return json.loads(resp.read())


def main():
    sys.path.insert(0, str(LIB))
    from metadata import tv_status  # noqa: E402
    from modules.keys import tmdb_key  # noqa: E402

    print('=== TMDB show.status (official) ===')
    for s in sorted(tv_status.TMDB_SHOW_STATUSES):
        tag = tv_status.classify_tmdb_show_status(s)
        print(f'  {s!r:22} -> {tag}')

    print('\n=== Trakt show.status (official) ===')
    for s in sorted(tv_status.TRAKT_SHOW_STATUSES):
        tag = tv_status.classify_trakt_show_status(s)
        print(f'  {s!r:22} -> {tag}')

    print('\n=== TMDB episode.episode_type ===')
    for t in sorted(tv_status.TMDB_EPISODE_TYPES | tv_status.TRAKT_EPISODE_TYPES):
        flags = []
        if tv_status.episode_type_is_season_finale(t):
            flags.append('season_finale')
        if tv_status.episode_type_is_mid_season_finale(t):
            flags.append('mid_season_only')
        print(f'  {t!r:22} -> {", ".join(flags) or "linear+1"}')

    print('\n=== Live TMDB samples ===')
    k = tmdb_key
    samples = [
        ('The Rookie', 79744, 7, 18),
        ('Breaking Bad', 1396, 5, 16),
    ]
    for title, tmdb_id, sn, en in samples:
        show = _get_json(f'https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={k}')
        ep_url = f'https://api.themoviedb.org/3/tv/{tmdb_id}/season/{sn}/episode/{en}?api_key={k}'
        try:
            ep = _get_json(ep_url)
            ep_type = ep.get('episode_type')
        except urllib.error.HTTPError:
            ep_type = '(404)'
        print(
            f'  {title}: show={show.get("status")!r} '
            f'blocks_next={tv_status.tmdb_show_blocks_next(show)} '
            f'S{sn:02d}E{en:02d} type={ep_type!r}'
        )
        nxt = show.get('next_episode_to_air')
        if nxt:
            print(f'    next_episode_to_air: S{nxt.get("season_number"):02d}E{nxt.get("episode_number"):02d}')

    print('\nNote: "pilot" show status does NOT hard-block next  -  use aired_episodes + TMDB.')
    print('      Hard block: ended / canceled only.')
    print('      There is no TMDB/Trakt value "ended production".')
    return 0


if __name__ == '__main__':
    sys.exit(main())

# -*- coding: utf-8 -*-

'''Offline probe for TMDB + Trakt path registries.'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.apis import tmdb_paths
    from resources.lib.trakt import paths as trakt_paths
    assert trakt_paths.path('sync', 'last_activities') == '/sync/last_activities'
    assert trakt_paths.path('calendars', 'my_shows', start_date='2026-01-01', days=7) == (
        '/calendars/my/shows/2026-01-01/7'
    )
    assert trakt_paths.path('users', 'history_shows') == '/users/me/history/shows'
    print('[OK] TRAKT_PATHS')

    assert tmdb_paths.path('detail', 'tv', tmdb_id=4400) == '/tv/4400'
    assert tmdb_paths.path('detail', 'movie', tmdb_id=99) == '/movie/99'
    assert tmdb_paths.path('discover', 'tv') == '/discover/tv'
    assert tmdb_paths.path('search', 'keyword') == '/search/keyword'
    assert tmdb_paths.path('lists', 'tv', 'on_the_air') == '/tv/on_the_air'
    assert tmdb_paths.path('episode', tmdb_id=1, season=2, episode=3) == (
        '/tv/1/season/2/episode/3'
    )
    print('[OK] TMDB_PATHS')

    print('All path registry probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

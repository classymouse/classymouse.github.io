# -*- coding: utf-8 -*-

'''Offline probe for progress/slot filters.'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.progress import filters as slot_filters

    slots = [
        {'show_data': {'ids': {'tmdb': '1', 'trakt': '10'}, 'status': 'returning series'},
         'season': 1, 'episode': 2, 'last_watched_at': 'a'},
        {'show_data': {'ids': {'tmdb': '1', 'trakt': '10'}, 'status': 'returning series'},
         'season': 1, 'episode': 2, 'last_watched_at': 'b'},
        {'show_data': {'ids': {'tmdb': '2', 'trakt': '20'}, 'status': 'returning series'},
         'season': 7, 'episode': 17, 'last_watched_at': 'c'},
        {'show_data': {'ids': {'tmdb': '3', 'trakt': '30'}, 'status': 'ended'},
         'season': 1, 'episode': 1, 'last_watched_at': 'd'},
    ]

    stats = slot_filters.FilterStats()
    out = slot_filters.filter_next_episode_slots(
        slots, hidden_trakt={'20'}, stats=stats,
    )
    assert len(out) == 1
    assert out[0]['show_data']['ids']['tmdb'] == '1'
    assert stats.dropped.get('dedup') == 1
    assert stats.dropped.get('hidden') == 1
    assert stats.dropped.get('ended') == 1
    print('[OK] next_episode filters dedup/hidden/ended')

    show_slots = [
        {'item': {'show': {'ids': {'trakt': '20'}}}},
        {'item': {'show': {'ids': {'trakt': '99'}}}},
    ]
    shows = slot_filters.filter_in_progress_show_slots(show_slots, hidden_trakt={'20'})
    assert len(shows) == 1
    print('[OK] in_progress hidden filter')

    resume_slots = [
        {'show_data': {'ids': {'tmdb': '1', 'trakt': '10'}}, 'season': 1, 'episode': 1},
        {'show_data': {'ids': {'tmdb': '1', 'trakt': '10'}}, 'season': 1, 'episode': 1},
        {'show_data': {'ids': {'tmdb': '2', 'trakt': '20'}}, 'season': 2, 'episode': 3},
    ]
    resume = slot_filters.filter_in_progress_episode_slots(
        resume_slots, hidden_trakt={'20'},
    )
    assert len(resume) == 1
    print('[OK] in_progress episode dedup/hidden')

    print('All slot filter probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

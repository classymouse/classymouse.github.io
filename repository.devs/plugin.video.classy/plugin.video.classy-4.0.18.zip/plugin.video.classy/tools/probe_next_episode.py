# -*- coding: utf-8 -*-

'''Offline probe for progress/next_episode.py (finale + 404 cascade).'''

from __future__ import print_function

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'


def _install_kodi_stubs():
    import types

    profile = ROOT / 'addon_data_test'
    profile.mkdir(exist_ok=True)

    def _info(key):
        data = {
            'id': 'plugin.video.classy',
            'version': '4.0.0',
            'path': str(ROOT),
            'profile': str(profile),
        }
        return data.get(key, '')

    addon = types.SimpleNamespace(
        getLocalizedString=lambda i: str(i),
        getAddonInfo=_info,
        getSetting=lambda id='', **k: '',
        setSetting=lambda id='', value='': None,
    )

    sys.modules.setdefault('xbmc', types.SimpleNamespace(
        LOGDEBUG=0, LOGINFO=1, LOGERROR=4,
        log=lambda msg, level=0: None,
        getInfoLabel=lambda label: '21.2 (21.2.0) Git:20250201' if label == 'System.BuildVersion' else 'Windows 10',
        executebuiltin=lambda cmd: None,
    ))
    sys.modules.setdefault('xbmcaddon', types.SimpleNamespace(Addon=lambda id=None: addon))
    sys.modules.setdefault('xbmcgui', types.SimpleNamespace())
    sys.modules.setdefault('xbmcvfs', types.SimpleNamespace(
        translatePath=lambda p: str(profile),
    ))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.progress import next_episode as ne  # noqa: E402

    checks = []

    # --- furthest watched ---
    seasons = [
        {'number': 7, 'episodes': [{'number': 17, 'last_watched_at': 'a'}, {'number': 18, 'last_watched_at': 'b'}]},
        {'number': 6, 'episodes': [{'number': 10}]},
    ]
    fw = ne.furthest_watched_episode(seasons)
    checks.append(('furthest S07E18', fw and fw['season'] == 7 and fw['episode'] == 18))

    # --- Trakt season_finale alias (The Rookie uses this string on Trakt) ---
    def fetch_trakt_finale(tmdb_id, season, episode):
        if season == 7 and episode == 18:
            return {'id': 1, 'episode_type': 'season_finale', 'name': 'Finale'}
        if season == 8 and episode == 1:
            return {'id': 2, 'name': 'Premiere'}
        return None

    resolved_trakt = ne.resolve_next_season_episode(
        '79744', 7, 18, show_title='Rookie-trakt-type',
        fetch_episode=fetch_trakt_finale,
        fetch_show=lambda _t: {'status': 'Returning Series'},
    )
    checks.append(('Trakt season_finale  ->  S08E01', resolved_trakt == (8, 1)))

    # --- finale type  ->  S+1 E01 ---
    def fetch_finale(tmdb_id, season, episode):
        if season == 7 and episode == 18:
            return {'id': 1, 'episode_type': 'finale', 'name': 'Finale'}
        if season == 8 and episode == 1:
            return {'id': 2, 'name': 'Premiere'}
        return None

    resolved = ne.resolve_next_season_episode(
        '123', 7, 18, show_title='Rookie',
        fetch_episode=fetch_finale,
        fetch_show=lambda _t: {'status': 'Returning Series'},
    )
    checks.append(('finale  ->  S08E01', resolved == (8, 1)))

    # --- finale but no next season yet ---
    resolved_none = ne.resolve_next_season_episode(
        '123', 7, 18, show_title='Rookie',
        fetch_episode=lambda t, s, e: {'episode_type': 'finale'} if (s, e) == (7, 18) else None,
        fetch_show=lambda _t: {'status': 'Returning Series'},
    )
    checks.append(('finale no S08  ->  None', resolved_none is None))

    # --- show ended ---
    ended = ne.resolve_next_season_episode(
        '123', 1, 5,
        show_data={'status': 'ended'},
        fetch_episode=lambda *a: {'id': 1},
    )
    checks.append(('trakt ended  ->  None', ended is None))

    # --- linear E+1 ---
    def fetch_linear(tmdb_id, season, episode):
        if (season, episode) == (1, 5):
            return {'id': 1, 'episode_type': 'standard'}
        if (season, episode) == (1, 6):
            return {'id': 2}
        return None

    linear = ne.resolve_next_season_episode(
        '99', 1, 5, fetch_episode=fetch_linear,
        fetch_show=lambda _t: {},
    )
    checks.append(('S01E05  ->  S01E06', linear == (1, 6)))

    # --- 404 on E+1  ->  S+1 E01 ---
    def fetch_404_mid(tmdb_id, season, episode):
        if (season, episode) == (7, 18):
            return {'id': 1, 'episode_type': 'standard'}
        if (season, episode) == (7, 19):
            return None
        if (season, episode) == (8, 1):
            return {'id': 2}
        return None

    bump = ne.resolve_next_season_episode(
        '55', 7, 18, show_title='UntaggedFinale',
        fetch_episode=fetch_404_mid,
        fetch_show=lambda _t: {'status': 'Returning Series'},
    )
    checks.append(('404 S07E19  ->  S08E01', bump == (8, 1)))

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(('[OK] ' if ok else '[FAIL] ') + name)

    if failed:
        print('FAILED:', ', '.join(failed))
        return 1
    print('All next_episode probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

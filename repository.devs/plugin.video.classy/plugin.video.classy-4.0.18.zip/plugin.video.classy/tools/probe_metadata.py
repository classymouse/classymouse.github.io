# -*- coding: utf-8 -*-

'''Offline probe for metadata/extract.py (phase 1b).'''

from __future__ import print_function

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'

FIXTURE = {
    'name': 'Pilot',
    'overview': 'A high school chemistry teacher diagnosed with cancer turns to manufacturing drugs.',
    'still_path': '/stills/pilot.jpg',
    'vote_average': 8.3,
    'credits': {
        'crew': [
            {'name': 'Vince Gilligan', 'job': 'Director'},
            {'name': 'Vince Gilligan', 'job': 'Writer'},
        ],
        'cast': [
            {'name': 'Bryan Cranston', 'character': 'Walter White', 'profile_path': '/profiles/bc.jpg'},
        ],
    },
    'videos': {
        'results': [
            {'site': 'YouTube', 'type': 'Trailer', 'key': 'HhesaQXLuRQ', 'official': True},
        ],
    },
}


def main():
    sys.path.insert(0, str(LIB))
    from metadata import extract  # noqa: E402

    checks = []
    director = extract.directors_from_crew(FIXTURE['credits']['crew'])
    checks.append(('director', director == 'Vince Gilligan', director))

    writer = extract.writers_from_crew(FIXTURE['credits']['crew'])
    checks.append(('writer', writer == 'Vince Gilligan', writer))

    poster = extract.poster_url(FIXTURE['still_path'])
    checks.append(('poster_url_medium', poster.endswith('/w500/stills/pilot.jpg'), poster))

    min_poster = extract.poster_url(FIXTURE['still_path'], size='w342')
    checks.append(('poster_url_min', min_poster.endswith('/w342/stills/pilot.jpg'), min_poster))

    cast = extract.cast_with_thumbs(FIXTURE['credits'])
    checks.append(('cast', len(cast) == 1 and cast[0]['name'] == 'Bryan Cranston', cast))

    trailer = extract.trailer_youtube(FIXTURE['videos'])
    checks.append(('trailer', 'HhesaQXLuRQ' in trailer, trailer))

    failed = 0
    for name, ok, detail in checks:
        status = 'OK' if ok else 'FAIL'
        print('%s  %s: %r' % (status, name, detail))
        if not ok:
            failed += 1
    if failed:
        print('\n%d check(s) failed' % failed)
        return 1
    print('\nAll passed (%d checks)' % len(checks))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print('FAIL: %s' % exc, file=sys.stderr)
        raise SystemExit(1)

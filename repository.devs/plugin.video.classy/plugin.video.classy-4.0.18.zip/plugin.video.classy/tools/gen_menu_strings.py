# -*- coding: utf-8 -*-
"""One-off generator: menu_ids.py, menu_labels.py, PO block from legacy menu_labels."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT / 'resources/lib/indexers/menu_labels.py'

SPECIAL = {
    'DEVELOPERS': 'developers',
    'MY_CREW_EMPTY': 'hint',
    'MY_TV_SECTION': 'section',
    'ALL_TV_SECTION': 'section',
    'MOVIE_CAL_THEATRICAL_WEEK': 'cal_theatrical_week',
    'MOVIE_CAL_THEATRICAL_MONTH': 'cal_theatrical_month',
    'MOVIE_CAL_DVD_WEEK': 'cal_dvd',
    'MOVIE_CAL_DVD_MONTH': 'cal_dvd',
    'TRAKT_AUTHORIZE': 'trakt_auth',
    'RESOLVEURL_SETTINGS': 'resolveurl_settings',
}

COLOR_TAG = re.compile(r'\[/?[^\]]+\]')


def plain(s):
    s = COLOR_TAG.sub('', s)
    s = s.replace('*', '').strip()
    return re.sub(r'\s+', ' ', s)


def main():
    text = LEGACY.read_text(encoding='utf-8')
    entries = []
    for m in re.finditer(r'^([A-Z][A-Z0-9_]+)\s*=\s*[\"\'](.+?)[\"\']\s*$', text, re.M):
        name, val = m.group(1), m.group(2)
        entries.append((name, plain(val), SPECIAL.get(name, 'item')))

    start = 30600
    ids_py = [
        '# -*- coding: utf-8 -*-',
        "'''Numeric string IDs for navigator menus (30600-30999).'''",
        '',
    ]
    labels_py = [
        '# -*- coding: utf-8 -*-',
        "'''Navigator labels  -  plain text IDs + display style (markup via menu_format).'''",
        '',
        'import re',
        '',
        'from ..modules.classy import c',
        'from . import menu_format',
        'from . import menu_ids as I',
        '',
        '_COLOR_TAG = re.compile(r\'\\[/?[^\\]]+\\]\', re.IGNORECASE)',
        '',
        '',
        'class NavLabel:',
        '    __slots__ = (\'id\', \'style\')',
        '',
        '    def __init__(self, string_id, style=\'item\'):',
        '        self.id = string_id',
        '        self.style = style',
        '',
        '',
        'def plain_text(label, row_style=None):',
        "    '''Resolve label to plain text (no markup) for storage / CM / pinboard.'''",
        '    style = row_style',
        '    if isinstance(label, NavLabel):',
        '        style = label.style or style',
        '        label = label.id',
        '    if isinstance(label, int):',
        '        return c.lang(label)',
        "    text = _COLOR_TAG.sub('', str(label or ''))",
        "    return ' '.join(text.replace('*', '').split()).strip()",
        '',
        '',
        'def display_label(label, row_style=None):',
        "    '''Resolve NavLabel / int / str to formatted Kodi list label.'''",
        "    style = row_style or 'item'",
        '    if isinstance(label, NavLabel):',
        '        style = label.style or style',
        '        text = c.lang(label.id)',
        '    elif isinstance(label, int):',
        '        text = c.lang(label)',
        '    else:',
        '        text = plain_text(label)',
        '    return menu_format.format_label(style, text)',
        '',
        '',
    ]
    po = []

    for i, (name, msg, style) in enumerate(entries):
        sid = start + i
        ids_py.append(f'{name} = {sid}')
        style_arg = f", '{style}'" if style != 'item' else ''
        labels_py.append(f'{name} = NavLabel(I.{name}{style_arg})')
        po.append(f'msgctxt "#{sid}"')
        po.append(f'msgid "{msg}"')
        po.append('msgstr ""')
        po.append('')

    out = ROOT / 'resources/lib/indexers'
    (out / 'menu_ids.py').write_text('\n'.join(ids_py) + '\n', encoding='utf-8')
    (out / 'menu_labels.py').write_text('\n'.join(labels_py) + '\n', encoding='utf-8')
    (ROOT / 'tools/_gen_strings_306xx.po').write_text('\n'.join(po) + '\n', encoding='utf-8')
    print(f'generated {len(entries)} labels ({start}-{start + len(entries) - 1})')


if __name__ == '__main__':
    main()

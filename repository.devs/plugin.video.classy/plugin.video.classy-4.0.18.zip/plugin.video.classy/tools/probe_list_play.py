# -*- coding: utf-8 -*-
'''Offline checks for lists/play sublink detection (no Kodi).'''

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'resources' / 'lib'))

_SUBLINK = re.compile(
    r'<sublink(?:\s+name=|)(?:\'|\"|)(.*?)(?:\'|\"|)>(.+?)</sublink>',
    re.DOTALL,
)

RING_URL = (
    '<sublink FREE PRELIMS></sublink>        '
    '<sublink FREE MAIN FIGHT ONLY></sublink>        '
    '<sublink DEBRID PRELIMS>https://rapidgator.net/file/example.mkv.html</sublink>        '
    '<sublink DEBRID FULL CARD>https://rapidgator.net/file/example2.mkv.html</sublink>'
)


def _has_sublink_markup(text):
    if '<sublink' in str(text or '').lower():
        return True
    return bool(_SUBLINK.search(text or ''))


def main():
    assert _has_sublink_markup(RING_URL), 'named sublinks must be detected'
    assert not _has_sublink_markup('plugin://plugin.video.classy/?action=play&imdb=tt123')
    items = _SUBLINK.findall(RING_URL)
    assert len(items) >= 3, f'expected multiple sublinks, got {len(items)}: {items!r}'
    print('probe_list_play: OK')


if __name__ == '__main__':
    main()

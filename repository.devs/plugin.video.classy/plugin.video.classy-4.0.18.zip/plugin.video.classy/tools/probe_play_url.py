# -*- coding: utf-8 -*-

'''Offline probe for play URL meta round-trip.'''

from __future__ import print_function

import sys
import types
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else '',
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(ROOT))


def main():
    _install_kodi_stubs()
    sys.argv = ['plugin://plugin.video.classy/']
    sys.path.insert(0, str(ROOT))

    from resources.lib.metadata.video_row import VideoRow
    from resources.lib.play.models import PlayRequest
    from resources.lib.play import metadata as play_metadata
    from resources.lib.play.url import meta_from_row, play_url

    row = VideoRow(
        mediatype='movie',
        title='Test Film',
        year='2024',
        tmdb='123',
        poster='https://image.tmdb.org/t/p/w500/x.jpg',
        tmdb_poster_path='/x.jpg',
        tmdb_backdrop_path='/y.jpg',
        plot='A plot',
    )
    meta = meta_from_row(row)
    assert meta['title'] == 'Test Film'
    assert meta['tmdb_poster_path'] == '/x.jpg'
    print('[OK] meta_from_row')

    url = play_url(row)
    assert 'meta=' in url
    qs = parse_qs(urlparse(url).query)
    req = PlayRequest.from_params({k: v[0] for k, v in qs.items()})
    assert req.title == 'Test Film'
    assert req.meta.get('poster')
    assert req.meta.get('tmdb_poster_path') == '/x.jpg'
    print('[OK] play_url to PlayRequest.from_params')

    # enrich should not need full TMDB when only imdb missing  -  stub resolve
    class _FakeIds:
        @staticmethod
        def valid_id(v):
            return str(v or '').strip()

        @staticmethod
        def resolve_movie_ids(tmdb=None):
            return {'imdb': 'tt999'}

    play_metadata.idmap = _FakeIds
    req.imdb = ''
    play_metadata.enrich_request(req)
    assert req.imdb == '999'
    assert req.meta.get('poster')
    print('[OK] enrich skips full TMDB when meta has art')

    req2 = PlayRequest(
        mediatype='movie',
        title='Cached',
        year='2020',
        tmdb='1',
        imdb='555',
        meta={'poster': 'http://p', 'fanart': 'http://f'},
    )
    play_metadata.enrich_request(req2)
    print('[OK] enrich no-op when scrape ids present')

    print('Play URL meta probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

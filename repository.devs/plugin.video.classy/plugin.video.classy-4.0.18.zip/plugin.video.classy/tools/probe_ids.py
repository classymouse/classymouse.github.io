# -*- coding: utf-8 -*-

'''Offline probe  -  fanart asset lang pick (same logic as artwork.py).'''

from __future__ import print_function


def pick_fanart_asset(fanart_json, asset_key, lang=None):
    if not fanart_json or not asset_key:
        return ''
    items = fanart_json.get(asset_key) or []
    if not isinstance(items, list) or not items:
        return ''
    lang = (lang or 'en').strip()[:2]

    def _sort_key(item):
        if not isinstance(item, dict):
            return (True, True, True)
        item_lang = (item.get('lang') or '').strip()
        return (
            item_lang != lang,
            item_lang != 'en',
            item_lang not in ('00', ''),
        )

    for item in sorted(items, key=_sort_key):
        if isinstance(item, dict):
            url = (item.get('url') or '').strip()
            if url:
                return url
    return ''


SAMPLE_FANART = {
    'tvposter': [
        {'lang': 'en', 'url': 'http://example/en.jpg'},
        {'lang': 'de', 'url': 'http://example/de.jpg'},
    ],
}


def main():
    checks = []
    checks.append((
        'pick_prefers_en',
        pick_fanart_asset(SAMPLE_FANART, 'tvposter', lang='en') == 'http://example/en.jpg',
        None,
    ))
    checks.append((
        'pick_fallback_en',
        pick_fanart_asset(SAMPLE_FANART, 'tvposter', lang='nl') == 'http://example/en.jpg',
        None,
    ))
    neutral = {
        'tvposter': [
            {'lang': '00', 'url': 'http://example/neutral.jpg'},
            {'lang': 'de', 'url': 'http://example/de.jpg'},
        ],
    }
    checks.append((
        'pick_neutral',
        pick_fanart_asset(neutral, 'tvposter', lang='nl') == 'http://example/neutral.jpg',
        None,
    ))

    failed = sum(0 if ok else 1 for _, ok, _ in checks)
    for name, ok, detail in checks:
        print('%s  %s' % ('OK' if ok else 'FAIL', name))
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())

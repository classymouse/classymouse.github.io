# -*- coding: utf-8 -*-

'''Offline probe  -  build PlayRequest and run scrape session (no Kodi player).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'
ADDONS = ROOT.parent


def _install_kodi_stubs():
    profile = PROFILE
    profile.mkdir(parents=True, exist_ok=True)

    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1,
        LOGERROR=4,
        LOGWARNING=3,
        log=lambda *a, **k: None,
        getInfoLabel=lambda label: '21.2' if 'BuildVersion' in label else '',
        getCondVisibility=lambda cond: 'script.module.magneto' in cond,
        Monitor=lambda: types.SimpleNamespace(),
        executebuiltin=lambda *a, **k: None,
        executeJSONRPC=lambda *a, **k: '{}',
        Player=lambda: types.SimpleNamespace(play=lambda *a, **k: None),
    )

    def _addon(addon_id=None):
        mag_profile = profile / 'magneto'
        mag_profile.mkdir(parents=True, exist_ok=True)
        mag_path = ADDONS / 'script.module.magneto'
        info = {
            'path': str(mag_path) if mag_path.is_dir() else str(ADDONS),
            'profile': str(mag_profile),
            'version': '6.06.01',
            'id': addon_id or 'plugin.video.classy',
        }
        return types.SimpleNamespace(
            getAddonInfo=lambda k: info.get(k, str(ROOT)),
            getSetting=lambda id='', **k: 'true' if ('enabled' in id or id.startswith('provider.')) else '',
            getLocalizedString=lambda i: str(i),
            setSetting=lambda *a, **k: None,
        )

    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_addon)
    sys.modules['xbmcgui'] = types.SimpleNamespace(
        Window=lambda wid: types.SimpleNamespace(
            getProperty=lambda key: '',
            setProperty=lambda key, value: None,
        ),
        Dialog=lambda: types.SimpleNamespace(select=lambda *a, **k: 0),
        DialogProgress=lambda: types.SimpleNamespace(),
        ListItem=lambda *a, **k: types.SimpleNamespace(
            setArt=lambda *x, **y: None,
            setProperty=lambda *x, **y: None,
        ),
    )
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        translatePath=lambda p: str(profile),
        exists=lambda p: False,
        delete=lambda p: None,
        mkdir=lambda p: None,
        mkdirs=lambda p: None,
        rename=lambda a, b: None,
        listdir=lambda p: ([], []),
        File=lambda *a, **k: types.SimpleNamespace(read=lambda: b'', write=lambda x: None, close=lambda: None),
    )


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.play.models import PlayRequest
    from resources.lib.sources.orchestrator import scrape_streams

    # Fight Club  -  should return torrent rows when providers are installed.
    request = PlayRequest(
        mediatype='movie',
        title='Fight Club',
        year='1999',
        tmdb='550',
        imdb='0137523',
    )
    streams, cancelled = scrape_streams(request, timeout=20, show_dialog=False)
    if cancelled:
        print('[OK] scrape_streams cancelled')
        return 0
    print(f'[OK] scrape_streams returned {len(streams)} candidates')
    for cand in streams[:8]:
        print(f'     {cand.label()[:120]}')
    if not streams:
        print('[WARN] zero streams  -  providers may be offline or blocked in probe env')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())

# -*- coding: utf-8 -*-

'''Offline probe  -  load provider registry without scraping.'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'
ADDONS = ROOT.parent


def _install_kodi_stubs():
    profile = PROFILE
    profile.mkdir(parents=True, exist_ok=True)

    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1,
        LOGERROR=4,
        LOGWARNING=3,
        log=lambda *a, **k: None,
        getInfoLabel=lambda label: '21.2' if 'BuildVersion' in label else '',
        getCondVisibility=lambda cond: any(
            pack in cond for pack in (
                'script.module.classyscrapers',
                'script.module.cocoscrapers',
                'script.module.gearsscrapers',
                'script.module.viperscrapers',
                'script.module.magneto',
            )
        ),
        Monitor=lambda: types.SimpleNamespace(),
        executebuiltin=lambda *a, **k: None,
        executeJSONRPC=lambda *a, **k: '{}',
    )

    def _addon(addon_id=None):
        mag_profile = profile / 'magneto'
        mag_profile.mkdir(parents=True, exist_ok=True)
        mag_path = ADDONS / 'script.module.magneto'
        info = {
            'path': str(mag_path) if mag_path.is_dir() else str(ADDONS),
            'profile': str(mag_profile),
            'version': '6.06.01',
            'id': addon_id or 'plugin.video.classy',
        }
        return types.SimpleNamespace(
            getAddonInfo=lambda k: info.get(k, str(ROOT)),
            getSetting=lambda id='', **k: 'true' if ('enabled' in id or id.startswith('provider.')) else '',
            getLocalizedString=lambda i: str(i),
            setSetting=lambda *a, **k: None,
        )

    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=_addon)
    sys.modules['xbmcgui'] = types.SimpleNamespace(
        Window=lambda wid: types.SimpleNamespace(
            getProperty=lambda key: '',
            setProperty=lambda key, value: None,
        ),
        Dialog=lambda: types.SimpleNamespace(),
        DialogProgress=lambda: types.SimpleNamespace(),
    )
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        translatePath=lambda p: str(profile),
        exists=lambda p: False,
        delete=lambda p: None,
        mkdir=lambda p: None,
        mkdirs=lambda p: None,
        rename=lambda a, b: None,
        listdir=lambda p: ([], []),
        File=lambda *a, **k: types.SimpleNamespace(read=lambda: b'', write=lambda x: None, close=lambda: None),
    )


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.sources import load_providers

    providers = load_providers()
    internal = [n for n, _ in providers if n.startswith('resources.lib.scrapers')]
    classy = [n for n, _ in providers if n.startswith('classyscrapers.')]
    magneto = [n for n, _ in providers if n.startswith('magneto.')]
    cocos = [n for n, _ in providers if n.startswith('cocoscrapers.')]
    gears = [n for n, _ in providers if n.startswith('gearsscrapers.')]
    vipers = [n for n, _ in providers if n.startswith('viperscrapers.')]

    print(f'[OK] load_providers total={len(providers)}')
    print(
        f'     internal={len(internal)} classy={len(classy)} magneto={len(magneto)} '
        f'cocos={len(cocos)} gears={len(gears)} vipers={len(vipers)}'
    )
    if internal:
        print(f'     sample internal: {internal[:5]}')
    if classy:
        print(f'     sample classy: {classy[:5]}')
    if magneto:
        print(f'     sample magneto: {magneto[:5]}')
    if len(providers) == 0:
        print('[WARN] zero providers loaded  -  check scraper imports')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())

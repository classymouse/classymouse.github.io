# -*- coding: utf-8 -*-

'''Offline probe for movie/TV search (history DB + TMDB paths + row mapping).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'
SEARCH_DB = PROFILE / 'search_probe.db'


def _install_kodi_stubs():
    PROFILE.mkdir(parents=True, exist_ok=True)

    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1,
        LOGERROR=4,
        LOGWARNING=3,
        log=lambda *a, **k: None,
        getInfoLabel=lambda label: '21.2' if 'BuildVersion' in label else '',
        executebuiltin=lambda *a, **k: None,
        Keyboard=lambda *a, **k: types.SimpleNamespace(
            doModal=lambda: None,
            isConfirmed=lambda: False,
            getText=lambda: '',
        ),
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace(
        Window=lambda wid: types.SimpleNamespace(
            getProperty=lambda key: '',
            setProperty=lambda key, value: None,
        ),
        Dialog=lambda: types.SimpleNamespace(
            ok=lambda *a, **k: None,
            select=lambda *a, **k: 0,
            yesno=lambda *a, **k: True,
            notification=lambda *a, **k: None,
        ),
        DialogProgress=lambda: types.SimpleNamespace(),
        DialogProgressBG=lambda: types.SimpleNamespace(),
        ListItem=lambda *a, **k: types.SimpleNamespace(
            setArt=lambda *x, **y: None,
            setProperty=lambda *x, **y: None,
        ),
    )
    sys.modules['xbmcvfs'] = types.SimpleNamespace(
        translatePath=lambda p: str(PROFILE),
        exists=lambda p: False,
        delete=lambda p: None,
        mkdir=lambda p: None,
        mkdirs=lambda p: None,
        rmdir=lambda p: None,
        rename=lambda a, b: None,
        listdir=lambda p: ([], []),
        File=lambda *a, **k: types.SimpleNamespace(
            read=lambda: b'',
            write=lambda x: None,
            close=lambda: None,
        ),
    )
    sys.modules['xbmcplugin'] = types.SimpleNamespace(
        addDirectoryItem=lambda *a, **k: True,
        addDirectoryItems=lambda *a, **k: True,
        setContent=lambda *a, **k: None,
        endOfDirectory=lambda *a, **k: None,
        addSortMethod=lambda *a, **k: None,
        setProperty=lambda *a, **k: None,
    )


def main():
    _install_kodi_stubs()
    if SEARCH_DB.exists():
        SEARCH_DB.unlink()

    sys.argv = ['plugin://plugin.video.classy/', '1']
    sys.path.insert(0, str(ROOT))

    from resources.lib.apis import tmdb_paths
    from resources.lib.metadata.video_row import VideoRow
    from resources.lib.modules import control
    from resources.lib.play.url import play_url
    from resources.lib.search import history
    from resources.lib.search import person
    from urllib.parse import quote_plus, urlencode

    control.searchFile = str(SEARCH_DB)

    assert history.normalize_mediatype('tv') == 'tvshow'
    assert history.normalize_mediatype('movie') == 'movie'
    print('[OK] normalize_mediatype')

    assert tmdb_paths.path('search', 'movie') == '/search/movie'
    assert tmdb_paths.path('search', 'tv') == '/search/tv'
    assert tmdb_paths.path('search', 'person') == '/search/person'
    assert tmdb_paths.path('person', 'movie_credits', person_id=287) == '/person/287/movie_credits'
    assert tmdb_paths.path('person', 'tv_credits', person_id=287) == '/person/287/tv_credits'
    print('[OK] tmdb search paths')

    history.touch_term('movie', 'Matrix')
    history.touch_term('movie', 'Alien')
    history.touch_term('movie', 'matrix')
    terms = history.list_terms('movie')
    assert [t for _, t in terms] == ['matrix', 'alien']
    print('[OK] touch_term + list_terms (dedupe, newest first)')

    term_id = terms[0][0]
    history.delete_term('movie', term_id)
    assert [t for _, t in history.list_terms('movie')] == ['alien']
    print('[OK] delete_term')

    history.touch_term('tvshow', 'breaking bad')
    assert history.list_terms('tvshow') == [(1, 'breaking bad')]
    history.clear_all()
    assert history.list_terms('movie') == []
    assert history.list_terms('tvshow') == []
    print('[OK] clear_all')

    assert person.normalize_scope('tv') == 'tvshow'
    assert person.normalize_scope('movie') == 'movie'
    print('[OK] person normalize_scope')

    movie_credit = VideoRow.from_tmdb_movie({
        'id': 603,
        'title': 'The Matrix',
        'release_date': '1999-03-31',
        'poster_path': '/poster.jpg',
    })
    assert movie_credit.tmdb == '603'
    tv_credit = VideoRow.from_tmdb_tv({
        'id': 1396,
        'name': 'Breaking Bad',
        'first_air_date': '2008-01-20',
        'poster_path': '/poster.jpg',
    })
    assert tv_credit.tmdb == '1396'
    print('[OK] person credits row mapping')

    movie_row = VideoRow.from_tmdb_movie({
        'id': 603,
        'title': 'The Matrix',
        'release_date': '1999-03-31',
        'overview': 'Neo',
        'poster_path': '/poster.jpg',
        'vote_average': 8.2,
        'vote_count': 24000,
    })
    assert movie_row.tmdb == '603'
    assert movie_row.year == '1999'
    print('[OK] VideoRow.from_tmdb_movie (search shape)')

    tv_row = VideoRow.from_tmdb_tv({
        'id': 1396,
        'name': 'Breaking Bad',
        'first_air_date': '2008-01-20',
        'overview': 'Walter',
        'poster_path': '/poster.jpg',
    })
    assert tv_row.tmdb == '1396'
    assert tv_row.tvshowtitle == 'Breaking Bad'
    print('[OK] VideoRow.from_tmdb_tv (search shape)')

    plugin = sys.argv[0]

    movie_results = f'{plugin}?action=movieSearchterm&name={quote_plus("the matrix")}'
    assert 'action=movieSearchterm' in movie_results
    assert 'name=the+matrix' in movie_results or 'name=the%20matrix' in movie_results
    print('[OK] results URL (movie)')

    tv_results = f'{plugin}?action=tvSearchterm&name={quote_plus("star trek: ds9")}'
    assert 'action=tvSearchterm' in tv_results
    assert 'name=' in tv_results
    print('[OK] results URL (tv, special chars)')

    movie_person_results = f'{plugin}?action=moviePersonterm&name={quote_plus("tom hanks")}'
    assert 'action=moviePersonterm' in movie_person_results
    movie_person_credits = f'{plugin}?action=moviePersonCredits&person_id=31&name={quote_plus("tom hanks")}'
    assert 'person_id=31' in movie_person_credits
    tv_person_results = f'{plugin}?action=tvPersonterm&name={quote_plus("bryan cranston")}'
    assert 'action=tvPersonterm' in tv_person_results
    print('[OK] person URL routing')

    movie_play = play_url(movie_row)
    assert 'action=play' in movie_play
    assert 'tmdb=603' in movie_play
    seasons_query = urlencode({
        'action': 'seasons',
        'tmdb': tv_row.tmdb,
        'tvdb': tv_row.tvdb,
        'imdb': tv_row.imdb,
        'tvshowtitle': tv_row.tvshowtitle or tv_row.title,
    })
    tv_seasons = f'{plugin}?{seasons_query}'
    assert 'action=seasons' in tv_seasons
    assert 'tmdb=1396' in tv_seasons
    print('[OK] item URL routing (movie play / tv seasons)')

    # Optional live TMDB (needs API key in settings or env)
    import os
    key = os.environ.get('TMDB_API_KEY', '').strip()
    if key:
        from resources.lib.apis.tmdb import TmdbApi

        api = TmdbApi(api_key=key)
        data = api.search('movie', 'matrix', page=1)
        assert data and data.get('results')
        print('[OK] live TMDB movie search (%s hits)' % len(data['results']))
        tv_data = api.search('tvshow', 'breaking bad', page=1)
        assert tv_data and tv_data.get('results')
        print('[OK] live TMDB tv search (%s hits)' % len(tv_data['results']))
        people_data = api.search_person('tom hanks', page=1)
        assert people_data and people_data.get('results')
        print('[OK] live TMDB person search (%s hits)' % len(people_data['results']))
        person_id = people_data['results'][0]['id']
        credits = api.person_movie_credits(person_id)
        assert credits and credits.get('cast')
        print('[OK] live TMDB person movie credits (%s cast)' % len(credits['cast']))
    else:
        print('[SKIP] live TMDB (set TMDB_API_KEY to enable)')

    print('Search probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

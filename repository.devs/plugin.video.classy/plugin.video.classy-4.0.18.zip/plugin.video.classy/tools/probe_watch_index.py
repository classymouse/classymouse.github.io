# -*- coding: utf-8 -*-

'''Offline probe for VideoRef + WatchIndex (show / season / episode scope).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2 (21.2.0)',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def _watched_fixture():
    return [
        {
            'show': {
                'title': 'In Progress Show',
                'aired_episodes': 10,
                'ids': {'tmdb': 100, 'imdb': 'tt100'},
            },
            'seasons': [
                {'number': 1, 'episodes': [{'number': 1}, {'number': 2}, {'number': 3}]},
                {'number': 2, 'episodes': [{'number': 1}]},
            ],
        },
        {
            'show': {
                'title': 'Complete Show',
                'aired_episodes': 3,
                'ids': {'tmdb': 200, 'imdb': 'tt200'},
            },
            'seasons': [
                {'number': 1, 'episodes': [{'number': 1}, {'number': 2}, {'number': 3}]},
            ],
        },
    ]


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.metadata.tv_ref import VideoRef
    from resources.lib.metadata.video_row import VideoRow
    from resources.lib.trakt.watch_index import WatchIndex

    index = WatchIndex.compile(_watched_fixture())

    # in-progress show
    st = index.state_for(VideoRef(tmdb='100'))
    assert st.watched_count == 4 and st.aired == 10 and not st.complete and st.playcount == 0
    print('[OK] in-progress show playcount=0')

    # complete show
    st = index.state_for(VideoRef(tmdb='200'))
    assert st.complete and st.playcount == 1
    print('[OK] complete show playcount=1')

    # season 1 complete for complete show (3 eps)
    st = index.state_for(VideoRef(tmdb='200', season=1), season_episode_count=3)
    assert st.complete and st.playcount == 1
    print('[OK] season complete')

    # season 2 partial on in-progress show
    st = index.state_for(VideoRef(tmdb='100', season=2), season_episode_count=5)
    assert st.watched and not st.complete and st.playcount == 0
    print('[OK] season partial playcount=0')

    # episode
    st = index.state_for(VideoRef(tmdb='100', season=1, episode=2))
    assert st.watched and st.playcount == 1
    print('[OK] episode watched')

    st = index.state_for(VideoRef(tmdb='100', season=2, episode=2))
    assert not st.watched and st.playcount == 0
    print('[OK] episode unwatched')

    row = VideoRow(mediatype='tvshow', tmdb='100', tvshowtitle='In Progress Show')
    index.apply_to_row(row)
    assert row.playcount == 0 and row.overlay == 6
    print('[OK] apply_to_row tvshow in-progress overlay')

    # season complete via apply with episode_count
    row = VideoRow(mediatype='season', tmdb='200', season=1, title='Season 1')
    index.apply_to_row(row, season_episode_count=3)
    assert row.playcount == 1 and row.overlay == 7
    print('[OK] season row apply complete')

    row = VideoRow(mediatype='episode', tmdb='100', season=1, episode=2, title='Ep 2')
    index.apply_to_row(row)
    assert row.playcount == 1
    print('[OK] episode row apply watched')

    from resources.lib.trakt.resume_index import ResumeIndex
    from resources.lib.trakt.browse_context import TVBrowseContext

    playback = [{
        'progress': 45.0,
        'show': {'ids': {'tmdb': 100}},
        'episode': {'season': 1, 'number': 2, 'runtime': 44},
    }]
    resume_idx = ResumeIndex.compile(playback)
    row = VideoRow(mediatype='episode', tmdb='100', season=1, episode=2, title='Ep 2')
    index.apply_to_row(row)
    assert row.playcount == 1
    resume_idx.apply_to_row(row)
    assert row.playcount == 0 and row.overlay == 6 and row.resume_point == 45.0
    print('[OK] resume overrides sync watched on episode')

    class _Ctx:
        watch = index
        resume = resume_idx

        def apply_watch(self, row, **kwargs):
            if self.resume.apply_to_row(row):
                return None
            return self.watch.apply_to_row(row, **kwargs)

    row = VideoRow(mediatype='episode', tmdb='100', season=1, episode=2, title='Ep 2')
    _Ctx().apply_watch(row)
    assert row.playcount == 0 and row.overlay == 6
    print('[OK] browse apply_watch resume priority')

    from resources.lib.trakt.movie_watch_index import MovieWatchIndex
    from resources.lib.trakt.movie_resume_index import MovieResumeIndex
    from resources.lib.trakt.browse_context import MovieBrowseContext

    movie_watch = MovieWatchIndex.compile([
        {'movie': {'title': 'Seen', 'ids': {'tmdb': 550, 'imdb': 'tt0137523'}}},
    ])
    row = VideoRow(mediatype='movie', tmdb='550', title='Fight Club')
    movie_watch.apply_to_row(row)
    assert row.playcount == 1 and row.overlay == 7
    print('[OK] movie watched overlay')

    movie_resume = MovieResumeIndex.compile([
        {
            'progress': 33.0,
            'movie': {'ids': {'tmdb': 99}, 'runtime': 120},
        },
    ])
    row = VideoRow(mediatype='movie', tmdb='99', title='Partial')
    movie_resume.apply_to_row(row)
    assert row.playcount == 0 and row.overlay == 6 and row.resume_point == 33.0
    print('[OK] movie resume overlay')

    class _MovieCtx:
        watch = movie_watch
        resume = movie_resume

        def apply_watch(self, row):
            if self.resume.apply_to_row(row):
                return True
            return self.watch.apply_to_row(row)

    row = VideoRow(mediatype='movie', tmdb='99', title='Partial')
    _MovieCtx().apply_watch(row)
    assert row.overlay == 6
    row = VideoRow(mediatype='movie', tmdb='550', title='Seen')
    _MovieCtx().apply_watch(row)
    assert row.overlay == 7
    print('[OK] movie browse resume over watched')

    from resources.lib.progress import slots as progress_slots

    playback_movies = [
        {
            'progress': 55.0,
            'paused_at': '2026-07-08T20:00:00.000Z',
            'movie': {
                'title': 'In Progress Film',
                'year': 2024,
                'released': '2024-06-01',
                'runtime': 110,
                'ids': {'tmdb': 42, 'imdb': 'tt42'},
            },
        },
        {'progress': 95.0, 'movie': {'ids': {'tmdb': 99}}},
        {'progress': 0.0, 'movie': {'ids': {'tmdb': 100}}},
    ]
    movie_slots, dropped = progress_slots.scan_in_progress_movie_slots(playback_movies)
    assert len(movie_slots) == 1 and dropped == 2
    row = progress_slots.slot_to_movie_resume_row(movie_slots[0])
    assert row.title == 'In Progress Film'
    assert row.resume_point == 55.0 and row.overlay == 6
    assert row.duration == 110 * 60
    print('[OK] movie continue-watching slots')

    print('All watch_index probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

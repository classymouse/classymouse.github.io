# -*- coding: utf-8 -*-

'''Offline probe for movie discover presets (no HTTP).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.apis import tmdb_discover
    from resources.lib.metadata.video_row import VideoRow
    from resources.lib.trakt import movie_lists as trakt_movie_lists

    p = tmdb_discover.discover_movie_params('popular')
    assert p['sort_by'] == 'popularity.desc'
    assert 'with_release_type' in p
    print('[OK] discover_movie_params popular')

    cert = tmdb_discover.discover_movie_params('tmdb_certification', tid='PG-13')
    assert cert['certification'] == 'PG-13'
    print('[OK] movie certification preset')

    lang = tmdb_discover.discover_movie_params('tmdb_language', tid='fr')
    assert lang['with_original_language'] == 'fr'
    print('[OK] movie language preset')

    featured = tmdb_discover.discover_movie_params('tmdb_movie_featured')
    assert featured['sort_by'] == 'popularity.desc'
    assert featured['with_release_type'] == '1|2|3'
    print('[OK] movie featured preset (New Movies)')

    latest = tmdb_discover.discover_movie_params('tmdb_movie_latest_releases')
    assert latest['with_release_type'] == '4|5|6'
    assert latest['sort_by'] == 'release_date.desc'
    print('[OK] movie latest releases preset')

    premieres = tmdb_discover.discover_movie_params('tmdb_movie_premieres')
    assert premieres['with_release_type'] == '1|3|2'
    print('[OK] movie premieres preset')

    cal_week = tmdb_discover.discover_movie_params('calendar_thisweek')
    assert cal_week['with_release_type'] == '2|3'
    assert cal_week['sort_by'] == 'release_date.asc'
    assert cal_week['with_original_language'] == 'en'
    cal_dvd = tmdb_discover.discover_movie_params('calendar_dvd_thismonth')
    assert cal_dvd['with_release_type'] == '5'
    print('[OK] movie calendar presets')

    year = tmdb_discover.discover_movie_params('tmdb_movie_discover_year', tid='1985')
    assert year['primary_release_year'] == '1985'
    print('[OK] movie discover year preset')

    assert 1970 <= 1985
    print('[OK] movie year floor (1970)')

    flat = tmdb_discover._flatten_trakt_boxoffice([
        {'rank': 1, 'revenue': 100, 'movie': {'title': 'Flat', 'year': 2024, 'ids': {'tmdb': 1}}},
    ])
    assert len(flat) == 1 and flat[0]['movie']['title'] == 'Flat'

    nested = tmdb_discover._flatten_trakt_boxoffice([
        {'movies': [{'rank': 1, 'movie': {'title': 'Nested', 'year': 2024, 'ids': {'tmdb': 2}}}]},
    ])
    assert len(nested) == 1 and nested[0]['movie']['title'] == 'Nested'
    print('[OK] trakt boxoffice flatten')

    page = tmdb_discover._tmdb_list_page({
        'page': 1,
        'total_pages': 2,
        'items': [{'id': 1, 'title': 'Oscar Film', 'release_date': '2020-01-01'}],
    })
    assert page['total_pages'] == 2
    assert page['results'][0]['title'] == 'Oscar Film'
    print('[OK] tmdb list page normalize')

    row = VideoRow.from_tmdb_movie({
        'id': 550,
        'title': 'Fight Club',
        'release_date': '1999-10-15',
        'overview': 'test',
        'poster_path': '/x.jpg',
        'vote_average': 8.4,
        'vote_count': 28000,
    })
    assert row.tmdb == '550'
    assert row.mediatype == 'movie'
    assert row.year == '1999'
    print('[OK] VideoRow.from_tmdb_movie')

    trakt_row = VideoRow.from_trakt_movie({
        'movie': {
            'title': 'Test',
            'year': 2026,
            'released': '2026-12-18',
            'ids': {'tmdb': 1, 'imdb': 'tt1'},
        },
    })
    assert trakt_row.tmdb == '1'
    assert trakt_row.premiered == '2026-12-18'
    print('[OK] VideoRow.from_trakt_movie')

    assert trakt_movie_lists.is_my_movie_preset('traktcollection')
    assert not trakt_movie_lists.is_my_movie_preset('traktplayed')
    assert len(trakt_movie_lists.MY_MOVIE_PRESETS) == 7
    coll = trakt_movie_lists.preset_config('traktcollection')
    assert coll['auth'] and coll['sort_title']
    rec = trakt_movie_lists.preset_config('traktrecommendations')
    feat = trakt_movie_lists.preset_config('traktfeatured')
    assert rec['path'] == feat['path']
    assert trakt_movie_lists._total_pages(1, 5, {'page_count': 267}, 40) == 1
    assert trakt_movie_lists._total_pages(1, 40, {'page_count': 10}, 40) == 10
    assert trakt_movie_lists._total_pages(3, 40, {}, 40) == 4
    filtered = trakt_movie_lists._filter_items([
        {'movie': {'title': 'Future', 'year': 2035}},
        {'movie': {'title': 'Now', 'year': 2020}},
    ], allow_future_years=False)
    assert len(filtered) == 1 and filtered[0]['movie']['title'] == 'Now'
    print('[OK] trakt my-movies preset registry')

    print('Movie discover preset probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

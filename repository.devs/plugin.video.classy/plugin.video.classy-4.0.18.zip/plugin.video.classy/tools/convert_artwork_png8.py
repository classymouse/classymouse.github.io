# -*- coding: utf-8 -*-
"""Convert Classy menu artwork PNGs to palette (PNG8) with alpha.

Keeps visual quality for Kodi menu icons while cutting package size.
Skips files already in palette mode (P). Writes in place.

Usage:
  python tools/convert_artwork_png8.py
  python tools/convert_artwork_png8.py --theme modern
  python tools/convert_artwork_png8.py --dry-run
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print('Pillow required: pip install Pillow')
    sys.exit(1)

ROOT = Path(__file__).resolve().parents[1]
ARTWORK = ROOT / 'resources' / 'lib' / 'artwork'


def convert_png(path: Path, dry_run: bool = False) -> tuple[str, int, int]:
    """Return (status, before_bytes, after_bytes)."""
    before = path.stat().st_size
    with Image.open(path) as im:
        mode = im.mode
        if mode == 'P':
            return 'skip-P', before, before

        rgba = im.convert('RGBA')
        # FASTOCTREE preserves alpha into a palette PNG on Pillow 9+.
        try:
            quantized = rgba.quantize(colors=256, method=Image.Quantize.FASTOCTREE)
        except Exception:
            quantized = rgba.quantize(colors=256, method=Image.Quantize.MEDIANCUT)

        if dry_run:
            # Estimate by encoding to a temp buffer
            from io import BytesIO
            buf = BytesIO()
            quantized.save(buf, format='PNG', optimize=True)
            after = buf.tell()
            return 'dry', before, after

        quantized.save(path, format='PNG', optimize=True)

    after = path.stat().st_size
    return 'ok', before, after


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--theme', default='modern', help='Theme folder under artwork/ (default: modern)')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    theme_dir = ARTWORK / args.theme
    if not theme_dir.is_dir():
        print(f'Theme not found: {theme_dir}')
        return 1

    pngs = sorted(theme_dir.rglob('*.png'))
    total_before = total_after = 0
    converted = skipped = 0

    for path in pngs:
        status, before, after = convert_png(path, dry_run=args.dry_run)
        total_before += before
        total_after += after
        rel = path.relative_to(ARTWORK)
        if status.startswith('skip'):
            skipped += 1
        else:
            converted += 1
            pct = (1 - after / before) * 100 if before else 0
            print(f'{status:4} {before/1024:7.1f}KB -> {after/1024:7.1f}KB ({pct:5.1f}%)  {rel}')

    print('---')
    print(f'files={len(pngs)} converted={converted} skipped={skipped}')
    print(f'total {total_before/1024/1024:.1f}MB -> {total_after/1024/1024:.1f}MB')
    if args.dry_run:
        print('(dry-run  -  nothing written)')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

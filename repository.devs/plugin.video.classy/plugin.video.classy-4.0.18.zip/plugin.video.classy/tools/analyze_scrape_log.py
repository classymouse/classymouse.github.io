# -*- coding: utf-8 -*-

'''Summarize classy.log [Play] provider results by scraper pack.'''

from __future__ import print_function

import re
import sys
from collections import defaultdict
from pathlib import Path

PAT = re.compile(r'\[Play\] ([^ ]+) -> (\d+) \(')


def pack_for(name):
    if name.startswith('resources.lib.scrapers.'):
        return 'internal'
    if name.startswith('magneto.'):
        return 'magneto'
    if name.startswith('cocoscrapers.'):
        return 'cocos'
    if name.startswith('gearsscrapers.'):
        return 'gears'
    if name.startswith('viperscrapers.'):
        return 'vipers'
    return 'other'


def parse_log(path):
    sessions = []
    current = None
    totals = defaultdict(int)

    with open(path, encoding='utf-8', errors='ignore') as handle:
        for line in handle:
            if '[Play] scrape start' in line:
                current = []
                sessions.append(current)
            match = PAT.search(line)
            if not match or current is None:
                continue
            name, count = match.group(1), int(match.group(2))
            current.append((name, count))
            totals[name] += count

    return sessions, totals


def summarize_session(providers):
    by_pack = defaultdict(lambda: {'hit': 0, 'miss': 0, 'streams': 0})
    hits = []
    for name, count in providers:
        pack = pack_for(name)
        if count > 0:
            by_pack[pack]['hit'] += 1
            by_pack[pack]['streams'] += count
            hits.append((name, count))
        else:
            by_pack[pack]['miss'] += 1
    return by_pack, hits


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / 'AppData/Roaming/Kodi/classy.log'
    if not path.is_file():
        print(f'[ERR] log not found: {path}')
        return 1

    sessions, totals = parse_log(path)
    if not sessions:
        print('[WARN] no scrape sessions in log')
        return 1

    print(f'Log: {path}')
    print(f'Scrape sessions: {len(sessions)}')
    print()

    by_pack, hits = summarize_session(sessions[-1])
    print('=== Last session by pack ===')
    for pack in ('internal', 'magneto', 'cocos', 'gears', 'vipers'):
        row = by_pack[pack]
        total = row['hit'] + row['miss']
        if not total:
            continue
        print(
            f'  {pack:8} loaded={total:3}  hits={row["hit"]:3}  '
            f'zero={row["miss"]:3}  streams={row["streams"]:4}'
        )

    print()
    print('=== Providers with results (last session) ===')
    for name, count in sorted(hits, key=lambda item: (-item[1], item[0])):
        print(f'  {count:4}  {name}')

    print()
    print('=== Packs with zero hits (last session) ===')
    for pack in ('cocos', 'vipers'):
        zeros = [
            name for name, count in sessions[-1]
            if pack_for(name) == pack and count == 0
        ]
        if zeros:
            print(f'  {pack}: {len(zeros)} providers  -  e.g. {zeros[0]}')

    print()
    all_hits = [name for name, count in totals.items() if count > 0]
    print(f'All-time providers with any hits in log: {len(all_hits)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())

#!/usr/bin/env python3
"""Assert plugin.video.classy resources/settings.xml is Omega-safe.

Fails on legacy types (folder/sep/bool/text/enum) and incomplete controls.
Run: python tools/assert_settings_omega.py
"""
from __future__ import annotations

import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SETTINGS = ROOT / 'resources' / 'settings.xml'

# Types Kodi 20+/Omega rejects or that belong to the old flat schema.
FORBIDDEN_TYPES = frozenset({
    'folder',
    'sep',
    'lsep',
    'bool',  # use boolean
    'text',  # use string
    'enum',  # use integer/list/spinner
})

# Types that must declare a <control> child in Omega nested format.
TYPES_NEED_CONTROL = frozenset({
    'path',
    'action',
    'boolean',
    'string',
    'integer',
    'number',
    'addon',
    'list',
    'slider',
    'date',
    'time',
})


def _local(tag: str) -> str:
    return tag.split('}', 1)[-1] if '}' in tag else tag


def main() -> int:
    if not SETTINGS.is_file():
        print(f'FAIL: missing {SETTINGS}')
        return 1

    try:
        tree = ET.parse(SETTINGS)
    except ET.ParseError as exc:
        print(f'FAIL: XML parse error: {exc}')
        return 1

    root = tree.getroot()
    if _local(root.tag) != 'settings':
        print(f'FAIL: root tag is <{_local(root.tag)}>, expected <settings>')
        return 1

    version = (root.attrib.get('version') or '').strip()
    if version != '1':
        print(f'FAIL: settings version="{version}" (expected version="1" Omega schema)')
        return 1

    sections = [e for e in root if _local(e.tag) == 'section']
    if not sections:
        print('FAIL: no <section> under <settings>')
        return 1

    errors: list[str] = []
    warnings: list[str] = []
    setting_ids: list[str] = []
    type_counts: dict[str, int] = {}

    for elem in root.iter():
        if _local(elem.tag) != 'setting':
            continue
        sid = (elem.attrib.get('id') or '').strip()
        stype = (elem.attrib.get('type') or '').strip()
        if not sid:
            errors.append('setting without id')
            continue
        if not stype:
            errors.append(f'{sid}: missing type=')
            continue

        setting_ids.append(sid)
        type_counts[stype] = type_counts.get(stype, 0) + 1

        if stype in FORBIDDEN_TYPES:
            errors.append(f'{sid}: forbidden legacy type="{stype}"')

        # Old flat-schema attributes that break / are ignored in Omega nested form.
        for bad_attr in ('action', 'lvalues', 'option', 'values'):
            if bad_attr in elem.attrib:
                errors.append(f'{sid}: legacy attribute {bad_attr}= (use nested Omega elements)')

        if 'enable' in elem.attrib:
            errors.append(f'{sid}: use <enable> child element, not enable= attribute')
        if 'visible' in elem.attrib and elem.attrib.get('visible') == 'hidden':
            warnings.append(f'{sid}: visible="hidden"  -  prefer <visible>false</visible>')

        # default= on opening tag duplicates nested <default> and confuses readers.
        if 'default' in elem.attrib and any(_local(c.tag) == 'default' for c in elem):
            warnings.append(f'{sid}: both default= attribute and <default> child')

        controls = [c for c in elem if _local(c.tag) == 'control']
        if stype in TYPES_NEED_CONTROL and not controls:
            errors.append(f'{sid}: type="{stype}" missing <control>')

        if stype == 'path':
            ok = any(
                c.attrib.get('type') == 'button' and c.attrib.get('format') == 'path'
                for c in controls
            )
            if not ok:
                errors.append(f'{sid}: path setting needs <control type="button" format="path">')

        if stype == 'action':
            data = [c for c in elem if _local(c.tag) == 'data']
            if not data or not (data[0].text or '').strip():
                errors.append(f'{sid}: action setting needs non-empty <data>')
            ok = any(
                c.attrib.get('type') == 'button' and c.attrib.get('format') == 'action'
                for c in controls
            )
            if not ok:
                errors.append(f'{sid}: action setting needs <control type="button" format="action">')

        if stype == 'boolean':
            ok = any(c.attrib.get('type') == 'toggle' for c in controls)
            if not ok:
                errors.append(f'{sid}: boolean setting needs <control type="toggle">')

    # Duplicate IDs
    seen: set[str] = set()
    for sid in setting_ids:
        if sid in seen:
            errors.append(f'duplicate setting id="{sid}"')
        seen.add(sid)

    # Library category must exist and use path (the block we just fixed).
    for required in ('library.movie', 'library.tv', 'library.update.action'):
        if required not in seen:
            errors.append(f'missing expected library setting id="{required}"')

    print(f'File: {SETTINGS}')
    print(f'Settings: {len(setting_ids)}  Types: {dict(sorted(type_counts.items()))}')
    for w in warnings:
        print(f'WARN: {w}')

    if errors:
        print(f'FAIL: {len(errors)} issue(s)')
        for e in errors:
            print(f'  - {e}')
        return 1

    print('OK: Classy settings.xml is Omega-clean (no legacy folder/sep; controls present)')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

# -*- coding: utf-8 -*-

'''Offline probe for Trakt TV calendar presets (no HTTP).'''

from __future__ import print_function

import sys
import types
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.metadata.enrich import NEEDS_CALENDAR, NEED_THUMB
    from resources.lib.metadata.video_row import VideoRow
    from resources.lib.trakt import calendar_lists
    from resources.lib.trakt import paths as trakt_paths

    assert NEED_THUMB in NEEDS_CALENDAR
    print('[OK] NEEDS_CALENDAR profile')

    assert calendar_lists.is_whats_on_preset('calendar_today')
    assert calendar_lists.is_history_preset('trakthistory')
    assert calendar_lists.is_calendar_preset('trakthistory')
    assert not calendar_lists.is_whats_on_preset('trakthistory')
    assert len(calendar_lists.WHATS_ON_PRESETS) == 7
    print('[OK] whats-on + history preset registry')

    today_cfg = calendar_lists.preset_config('calendar_today')
    assert today_cfg['scope'] == 'my' and today_cfg['date_filter'] == 'today'
    global_cfg = calendar_lists.preset_config('calendar_all_thismonth')
    assert global_cfg['scope'] == 'all' and global_cfg['paginate']
    print('[OK] preset config')

    path = trakt_paths.path(
        'calendars', 'my_shows',
        start_date=date.today().isoformat(),
        days=7,
    )
    assert path == f'/calendars/my/shows/{date.today().isoformat()}/7'
    print('[OK] calendar path template')

    sample = {
        'first_aired': '2026-07-09T20:00:00.000Z',
        'show': {'title': 'Demo Show', 'ids': {'tmdb': 1, 'imdb': 'tt123', 'tvdb': 2}},
        'episode': {
            'season': 1,
            'number': 3,
            'title': 'Pilot',
            'overview': 'Plot here',
            'first_aired': '2026-07-09T20:00:00.000Z',
        },
    }
    row = calendar_lists._item_to_row(sample)
    assert row.tmdb == '1'
    assert row.season == 1 and row.episode == 3
    assert row.premiered == '2026-07-09'
    assert row.plot == 'Plot here'
    print('[OK] calendar item to VideoRow')

    rows = [
        VideoRow(mediatype='episode', tvshowtitle='A', tmdb='10', season=1, episode=1, premiered='2026-07-09'),
        VideoRow(mediatype='episode', tvshowtitle='A', tmdb='10', season=1, episode=1, premiered='2026-07-09'),
        VideoRow(mediatype='episode', tvshowtitle='B', tmdb='11', season=1, episode=2, premiered='2026-07-10'),
    ]
    deduped = calendar_lists._dedupe_rows(rows)
    assert len(deduped) == 2
    print('[OK] dedupe')

    today = date.today()
    filtered = calendar_lists._apply_date_filter([
        VideoRow(mediatype='episode', premiered=today.isoformat()),
        VideoRow(mediatype='episode', premiered=(today + timedelta(days=10)).isoformat()),
    ], 'today')
    assert len(filtered) == 1
    print('[OK] date filters')

    print('[OK] date filters')

    print('Calendar preset probes passed.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

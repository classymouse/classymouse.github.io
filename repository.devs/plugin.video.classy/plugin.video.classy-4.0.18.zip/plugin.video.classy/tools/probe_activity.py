# -*- coding: utf-8 -*-

'''Offline probe for trakt/activity fingerprint (phase 1).'''

from __future__ import print_function

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'
sys.path.insert(0, str(LIB))

PROGRESS_ACTIVITY_KEYS = ('episodes', 'shows')


def _canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'))


def last_activities_fingerprint(payload):
    if not payload or not isinstance(payload, dict):
        return ''
    return hashlib.md5(_canonical_json(payload).encode('utf-8')).hexdigest()


def progress_activity_fingerprint(payload):
    if not payload or not isinstance(payload, dict):
        return ''
    sliced = {k: payload[k] for k in PROGRESS_ACTIVITY_KEYS if k in payload}
    if not sliced:
        return ''
    return hashlib.md5(_canonical_json(sliced).encode('utf-8')).hexdigest()


SAMPLE_A = {
    'movies': {'watched_at': '2026-01-01T00:00:00.000Z'},
    'episodes': {'watched_at': '2026-01-02T00:00:00.000Z'},
}
SAMPLE_B = {
    'episodes': {'watched_at': '2026-01-02T00:00:00.000Z'},
    'movies': {'watched_at': '2026-01-01T00:00:00.000Z'},
}


def main():
    checks = []
    stable = progress_activity_fingerprint(SAMPLE_A) == progress_activity_fingerprint(SAMPLE_B)
    checks.append(('progress_fp_stable_key_order', stable, progress_activity_fingerprint(SAMPLE_A)))

    changed = progress_activity_fingerprint(SAMPLE_A) != progress_activity_fingerprint({
        **SAMPLE_A,
        'episodes': {'watched_at': '2026-01-03T00:00:00.000Z'},
    })
    checks.append(('progress_fp_changes_on_episode_edit', changed, None))

    movie_only = progress_activity_fingerprint(SAMPLE_A) == progress_activity_fingerprint({
        **SAMPLE_A,
        'movies': {'watched_at': '2026-06-01T00:00:00.000Z'},
    })
    checks.append(('progress_fp_ignores_movie_watch', movie_only, None))

    full_vs_tv = last_activities_fingerprint(SAMPLE_A) != progress_activity_fingerprint(SAMPLE_A)
    checks.append(('full_fp_differs_from_tv_slice', full_vs_tv, None))

    empty = (
        progress_activity_fingerprint(None) == ''
        and progress_activity_fingerprint({}) == ''
    )
    checks.append(('empty_input', empty, None))

    failed = 0
    for name, ok, detail in checks:
        status = 'OK' if ok else 'FAIL'
        extra = '' if detail is None else ' %r' % detail
        print('%s  %s%s' % (status, name, extra))
        if not ok:
            failed += 1
    if failed:
        print('\n%d check(s) failed' % failed)
        return 1
    print('\nAll passed (%d checks)' % len(checks))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

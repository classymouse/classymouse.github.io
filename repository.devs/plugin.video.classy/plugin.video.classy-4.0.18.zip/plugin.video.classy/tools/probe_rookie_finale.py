# -*- coding: utf-8 -*-

'''Live probe  -  The Rookie S07E18 season finale (Trakt vs TMDB vs Classy resolver).'''

from __future__ import print_function

import json
import sys
import types
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'
IMDB = 'tt7587890'
TMDB_ID = 79744


def _load_trakt_token():
    for sp in [
        Path(r'c:\Users\fvanb\AppData\Roaming\Kodi\userdata\addon_data\plugin.video.thecrew\settings.xml'),
        Path(r'c:\Users\fvanb\AppData\Roaming\Kodi\userdata\addon_data\plugin.video.classy\settings.xml'),
    ]:
        if not sp.exists():
            continue
        for el in ET.parse(sp).getroot().findall('setting'):
            if el.get('id') == 'trakt.token' and el.text:
                return el.text.strip()
    return ''


def _install_kodi_stubs(token):
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2 (21.2.0)',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: token if id == 'trakt.token' else '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    token = _load_trakt_token()
    if not token:
        print('No Trakt token in Kodi settings  -  cannot probe progress/watched')
        return 1

    _install_kodi_stubs(token)
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / 'resources' / 'lib'))

    from modules.keys import tmdb_key
    from resources.lib.trakt import transport
    from resources.lib.progress import next_episode as ne

    print('=== The Rookie S07E18  -  season finale probe ===\n')

    # Trakt episode metadata
    ep18 = transport.get_json(f'/shows/{IMDB}/seasons/7/episodes/18', {'extended': 'full'})
    print('Trakt S07E18 episode_type:', ep18.get('episode_type') if ep18 else None)
    print('Trakt S07E18 title:', ep18.get('title') if ep18 else None)

    for sn, en in ((7, 19), (8, 1)):
        data = transport.get_json(f'/shows/{IMDB}/seasons/{sn}/episodes/{en}', {'extended': 'full'})
        print(f'Trakt S{sn:02d}E{en:02d}:', 'EXISTS' if data else f'HTTP {transport.last_status()}')

    # Trakt progress/watched (next_episode field  -  untrusted)
    prog = transport.get_json(
        f'/shows/{IMDB}/progress/watched',
        {'hidden': 'false', 'specials': 'false'},
    )
    if prog:
        last = prog.get('last_episode') or {}
        nxt = prog.get('next_episode') or {}
        print('\nTrakt progress/watched (your account):')
        print(
            f'  last_episode: S{last.get("season", 0):02d}E{last.get("number", 0):02d} '
            f'({last.get("title", "")})'
        )
        print(
            f'  next_episode: S{nxt.get("season", 0):02d}E{nxt.get("number", 0):02d} '
            f'({nxt.get("title", "")}) type={nxt.get("episode_type")}'
        )
        print('  ^ naive next-unwatched  -  can be S07E19 after finale even when 404')

    # TMDB
    def tmdb_get(path):
        url = f'https://api.themoviedb.org/3{path}?api_key={tmdb_key}'
        with urllib.request.urlopen(url, timeout=15) as r:
            return json.loads(r.read())

    tmdb_ep = tmdb_get(f'/tv/{TMDB_ID}/season/7/episode/18')
    print('\nTMDB S07E18 episode_type:', tmdb_ep.get('episode_type'))
    try:
        tmdb_get(f'/tv/{TMDB_ID}/season/7/episode/19')
        print('TMDB S07E19: EXISTS')
    except urllib.error.HTTPError as e:
        print(f'TMDB S07E19: HTTP {e.code}')
    tmdb_s8 = tmdb_get(f'/tv/{TMDB_ID}/season/8/episode/1')
    print('TMDB S08E01:', tmdb_s8.get('name'))

    # Classy resolver (simulated watched through S07E18)
    resolved = ne.resolve_next_season_episode(
        str(TMDB_ID), 7, 18,
        show_data={'title': 'The Rookie', 'status': 'returning series'},
        show_title='The Rookie',
    )
    print('\nClassy resolve_next_season_episode(7, 18):', resolved)
    print('Expected: (8, 1)  -  NOT (7, 19)')
    return 0 if resolved == (8, 1) else 1


if __name__ == '__main__':
    sys.exit(main())

# -*- coding: utf-8 -*-

'''Live probe: Trakt extended= values and response shapes (needs auth for /sync).'''

from __future__ import print_function

import json
import os
import sys
import types
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = Path(os.environ.get('APPDATA', '')) / 'Kodi' / 'userdata' / 'addon_data' / 'plugin.video.classy'


def _install_kodi_stubs():
    settings = {}
    settings_path = PROFILE / 'settings.xml'
    if settings_path.is_file():
        for node in ET.parse(settings_path).getroot().iter('setting'):
            settings[node.get('id', '')] = (node.text or '').strip()

    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: settings.get(id, ''),
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def _shape(data):
    if isinstance(data, list):
        keys = list(data[0].keys())[:6] if data and isinstance(data[0], dict) else []
        return 'list[%d] keys0=%s' % (len(data), keys)
    if isinstance(data, dict):
        sample = next(iter(data.items()), None)
        return 'dict[%d] sample=%s' % (len(data), sample)
    return repr(type(data).__name__)


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.trakt import auth, paths, transport

    cases = [
        ('public', paths.path('movies', 'boxoffice'), None, False),
        ('public', paths.path('movies', 'trending'), {'page': 1, 'limit': 2}, False),
        ('public', paths.path('movies', 'trending'), {'page': 1, 'limit': 2, 'extended': 'full'}, False),
    ]
    if auth.has_credentials():
        cases += [
            ('auth', paths.path('sync', 'watched_movies'), {'extended': 'min'}, True),
            ('auth', paths.path('sync', 'watched_movies'), {'page': 1, 'limit': 5}, True),
            ('auth', paths.path('sync', 'watched_movies'), {'page': 1, 'limit': 5, 'extended': 'full'}, True),
            ('auth', paths.path('sync', 'watched_shows'), {'page': 1, 'limit': 2, 'extended': 'progress'}, True),
            ('auth', paths.path('sync', 'playback_movies'), {'extended': 'full'}, True),
            ('auth', paths.path('sync', 'playback_episodes'), {'extended': 'full'}, True),
        ]
    else:
        print('[SKIP] no Trakt token  -  sync probes omitted')

    for label, path, params, with_auth in cases:
        data = transport.get_json(path, params=params, with_auth=with_auth)
        print('[%s] %s %s -> HTTP %s %s' % (
            label, path, params or {}, transport.last_status(), _shape(data),
        ))
        if isinstance(data, list) and data and isinstance(data[0], dict):
            movie = data[0].get('movie') if isinstance(data[0].get('movie'), dict) else data[0]
            if isinstance(movie, dict):
                ids = movie.get('ids') or {}
                print('       title=%r tmdb=%s trakt=%s' % (
                    movie.get('title'), ids.get('tmdb'), ids.get('trakt'),
                ))
    return 0


if __name__ == '__main__':
    sys.exit(main())

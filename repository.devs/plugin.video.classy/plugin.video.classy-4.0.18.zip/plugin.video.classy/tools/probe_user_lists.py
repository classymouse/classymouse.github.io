# -*- coding: utf-8 -*-

'''Offline probe for Trakt personal list helpers (no HTTP).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.trakt import user_lists

    owned = user_lists._normalize_owned({
        'name': 'Classy',
        'ids': {'slug': 'classy'},
    })
    assert owned['items_url'].endswith('/users/me/lists/classy/items')
    print('[OK] normalize owned list')

    liked = user_lists._normalize_liked({
        'list': {
            'name': 'Test',
            'ids': {'slug': 'test'},
            'user': {'username': 'friend'},
        },
    })
    assert liked['items_url'].endswith('/users/friend/lists/test/items')
    print('[OK] normalize liked list')

    url = 'https://api.trakt.tv/users/me/lists/classy/items'
    assert user_lists.is_list_items_url(url)
    assert user_lists.is_personal_list_url(url)
    assert not user_lists.is_list_items_url('https://api.trakt.tv/movies/popular')
    print('[OK] list items URL detection')

    path, extra = user_lists._list_path_from_url(
        'https://api.trakt.tv/users/giladg/lists/latest-releases/items?page=2',
    )
    assert path == '/users/giladg/lists/latest-releases/items'
    assert extra.get('page') == '2'
    print('[OK] list path parse')

    print('probe_user_lists: all checks passed')


if __name__ == '__main__':
    main()

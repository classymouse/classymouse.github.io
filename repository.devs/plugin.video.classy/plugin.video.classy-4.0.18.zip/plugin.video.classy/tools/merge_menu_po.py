# -*- coding: utf-8 -*-
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
po_path = ROOT / 'tools/_gen_strings_306xx.po'
target = ROOT / 'resources/language/resource.language.en_gb/strings.po'

po = po_path.read_text(encoding='utf-8')
po = po.replace('msgid "TRAKT : Authorize"', 'msgid "Authorize"')
po = po.replace('msgid "ResolveUrl: Settings"', 'msgid "Settings"')

text = target.read_text(encoding='utf-8')
if '#30600' in text:
    print('306xx already present')
else:
    marker = '\nmsgctxt "#32800"'
    if marker in text:
        text = text.replace(marker, '\n' + po + marker)
    else:
        text = text.rstrip() + '\n\n' + po
    target.write_text(text, encoding='utf-8')
    print('merged 306xx into strings.po')

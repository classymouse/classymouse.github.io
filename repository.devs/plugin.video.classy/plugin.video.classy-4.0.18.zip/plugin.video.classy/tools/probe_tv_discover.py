# -*- coding: utf-8 -*-

'''Offline probe for TV discover presets (no HTTP).'''

from __future__ import print_function

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE = ROOT / 'addon_data_test'


def _install_kodi_stubs():
    sys.modules['xbmc'] = types.SimpleNamespace(
        LOGINFO=1, LOGERROR=4, log=lambda *a, **k: None,
        getInfoLabel=lambda l: '21.2',
    )
    sys.modules['xbmcaddon'] = types.SimpleNamespace(Addon=lambda: types.SimpleNamespace(
        getAddonInfo=lambda k: str(ROOT) if k == 'path' else str(PROFILE),
        getSetting=lambda id='', **k: '',
        getLocalizedString=lambda i: str(i),
        setSetting=lambda *a, **k: None,
    ))
    sys.modules['xbmcgui'] = types.SimpleNamespace()
    sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p: str(PROFILE))


def main():
    _install_kodi_stubs()
    sys.path.insert(0, str(ROOT))

    from resources.lib.apis import tmdb_discover
    from resources.lib.metadata.video_row import VideoRow
    from resources.lib.trakt import tv_lists as trakt_tv_lists

    p = tmdb_discover.discover_params('popular')
    assert p['sort_by'] == 'popularity.desc'
    assert 'vote_count.gte' in p
    print('[OK] discover_params popular')

    net = tmdb_discover.discover_params('tmdb_networks', network_id=213)
    assert net['with_networks'] == '213'
    print('[OK] network preset')

    cert = tmdb_discover.discover_params('tmdb_certification', tid='TV-PG')
    assert cert['certification'] == 'TV-PG'
    assert cert['certification_country'] == 'US'
    print('[OK] certification preset')

    lang = tmdb_discover.discover_params('tmdb_language', tid='ja')
    assert lang['with_original_language'] == 'ja'
    print('[OK] language preset')

    row = VideoRow.from_tmdb_tv({
        'id': 4400,
        'name': '4400',
        'first_air_date': '2021-07-19',
        'overview': 'test',
        'poster_path': '/x.jpg',
        'vote_average': 7.1,
        'vote_count': 100,
    })
    assert row.tmdb == '4400'
    assert row.year == '2021'
    print('[OK] VideoRow.from_tmdb_tv')

    trakt_row = VideoRow.from_trakt_watched_show({
        'show': {
            'title': 'Future Show',
            'year': 2027,
            'first_aired': '2027-03-01',
            'status': 'Upcoming',
            'ids': {'tmdb': 99, 'trakt': 1},
        },
    })
    assert trakt_row.premiered == '2027-03-01'
    assert trakt_row.year == '2027'
    print('[OK] VideoRow.from_trakt_watched_show first_aired')

    assert trakt_tv_lists.is_my_tv_preset('traktcollection')
    assert not trakt_tv_lists.is_my_tv_preset('trakthistory')
    assert len(trakt_tv_lists.MY_TV_PRESETS) == 10
    coll = trakt_tv_lists.preset_config('traktcollection')
    assert coll['auth'] and coll['sort_title']
    played = trakt_tv_lists.preset_config('traktplayed')
    assert played['path'].endswith('/played/weekly')
    assert trakt_tv_lists._total_pages(1, 5, {'page_count': 200}, 40) == 1
    filtered = trakt_tv_lists._filter_items([
        {'show': {'title': 'Future', 'year': 2099}},
        {'show': {'title': 'Past', 'year': 2020}},
    ], allow_future_years=False)
    assert len(filtered) == 1
    print('[OK] trakt my-tv preset registry')

    print('TV discover preset probes passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())

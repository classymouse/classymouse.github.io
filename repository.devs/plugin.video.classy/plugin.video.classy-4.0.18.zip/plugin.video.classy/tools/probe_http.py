#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Offline smoke test  -  http_policy + msg_handler (no Kodi).

Run from repo root:
  python tools/probe_http.py

Full client + CDN proof still requires Kodi:
  Developers  ->  Client + CDN test (devmode)
"""

from __future__ import print_function

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / 'resources' / 'lib'


def _install_kodi_stubs():
    """Minimal stubs so msg_handler can import classy.c.log."""
    profile = ROOT / 'addon_data_test'
    profile.mkdir(exist_ok=True)

    def _info(key):
        data = {
            'id': 'plugin.video.classy',
            'version': '4.0.0',
            'name': 'Classy',
            'path': str(ROOT),
            'profile': str(profile),
            'fanart': '',
            'icon': '',
        }
        return data.get(key, '')

    def _setting(setting_id=None, **kwargs):
        key = setting_id or kwargs.get('id', '')
        defaults = {
            'theme': '0',
            'dev_pw': '',
            'addon_debug': 'false',
        }
        return defaults.get(key, '')

    addon = types.SimpleNamespace(
        getLocalizedString=lambda i: str(i),
        getAddonInfo=_info,
        getSetting=_setting,
        setSetting=lambda id='', value='': None,
    )

    sys.modules.setdefault('xbmc', types.SimpleNamespace(
        LOGDEBUG=0, LOGINFO=1, LOGERROR=4,
        log=lambda msg, level=0: None,
        executebuiltin=lambda cmd: None,
        getInfoLabel=lambda label: '21.2 (21.2.0) Git:20250201' if label == 'System.BuildVersion' else 'Windows 10',
    ))
    sys.modules.setdefault('xbmcaddon', types.SimpleNamespace(
        Addon=lambda id=None: addon,
    ))
    sys.modules.setdefault('xbmcgui', types.SimpleNamespace())
    sys.modules.setdefault('xbmcplugin', types.SimpleNamespace())
    sys.modules.setdefault('xbmcvfs', types.SimpleNamespace(
        translatePath=lambda p: str(profile if p.startswith('special://') else p),
    ))


def _load_modules():
    _install_kodi_stubs()
    sys.path.insert(0, str(LIB))
    from modules import http_policy  # noqa: E402
    from modules import msg_handler  # noqa: E402
    return http_policy, msg_handler


class _FakeResponse(object):
    def __init__(self, headers):
        self.headers = headers


def _run():
    hp, mh = _load_modules()
    passed = 0

    def check(name, cond):
        nonlocal passed
        if not cond:
            raise AssertionError('failed: %s' % name)
        passed += 1
        print('OK  %s' % name)

    check('is_success 200', hp.is_success(200))
    check('is_success 404', not hp.is_success(404))
    check('is_transient 503', hp.is_transient(503))
    check('is_transient 404', not hp.is_transient(404))
    check(
        'parse_retry_after seconds',
        hp.parse_retry_after(_FakeResponse({'Retry-After': '3'}), 0) == 3.0,
    )

    ctx401 = mh.MessageContext(api=mh.API_TRAKT, url='/users/me', status=401)
    check('trakt 401 -> REFRESH_AUTH', mh.handle(ctx401) == mh.Action.REFRESH_AUTH)

    ctx401_retry = mh.MessageContext(
        api=mh.API_TRAKT, url='/users/me', status=401, retried=True,
    )
    check('trakt 401 retried -> FAIL', mh.handle(ctx401_retry) == mh.Action.FAIL)

    ctx404 = mh.MessageContext(api=mh.API_TRAKT, url='/shows/x', status=404)
    check('trakt 404 -> FAIL', mh.handle(ctx404) == mh.Action.FAIL)

    ctx503 = mh.MessageContext(api=mh.API_GENERIC, url='/x', status=503)
    check('generic 503 -> RETRY_ONCE', mh.handle(ctx503) == mh.Action.RETRY_ONCE)

    ctx_dns = mh.MessageContext(
        api=mh.API_TMDB,
        url='https://api.themoviedb.org/3/tv/1',
        status=0,
        error='[Errno 11004] getaddrinfo failed',
    )
    check('transport getaddrinfo -> RETRY_ONCE', mh.handle(ctx_dns) == mh.Action.RETRY_ONCE)

    ctx_dns_retry = mh.MessageContext(
        api=mh.API_TMDB,
        url='https://api.themoviedb.org/3/tv/1',
        status=0,
        error='[Errno 11004] getaddrinfo failed',
        retried=True,
    )
    check('transport getaddrinfo retried -> FAIL', mh.handle(ctx_dns_retry) == mh.Action.FAIL)

    check(
        'is_transport_transient getaddrinfo',
        hp.is_transport_transient('[Errno 11004] getaddrinfo failed'),
    )
    check('is_transport_transient 404 body', not hp.is_transport_transient('HTTP 404'))

    ctx429_no_header = mh.MessageContext(
        api=mh.API_TRAKT, url='/sync/last_activities', status=429,
        response=_FakeResponse({}),
    )
    check('trakt 429 no Retry-After -> FAIL', mh.handle(ctx429_no_header) == mh.Action.FAIL)

    print('')
    print('All passed (%d checks)' % passed)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(_run())
    except Exception as exc:
        print('FAIL: %s' % exc, file=sys.stderr)
        sys.exit(1)

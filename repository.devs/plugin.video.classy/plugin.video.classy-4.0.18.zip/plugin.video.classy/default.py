# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file default.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''


from resources.lib.modules import xbox_ssl  # Xbox UWP SSL  -  before any HTTP (sources + play)

from sys import argv
from urllib.parse import parse_qsl
from resources.lib.modules import brand_gate
from resources.lib.modules import router

from resources.lib.modules.classy import c

if __name__ == "__main__":
    if not brand_gate.assert_identity():
        raise SystemExit(1)
    params = dict(parse_qsl(argv[2].replace('?', '')))
    if c.devmode:
        c.log(f"Starting {c.name} with parameters: {params}")
    router.router(params)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt My TV Shows list presets  -  one fetcher for Crew tvshows&url=trakt* keys.

Maps preset  ->  API path + auth/pagination/sort rules; returns discover-shaped pages
for tv_discover.directory.'''

from datetime import datetime

from ..modules.classy import c
from . import auth as trakt_auth
from . import paths as trakt_paths
from . import transport as trakt_transport

_PAGE_LIMIT = 40

# Personal lists  -  one fetch like Crew (no Kodi pagination on bogus Trakt headers).
_PERSONAL_LIST_LIMITS = {
    'traktcollection': 1000,
    'traktwatchlist': 2000,
}

# My TV Shows submenu  -  Trakt rows using tvshows&url= (not calendar/progress).
MY_TV_PRESETS = frozenset({
    'traktcollection',
    'traktwatchlist',
    'traktfeatured',
    'traktrecommendations',
    'traktpopular',
    'traktanticipated',
    'traktplayed',
    'traktwatched',
    'traktcollected',
    'trakthidden',
})

_HIDDEN_SECTIONS = (
    'calendar',
    'progress_watched',
    'progress_collected',
    'recommendations',
    'dropped',
)

_PRESET_CONFIG = {
    'traktcollection': {
        'path': trakt_paths.path('users', 'collection_shows'),
        'auth': True,
        'sort_title': True,
        'allow_future_years': True,
    },
    'traktwatchlist': {
        'path': trakt_paths.path('users', 'watchlist_shows'),
        'auth': True,
        'sort_title': True,
        'allow_future_years': True,
    },
    'traktfeatured': {
        'path': trakt_paths.path('recommendations', 'shows'),
        'auth': True,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktrecommendations': {
        'path': trakt_paths.path('recommendations', 'shows'),
        'auth': True,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktpopular': {
        'path': trakt_paths.path('shows', 'popular'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktanticipated': {
        'path': trakt_paths.path('shows', 'anticipated'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': True,
    },
    'traktplayed': {
        'path': trakt_paths.path('shows', 'played_weekly'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktwatched': {
        'path': trakt_paths.path('shows', 'watched_weekly'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktcollected': {
        'path': trakt_paths.path('shows', 'collected_weekly'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': False,
    },
}


def is_my_tv_preset(preset):
    return (preset or '').strip() in MY_TV_PRESETS


def preset_config(preset):
    return _PRESET_CONFIG.get((preset or '').strip())


def _current_year():
    return datetime.now().year


def _show_payload(item):
    if not isinstance(item, dict):
        return None
    nested = item.get('show')
    if isinstance(nested, dict):
        return nested
    if item.get('title'):
        return item
    return None


def _title_sort_key(item):
    show = _show_payload(item) or {}
    return str(show.get('title') or '').casefold()


def _premiered_sort_key(item):
    show = _show_payload(item) or {}
    aired = str(show.get('first_aired') or '')[:10]
    return aired or '9999-12-31'


def _filter_items(items, *, allow_future_years):
    if allow_future_years:
        return items
    year_now = _current_year()
    kept = []
    for item in items:
        show = _show_payload(item)
        if not show:
            continue
        year = show.get('year')
        try:
            if int(year) > year_now:
                continue
        except (TypeError, ValueError):
            pass
        kept.append(item)
    return kept


def _total_pages(page, raw_len, pag, limit):
    if raw_len < limit:
        return page
    page_count = int(pag.get('page_count') or 0)
    if page_count > 0:
        return page_count
    return page + 1


def _fetch_hidden_shows():
    '''Crew trakthidden_list  -  merge hidden show entries across Trakt sections.'''
    if not trakt_auth.has_credentials():
        c.log('[TraktTVLists] trakthidden requires auth', 1)
        return None

    seen = set()
    combined = []
    for section in _HIDDEN_SECTIONS:
        data = trakt_transport.get_json(
            trakt_paths.path('users', 'hidden_section', section=section),
            params={'type': 'show', 'limit': 1000},
            with_auth=True,
        )
        if not isinstance(data, list):
            continue
        for entry in data:
            show = _show_payload(entry)
            if not show:
                continue
            trakt_id = str((show.get('ids') or {}).get('trakt') or '').strip()
            if trakt_id and trakt_id in seen:
                continue
            if trakt_id:
                seen.add(trakt_id)
            combined.append(entry if 'show' in entry else {'show': show})

    combined.sort(key=_title_sort_key)
    if c.is_devmode():
        c.log(f'[TraktTVLists] trakthidden {len(combined)} unique show(s)')
    return {
        'results': combined,
        'page': 1,
        'total_pages': 1,
        '_source': 'trakt_shows',
        '_preset': 'trakthidden',
    }


def fetch_page(preset, *, page=1):
    '''Fetch one Trakt My TV Shows page; returns discover-shaped dict or None.'''
    preset = (preset or '').strip()
    if preset == 'trakthidden':
        return _fetch_hidden_shows()

    cfg = preset_config(preset)
    if not cfg:
        return None

    page = max(1, int(page or 1))
    if cfg['auth'] and not trakt_auth.has_credentials():
        c.log(f'[TraktTVLists] {preset} requires auth', 1)
        return None

    fetch_all = preset in _PERSONAL_LIST_LIMITS
    limit = _PERSONAL_LIST_LIMITS.get(preset, _PAGE_LIMIT)
    req_page = 1 if fetch_all else page

    data, headers, status = trakt_transport.get_json_with_meta(
        cfg['path'],
        params={
            'page': req_page,
            'limit': limit,
            'extended': 'full',
        },
        with_auth=cfg['auth'],
    )
    if status and status >= 400:
        c.log(f'[TraktTVLists] {preset} HTTP {status}', 1)
        return None
    if not isinstance(data, list):
        return None

    items = _filter_items(data, allow_future_years=cfg['allow_future_years'])
    if preset == 'traktanticipated':
        items = sorted(items, key=_premiered_sort_key)
    elif cfg['sort_title']:
        items = sorted(items, key=_title_sort_key)

    pag = trakt_transport.parse_pagination_headers(headers)
    if fetch_all:
        total_pages = 1
    else:
        total_pages = _total_pages(req_page, len(data), pag, limit)

    return {
        'results': items,
        'page': 1 if fetch_all else (pag.get('page') or req_page),
        'total_pages': max(1, total_pages),
        '_source': 'trakt_shows',
        '_preset': preset,
    }

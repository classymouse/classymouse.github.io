# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_resume_index.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Partial-watch state from Trakt /sync/playback/movies.'''

from ..progress import filters as slot_filters

OVERLAY_UNWATCHED = 6


class MovieResumeIndex:
    __slots__ = ('_movies',)

    def __init__(self, movies=None):
        self._movies = dict(movies or {})

    @classmethod
    def compile(cls, playback_items):
        movies = {}
        pmin = slot_filters.resume_progress_min()
        pmax = slot_filters.resume_progress_max()

        for item in playback_items or []:
            if not isinstance(item, dict):
                continue
            try:
                progress = float(item.get('progress', 0) or 0)
                if progress <= pmin or progress >= pmax:
                    continue

                movie_data = item.get('movie') if isinstance(item.get('movie'), dict) else {}
                ids = movie_data.get('ids') if isinstance(movie_data.get('ids'), dict) else {}
                tmdb = str(ids.get('tmdb') or '').strip()
                imdb = str(ids.get('imdb') or '').strip()
                if not tmdb and not imdb:
                    continue

                runtime_min = int(movie_data.get('runtime') or 0)
                entry = {
                    'progress': progress,
                    'duration': runtime_min * 60 if runtime_min > 0 else 0,
                    'tmdb': tmdb,
                    'imdb': imdb,
                }
                if tmdb:
                    movies[('tmdb', tmdb)] = entry
                if imdb:
                    movies[('imdb', imdb)] = entry
            except (TypeError, ValueError):
                continue
        return cls(movies)

    def for_movie(self, tmdb='', imdb=''):
        tmdb = str(tmdb or '').strip()
        imdb = str(imdb or '').strip()
        if tmdb:
            hit = self._movies.get(('tmdb', tmdb))
            if hit:
                return hit
        if imdb:
            return self._movies.get(('imdb', imdb))
        return None

    def apply_to_row(self, row):
        if getattr(row, 'mediatype', '') != 'movie':
            return False
        entry = self.for_movie(row.tmdb, row.imdb)
        if not entry:
            return False
        row.playcount = 0
        row.overlay = OVERLAY_UNWATCHED
        row.resume_point = float(entry['progress'])
        if entry.get('duration') and not int(row.duration or 0):
            row.duration = int(entry['duration'])
        return True

    def __len__(self):
        return len(self._movies)

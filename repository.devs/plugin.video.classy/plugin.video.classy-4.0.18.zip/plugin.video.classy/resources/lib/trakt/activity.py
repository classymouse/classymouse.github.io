# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file activity.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt /sync/last_activities  -  layered fingerprints + change detection.'''

import hashlib
import json
import threading
import time

from .. import cache
from ..modules.classy import c
from . import paths
from . import transport

NS_ACTIVITY = 'activity'
KEY_STORED_FINGERPRINTS = 'fingerprints'

# TV progress widgets + future hidden-show filter on show-level activity.
PROGRESS_ACTIVITY_KEYS = ('episodes', 'shows')

_probe_local = threading.local()


def _canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'))


def _hash_blob(data):
    return hashlib.md5(_canonical_json(data).encode('utf-8')).hexdigest()


def last_activities_fingerprint(payload):
    '''Stable MD5 of the full last_activities JSON (all domains).'''
    if not payload or not isinstance(payload, dict):
        return ''
    return _hash_blob(payload)


def build_fingerprints(payload):
    '''Per top-level key MD5 plus composite all.'''
    if not payload or not isinstance(payload, dict):
        return {}
    fingerprints = {'all': last_activities_fingerprint(payload)}
    for key, value in payload.items():
        if value is not None:
            fingerprints[key] = _hash_blob(value)
    return fingerprints


def composite_fingerprint(fingerprints, *domains):
    '''Single invalidation stamp for one or more activity domains.'''
    if not fingerprints or not domains:
        return ''
    if len(domains) == 1:
        return str(fingerprints.get(domains[0]) or '')
    parts = {key: fingerprints[key] for key in sorted(domains) if key in fingerprints}
    if not parts:
        return ''
    return _hash_blob(parts)


def read_stored_fingerprints():
    return cache.get_json(NS_ACTIVITY, KEY_STORED_FINGERPRINTS) or {}


def commit_fingerprints(fingerprints):
    if not fingerprints:
        return False
    return cache.put_json(
        NS_ACTIVITY,
        KEY_STORED_FINGERPRINTS,
        fingerprints,
        invalidation='meta',
    )


class ActivityProbe:
    '''One last_activities fetch; compare current vs last-committed fingerprints.'''

    __slots__ = ('payload', 'fingerprints', 'stored', 'log_label')

    def __init__(self, payload, fingerprints, stored, log_label=''):
        self.payload = payload
        self.fingerprints = fingerprints or {}
        self.stored = stored or {}
        self.log_label = log_label or ''

    def fingerprint(self, *domains):
        return composite_fingerprint(self.fingerprints, *domains)

    def stored_fingerprint(self, *domains):
        return composite_fingerprint(self.stored, *domains)

    def changed(self, *domains):
        if not domains:
            domains = tuple(self.fingerprints.keys())
        for domain in domains:
            cur = self.fingerprints.get(domain)
            if not cur:
                continue
            if cur != self.stored.get(domain):
                return True
        return False

    def progress_fingerprint(self):
        return self.fingerprint(*PROGRESS_ACTIVITY_KEYS)

    def progress_unchanged(self):
        cur = self.progress_fingerprint()
        prev = self.stored_fingerprint(*PROGRESS_ACTIVITY_KEYS)
        return bool(cur and prev and cur == prev)

    def changed_domains(self):
        return sorted(
            key for key, fp in self.fingerprints.items()
            if key != 'all' and fp and fp != self.stored.get(key)
        )


def clear_probe_cache():
    '''Drop per-thread probe cache (call at route entry if needed).'''
    _probe_local.probe = None


def fetch_last_activities():
    return transport.get_json(paths.path('sync', 'last_activities'))


def probe_last_activities(log_label='', force_refresh=False):
    '''
    Fetch /sync/last_activities once per route (thread-local cache).

    Compares current per-domain fingerprints to last-committed set in SQLite.
    Call commit_fingerprints(probe.fingerprints) after a successful sync cycle.
    '''
    if not force_refresh:
        cached = getattr(_probe_local, 'probe', None)
        if cached is not None:
            return cached

    t0 = time.time()
    payload = fetch_last_activities()
    fingerprints = build_fingerprints(payload) if payload else {}
    stored = read_stored_fingerprints()
    probe = ActivityProbe(payload, fingerprints, stored, log_label=log_label)

    if c.devmode:
        suffix = f' ({log_label})' if log_label else ''
        probe_ms = int((time.time() - t0) * 1000)
        if probe.progress_unchanged():
            c.log(
                f'[Trakt] last_activities{suffix}: TV progress unchanged '
                f'(fp={probe.progress_fingerprint()[:8]}... probe_ms={probe_ms})'
            )
        else:
            changed = probe.changed_domains()
            detail = ','.join(changed) if changed else 'baseline'
            c.log(
                f'[Trakt] last_activities{suffix}: TV progress stale ({detail}) '
                f'(fp={probe.progress_fingerprint()[:8]}... probe_ms={probe_ms})'
            )

    _probe_local.probe = probe
    return probe


def persist_fingerprint(payload):
    fingerprints = build_fingerprints(payload)
    if fingerprints:
        commit_fingerprints(fingerprints)
    return composite_fingerprint(fingerprints, *PROGRESS_ACTIVITY_KEYS)


def probe_last_activities_gate(log_label='', force_refresh=False):
    '''
    Back-compat shim: (payload, unchanged, progress_fingerprint).

    Prefer probe_last_activities() for new code.
    '''
    probe = probe_last_activities(log_label=log_label, force_refresh=force_refresh)
    return probe.payload, probe.progress_unchanged(), probe.progress_fingerprint()


def progress_activity_slice(payload):
    '''Subset of last_activities for TV progress (episodes + shows).'''
    if not payload or not isinstance(payload, dict):
        return {}
    return {key: payload[key] for key in PROGRESS_ACTIVITY_KEYS if key in payload}


def progress_activity_fingerprint(payload):
    return composite_fingerprint(build_fingerprints(payload), *PROGRESS_ACTIVITY_KEYS)

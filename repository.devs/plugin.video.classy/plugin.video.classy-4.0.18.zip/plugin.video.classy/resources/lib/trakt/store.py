# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file store.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt profile persistence  -  SQLite cache with activity-fingerprint invalidation.'''

import json

import xbmcaddon
import xbmcvfs

from .. import cache
from ..modules.classy import c

NS_TRAKT = 'trakt'
KEY_WATCHED_SHOWS = 'watched_shows'
KEY_NEXT_EPISODE_SLOTS = 'next_episode_slots'
KEY_IN_PROGRESS_SHOW_SLOTS = 'in_progress_show_slots'
KEY_PLAYBACK_EPISODES = 'playback_episodes'
KEY_PLAYBACK_MOVIES = 'playback_movies'
KEY_WATCHED_MOVIES = 'watched_movies'
KEY_IN_PROGRESS_EPISODE_SLOTS = 'in_progress_episode_slots'
KEY_IN_PROGRESS_MOVIE_SLOTS = 'in_progress_movie_slots'

# Legacy JSON filenames (migrate once into SQLite).
_STATE_FILE = 'trakt_state.json'
_WATCHED_SHOWS_FILE = 'trakt_watched_shows.json'
_NEXT_EPISODE_SLOTS_FILE = 'trakt_next_episode_slots.json'
_SHOW_SLOTS_FILE = 'trakt_in_progress_show_slots.json'
_WATCHED_SHOWS_VERSION = 3
_DERIVED_SLOTS_VERSION = 3
# Bump when next-episode slot shape / filter pipeline changes (invalidates stale cache).
_NEXT_EPISODE_SLOTS_SCHEMA = 4


def _vfs_path(filename):
    profile = xbmcaddon.Addon().getAddonInfo('profile')
    if not profile:
        return ''
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    sep = '' if profile.endswith('/') else '/'
    return f'{profile}{sep}{filename}'


def _read_text(vfs_path):
    handle = xbmcvfs.File(vfs_path)
    try:
        raw = handle.read()
    finally:
        handle.close()
    if not raw:
        return ''
    if isinstance(raw, bytes):
        return raw.decode('utf-8', errors='replace')
    return str(raw)


def _read_json_file(filename, default=None):
    vfs = _vfs_path(filename)
    if not vfs or not xbmcvfs.exists(vfs):
        return default
    try:
        return json.loads(_read_text(vfs))
    except Exception as exc:
        c.log(f'[TraktStore] read {filename} failed: {exc}', 1)
        return default


def watched_has_episode_detail(shows):
    '''True when at least one show has season/episode rows (extended=progress).'''
    if not isinstance(shows, list):
        return False
    for item in shows:
        if not isinstance(item, dict):
            continue
        seasons = item.get('seasons')
        if not seasons:
            continue
        if isinstance(seasons, dict):
            seasons = list(seasons.values())
        for season in seasons:
            if season.get('episodes'):
                return True
    return False


def _migrate_watched_shows_json():
    blob = _read_json_file(_WATCHED_SHOWS_FILE)
    shows = None
    if isinstance(blob, dict) and blob.get('v') == _WATCHED_SHOWS_VERSION:
        shows = blob.get('shows')
    elif isinstance(blob, list):
        shows = blob
    if isinstance(shows, list) and watched_has_episode_detail(shows):
        return shows
    return None


def read_watched_shows(invalidation):
    if not invalidation:
        return None
    shows = cache.get_json(NS_TRAKT, KEY_WATCHED_SHOWS, invalidation=invalidation)
    if isinstance(shows, list) and watched_has_episode_detail(shows):
        return shows
    legacy = _migrate_watched_shows_json()
    if legacy is not None:
        write_watched_shows(legacy, invalidation)
        c.log('[TraktStore] migrated watched/shows JSON  ->  SQLite')
        return legacy
    return None


def write_watched_shows(shows, invalidation):
    if not isinstance(shows, list) or not invalidation:
        return False
    if not watched_has_episode_detail(shows):
        c.log(
            '[TraktStore] watched/shows not cached  -  response lacks season/episode detail',
            1,
        )
        return False
    return cache.put_json(
        NS_TRAKT, KEY_WATCHED_SHOWS, shows, invalidation=invalidation,
    )


def _migrate_slots_json(filename):
    blob = _read_json_file(filename)
    if not isinstance(blob, dict):
        return None, ''
    if blob.get('v') != _DERIVED_SLOTS_VERSION:
        return None, ''
    slots = blob.get('slots')
    fp = str(blob.get('fp') or '')
    if isinstance(slots, list) and slots and fp:
        return slots, fp
    return None, ''


def _unwrap_next_slots(blob):
    if isinstance(blob, dict):
        if int(blob.get('v') or 0) < _NEXT_EPISODE_SLOTS_SCHEMA:
            return None
        slots = blob.get('slots')
        return slots if isinstance(slots, list) else None
    # Legacy: raw list without schema  -  drop to force rescan + filters.
    return None


def read_slots_cache(invalidation):
    if not invalidation:
        return None
    blob = cache.get_json(NS_TRAKT, KEY_NEXT_EPISODE_SLOTS, invalidation=invalidation)
    slots = _unwrap_next_slots(blob)
    if isinstance(slots, list) and slots:
        return slots
    legacy, fp = _migrate_slots_json(_NEXT_EPISODE_SLOTS_FILE)
    if legacy is not None and fp == invalidation:
        write_slots_cache(invalidation, legacy)
        c.log('[TraktStore] migrated next-episode slots JSON  ->  SQLite')
        return _unwrap_next_slots({'v': _NEXT_EPISODE_SLOTS_SCHEMA, 'slots': legacy})
    return None


def write_slots_cache(invalidation, slots):
    if not invalidation or not slots:
        return False
    payload = {'v': _NEXT_EPISODE_SLOTS_SCHEMA, 'slots': slots}
    return cache.put_json(
        NS_TRAKT, KEY_NEXT_EPISODE_SLOTS, payload, invalidation=invalidation,
    )


def read_show_slots_cache(invalidation):
    if not invalidation:
        return None
    slots = cache.get_json(NS_TRAKT, KEY_IN_PROGRESS_SHOW_SLOTS, invalidation=invalidation)
    if isinstance(slots, list) and slots:
        return slots
    legacy, fp = _migrate_slots_json(_SHOW_SLOTS_FILE)
    if legacy is not None and fp == invalidation:
        write_show_slots_cache(invalidation, legacy)
        c.log('[TraktStore] migrated in-progress show slots JSON  ->  SQLite')
        return legacy
    return None


def write_show_slots_cache(invalidation, slots):
    if not invalidation or not slots:
        return False
    return cache.put_json(
        NS_TRAKT, KEY_IN_PROGRESS_SHOW_SLOTS, slots, invalidation=invalidation,
    )


def read_playback_episodes(invalidation):
    if not invalidation:
        return None
    items = cache.get_json(NS_TRAKT, KEY_PLAYBACK_EPISODES, invalidation=invalidation)
    return items if isinstance(items, list) else None


def write_playback_episodes(items, invalidation):
    if not invalidation or not isinstance(items, list):
        return False
    return cache.put_json(
        NS_TRAKT, KEY_PLAYBACK_EPISODES, items, invalidation=invalidation,
    )


def read_watched_movies(invalidation):
    if not invalidation:
        return None
    items = cache.get_json(NS_TRAKT, KEY_WATCHED_MOVIES, invalidation=invalidation)
    return items if isinstance(items, list) else None


def write_watched_movies(items, invalidation):
    if not invalidation or not isinstance(items, list):
        return False
    return cache.put_json(
        NS_TRAKT, KEY_WATCHED_MOVIES, items, invalidation=invalidation,
    )


def read_playback_movies(invalidation):
    if not invalidation:
        return None
    items = cache.get_json(NS_TRAKT, KEY_PLAYBACK_MOVIES, invalidation=invalidation)
    return items if isinstance(items, list) else None


def write_playback_movies(items, invalidation):
    if not invalidation or not isinstance(items, list):
        return False
    return cache.put_json(
        NS_TRAKT, KEY_PLAYBACK_MOVIES, items, invalidation=invalidation,
    )


def read_episode_slots_cache(invalidation):
    if not invalidation:
        return None
    slots = cache.get_json(NS_TRAKT, KEY_IN_PROGRESS_EPISODE_SLOTS, invalidation=invalidation)
    return slots if isinstance(slots, list) else None


def write_episode_slots_cache(invalidation, slots):
    if not invalidation or not slots:
        return False
    return cache.put_json(
        NS_TRAKT, KEY_IN_PROGRESS_EPISODE_SLOTS, slots, invalidation=invalidation,
    )


def read_movie_slots_cache(invalidation):
    if not invalidation:
        return None
    slots = cache.get_json(NS_TRAKT, KEY_IN_PROGRESS_MOVIE_SLOTS, invalidation=invalidation)
    return slots if isinstance(slots, list) else None


def write_movie_slots_cache(invalidation, slots):
    if not invalidation or not slots:
        return False
    return cache.put_json(
        NS_TRAKT, KEY_IN_PROGRESS_MOVIE_SLOTS, slots, invalidation=invalidation,
    )


# Legacy API  -  no longer used; fingerprints live on cache rows + activity namespace.
def read_md5():
    return ''


def write_md5(_fp):
    return False

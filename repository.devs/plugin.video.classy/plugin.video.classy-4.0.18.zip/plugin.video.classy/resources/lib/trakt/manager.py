# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file manager.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt Manager dialog  -  collection, watchlist, user lists.'''

from __future__ import annotations

import json

import xbmcgui

from ..modules import control
from ..modules.classy import c
from . import auth
from . import paths
from . import transport

# 32520 - 32522 are stream strings in Classy  -  literals for list actions.
L_NEW_LIST = 'Add to new List'
L_ADD_LIST = 'Add to %s'
L_REMOVE_LIST = 'Remove from %s'


def _success_message(label):
    '''Action menu uses Add/Remove; toast uses past tense.'''
    text = str(label or '').strip()
    if text.startswith('Add to '):
        return 'Added to ' + text[len('Add to '):]
    if text.startswith('Remove from '):
        return 'Removed from ' + text[len('Remove from '):]
    return text


def _valid_id(value):
    text = str(value or '').strip()
    return text and text not in ('0', 'None')


def _sync_post(content, imdb, tmdb):
    if content == 'movie':
        ids = {}
        if _valid_id(imdb):
            ids['imdb'] = imdb
        if _valid_id(tmdb):
            try:
                ids['tmdb'] = int(tmdb)
            except (TypeError, ValueError):
                pass
        return {'movies': [{'ids': ids}]} if ids else None

    ids = {}
    if _valid_id(tmdb):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    if _valid_id(imdb):
        ids['imdb'] = imdb
    return {'shows': [{'ids': ids}]} if ids else None


def _response_ok(status):
    return status and 200 <= int(status) < 300


def _user_lists():
    data = transport.get_json(
        paths.path('users', 'lists'),
        params={'limit': 250},
        with_auth=True,
    )
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        if not isinstance(item, dict):
            continue
        name = (item.get('name') or '').strip()
        slug = ((item.get('ids') or {}).get('slug') or '').strip()
        if name and slug:
            out.append((name, slug))
    return out


def _post_sync(endpoint, post):
    body, _hdrs, status = transport.post(endpoint, json_body=post, with_auth=True)
    return _response_ok(status), body


def _create_list(name):
    result = transport.post_json(
        paths.path('users', 'lists'),
        json_body={'name': name, 'privacy': 'private'},
        with_auth=True,
    )
    if not isinstance(result, dict):
        return None
    return ((result.get('ids') or {}).get('slug') or '').strip() or None


def manager(name, imdb, tmdb, content):
    '''Context menu entry  -  Trakt collection / watchlist / custom lists.'''
    if not auth.has_credentials():
        c.infoDialog('Trakt account required', heading='Trakt', sound=True, icon='ERROR')
        return

    post = _sync_post(content, imdb, tmdb)
    if not post:
        c.infoDialog('No valid Trakt ID for this item', heading=name or 'Trakt', sound=True, icon='ERROR')
        return

    actions = [
        ('Add to Collection', paths.path('sync', 'collection')),
        ('Remove from Collection', paths.path('sync', 'collection_remove')),
        ('Add to Watchlist', paths.path('sync', 'watchlist')),
        ('Remove from Watchlist', paths.path('sync', 'watchlist_remove')),
        (L_NEW_LIST, '__create__'),
    ]

    for list_name, slug in _user_lists():
        actions.append((L_ADD_LIST % list_name, f'/users/me/lists/{slug}/items'))
        actions.append((L_REMOVE_LIST % list_name, f'/users/me/lists/{slug}/items/remove'))

    labels = [label for label, _endpoint in actions]
    select = control.selectDialog(labels, 'Trakt Manager')
    if select < 0:
        return

    label, endpoint = actions[select]
    success_label = label

    try:
        if endpoint == '__create__':
            keyboard = xbmcgui.Dialog().input('New list name', type=xbmcgui.INPUT_ALPHANUM)
            if not keyboard:
                return
            slug = _create_list(keyboard.strip())
            if not slug:
                c.infoDialog('Could not create Trakt list', heading=name, sound=True, icon='ERROR')
                return
            endpoint = f'/users/me/lists/{slug}/items'
            success_label = f'Added to {keyboard.strip()}'

        ok, body = _post_sync(endpoint, post)
        if not ok:
            c.log(f'[Trakt Manager] POST {endpoint} failed: {body!r}', 1)
            c.infoDialog('Trakt request failed  -  see classy.log', heading=name, sound=True, icon='ERROR')
            return

        if endpoint == paths.path('sync', 'watchlist'):
            try:
                payload = json.loads(body or '{}')
                key = 'movies' if content == 'movie' else 'shows'
                if int((payload.get('added') or {}).get(key, 0)) == 0:
                    c.infoDialog(
                        'Trakt did not add this item  -  see classy.log',
                        heading=name,
                        sound=True,
                        icon='ERROR',
                    )
                    return
            except Exception:
                pass

        success_label = _success_message(success_label)
        c.log(f'[Trakt Manager] {success_label} ({content}, imdb={imdb}, tmdb={tmdb})')
        control.execute('Container.Refresh')
        c.infoDialog(success_label, heading=name, sound=True)
    except Exception as exc:
        c.log(f'[Trakt Manager] error: {exc}', 1)
    finally:
        control.idle()

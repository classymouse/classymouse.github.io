# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scrobble.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt scrobble + playback delete  -  single API owner during playback.'''

import xbmc

from ..modules.classy import c
from ..progress import filters as slot_filters
from . import auth
from . import paths
from . import sync
from . import transport

WATCHED_PCT_DEFAULT = slot_filters.RESUME_PROGRESS_MAX_DEFAULT
MIN_POSITION_SEC = 60


def watched_percent():
    return slot_filters.resume_progress_max()


def _devmode_scrobble_notify(api_action, percent=0, *, ok=True, skipped='', watched=False):
    '''Short toast when dev_pw matches  -  e.g. "scrobble -> pause (45%)".'''
    if not c.devmode:
        return
    try:
        playing = xbmc.Player().isPlayingVideo()
    except Exception:
        playing = False

    # Crew parity: pause toast even on the pause OSD; suppress start/stop over a playing stream.
    if playing and api_action not in ('pause',):
        return

    if skipped:
        msg = f'scrobble -> {api_action} (skipped: {skipped})'
    elif watched:
        msg = 'scrobble -> stop (watched)'
    elif ok:
        msg = f'scrobble -> {api_action}'
        if percent > 0:
            msg += f' ({percent:.0f}%)'
    else:
        msg = f'scrobble -> {api_action} (failed)'

    try:
        import time
        time.sleep(0.4)
    except Exception:
        pass
    c.infoDialog(msg, heading='Devmode', time=2500)


def _valid_id(value):
    return str(value or '').strip() not in ('', '0', 'None', 'null')


def _scrobble_ids(imdb='', tmdb=''):
    ids = {}
    if _valid_id(imdb):
        imdb_val = str(imdb)
        ids['imdb'] = imdb_val if imdb_val.startswith('tt') else f'tt{imdb_val}'
    if _valid_id(tmdb):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    return ids


def official_trakt_active(media_type):
    '''Skip own scrobble when script.trakt is installed, authorized, and enabled.'''
    try:
        import xbmcaddon

        if not xbmc.getCondVisibility('System.HasAddon(script.trakt)'):
            return False
        addon = xbmcaddon.Addon('script.trakt')
        if not (addon.getSetting('authorization') or '').strip():
            return False
        if (addon.getSetting('ExcludeHTTP') or '').lower() == 'true':
            return False
        setting_key = 'scrobble_movie' if media_type == 'movie' else 'scrobble_episode'
        if (addon.getSetting(setting_key) or '').lower() == 'false':
            return False
        c.log(f'[Scrobble] script.trakt active for {media_type}  -  skipping own call')
        return True
    except Exception as exc:
        c.log(f'[Scrobble] official Trakt check failed: {exc}', 1)
        return False


def _response_ok(status):
    return 200 <= int(status or 0) < 300


def delete_playback(playback_id):
    if not playback_id:
        return False
    if not auth.has_credentials():
        c.log('[Scrobble] delete playback skipped  -  not authenticated', 1)
        return False
    path = paths.path('sync', 'playback_id', playback_id=playback_id)
    _body, _hdrs, status = transport.delete(path)
    if status in (204, 404) or _response_ok(status):
        c.log(f'[Scrobble] deleted playback id={playback_id}')
        return True
    c.log(f'[Scrobble] delete playback failed id={playback_id} status={status}', 1)
    return False


def scrobble_session(session, current_sec, total_sec, action):
    '''
    Send scrobble/start|pause|stop for the active playback session.

    session: dict from playback.session.load()
    '''
    if not auth.scrobble_enabled() or not auth.has_credentials():
        return False

    mediatype = (session.get('mediatype') or 'movie').lower()
    if official_trakt_active('episode' if mediatype == 'episode' else 'movie'):
        _devmode_scrobble_notify(action, skipped='script.trakt')
        return True

    imdb = session.get('imdb') or ''
    tmdb = session.get('tmdb') or ''
    ids = _scrobble_ids(imdb=imdb, tmdb=tmdb)
    if not ids:
        c.log(f'[Scrobble] skip {action}  -  no imdb/tmdb id', 1)
        _devmode_scrobble_notify(action, skipped='no id')
        return False

    try:
        current = float(current_sec or 0)
        total = float(total_sec or 0)
    except (TypeError, ValueError):
        current = 0.0
        total = 0.0

    percent = (current / total * 100.0) if current > 0 and total > 0 else 0.0
    percent = round(percent, 2)
    watched_pct = watched_percent()
    outcome_watched = bool(session.get('_outcome_watched'))

    if action in ('pause', 'stop') and current < MIN_POSITION_SEC and percent < watched_pct:
        c.log(f'[Scrobble] skip {action}  -  position {current:.0f}s below minimum')
        _devmode_scrobble_notify(action, skipped=f'<{MIN_POSITION_SEC}s')
        return False

    # Trakt server watched bar is opaque  -  send 100% on Classy watched decisions.
    if action == 'stop' and (outcome_watched or percent >= watched_pct):
        percent = 100.0

    api_action = action
    if (outcome_watched or percent >= watched_pct) and action in ('pause', 'stop'):
        api_action = 'stop'

    if api_action != 'start' and percent <= 0:
        _devmode_scrobble_notify(api_action, skipped='0%')
        return False

    if mediatype == 'episode':
        try:
            season = int(session.get('season') or 0)
            episode = int(session.get('episode') or 0)
        except (TypeError, ValueError):
            season = episode = 0
        if season <= 0 or episode <= 0:
            c.log(f'[Scrobble] skip episode {action}  -  missing season/episode', 1)
            _devmode_scrobble_notify(action, skipped='no S/E')
            return False
        body = {
            'show': {'ids': ids},
            'episode': {'season': season, 'number': episode},
            'progress': percent,
        }
        label = f'S{season:02d}E{episode:02d}'
    else:
        body = {
            'movie': {'ids': ids},
            'progress': percent,
        }
        label = 'movie'

    path = paths.path('scrobble', api_action)
    c.log(f'[Scrobble] {api_action} {label} ids={ids} progress={percent}%')
    _result = transport.post_json(path, json_body=body)
    ok = _response_ok(transport.last_status())
    if ok:
        sync.invalidate_playback_caches()
        if percent >= watched_pct and api_action == 'stop':
            sync.invalidate_watched_caches()
        if action in ('pause', 'stop'):
            try:
                from ..progress.widget_signals import notify_progress_changed
                notify_progress_changed(f'trakt_scrobble_{api_action}')
            except Exception:
                pass
        _devmode_scrobble_notify(
            api_action,
            percent,
            ok=True,
            watched=(percent >= watched_pct and api_action == 'stop'),
        )
    else:
        _devmode_scrobble_notify(api_action, percent, ok=False)
    return ok

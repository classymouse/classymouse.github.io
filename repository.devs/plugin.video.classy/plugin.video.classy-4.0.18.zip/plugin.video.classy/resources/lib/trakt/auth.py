# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file auth.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt auth - credential storage + token refresh.

Invoked from trakt/ui.py (device flow) and msg_handler.after_action (401 retry).'''

import time

from ..modules import keys
from ..modules.classy import c
from . import paths

BASE_URL = 'https://api.trakt.tv'
CLIENT_ID = keys.trakt_id
CLIENT_SECRET = keys.trakt_secret
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'


def has_credentials() -> bool:
    token = (c.get_setting('trakt.token') or '').strip()
    refresh = (c.get_setting('trakt.refresh') or '').strip()
    return bool(token and refresh)


def scrobble_enabled() -> bool:
    '''Respect trakt.scrobble toggle; default on when unset (Crew parity).'''
    value = c.get_setting('trakt.scrobble')
    if value is None or value == '':
        return True
    return str(value).lower() != 'false'


def set_credentials(user='', token='', refresh='', expires_at=None):
    c.set_setting('trakt.token', token or '')
    c.set_setting('trakt.refresh', refresh or '')
    if expires_at:
        c.set_setting('trakt.expires_at', str(expires_at))
    elif not token:
        c.set_setting('trakt.expires_at', '')
    if user or not token:
        c.set_setting('trakt.user', user or '')


def build_auth_headers(headers=None):
    return build_headers(headers, auth=True)


def build_headers(headers=None, auth=True):
    out = dict(headers or {})
    if auth:
        token = (c.get_setting('trakt.token') or '').strip()
        if token:
            out['Authorization'] = f'Bearer {token}'
    out.setdefault('Content-Type', 'application/json')
    out.setdefault('trakt-api-version', '2')
    if CLIENT_ID:
        out.setdefault('trakt-api-key', CLIENT_ID)
    return out


def _username_from_me_payload(me):
    if not isinstance(me, dict):
        return ''
    for key in ('username', 'slug'):
        val = me.get(key)
        if val:
            return str(val).strip()
    nested = me.get('user')
    if isinstance(nested, dict):
        val = nested.get('username') or nested.get('slug')
        if val:
            return str(val).strip()
    ids = me.get('ids')
    if isinstance(ids, dict) and ids.get('slug'):
        return str(ids['slug']).strip()
    return ''


def ensure_username_from_api(force=False):
    existing = (c.get_setting('trakt.user') or '').strip()
    if existing and not force:
        return existing
    if not has_credentials():
        return existing

    from . import transport

    me = transport.get_json(paths.path('users', 'me'))
    user = _username_from_me_payload(me)
    if user:
        c.set_setting('trakt.user', user)
        c.log(f'[TraktAuth] stored username: {user}')
        return user
    return (c.get_setting('trakt.user') or '').strip()


def try_refresh(ctx, headers):
    """
    Called from msg_handler after REFRESH_AUTH.
    Return True when Authorization was updated for a retry.
    """
    if not has_credentials():
        c.log('[TraktAuth] refresh skipped - no credentials')
        return False

    refresh_token = (c.get_setting('trakt.refresh') or '').strip()
    if not refresh_token:
        c.log('[TraktAuth] refresh skipped - no refresh token')
        return False

    from . import transport

    body = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'redirect_uri': REDIRECT_URI,
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
    }
    result = transport.post_json(
        paths.path('oauth', 'token'),
        json_body=body,
        with_auth=False,
    )
    if not isinstance(result, dict) or not result.get('access_token'):
        c.log(f'[TraktAuth] refresh failed status={transport.last_status()}', 1)
        return False

    token = result['access_token']
    refresh = result.get('refresh_token') or refresh_token
    expires_in = int(result.get('expires_in', 86400))
    expires_at = int(time.time()) + expires_in
    set_credentials('', token, refresh, expires_at)
    c.log('[TraktAuth] token refreshed')
    return True

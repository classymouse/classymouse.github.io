# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file sync.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt sync bulk reads  -  watched shows with activity gate + SQLite cache.'''

import threading

from .. import cache as disk_cache
from ..modules.classy import c
from . import activity
from . import paths
from . import store
from . import transport

_watched_lock = threading.Lock()

_PROGRESS_PAGE_LIMIT = 100
_MOVIE_PAGE_LIMIT = 250
_MAX_PROGRESS_PAGES = 500
_MAX_MOVIE_PAGES = 500


def _show_trakt_id(item):
    try:
        return str((item.get('show') or {}).get('ids', {}).get('trakt') or '')
    except Exception:
        return ''


def _merge_watched_page(merged, seen, batch):
    added = 0
    for item in batch:
        if not isinstance(item, dict):
            continue
        tid = _show_trakt_id(item)
        if tid and tid in seen:
            continue
        if tid:
            seen.add(tid)
        merged.append(item)
        added += 1
    return added


def _fetch_watched_shows_progress():
    path = paths.path('sync', 'watched_shows')
    merged = []
    seen = set()
    page = 1
    page_count = 0
    total_items = 0

    while page <= _MAX_PROGRESS_PAGES:
        data, headers, status = transport.get_json_with_meta(
            path,
            params={
                'extended': 'progress',
                'page': page,
                'limit': _PROGRESS_PAGE_LIMIT,
            },
        )
        if status and status >= 400:
            c.log(f'[Trakt] watched/shows progress page {page} HTTP {status}', 1)
            break
        if not isinstance(data, list) or not data:
            break

        pag = transport.parse_pagination_headers(headers)
        if pag.get('page_count'):
            page_count = pag['page_count']
        if pag.get('item_count'):
            total_items = pag['item_count']
        applied_limit = pag.get('limit') or len(data)

        added = _merge_watched_page(merged, seen, data)
        if c.devmode:
            c.log(
                f'[Trakt] watched/shows progress page {page}'
                f'{f"/{page_count}" if page_count else ""}: '
                f'+{added} shows (batch={len(data)} applied_limit={applied_limit})'
            )

        if page_count and page >= page_count:
            break
        if len(data) < applied_limit:
            break
        page += 1

    if c.devmode and total_items and len(merged) != total_items:
        c.log(
            f'[Trakt] watched/shows progress: merged {len(merged)} shows '
            f'vs header item_count={total_items}',
            1,
        )
    return merged


def _movie_trakt_id(item):
    try:
        return str((item.get('movie') or {}).get('ids', {}).get('trakt') or '')
    except Exception:
        return ''


def _merge_watched_movies_page(merged, seen, batch):
    added = 0
    for item in batch:
        if not isinstance(item, dict):
            continue
        tid = _movie_trakt_id(item)
        if tid and tid in seen:
            continue
        if tid:
            seen.add(tid)
        merged.append(item)
        added += 1
    return added


def _fetch_watched_movies():
    '''Paginated /sync/watched/movies (default extended  -  full movie metadata).'''
    path = paths.path('sync', 'watched_movies')
    merged = []
    seen = set()
    page = 1
    page_count = 0
    total_items = 0

    while page <= _MAX_MOVIE_PAGES:
        data, headers, status = transport.get_json_with_meta(
            path,
            params={'page': page, 'limit': _MOVIE_PAGE_LIMIT},
        )
        if status and status >= 400:
            c.log(f'[Trakt] watched/movies page {page} HTTP {status}', 1)
            break
        if not isinstance(data, list) or not data:
            break

        pag = transport.parse_pagination_headers(headers)
        if pag.get('page_count'):
            page_count = pag['page_count']
        if pag.get('item_count'):
            total_items = pag['item_count']
        applied_limit = pag.get('limit') or len(data)

        added = _merge_watched_movies_page(merged, seen, data)
        if c.devmode:
            c.log(
                f'[Trakt] watched/movies page {page}'
                f'{f"/{page_count}" if page_count else ""}: '
                f'+{added} movies (batch={len(data)} applied_limit={applied_limit})'
            )

        if page_count and page >= page_count:
            break
        if len(data) < applied_limit:
            break
        page += 1

    if c.devmode and total_items and len(merged) != total_items:
        c.log(
            f'[Trakt] watched/movies: merged {len(merged)} movies '
            f'vs header item_count={total_items}',
            1,
        )
    return merged


def fetch_watched_shows_min():
    path = paths.path('sync', 'watched_shows')
    return transport.get_json(path, params={'extended': 'min'})


def fetch_watched_episodes_min():
    path = paths.path('sync', 'watched_episodes')
    return transport.get_json(path, params={'extended': 'min'})


def get_watched_shows_extended(log_label='', probe=None):
    '''
    Watched shows with per-episode progress  -  SQLite cache keyed by TV activity fp.

    Pass probe from the route to avoid a second last_activities fetch.
    '''
    label = log_label or 'watched_shows'
    suffix = f' ({label})' if label else ''

    with _watched_lock:
        if probe is None:
            probe = activity.probe_last_activities(log_label=label)
        inv = probe.progress_fingerprint()

        cached = store.read_watched_shows(inv)
        if cached is not None:
            if c.devmode:
                c.log(
                    f'[Trakt] watched/shows{suffix}: cache hit '
                    f'({len(cached)} shows, inv={inv[:8]}...)'
                )
            return cached

        result = _fetch_watched_shows_progress()
        if not isinstance(result, list):
            c.log(f'[Trakt] watched/shows{suffix}: fetch failed status={transport.last_status()}', 1)
            stale = disk_cache.get_json(store.NS_TRAKT, store.KEY_WATCHED_SHOWS)
            if isinstance(stale, list) and store.watched_has_episode_detail(stale):
                return stale
            return []

        has_detail = store.watched_has_episode_detail(result)
        c.log(
            f'[Trakt] watched/shows{suffix}: fetched {len(result)} shows '
            f'(episode_detail={has_detail}, extended=progress)'
        )
        if has_detail and inv:
            if store.write_watched_shows(result, inv):
                activity.commit_fingerprints(probe.fingerprints)
                if c.devmode:
                    c.log(f'[Trakt] watched/shows{suffix}: cached (inv={inv[:8]}...)')
            else:
                c.log(f'[Trakt] watched/shows{suffix}: SQLite cache write failed', 1)
        elif not has_detail:
            c.log(
                '[Trakt] watched/shows: no season/episode data  -  '
                'expected extended=progress pagination',
                1,
            )
        return result


_playback_lock = threading.Lock()


def get_playback_episodes_extended(log_label='', probe=None):
    '''
    Trakt /sync/playback/episodes?extended=full  -  SQLite cache keyed by episodes activity.
    '''
    label = log_label or 'playback_episodes'
    suffix = f' ({label})' if label else ''

    with _playback_lock:
        if probe is None:
            probe = activity.probe_last_activities(log_label=label)
        inv = probe.fingerprint('episodes')

        cached = store.read_playback_episodes(inv)
        if cached is not None:
            if c.devmode:
                c.log(
                    f'[Trakt] playback/episodes{suffix}: cache hit '
                    f'({len(cached)} items, inv={inv[:8]}...)'
                )
            return cached

        path = paths.path('sync', 'playback_episodes')
        result = transport.get_json(path, params={'extended': 'full'})
        if not isinstance(result, list):
            c.log(
                f'[Trakt] playback/episodes{suffix}: fetch failed '
                f'status={transport.last_status()}',
                1,
            )
            stale = disk_cache.get_json(store.NS_TRAKT, store.KEY_PLAYBACK_EPISODES)
            if isinstance(stale, list):
                return stale
            return []

        c.log(f'[Trakt] playback/episodes{suffix}: fetched {len(result)} items')
        if inv:
            if store.write_playback_episodes(result, inv):
                activity.commit_fingerprints(probe.fingerprints)
                if c.devmode:
                    c.log(f'[Trakt] playback/episodes{suffix}: cached (inv={inv[:8]}...)')
            else:
                c.log(f'[Trakt] playback/episodes{suffix}: SQLite cache write failed', 1)
        return result


_movies_lock = threading.Lock()


def fetch_watched_movies_min():
    '''Compact watched map: {trakt_id: [watched_at, ...]}  -  not for browse overlays.'''
    path = paths.path('sync', 'watched_movies')
    result = transport.get_json(path, params={'extended': 'min'})
    return result if isinstance(result, dict) else None


def get_watched_movies_extended(log_label='', probe=None):
    '''Trakt /sync/watched/movies  -  paginated default extended; SQLite cache.'''
    label = log_label or 'watched_movies'
    suffix = f' ({label})' if label else ''

    with _movies_lock:
        if probe is None:
            probe = activity.probe_last_activities(log_label=label)
        inv = probe.fingerprint('movies')

        cached = store.read_watched_movies(inv)
        if cached is not None:
            if c.devmode:
                c.log(
                    f'[Trakt] watched/movies{suffix}: cache hit '
                    f'({len(cached)} items, inv={inv[:8]}...)'
                )
            return cached

        result = _fetch_watched_movies()
        if not isinstance(result, list):
            c.log(
                f'[Trakt] watched/movies{suffix}: fetch failed '
                f'status={transport.last_status()}',
                1,
            )
            stale = disk_cache.get_json(store.NS_TRAKT, store.KEY_WATCHED_MOVIES)
            if isinstance(stale, list):
                return stale
            return []

        c.log(f'[Trakt] watched/movies{suffix}: fetched {len(result)} items (paginated)')
        if inv:
            if store.write_watched_movies(result, inv):
                activity.commit_fingerprints(probe.fingerprints)
                if c.devmode:
                    c.log(f'[Trakt] watched/movies{suffix}: cached (inv={inv[:8]}...)')
            else:
                c.log(f'[Trakt] watched/movies{suffix}: SQLite cache write failed', 1)
        return result


def get_playback_movies_extended(log_label='', probe=None):
    '''Trakt /sync/playback/movies  -  partial watch for movie overlays.'''
    label = log_label or 'playback_movies'
    suffix = f' ({label})' if label else ''

    with _movies_lock:
        if probe is None:
            probe = activity.probe_last_activities(log_label=label)
        inv = probe.fingerprint('movies')

        cached = store.read_playback_movies(inv)
        if cached is not None:
            if c.devmode:
                c.log(
                    f'[Trakt] playback/movies{suffix}: cache hit '
                    f'({len(cached)} items, inv={inv[:8]}...)'
                )
            return cached

        path = paths.path('sync', 'playback_movies')
        result = transport.get_json(path, params={'extended': 'full'})
        if not isinstance(result, list):
            c.log(
                f'[Trakt] playback/movies{suffix}: fetch failed '
                f'status={transport.last_status()}',
                1,
            )
            stale = disk_cache.get_json(store.NS_TRAKT, store.KEY_PLAYBACK_MOVIES)
            if isinstance(stale, list):
                return stale
            return []

        c.log(f'[Trakt] playback/movies{suffix}: fetched {len(result)} items')
        if inv:
            if store.write_playback_movies(result, inv):
                activity.commit_fingerprints(probe.fingerprints)
                if c.devmode:
                    c.log(f'[Trakt] playback/movies{suffix}: cached (inv={inv[:8]}...)')
            else:
                c.log(f'[Trakt] playback/movies{suffix}: SQLite cache write failed', 1)
        return result


def invalidate_playback_caches():
    '''Drop cached /sync/playback rows after scrobble or clear-resume.'''
    disk_cache.delete(store.NS_TRAKT, store.KEY_PLAYBACK_EPISODES)
    disk_cache.delete(store.NS_TRAKT, store.KEY_PLAYBACK_MOVIES)


def invalidate_watched_caches():
    '''Drop watched caches after a completed scrobble stop.'''
    disk_cache.delete(store.NS_TRAKT, store.KEY_WATCHED_SHOWS)
    disk_cache.delete(store.NS_TRAKT, store.KEY_WATCHED_MOVIES)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file calendar_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt TV calendar presets  -  What's On submenu (calendar&url=...).

Fetches Trakt /calendars/{my|all}/shows/{start}/{days}, maps to VideoRow,
applies Crew-style date filters for personal shortcuts, paginates global views.'''

from __future__ import annotations

import time
import unicodedata
from datetime import date, timedelta

from ..metadata.video_row import VideoRow
from ..modules.classy import c
from ..modules.unaired import is_unaired, show_unaired_enabled
from . import auth as trakt_auth
from . import paths as trakt_paths
from . import transport as trakt_transport

_TRAKT_PAGE_LIMIT = 1000
_GLOBAL_MAX_PAGES = 5
_GLOBAL_PAGE_SIZE = 50
_CACHE_TTL = 7200

# What's On  -  calendars_menu rows (not trakthistory / added).
WHATS_ON_PRESETS = frozenset({
    'mycalendar',
    'calendar_today',
    'calendar_thisweek',
    'calendar_nextweek',
    'calendar_all_today',
    'calendar_all_thisweek',
    'calendar_all_thismonth',
})

# My TV Shows  -  Trakt watch history (calendar&url=trakthistory).
HISTORY_PRESETS = frozenset({
    'trakthistory',
})

CALENDAR_PRESETS = WHATS_ON_PRESETS | HISTORY_PRESETS

# Keep scheduled episodes visible when showunaired is off.
_UNAIRED_SAFE_PRESETS = frozenset({
    'calendar_nextweek',
    'calendar_all_today',
    'calendar_all_thisweek',
    'calendar_all_thismonth',
})

_PRESET_CONFIG = {
    'mycalendar': {
        'scope': 'my',
        'start_offset': 7,
        'days': 7,
        # Newest first, then title within day (#244)
        'sort_mode': 'date_desc',
        'date_filter': None,
        'paginate': False,
    },
    'calendar_today': {
        'scope': 'my',
        'start_offset': 0,
        'days': 1,
        'sort_mode': 'alpha',
        'date_filter': 'today',
        'paginate': False,
    },
    'calendar_thisweek': {
        'scope': 'my',
        'start_offset': 0,
        'days': 7,
        'sort_mode': 'date_asc',
        'date_filter': 'thisweek',
        'paginate': False,
    },
    'calendar_nextweek': {
        'scope': 'my',
        'start_offset': 0,
        'days': 14,
        'sort_mode': 'date_asc',
        'date_filter': 'nextweek',
        'paginate': False,
    },
    'calendar_all_today': {
        'scope': 'all',
        'start_offset': 0,
        'days': 1,
        'sort_mode': 'alpha',
        'date_filter': None,
        'paginate': True,
    },
    'calendar_all_thisweek': {
        'scope': 'all',
        'start_offset': 0,
        'days': 7,
        'sort_mode': 'date_asc',
        'date_filter': None,
        'paginate': True,
    },
    'calendar_all_thismonth': {
        'scope': 'all',
        'start_offset': 0,
        'days': 30,
        'sort_mode': 'date_asc',
        'date_filter': None,
        'paginate': True,
    },
}

_HISTORY_PAGE_LIMIT = 40

_global_cache = {}


def is_whats_on_preset(preset):
    return (preset or '').strip() in WHATS_ON_PRESETS


def is_history_preset(preset):
    return (preset or '').strip() in HISTORY_PRESETS


def is_calendar_preset(preset):
    return is_whats_on_preset(preset) or is_history_preset(preset)


def preset_config(preset):
    return _PRESET_CONFIG.get((preset or '').strip())


def _start_date(offset_days):
    return (date.today() - timedelta(days=int(offset_days))).isoformat()


def _calendar_path(scope, start_offset, days):
    key = 'my_shows' if scope == 'my' else 'all_shows'
    return trakt_paths.path(
        'calendars', key,
        start_date=_start_date(start_offset),
        days=int(days),
    )


def _norm_title(value):
    text = (value or '').strip()
    if not text:
        return ''
    return unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode().lower()


def _premiere_date(item):
    ep = item.get('episode') if isinstance(item.get('episode'), dict) else {}
    raw = item.get('first_aired') or ep.get('first_aired') or ''
    return str(raw)[:10]


def _parse_date(value):
    text = str(value or '')[:10]
    if len(text) != 10:
        return None
    try:
        return date.fromisoformat(text)
    except ValueError:
        return None


def _item_to_row(item):
    ep = item.get('episode') if isinstance(item.get('episode'), dict) else {}
    show = item.get('show') if isinstance(item.get('show'), dict) else {}
    season_raw = ep.get('season')
    ep_raw = ep.get('number')
    if season_raw is None or ep_raw is None:
        return None
    try:
        season = int(season_raw)
        episode = int(ep_raw)
    except (TypeError, ValueError):
        return None
    if season <= 0:
        return None

    row = VideoRow.from_trakt_episode(item)
    row.season = season
    row.episode = episode
    premiered = _premiere_date(item)
    if premiered:
        row.premiered = premiered
    if not row.plot:
        row.plot = (ep.get('overview') or '').strip()
    try:
        row.rating = float(ep.get('rating') or 0)
    except (TypeError, ValueError):
        row.rating = 0.0
    try:
        row.votes = int(ep.get('votes') or 0)
    except (TypeError, ValueError):
        row.votes = 0
    if not row.tvshowtitle:
        row.tvshowtitle = (show.get('title') or '').strip()
    row.label = ''
    return row


def _dedupe_rows(rows):
    seen_tmdb = set()
    seen_title = set()
    out = []
    for row in rows:
        if not row:
            continue
        key_tmdb = (row.tmdb, row.season, row.episode)
        key_title = (_norm_title(row.tvshowtitle), row.season, row.episode)
        if row.tmdb and key_tmdb in seen_tmdb:
            continue
        if key_title[0] and key_title in seen_title:
            continue
        if row.tmdb:
            seen_tmdb.add(key_tmdb)
        if key_title[0]:
            seen_title.add(key_title)
        out.append(row)
    return out


def _apply_date_filter(rows, date_filter):
    if not date_filter or not rows:
        return rows
    today = date.today()
    if date_filter == 'today':
        return [r for r in rows if _parse_date(r.premiered) == today]
    if date_filter == 'thisweek':
        end = today + timedelta(days=6)
        out = []
        for r in rows:
            d = _parse_date(r.premiered)
            if d is not None and today <= d <= end:
                out.append(r)
        return out
    if date_filter == 'nextweek':
        start = today + timedelta(days=7)
        end = today + timedelta(days=14)
        out = []
        for r in rows:
            d = _parse_date(r.premiered)
            if d is not None and start < d <= end:
                out.append(r)
        return out
    return rows


def _should_filter_unaired(preset):
    if show_unaired_enabled():
        return False
    return preset not in _UNAIRED_SAFE_PRESETS


def _fetch_trakt_pages(path, *, with_auth):
    items = []
    for page in range(1, _GLOBAL_MAX_PAGES + 1):
        params = {'extended': 'full', 'limit': _TRAKT_PAGE_LIMIT}
        if page > 1:
            params['page'] = page
        payload, headers, _status = trakt_transport.get_json_with_meta(
            path, params=params, with_auth=with_auth,
        )
        if not isinstance(payload, list) or not payload:
            break
        items.extend(payload)
        if len(payload) < _TRAKT_PAGE_LIMIT:
            break
        pagination = trakt_transport.parse_pagination_headers(headers)
        page_count = int(pagination.get('page_count') or 0)
        if page_count and page >= page_count:
            break
    return items


def _following_keys(path):
    if not trakt_auth.has_credentials():
        return set()
    my_path = path.replace('/calendars/all/', '/calendars/my/')
    items = _fetch_trakt_pages(my_path, with_auth=True)
    keys = set()
    for item in items or []:
        row = _item_to_row(item)
        if not row:
            continue
        tv = _norm_title(row.tvshowtitle)
        keys.add((tv, row.season, row.episode))
        if row.tmdb:
            keys.add((row.tmdb, row.season, row.episode))
    return keys


def _tag_following(rows, following_keys):
    if not following_keys:
        return rows
    for row in rows:
        tv = _norm_title(row.tvshowtitle)
        if (tv, row.season, row.episode) in following_keys:
            row.tvshowtitle = f'[COLOR limegreen]*[/COLOR] {row.tvshowtitle}'
            continue
        if row.tmdb and (row.tmdb, row.season, row.episode) in following_keys:
            row.tvshowtitle = f'[COLOR limegreen]*[/COLOR] {row.tvshowtitle}'
    return rows


def _cache_get(key):
    entry = _global_cache.get(key)
    if not entry:
        return None
    ts, rows = entry
    if (time.monotonic() - ts) > _CACHE_TTL:
        _global_cache.pop(key, None)
        return None
    return rows


def _cache_put(key, rows):
    _global_cache[key] = (time.monotonic(), list(rows))


def _watched_at_key(item):
    return str((item or {}).get('watched_at') or '')


def _build_history_rows(page):
    if not trakt_auth.has_credentials():
        c.log('[Calendar] trakthistory: Trakt auth required')
        return [], 0

    page = max(1, int(page or 1))
    path = trakt_paths.path('users', 'history_shows')
    payload, headers, status = trakt_transport.get_json_with_meta(
        path,
        params={'page': page, 'limit': _HISTORY_PAGE_LIMIT, 'extended': 'full'},
        with_auth=True,
    )
    if status and status >= 400:
        c.log(f'[Calendar] trakthistory HTTP {status}', 1)
        return [], 0
    if not isinstance(payload, list) or not payload:
        return [], 0

    items = sorted(payload, key=_watched_at_key, reverse=True)
    rows = [r for item in items for r in (_item_to_row(item),) if r]
    pag = trakt_transport.parse_pagination_headers(headers)
    total = int(pag.get('item_count') or 0) or len(rows)
    page_count = int(pag.get('page_count') or 0)
    if page_count > 1 and not pag.get('item_count'):
        total = page_count * _HISTORY_PAGE_LIMIT
    return rows, total


def _build_rows(preset, config):
    scope = config['scope']
    path = _calendar_path(scope, config['start_offset'], config['days'])
    with_auth = scope == 'my'
    if with_auth and not trakt_auth.has_credentials():
        c.log(f'[Calendar] {preset}: Trakt auth required')
        return []

    cache_key = f'{preset}:{path}'
    if config.get('paginate'):
        cached = _cache_get(cache_key)
        if cached is not None:
            rows = list(cached)
        else:
            items = _fetch_trakt_pages(path, with_auth=with_auth)
            rows = [r for item in items for r in (_item_to_row(item),) if r]
            rows = _dedupe_rows(rows)
            rows.sort(key=lambda r: r.premiered or '')
            if scope == 'all' and trakt_auth.has_credentials():
                rows = _tag_following(rows, _following_keys(path))
            _cache_put(cache_key, rows)
    else:
        items = _fetch_trakt_pages(path, with_auth=with_auth)
        rows = [r for item in items for r in (_item_to_row(item),) if r]
        rows = _dedupe_rows(rows)

    rows = _apply_date_filter(rows, config.get('date_filter'))
    if _should_filter_unaired(preset):
        rows = [r for r in rows if not is_unaired(r)]
    rows = _sort_calendar_rows(rows, config.get('sort_mode') or config.get('sort_asc'))
    return rows


def _sort_calendar_rows(rows, sort_mode):
    '''
    Calendar list order:
    - alpha: show title A - Z (Today)
    - date_desc: newest premiered first, then title within day (New Aired)
    - date_asc / default: oldest premiered first, then title within day
    '''
    if not rows:
        return rows

    # Legacy bool from older configs
    if sort_mode is True:
        sort_mode = 'date_asc'
    elif sort_mode is False:
        sort_mode = 'date_desc'

    mode = (sort_mode or 'date_asc').strip().lower()

    def _title_key(row):
        return _norm_title(getattr(row, 'tvshowtitle', None) or getattr(row, 'title', None) or '')

    if mode == 'alpha':
        return sorted(rows, key=_title_key)

    newest_first = mode == 'date_desc'
    by_title = sorted(rows, key=_title_key)
    return sorted(
        by_title,
        key=lambda r: getattr(r, 'premiered', None) or '',
        reverse=newest_first,
    )


def fetch_page(preset, page=1, *, page_size=None, widget_limit=None):
    '''
    Return (rows, total_count) for a calendar or history preset.

    Global calendar presets paginate at page_size (default 50). Personal calendar
    presets return the full filtered window on page 1. History uses Trakt paging.
    '''
    preset = (preset or '').strip()
    if is_history_preset(preset):
        rows, total = _build_history_rows(page)
        c.log(f'[Calendar] {preset}: {len(rows)} history row(s) (total ~{total})')
        if widget_limit:
            return rows[:widget_limit], total
        return rows, total

    config = preset_config(preset)
    if not config:
        return [], 0

    rows = _build_rows(preset, config)
    total = len(rows)
    c.log(f'[Calendar] {preset}: {total} episode(s) after filters')

    if widget_limit:
        return rows[:widget_limit], total

    if config.get('paginate'):
        page = max(1, int(page or 1))
        size = int(page_size or _GLOBAL_PAGE_SIZE)
        start = (page - 1) * size
        end = start + size
        return rows[start:end], total

    if page > 1:
        return [], total
    return rows, total

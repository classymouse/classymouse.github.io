# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file aliases.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt title aliases for scraper pack title matching.'''

from ..modules.classy import c
from . import transport as trakt_transport


def _imdb_slug(imdb):
    text = str(imdb or '').strip()
    if not text:
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _primary_lang():
    try:
        lang_map = {
            'English': 'en', 'German': 'de', 'German+English': 'de', 'French': 'fr',
            'French+English': 'fr', 'Portuguese': 'pt', 'Portuguese+English': 'pt',
            'Polish': 'pl', 'Polish+English': 'pl', 'Korean': 'ko', 'Korean+English': 'ko',
            'Russian': 'ru', 'Russian+English': 'ru', 'Spanish': 'es', 'Spanish+English': 'es',
            'Italian': 'it', 'Italian+English': 'it', 'Greek': 'gr', 'Greek+English': 'gr',
        }
        name = c.get_setting('providers.lang') or 'English'
        return lang_map.get(name, 'en')
    except Exception:
        return 'en'


def fetch_aliases(imdb, content='movie', localtitle=None):
    '''
    Return Trakt alias dicts (Crew-compatible) for scraper packs.
    content: 'movie' or 'episode' (uses show aliases).
    '''
    slug = _imdb_slug(imdb)
    if not slug:
        return []

    path = f'/movies/{slug}/aliases' if content == 'movie' else f'/shows/{slug}/aliases'
    try:
        rows = trakt_transport.get_json(path, with_auth=False)
    except Exception:
        rows = []
    if not isinstance(rows, list):
        return []

    lang = _primary_lang()
    local = (localtitle or '').strip().lower()
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        country = str(row.get('country') or '').lower()
        if country and country not in ('', 'us', lang):
            continue
        title = (row.get('title') or '').strip()
        if not title:
            continue
        if local and title.lower() == local:
            continue
        out.append(row)
    return out

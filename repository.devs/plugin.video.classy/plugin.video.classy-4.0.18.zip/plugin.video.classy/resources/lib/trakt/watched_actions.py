# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file watched_actions.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt /sync/history mark watched / unwatched  -  context menu playcount routes.'''

from __future__ import annotations

from ..modules import control
from ..modules.classy import c
from ..play.models import PlayRequest
from ..playback import resume as playback_resume
from . import auth
from . import paths
from . import sync
from . import transport
from .watch_index import OVERLAY_WATCHED


def _valid_id(value):
    text = str(value or '').strip()
    return text and text not in ('0', 'None', 'null')


def _parse_watched(query):
    try:
        value = int(query)
    except (TypeError, ValueError):
        return None
    if value == OVERLAY_WATCHED:
        return True
    if value == 6:
        return False
    return None


def _response_ok(status):
    return status and 200 <= int(status) < 300


def _imdb_for_trakt(imdb):
    text = str(imdb or '').strip()
    if not text:
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _show_ids(imdb='', tmdb=''):
    ids = {}
    if _valid_id(imdb):
        ids['imdb'] = _imdb_for_trakt(imdb)
    if _valid_id(tmdb):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            ids['tmdb'] = tmdb
    return ids


def _movie_ids(imdb='', tmdb=''):
    ids = {}
    if _valid_id(imdb):
        ids['imdb'] = _imdb_for_trakt(imdb)
    if _valid_id(tmdb):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            ids['tmdb'] = tmdb
    return ids


def _post_history(payload):
    ok, _body = _post_sync(paths.path('sync', 'history'), payload)
    return ok


def _post_history_remove(payload):
    ok, _body = _post_sync(paths.path('sync', 'history_remove'), payload)
    return ok


def _post_sync(endpoint, post):
    _body, _hdrs, status = transport.post(endpoint, json_body=post, with_auth=True)
    return _response_ok(status), _body


def _clear_partial_resume(imdb, tmdb, *, mediatype, season=0, episode=0):
    request = PlayRequest(
        mediatype=mediatype,
        imdb=imdb,
        tmdb=tmdb,
        season=season,
        episode=episode,
    )
    playback_resume.clear_resume(request)


def _after_success(*, mark_watched):
    sync.invalidate_watched_caches()
    if mark_watched:
        sync.invalidate_playback_caches()
    try:
        from ..progress.widget_signals import notify_progress_changed
        notify_progress_changed('trakt_playcount')
    except Exception:
        pass
    control.execute('Container.Refresh')


def mark_movie(imdb, tmdb='', *, watched=True):
    ids = _movie_ids(imdb, tmdb)
    if not ids:
        return False

    if watched:
        ok = _post_history({'movies': [{'ids': ids}]})
        if ok:
            _clear_partial_resume(imdb, tmdb, mediatype='movie')
    else:
        ok = _post_history_remove({'movies': [{'ids': ids}]})

    if ok:
        c.log(f'[Playcount] movie watched={watched} imdb={imdb} tmdb={tmdb}')
        _after_success(mark_watched=watched)
    else:
        c.log(f'[Playcount] movie mark failed watched={watched} status={transport.last_status()}', 1)
    return ok


def mark_episode(imdb, tmdb, season, episode, *, watched=True):
    ids = _show_ids(imdb, tmdb)
    if not ids:
        return False
    try:
        sn = int(season)
        en = int(episode)
    except (TypeError, ValueError):
        return False
    if sn <= 0 or en <= 0:
        return False

    payload = {
        'shows': [{
            'ids': ids,
            'seasons': [{
                'number': sn,
                'episodes': [{'number': en}],
            }],
        }],
    }

    if watched:
        ok = _post_history(payload)
        if ok:
            _clear_partial_resume(imdb, tmdb, mediatype='episode', season=sn, episode=en)
    else:
        ok = _post_history_remove(payload)

    if ok:
        c.log(f'[Playcount] episode watched={watched} S{sn:02d}E{en:02d} imdb={imdb} tmdb={tmdb}')
        _after_success(mark_watched=watched)
    else:
        c.log(
            f'[Playcount] episode mark failed watched={watched} '
            f'S{sn:02d}E{en:02d} status={transport.last_status()}',
            1,
        )
    return ok


def mark_season(imdb, tmdb, season, *, watched=True):
    ids = _show_ids(imdb, tmdb)
    if not ids:
        return False
    try:
        sn = int(season)
    except (TypeError, ValueError):
        return False
    if sn < 0:
        return False

    season_block = {'number': sn}
    tmdb_id = str(tmdb or '').strip()
    if _valid_id(tmdb_id):
        try:
            from ..apis import tmdb as tmdb_api
            season_data = tmdb_api.get_tv_season(tmdb_id, sn)
            if isinstance(season_data, dict):
                episode_numbers = []
                for ep in season_data.get('episodes') or []:
                    if not isinstance(ep, dict):
                        continue
                    try:
                        en = int(ep.get('episode_number') or 0)
                    except (TypeError, ValueError):
                        continue
                    if en > 0:
                        episode_numbers.append({'number': en})
                if episode_numbers:
                    season_block['episodes'] = episode_numbers
        except Exception as exc:
            c.log(f'[Playcount] season TMDB episode list skipped: {exc}', 1)

    payload = {
        'shows': [{
            'ids': ids,
            'seasons': [season_block],
        }],
    }

    if watched:
        ok = _post_history(payload)
    else:
        ok = _post_history_remove(payload)

    if ok:
        c.log(f'[Playcount] season watched={watched} S{sn:02d} imdb={imdb} tmdb={tmdb}')
        _after_success(mark_watched=watched)
    else:
        c.log(
            f'[Playcount] season mark failed watched={watched} '
            f'S{sn:02d} status={transport.last_status()}',
            1,
        )
    return ok


def mark_show(imdb, tmdb='', *, watched=True):
    ids = _show_ids(imdb, tmdb)
    if not ids:
        return False

    payload = {'shows': [{'ids': ids}]}
    if watched:
        ok = _post_history(payload)
    else:
        ok = _post_history_remove(payload)

    if ok:
        c.log(f'[Playcount] show watched={watched} imdb={imdb} tmdb={tmdb}')
        _after_success(mark_watched=watched)
    else:
        c.log(f'[Playcount] show mark failed watched={watched} status={transport.last_status()}', 1)
    return ok


def apply_playcount(params, *, mediatype):
    if not auth.has_credentials():
        return False, 'Connect Trakt to mark watched'

    watched = _parse_watched((params or {}).get('query'))
    if watched is None:
        return False, 'Invalid playcount action'

    imdb = (params or {}).get('imdb') or ''
    tmdb = (params or {}).get('tmdb') or ''

    if mediatype == 'movie':
        ok = mark_movie(imdb, tmdb, watched=watched)
    elif mediatype == 'episode':
        ok = mark_episode(
            imdb,
            tmdb,
            (params or {}).get('season'),
            (params or {}).get('episode'),
            watched=watched,
        )
    elif mediatype == 'tvshow':
        control.busy()
        try:
            ok = mark_show(imdb, tmdb, watched=watched)
        finally:
            control.idle()
    elif mediatype == 'season':
        control.busy()
        try:
            ok = mark_season(
                imdb,
                tmdb,
                (params or {}).get('season'),
                watched=watched,
            )
        finally:
            control.idle()
    else:
        return False, 'Unsupported media type'

    if ok:
        return True, 'Marked as watched' if watched else 'Marked as unwatched'
    return False, 'Trakt request failed  -  see classy.log'

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

# Trakt package (v4)  -  import submodules directly; avoid eager cross-imports here.

__all__ = ('auth', 'paths', 'transport', 'ui')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file browse_context.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

One Trakt mirror load per directory  -  shared by slots + watch overlays.'''

from . import activity
from . import sync
from .resume_index import ResumeIndex
from .watch_index import WatchIndex, WatchState
from .movie_watch_index import MovieWatchIndex
from .movie_resume_index import MovieResumeIndex


class TVBrowseContext:
    __slots__ = ('probe', 'watched', 'watch', 'resume', 'log_label')

    def __init__(self, probe, watched, watch, resume, log_label=''):
        self.probe = probe
        self.watched = watched or []
        self.watch = watch
        self.resume = resume
        self.log_label = log_label or ''

    @classmethod
    def load(cls, log_label='', probe=None, watched=None, playback=None, *, clear_probe=False):
        from .. import tracker

        label = log_label or 'browse'
        if tracker.is_simkl() and tracker.live():
            from ..simkl import progress as simkl_progress
            from ..simkl import watch_sync as simkl_watch

            if watched is None:
                watched = simkl_watch.watched_shows()
            if playback is None:
                playback = simkl_progress.episode_playback_items()
            watch = WatchIndex.compile(watched)
            resume = ResumeIndex.compile(playback)
            return cls(None, watched, watch, resume, log_label=label)

        if tracker.is_wetrakr() and tracker.live():
            from ..wetrakr import progress as wetrakr_progress
            from ..wetrakr import watch_sync as wetrakr_watch

            if watched is None:
                watched = wetrakr_watch.watched_shows()
            if playback is None:
                playback = wetrakr_progress.episode_playback_items()
            watch = WatchIndex.compile(watched)
            resume = ResumeIndex.compile(playback)
            return cls(None, watched, watch, resume, log_label=label)

        if probe is None:
            if clear_probe:
                activity.clear_probe_cache()
            probe = activity.probe_last_activities(log_label=label)
        if watched is None:
            watched = sync.get_watched_shows_extended(label, probe=probe)
        if playback is None:
            playback = sync.get_playback_episodes_extended(label, probe=probe)
        watch = WatchIndex.compile(watched)
        resume = ResumeIndex.compile(playback)
        return cls(probe, watched, watch, resume, log_label=label)

    def apply_watch(self, row, **kwargs):
        '''Resume (partial) wins over sync watched for episode overlays.'''
        if self.resume.apply_to_row(row):
            return WatchState(
                playcount=0,
                watched=True,
                complete=False,
                watched_count=0,
                aired=1,
            )
        state = self.watch.apply_to_row(row, **kwargs)
        try:
            from ..modules import bookmarks as local_bookmarks
            if local_bookmarks.apply_to_row(row):
                if int(getattr(row, 'overlay', 0) or 0) == 7:
                    return WatchState(
                        playcount=int(getattr(row, 'playcount', 0) or 1),
                        watched=True,
                        complete=True,
                        watched_count=1,
                        aired=1,
                    )
                return WatchState(
                    playcount=0,
                    watched=True,
                    complete=False,
                    watched_count=0,
                    aired=1,
                )
        except Exception:
            pass
        return state

    def apply_watch_rows(self, rows, **kwargs):
        states = []
        for row in rows:
            states.append(self.apply_watch(row, **kwargs))
        return states


class MovieBrowseContext:
    __slots__ = ('probe', 'watch', 'resume', 'log_label')

    def __init__(self, probe, watch, resume, log_label=''):
        self.probe = probe
        self.watch = watch
        self.resume = resume
        self.log_label = log_label or ''

    @classmethod
    def load(cls, log_label='', probe=None, watched=None, playback=None, *, clear_probe=False):
        from .. import tracker
        from . import sync

        label = log_label or 'movie_browse'
        if tracker.is_simkl() and tracker.live():
            from ..simkl import progress as simkl_progress
            from ..simkl import watch_sync as simkl_watch

            if watched is None:
                watched = simkl_watch.watched_movies()
            if playback is None:
                playback = simkl_progress.movie_playback_items()
            watch = MovieWatchIndex.compile(watched)
            resume = MovieResumeIndex.compile(playback)
            return cls(None, watch, resume, log_label=label)

        if tracker.is_wetrakr() and tracker.live():
            from ..wetrakr import progress as wetrakr_progress
            from ..wetrakr import watch_sync as wetrakr_watch

            if watched is None:
                watched = wetrakr_watch.watched_movies()
            if playback is None:
                playback = wetrakr_progress.movie_playback_items()
            watch = MovieWatchIndex.compile(watched)
            resume = MovieResumeIndex.compile(playback)
            return cls(None, watch, resume, log_label=label)

        if probe is None:
            if clear_probe:
                activity.clear_probe_cache()
            probe = activity.probe_last_activities(log_label=label)
        if watched is None:
            watched = sync.get_watched_movies_extended(label, probe=probe)
        if playback is None:
            playback = sync.get_playback_movies_extended(label, probe=probe)
        watch = MovieWatchIndex.compile(watched)
        resume = MovieResumeIndex.compile(playback)
        return cls(probe, watch, resume, log_label=label)

    def apply_watch(self, row):
        if self.resume.apply_to_row(row):
            return True
        applied = self.watch.apply_to_row(row)
        try:
            from ..modules import bookmarks as local_bookmarks
            if local_bookmarks.apply_to_row(row):
                return True
        except Exception:
            pass
        return applied

    def apply_watch_rows(self, rows):
        applied = []
        for row in rows:
            applied.append(self.apply_watch(row))
        return applied

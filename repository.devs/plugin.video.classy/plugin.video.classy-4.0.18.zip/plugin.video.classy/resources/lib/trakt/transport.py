# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file transport.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt HTTP transport  -  single entry for Trakt API calls.

Returns parsed JSON (dict / list) or None. Non-2xx  ->  msg_handler (never decide here).'''

import json
from urllib.parse import urlencode, urljoin

from ..modules import client
from ..modules import msg_handler
from ..modules.classy import c

BASE_URL = 'https://api.trakt.tv'


def _build_url(path, params=None):
    path = str(path or '')
    if path.startswith('http'):
        url = path
    else:
        if not path.startswith('/'):
            path = '/' + path
        url = urljoin(BASE_URL, path)
    if params:
        clean = {k: v for k, v in params.items() if v is not None and v != ''}
        if clean:
            sep = '&' if '?' in url else '?'
            url = url + sep + urlencode(clean)
    return url


class TraktTransport:
    def __init__(self):
        self._last_status = 0

    @property
    def last_status(self):
        return self._last_status

    def request(self, path, method='GET', json_body=None, headers=None, params=None, with_auth=True):
        from . import auth as trakt_auth

        url = _build_url(path, params)
        headers = trakt_auth.build_headers(headers, auth=with_auth)
        resp = client.api_request(
            msg_handler.API_TRAKT,
            url,
            method=method,
            headers=headers,
            json_body=json_body,
        )
        self._last_status = resp.status
        return resp.body, resp.headers, resp.status

    def get(self, path, params=None, headers=None, with_auth=True):
        return self.request(path, 'GET', headers=headers, params=params, with_auth=with_auth)

    def post(self, path, json_body=None, headers=None, params=None, with_auth=True):
        return self.request(
            path, 'POST', json_body=json_body, headers=headers, params=params, with_auth=with_auth,
        )

    def delete(self, path, headers=None, params=None, with_auth=True):
        return self.request(
            path, 'DELETE', headers=headers, params=params, with_auth=with_auth,
        )

    def get_json(self, path, params=None, headers=None, with_auth=True):
        body, _hdrs, status = self.get(path, params=params, headers=headers, with_auth=with_auth)
        return _parse_json(body, status, path)

    def get_json_with_meta(self, path, params=None, headers=None, with_auth=True):
        body, hdrs, status = self.get(path, params=params, headers=headers, with_auth=with_auth)
        return _parse_json(body, status, path), hdrs, status

    def post_json(self, path, json_body=None, headers=None, params=None, with_auth=True):
        body, _hdrs, status = self.post(
            path, json_body=json_body, headers=headers, params=params, with_auth=with_auth,
        )
        return _parse_json(body, status, path)


def _parse_json(body, status, path):
    if status == 204:
        return None
    if not body:
        return None
    try:
        return json.loads(body)
    except Exception as exc:
        c.log(f'[Trakt] JSON parse failed {path}: {exc}', 1)
        return None


_transport = TraktTransport()


def get(path, params=None, headers=None, with_auth=True):
    return _transport.get(path, params=params, headers=headers, with_auth=with_auth)


def post(path, json_body=None, headers=None, params=None, with_auth=True):
    return _transport.post(
        path, json_body=json_body, headers=headers, params=params, with_auth=with_auth,
    )


def delete(path, headers=None, params=None, with_auth=True):
    return _transport.delete(path, headers=headers, params=params, with_auth=with_auth)


def get_json(path, params=None, headers=None, with_auth=True):
    return _transport.get_json(path, params=params, headers=headers, with_auth=with_auth)


def get_json_with_meta(path, params=None, headers=None, with_auth=True):
    return _transport.get_json_with_meta(
        path, params=params, headers=headers, with_auth=with_auth,
    )


def parse_pagination_headers(headers):
    '''
    Parse Trakt X-Pagination-* headers (case-insensitive).

    See docs/TRAKT_WATCHED_API.md  -  applied limit may be lower than requested.
    '''
    if not headers:
        return {}
    norm = {str(k).lower(): v for k, v in headers.items()}

    def _int(key):
        try:
            return int(norm.get(key, 0) or 0)
        except (TypeError, ValueError):
            return 0

    return {
        'page': _int('x-pagination-page'),
        'page_count': _int('x-pagination-page-count'),
        'limit': _int('x-pagination-limit'),
        'item_count': _int('x-pagination-item-count'),
    }


def post_json(path, json_body=None, headers=None, params=None, with_auth=True):
    return _transport.post_json(
        path, json_body=json_body, headers=headers, params=params, with_auth=with_auth,
    )


def last_status():
    return _transport.last_status

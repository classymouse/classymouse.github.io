# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resume_index.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Partial-watch state from Trakt /sync/playback/episodes.

Takes priority over WatchIndex for episode rows (overlay 6 + resume arrow).'''

from ..progress import filters as slot_filters


class ResumeIndex:
    __slots__ = ('_episodes',)

    def __init__(self, episodes=None):
        self._episodes = dict(episodes or {})

    @classmethod
    def compile(cls, playback_items):
        eps = {}
        pmin = slot_filters.resume_progress_min()
        pmax = slot_filters.resume_progress_max()

        for item in playback_items or []:
            if not isinstance(item, dict):
                continue
            try:
                progress = float(item.get('progress', 0) or 0)
                if progress <= pmin or progress >= pmax:
                    continue

                episode_data = item.get('episode') if isinstance(item.get('episode'), dict) else {}
                show_data = item.get('show') if isinstance(item.get('show'), dict) else {}
                season = int(episode_data.get('season') or 0)
                episode = int(episode_data.get('number') or 0)
                if season <= 0 or episode <= 0:
                    continue

                show_ids = show_data.get('ids') if isinstance(show_data.get('ids'), dict) else {}
                tmdb = str(show_ids.get('tmdb') or '').strip()
                if not tmdb or tmdb in ('0', 'None'):
                    continue

                runtime_min = int(episode_data.get('runtime') or 0)
                key = (tmdb, season, episode)
                eps[key] = {
                    'progress': progress,
                    'duration': runtime_min * 60 if runtime_min > 0 else 0,
                }
            except (TypeError, ValueError):
                continue
        return cls(eps)

    def for_episode(self, tmdb, season, episode):
        key = (str(tmdb or '').strip(), int(season or 0), int(episode or 0))
        if not key[0] or key[1] <= 0 or key[2] <= 0:
            return None
        return self._episodes.get(key)

    def apply_to_row(self, row):
        if getattr(row, 'mediatype', '') != 'episode':
            return False
        entry = self.for_episode(row.tmdb, row.season, row.episode)
        if not entry:
            return False
        row.playcount = 0
        row.overlay = 6
        row.resume_point = float(entry['progress'])
        if entry.get('duration') and not int(row.duration or 0):
            row.duration = int(entry['duration'])
        return True

    def __len__(self):
        return len(self._episodes)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file paths.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt API path registry  -  templates only, no HTTP.

Use path('sync', 'last_activities') or path('users', 'list_items', list_id='abc').
Query params (?limit=1) belong on transport.get_json(..., params={...}).

TMDB routes live in apis/tmdb_paths.py (TMDB_PATHS).'''

from ..path_resolve import resolve_path

TRAKT_PATHS = {
    'oauth': {
        'device_code': '/oauth/device/code',
        'device_token': '/oauth/device/token',
        'token': '/oauth/token',
    },
    'users': {
        'me': '/users/me',
        'settings': '/users/settings',
        'lists': '/users/me/lists',
        'list_items': '/users/me/lists/{list_id}/items',
        'collection_movies': '/users/me/collection/movies',
        'collection_shows': '/users/me/collection/shows',
        'watchlist_movies': '/users/me/watchlist/movies',
        'watchlist_shows': '/users/me/watchlist/shows',
        'history_movies': '/users/me/history/movies',
        'history_shows': '/users/me/history/shows',
        'watched_movies': '/users/me/watched/movies',
        'watched_shows': '/users/me/watched/shows',
        'hidden_progress_watched': '/users/hidden/progress_watched',
        'hidden_section': '/users/hidden/{section}',
        'likes_lists': '/users/likes/lists',
    },
    'sync': {
        'last_activities': '/sync/last_activities',
        'playback': '/sync/playback',
        'playback_episodes': '/sync/playback/episodes',
        'playback_movies': '/sync/playback/movies',
        'playback_id': '/sync/playback/{playback_id}',
        'history': '/sync/history',
        'history_remove': '/sync/history/remove',
        'history_movies': '/sync/history/movies',
        'history_episodes': '/sync/history/episodes',
        'watchlist': '/sync/watchlist',
        'watchlist_remove': '/sync/watchlist/remove',
        'collection': '/sync/collection',
        'collection_movies': '/sync/collection/movies',
        'collection_shows': '/sync/collection/shows',
        'collection_remove': '/sync/collection/remove',
        'watched_movies': '/sync/watched/movies',
        'watched_shows': '/sync/watched/shows',
        'watched_episodes': '/sync/watched/episodes',
        'ratings': '/sync/ratings',
        'ratings_remove': '/sync/ratings/remove',
    },
    'movies': {
        'trending': '/movies/trending',
        'popular': '/movies/popular',
        'played': '/movies/played',
        'watched': '/movies/watched',
        'collected': '/movies/collected',
        'anticipated': '/movies/anticipated',
        'boxoffice': '/movies/boxoffice',
        'updates': '/movies/updates/{start_date}',
        'detail': '/movies/{trakt_id}',
        'aliases': '/movies/{trakt_id}/aliases',
        'translations': '/movies/{trakt_id}/translations/{language}',
        'ratings': '/movies/{trakt_id}/ratings',
    },
    'shows': {
        'trending': '/shows/trending',
        'popular': '/shows/popular',
        'played': '/shows/played',
        'watched': '/shows/watched',
        'collected': '/shows/collected',
        'anticipated': '/shows/anticipated',
        'played_weekly': '/shows/played/weekly',
        'watched_weekly': '/shows/watched/weekly',
        'collected_weekly': '/shows/collected/weekly',
        'updates': '/shows/updates/{start_date}',
        'detail': '/shows/{trakt_id}',
        'aliases': '/shows/{trakt_id}/aliases',
        'translations': '/shows/{trakt_id}/translations/{language}',
        'ratings': '/shows/{trakt_id}/ratings',
        'progress_watched': '/shows/{trakt_id}/progress/watched',
        'season': '/shows/{trakt_id}/seasons/{season}',
        'episode': '/shows/{trakt_id}/seasons/{season}/episodes/{episode}',
        'episode_ratings': (
            '/shows/{trakt_id}/seasons/{season}/episodes/{episode}/ratings'
        ),
        'episode_translations': (
            '/shows/{trakt_id}/seasons/{season}/episodes/{episode}/translations/{language}'
        ),
        'next_episode': '/shows/{trakt_id}/next_episode',
    },
    'search': {
        'movie': '/search/movie',
        'show': '/search/show',
        'person': '/search/person',
        'episode': '/search/episode',
        'by_id': '/search/{id_type}/{id}',
    },
    'calendars': {
        'my_shows': '/calendars/my/shows/{start_date}/{days}',
        'my_movies': '/calendars/my/movies/{start_date}/{days}',
        'all_shows': '/calendars/all/shows/{start_date}/{days}',
        'all_movies': '/calendars/all/movies/{start_date}/{days}',
    },
    'recommendations': {
        'movies': '/recommendations/movies',
        'shows': '/recommendations/shows',
        'movies_hide': '/recommendations/movies/hide/{trakt_id}',
        'shows_hide': '/recommendations/shows/hide/{trakt_id}',
    },
    'scrobble': {
        'start': '/scrobble/start',
        'pause': '/scrobble/pause',
        'stop': '/scrobble/stop',
    },
    'people': {
        'detail': '/people/{trakt_id}',
        'movies': '/people/{trakt_id}/movies',
        'shows': '/people/{trakt_id}/shows',
    },
}

# Back-compat alias for importers expecting PATHS.
PATHS = TRAKT_PATHS


def path(*keys, **fmt):
    '''Resolve a Trakt path template from TRAKT_PATHS.'''
    return resolve_path(TRAKT_PATHS, keys, fmt or None, label='Trakt path')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file watch_index.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Compiled watch state from Trakt /sync/watched/shows?extended=progress.

One compile per directory request  -  no second Trakt fetch for overlays.
Season / episode / show queries are in-memory set lookups.'''

from ..metadata.tv_ref import VideoRef

OVERLAY_UNWATCHED = 6
OVERLAY_WATCHED = 7


class WatchState:
    __slots__ = ('playcount', 'watched', 'complete', 'watched_count', 'aired')

    def __init__(self, playcount=0, watched=False, complete=False, watched_count=0, aired=0):
        self.playcount = int(playcount)
        self.watched = bool(watched)
        self.complete = bool(complete)
        self.watched_count = int(watched_count)
        self.aired = int(aired)


class ShowWatch:
    __slots__ = ('tmdb', 'imdb', 'trakt', 'aired', 'watched_eps')

    def __init__(self, tmdb, imdb, trakt, aired, watched_eps):
        self.tmdb = tmdb
        self.imdb = imdb
        self.trakt = trakt
        self.aired = int(aired or 0)
        self.watched_eps = frozenset(watched_eps or ())

    @property
    def watched_count(self):
        return len(self.watched_eps)

    def has_episode(self, season, episode):
        return (int(season), int(episode)) in self.watched_eps

    def watched_in_season(self, season):
        sn = int(season)
        return {ep for s, ep in self.watched_eps if s == sn}

    def season_complete(self, season, episode_count):
        count = int(episode_count or 0)
        if count <= 0:
            return False
        watched = self.watched_in_season(season)
        return len(watched) >= count

    def is_complete(self):
        if self.aired <= 0:
            return False
        return self.watched_count >= self.aired

    def in_progress(self):
        return 0 < self.watched_count < self.aired or (
            self.aired <= 0 and self.watched_count > 0
        )

    def episode_state(self, season, episode):
        watched = self.has_episode(season, episode)
        return WatchState(
            playcount=1 if watched else 0,
            watched=watched,
            complete=watched,
            watched_count=1 if watched else 0,
            aired=1,
        )

    def season_state(self, season, episode_count):
        count = int(episode_count or 0)
        watched_n = len(self.watched_in_season(season))
        complete = self.season_complete(season, count)
        return WatchState(
            playcount=1 if complete else 0,
            watched=watched_n > 0,
            complete=complete,
            watched_count=watched_n,
            aired=count,
        )

    def show_state(self):
        complete = self.is_complete()
        return WatchState(
            playcount=1 if complete else 0,
            watched=self.watched_count > 0,
            complete=complete,
            watched_count=self.watched_count,
            aired=self.aired,
        )


class WatchIndex:
    __slots__ = ('_shows',)

    def __init__(self, shows=None):
        self._shows = dict(shows or {})

    @classmethod
    def compile(cls, watched_shows):
        shows = {}
        for item in watched_shows or []:
            if not isinstance(item, dict):
                continue
            show = item.get('show') if isinstance(item.get('show'), dict) else {}
            ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
            tmdb = str(ids.get('tmdb') or '').strip()
            if not tmdb or tmdb in ('0', 'None'):
                continue

            watched_eps = set()
            for season in item.get('seasons') or []:
                sn = int(season.get('number') or 0)
                if sn <= 0:
                    continue
                for ep in season.get('episodes') or []:
                    en = int(ep.get('number') or 0)
                    if en > 0:
                        watched_eps.add((sn, en))

            shows[tmdb] = ShowWatch(
                tmdb=tmdb,
                imdb=str(ids.get('imdb') or ''),
                trakt=str(ids.get('trakt') or ''),
                aired=int(show.get('aired_episodes') or 0),
                watched_eps=watched_eps,
            )
        return cls(shows)

    def for_show(self, tmdb):
        key = str(tmdb or '').strip()
        if not key:
            return None
        return self._shows.get(key)

    def state_for(self, ref, *, season_episode_count=None):
        ref = ref if isinstance(ref, VideoRef) else VideoRef.from_row(ref)
        show = self.for_show(ref.tmdb)
        if not show:
            return WatchState()

        if ref.is_episode():
            return show.episode_state(ref.season, ref.episode)
        if ref.is_season():
            return show.season_state(ref.season, season_episode_count or 0)
        return show.show_state()

    def apply_to_row(self, row, *, season_episode_count=None):
        state = self.state_for(row, season_episode_count=season_episode_count)
        row.playcount = state.playcount
        if state.complete:
            row.overlay = OVERLAY_WATCHED
        elif state.watched:
            row.overlay = OVERLAY_UNWATCHED
        else:
            row.overlay = 0
        return state

    def apply_to_rows(self, rows, *, season_episode_count=None):
        states = []
        for row in rows:
            states.append(self.apply_to_row(row, season_episode_count=season_episode_count))
        return states

    def __len__(self):
        return len(self._shows)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_watch_index.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Watched movie state from Trakt /sync/watched/movies.'''

OVERLAY_UNWATCHED = 6
OVERLAY_WATCHED = 7


class MovieWatchIndex:
    __slots__ = ('_tmdb', '_imdb')

    def __init__(self, tmdb=None, imdb=None):
        self._tmdb = set(tmdb or ())
        self._imdb = set(imdb or ())

    @classmethod
    def compile(cls, watched_movies):
        tmdb_ids = set()
        imdb_ids = set()
        for item in watched_movies or []:
            if not isinstance(item, dict):
                continue
            movie = item.get('movie') if isinstance(item.get('movie'), dict) else item
            ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
            tmdb = str(ids.get('tmdb') or '').strip()
            imdb = str(ids.get('imdb') or '').strip()
            if tmdb and tmdb not in ('0', 'None'):
                tmdb_ids.add(tmdb)
            if imdb and imdb not in ('0', 'None'):
                imdb_ids.add(imdb)
        return cls(tmdb_ids, imdb_ids)

    def is_watched(self, *, tmdb='', imdb=''):
        tmdb = str(tmdb or '').strip()
        imdb = str(imdb or '').strip()
        if tmdb and tmdb in self._tmdb:
            return True
        if imdb and imdb in self._imdb:
            return True
        return False

    def apply_to_row(self, row):
        if getattr(row, 'mediatype', '') != 'movie':
            return False
        if not self.is_watched(tmdb=row.tmdb, imdb=row.imdb):
            return False
        row.playcount = 1
        row.overlay = OVERLAY_WATCHED
        return True

    def __len__(self):
        return len(self._tmdb) + len(self._imdb)

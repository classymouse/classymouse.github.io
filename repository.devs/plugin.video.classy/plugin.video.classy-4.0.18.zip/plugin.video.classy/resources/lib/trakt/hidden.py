# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file hidden.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt hidden items  -  used by progress list filters (not indexers).'''

from ..modules.classy import c
from . import auth
from . import paths
from . import transport

_PAGE_LIMIT = 100
_MAX_PAGES = 50

_session_ids = None


def _show_trakt_id(entry):
    if not isinstance(entry, dict):
        return ''
    show = entry.get('show') if isinstance(entry.get('show'), dict) else entry
    ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
    return str(ids.get('trakt') or '').strip()


def fetch_hidden_progress_watched_ids(*, log_label='hidden'):
    '''
    Trakt IDs of shows hidden from progress (progress_watched hidden list).

    Returns a set of str trakt ids  -  empty when unauthenticated or on failure.
    '''
    if not auth.has_credentials():
        return set()

    ids = set()
    page = 1
    while page <= _MAX_PAGES:
        data = transport.get_json(
            paths.path('users', 'hidden_progress_watched'),
            params={'limit': _PAGE_LIMIT, 'page': page},
        )
        if not isinstance(data, list):
            if page == 1:
                c.log(
                    f'[Trakt] hidden progress_watched fetch failed '
                    f'status={transport.last_status()}',
                    1,
                )
            break
        if not data:
            break
        for entry in data:
            tid = _show_trakt_id(entry)
            if tid:
                ids.add(tid)
        if len(data) < _PAGE_LIMIT:
            break
        page += 1

    if ids:
        c.log(f'[Trakt] hidden progress_watched ({log_label}): {len(ids)} shows')
    return ids


def hidden_show_trakt_ids(*, refresh=False, log_label='progress'):
    '''Session-cached hidden show ids for progress routes.'''
    global _session_ids
    if _session_ids is not None and not refresh:
        return _session_ids
    _session_ids = fetch_hidden_progress_watched_ids(log_label=log_label)
    return _session_ids


def clear_session_cache():
    global _session_ids
    _session_ids = None

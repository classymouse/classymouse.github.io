# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file ui.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt UI  -  device auth dialog (QR + poll), same flow as Crew 3.x.'''

import threading
import time
import traceback
from urllib.parse import quote

import xbmcgui

from ..modules.classy import c
from . import auth
from . import paths
from . import transport


def _qr_image_url(data, size=280):
    return (
        f'https://api.qrserver.com/v1/create-qr-code/?data={quote(data)}&size={size}x{size}'
    )


def _show_trakt_qr_dialog(verification_url, user_code, qr_path, device_code, interval, expires_in):
    try:
        class TraktQRViewer(xbmcgui.WindowXMLDialog):
            def __init__(self, *args, **kwargs):
                self.header = kwargs.get('header', 'Trakt Authentication')
                self.message = kwargs.get('message', '')
                self.qr_path = kwargs.get('qr_path', '')
                self.device_code = kwargs.get('device_code', '')
                self.interval = max(1, int(kwargs.get('interval', 1)))
                self.expires_in = int(kwargs.get('expires_in', 600))
                self.authenticated = False
                self.access_token = None
                self.polling = True
                self.poll_thread = None

            def onInit(self):
                try:
                    self.getControl(101).setLabel(self.header)
                    self.getControl(502).setText(self.message)
                    self.getControl(501).setImage(self.qr_path)
                    self.setFocusId(503)
                    self.poll_thread = threading.Thread(target=self._poll_for_token)
                    self.poll_thread.daemon = True
                    self.poll_thread.start()
                except Exception:
                    pass

            def _poll_for_token(self):
                try:
                    start = time.time()
                    while self.polling and (time.time() - start) < self.expires_in:
                        time.sleep(self.interval)
                        try:
                            payload = {
                                'client_id': auth.CLIENT_ID,
                                'client_secret': auth.CLIENT_SECRET,
                                'code': self.device_code,
                            }
                            result = transport.post_json(
                                paths.path('oauth', 'device_token'),
                                json_body=payload,
                                with_auth=False,
                            )
                            if isinstance(result, dict) and result.get('access_token'):
                                self.authenticated = True
                                self.access_token = result
                                self.close()
                                return
                        except Exception:
                            pass
                    if self.polling:
                        self.close()
                except Exception as exc:
                    c.log(f'[Trakt QR] polling error: {exc}', 1)

            def onAction(self, action):
                if action.getId() in (10, 92):
                    self.polling = False
                    self.close()

            def onClick(self, control_id):
                if control_id == 503:
                    self.polling = False
                    self.close()

        message = (
            f'Scan QR code with your mobile device\n\n'
            f'OR visit:\n{verification_url}\n\n'
            f'Enter code: {user_code}\n\n'
            f'Waiting for authentication...'
        )
        addon_path, skin = c.resolve_dialog_skin('LogViewer_QR.xml')
        dialog = TraktQRViewer(
            'LogViewer_QR.xml',
            addon_path,
            skin,
            '1080i',
            header='Trakt Authentication',
            message=message,
            qr_path=qr_path,
            device_code=device_code,
            interval=interval,
            expires_in=expires_in,
        )
        dialog.doModal()
        authenticated = dialog.authenticated
        token_payload = dialog.access_token
        dialog.polling = False
        del dialog
        return authenticated, token_payload
    except Exception:
        c.log(f'[Trakt] QR dialog failed:\n{traceback.format_exc()}', 1)
        return False, None


def auth_trakt():
    '''Tools  ->  Auth Trakt  -  device flow with QR dialog.'''
    try:
        if auth.has_credentials():
            if c.yesnoDialog(
                f'{c.lang(32511)}[CR]{c.lang(32512)}',
                heading='Trakt',
            ):
                auth.set_credentials('', '', '')
                c.infoDialog('Trakt account cleared', heading='Trakt', sound=True)
            return

        result = transport.post_json(
            paths.path('oauth', 'device_code'),
            json_body={'client_id': auth.CLIENT_ID},
            with_auth=False,
        )
        if not isinstance(result, dict) or not result.get('device_code'):
            c.log(f'[Trakt] device code failed: {result}', 1)
            c.infoDialog('Failed to connect to Trakt', heading='Trakt', sound=True)
            return

        verification_url = result.get('verification_url', 'https://trakt.tv/activate')
        user_code = result.get('user_code', '')
        expires_in = int(result.get('expires_in', 600))
        device_code = result.get('device_code', '')
        interval = int(result.get('interval', 5))
        activation_url = f'{verification_url.rstrip("/")}/{user_code}'
        qr_path = _qr_image_url(activation_url, size=280)

        authenticated, payload = _show_trakt_qr_dialog(
            verification_url,
            user_code,
            qr_path,
            device_code,
            interval,
            expires_in,
        )

        if not authenticated or not isinstance(payload, dict) or not payload.get('access_token'):
            c.log('[Trakt] authorization failed or timed out', 1)
            c.infoDialog('Trakt authorization failed or timed out', heading='Trakt', sound=True)
            return

        token = payload['access_token']
        refresh = payload.get('refresh_token', '')
        expires_in = int(payload.get('expires_in', 86400))
        expires_at = int(time.time()) + expires_in
        auth.set_credentials('', token, refresh, expires_at)

        user = auth.ensure_username_from_api()
        c.infoDialog(
            f'Trakt authorized{": " + user if user else ""}',
            heading='Trakt',
            sound=True,
        )
    except Exception as exc:
        c.log(f'[Trakt] authorization error: {exc}', 1)
        c.log(traceback.format_exc(), 1)
        c.infoDialog('Trakt authorization error', heading='Trakt', sound=True)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt My Movies list presets  -  one fetcher for Crew movies&url=trakt* keys.

Maps preset  ->  API path + auth/pagination/sort rules; returns discover-shaped pages
for movie_discover.directory.'''

from datetime import datetime

from ..modules.classy import c
from . import auth as trakt_auth
from . import paths as trakt_paths
from . import transport as trakt_transport

_PAGE_LIMIT = 40

# Personal lists  -  one fetch like Crew (no Kodi pagination on bogus Trakt headers).
_PERSONAL_LIST_LIMITS = {
    'traktcollection': 1000,
    'traktwatchlist': 2000,
}

# My Movies submenu  -  7 presets, 6 unique endpoints (featured == recommendations).
MY_MOVIE_PRESETS = frozenset({
    'traktcollection',
    'traktwatchlist',
    'traktfeatured',
    'traktrecommendations',
    'traktpopular',
    'traktanticipated',
    'trakthistory',
})

_PRESET_CONFIG = {
    'traktcollection': {
        'path': trakt_paths.path('users', 'collection_movies'),
        'auth': True,
        'sort_title': True,
        'allow_future_years': True,
    },
    'traktwatchlist': {
        'path': trakt_paths.path('users', 'watchlist_movies'),
        'auth': True,
        'sort_title': True,
        'allow_future_years': True,
    },
    'traktfeatured': {
        'path': trakt_paths.path('recommendations', 'movies'),
        'auth': True,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktrecommendations': {
        'path': trakt_paths.path('recommendations', 'movies'),
        'auth': True,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktpopular': {
        'path': trakt_paths.path('movies', 'popular'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': False,
    },
    'traktanticipated': {
        'path': trakt_paths.path('movies', 'anticipated'),
        'auth': False,
        'sort_title': False,
        'allow_future_years': True,
    },
    'trakthistory': {
        'path': trakt_paths.path('users', 'history_movies'),
        'auth': True,
        'sort_title': False,
        'allow_future_years': True,
    },
}


def is_my_movie_preset(preset):
    return (preset or '').strip() in MY_MOVIE_PRESETS


def preset_config(preset):
    return _PRESET_CONFIG.get((preset or '').strip())


def _current_year():
    return datetime.now().year


def _movie_payload(item):
    if not isinstance(item, dict):
        return None
    nested = item.get('movie')
    if isinstance(nested, dict):
        return nested
    if item.get('title'):
        return item
    return None


def _title_sort_key(item):
    movie = _movie_payload(item) or {}
    return str(movie.get('title') or '').casefold()


def _premiered_sort_key(item):
    movie = _movie_payload(item) or {}
    released = str(movie.get('released') or '')[:10]
    return released or '9999-12-31'


def _filter_items(items, *, allow_future_years):
    if allow_future_years:
        return items
    year_now = _current_year()
    kept = []
    for item in items:
        movie = _movie_payload(item)
        if not movie:
            continue
        year = movie.get('year')
        try:
            if int(year) > year_now:
                continue
        except (TypeError, ValueError):
            pass
        kept.append(item)
    return kept


def _total_pages(page, raw_len, pag, limit):
    '''Resolve page count  -  short responses end the list (Crew trakt_list parity).

    Trakt X-Pagination-Page-Count is unreliable on some /users/me/* endpoints
    (e.g. collection can report hundreds of pages while page 1 holds every item).
    '''
    if raw_len < limit:
        return page
    page_count = int(pag.get('page_count') or 0)
    if page_count > 0:
        return page_count
    return page + 1


def fetch_page(preset, *, page=1):
    '''Fetch one Trakt My Movies page; returns discover-shaped dict or None.'''
    preset = (preset or '').strip()
    cfg = preset_config(preset)
    if not cfg:
        return None

    page = max(1, int(page or 1))
    if cfg['auth'] and not trakt_auth.has_credentials():
        c.log(f'[TraktMovieLists] {preset} requires auth', 1)
        return None

    fetch_all = preset in _PERSONAL_LIST_LIMITS
    limit = _PERSONAL_LIST_LIMITS.get(preset, _PAGE_LIMIT)
    req_page = 1 if fetch_all else page

    data, headers, status = trakt_transport.get_json_with_meta(
        cfg['path'],
        params={
            'page': req_page,
            'limit': limit,
            'extended': 'full',
        },
        with_auth=cfg['auth'],
    )
    if status and status >= 400:
        c.log(f'[TraktMovieLists] {preset} HTTP {status}', 1)
        return None
    if not isinstance(data, list):
        return None

    items = _filter_items(data, allow_future_years=cfg['allow_future_years'])
    if preset == 'traktanticipated':
        items = sorted(items, key=_premiered_sort_key)
    elif cfg['sort_title']:
        items = sorted(items, key=_title_sort_key)

    pag = trakt_transport.parse_pagination_headers(headers)
    if fetch_all:
        total_pages = 1
    else:
        total_pages = _total_pages(req_page, len(data), pag, limit)

    return {
        'results': items,
        'page': 1 if fetch_all else (pag.get('page') or req_page),
        'total_pages': max(1, total_pages),
        '_source': 'trakt_movies',
        '_preset': preset,
    }

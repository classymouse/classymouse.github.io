# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file user_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Personal Trakt lists  -  index (/users/me/lists + liked) and list items fetcher.

Crew parity: same list names under My Movies and My TV Shows were identical;
Classy keeps a single My Movies entry. List items may be movies, shows, or mixed.'''

from urllib.parse import parse_qsl, urlparse

from ..modules.classy import c
from . import auth as trakt_auth
from . import paths as trakt_paths
from . import transport as trakt_transport

BASE = trakt_transport.BASE_URL
_LIST_ITEMS_LIMIT = 100
_OWNED_LISTS_LIMIT = 250


def is_list_items_url(url):
    '''True for Trakt .../users/{user}/lists/{slug}/items URLs.'''
    text = (url or '').strip()
    if not text.startswith('http'):
        return False
    parsed = urlparse(text)
    if 'trakt.tv' not in (parsed.netloc or '').lower():
        return False
    path = (parsed.path or '').lower().rstrip('/')
    return '/lists/' in path and path.endswith('/items')


def items_url(username, slug):
    user = (username or 'me').strip() or 'me'
    slug = (slug or '').strip()
    if not slug:
        return ''
    return f'{BASE}/users/{user}/lists/{slug}/items'


def _name_sort_key(entry):
    return str(entry.get('name') or '').casefold()


def _normalize_owned(item):
    if not isinstance(item, dict):
        return None
    name = (item.get('name') or '').strip()
    slug = ((item.get('ids') or {}).get('slug') or '').strip()
    if not name or not slug:
        return None
    return {
        'name': name,
        'username': 'me',
        'slug': slug,
        'items_url': items_url('me', slug),
    }


def _normalize_liked(item):
    if not isinstance(item, dict):
        return None
    lst = item.get('list') if isinstance(item.get('list'), dict) else item
    if not lst:
        return None
    name = (lst.get('name') or '').strip()
    slug = ((lst.get('ids') or {}).get('slug') or '').strip()
    user_obj = lst.get('user') if isinstance(lst.get('user'), dict) else {}
    username = (user_obj.get('username') or '').strip()
    if not username:
        username = str((user_obj.get('ids') or {}).get('slug') or 'me').strip()
    if not name or not slug:
        return None
    return {
        'name': name,
        'username': username,
        'slug': slug,
        'items_url': items_url(username, slug),
    }


def _fetch_owned_lists():
    out = []
    page = 1
    while page <= 20:
        data, headers, status = trakt_transport.get_json_with_meta(
            trakt_paths.path('users', 'lists'),
            params={'page': page, 'limit': _OWNED_LISTS_LIMIT},
            with_auth=True,
        )
        if status and status >= 400:
            break
        if not isinstance(data, list) or not data:
            break
        for item in data:
            row = _normalize_owned(item)
            if row:
                out.append(row)
        pag = trakt_transport.parse_pagination_headers(headers)
        page_count = int(pag.get('page_count') or 1)
        if page >= page_count or len(data) < _OWNED_LISTS_LIMIT:
            break
        page += 1
    return out


def _fetch_liked_lists():
    data = trakt_transport.get_json(
        trakt_paths.path('users', 'likes_lists'),
        params={'limit': 1000},
        with_auth=True,
    )
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        row = _normalize_liked(item)
        if row:
            out.append(row)
    return out


def fetch_index():
    '''Owned + liked lists sorted by name (Crew movieUserlists / tvUserlists).'''
    if not trakt_auth.has_credentials():
        c.log('[TraktUserLists] auth required for index', 1)
        return []

    entries = []
    try:
        entries.extend(_fetch_owned_lists())
    except Exception as exc:
        c.log(f'[TraktUserLists] owned lists failed: {exc}', 1)
    try:
        entries.extend(_fetch_liked_lists())
    except Exception as exc:
        c.log(f'[TraktUserLists] liked lists failed: {exc}', 1)

    seen = set()
    unique = []
    for entry in entries:
        key = entry.get('items_url')
        if not key or key in seen:
            continue
        seen.add(key)
        unique.append(entry)

    unique.sort(key=_name_sort_key)
    if c.is_devmode():
        names = ', '.join(e['name'] for e in unique[:12])
        suffix = '...' if len(unique) > 12 else ''
        c.log(f'[TraktUserLists] index {len(unique)} list(s): {names}{suffix}')
    return unique


def _list_path_from_url(url):
    text = (url or '').strip()
    if text.startswith('http'):
        parsed = urlparse(text)
        path = parsed.path or ''
        extra_q = dict(parse_qsl(parsed.query, keep_blank_values=True))
    else:
        path = text.split('?', 1)[0]
        q = text.split('?', 1)[1] if '?' in text else ''
        extra_q = dict(parse_qsl(q, keep_blank_values=True))
    if not path.startswith('/'):
        path = '/' + path
    return path, extra_q


def is_personal_list_url(url):
    path, _q = _list_path_from_url(url)
    return '/users/me/lists/' in path


def fetch_items_page(url, *, page=1):
    '''One page of list items; discover-shaped dict for movie_discover.'''
    if not is_list_items_url(url):
        return None

    page = max(1, int(page or 1))
    path, extra_q = _list_path_from_url(url)
    params = {
        'page': page,
        'limit': _LIST_ITEMS_LIMIT,
        'extended': 'full',
    }
    params.update({k: v for k, v in extra_q.items() if k not in params})

    # Public curated lists (Movies  ->  Trakt Lists) work without a user token.
    # Forcing auth breaks them when leftover Trakt tokens are dead under Simkl.
    need_auth = is_personal_list_url(url)
    data, headers, status = trakt_transport.get_json_with_meta(
        path, params=params, with_auth=need_auth,
    )
    if status and status >= 400:
        c.log(f'[TraktUserLists] items HTTP {status} path={path}', 1)
        return None
    if not isinstance(data, list):
        return None

    pag = trakt_transport.parse_pagination_headers(headers)
    raw_len = len(data)
    page_count = int(pag.get('page_count') or 0)
    if raw_len < _LIST_ITEMS_LIMIT:
        total_pages = page
    elif page_count > 0:
        total_pages = page_count
    else:
        total_pages = page + 1

    return {
        'results': data,
        'page': int(pag.get('page') or page),
        'total_pages': max(1, total_pages),
        '_source': 'trakt_list_items',
        '_preset': url,
        '_personal_list': is_personal_list_url(url),
    }

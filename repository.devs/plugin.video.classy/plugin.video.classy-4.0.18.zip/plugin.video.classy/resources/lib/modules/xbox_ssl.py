# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file xbox_ssl.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Xbox One UWP SSL fix  -  required for sources + play on Xbox.

On Xbox One, the UWP sandbox forbids ssl._create_unverified_context().
Scraper packs (Gears, Coco, Viper, Magneto) and urllib callers that hit
that API fail silently  ->  zero scrape results  ->  nothing to play.

3.1 applies this in client.py and imports client at startup via pack_client.
v4 keeps the same behaviour in this tiny module so default.py / service.py
can import it before anything else touches HTTPS.

Do not remove or defer this import  -  Xbox users depend on it for play.'''

import ssl

from .uwp_compat import is_xbox as _uwp_is_xbox

_IS_XBOX = False
_PATCHED = False


def is_xbox():
    return _IS_XBOX


def apply_patch():
    """Replace ssl._create_unverified_context on Xbox (idempotent)."""
    global _PATCHED
    if _PATCHED:
        return
    _PATCHED = True
    if not _IS_XBOX:
        return
    try:
        def _xbox_safe_unverified_context(*args, **kwargs):
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            try:
                import _ssl as _ssl_mod
                ctx.verify_mode = _ssl_mod.CERT_NONE
            except Exception:
                ctx.verify_mode = ssl.CERT_NONE
            return ctx

        ssl._create_unverified_context = _xbox_safe_unverified_context
    except Exception:
        pass


def ssl_context(verify=True):
    """
    SSL context for urllib HTTPSHandler (3.1 client._build_opener_and_cj).
    On Xbox, never call ssl._create_unverified_context() directly.
    """
    if not verify and not _IS_XBOX:
        return ssl._create_unverified_context()
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    try:
        import _ssl as _ssl_mod
        ctx.verify_mode = _ssl_mod.CERT_NONE
    except Exception:
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


# platform.uname() crashes on Xbox UWP (missing CreateProcess)  -  use uwp_compat.
try:
    _IS_XBOX = _uwp_is_xbox()
except Exception:
    _IS_XBOX = False

apply_patch()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file client.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy v4  -  HTTP client (dumb wire).

Transport only. Non-2xx decisions  ->  msg_handler.handle().
Do not embed Trakt/API retry rules here.'''

import gzip
import importlib.machinery
import importlib.util
import os
from io import BytesIO
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, HTTPSHandler, Request, build_opener

import xbmcaddon
import xbmcvfs

from . import http_policy
from . import msg_handler
from . import redirect_guard
from . import xbox_ssl
from .classy import c


# Xbox UWP SSL  -  see xbox_ssl.py (imported at boot from default.py / service.py).
xbox_ssl.apply_patch()


_DEFAULT_OPENER = None


def _default_opener():
    """Reuse one HTTPS opener for API calls (keep-alive, fewer DNS lookups)."""
    global _DEFAULT_OPENER
    if _DEFAULT_OPENER is None:
        _DEFAULT_OPENER = build_opener(HTTPSHandler(context=xbox_ssl.ssl_context(True)))
    return _DEFAULT_OPENER


# --- Response object -------------------------------------------------------
class HttpResponse:
    __slots__ = ('ok', 'status', 'body', 'headers', 'url', 'error', 'raw')

    def __init__(self, status=0, body='', headers=None, url='', error=None, raw=None):
        self.status = int(status or 0)
        self.body = body if body is not None else ''
        self.headers = dict(headers or {})
        self.url = url or ''
        self.error = error
        self.raw = raw
        self.ok = http_policy.is_success(self.status) and not error


# --- Paths -----------------------------------------------------------------
def addon_data_path():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def cdn_cache_dir():
    path = os.path.join(addon_data_path(), 'cdn')
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def cdn_cache_file(name):
    base = (name or '').strip()
    if base.endswith('.py'):
        base = base[:-3]
    return os.path.join(cdn_cache_dir(), f'{base}.py')


# --- Low-level fetch (urllib  -  scrapers, CDN) --------------------------------
def _read_body(response, limit_kb=None):
    try:
        if limit_kb:
            data = response.read(int(limit_kb) * 1024)
        else:
            data = response.read(5 * 1024 * 1024)
    except Exception:
        return ''
    encoding = None
    try:
        encoding = response.info().get('Content-Encoding')
    except Exception:
        encoding = getattr(response, 'headers', {}).get('Content-Encoding')
    if encoding == 'gzip' and data:
        try:
            data = gzip.GzipFile(fileobj=BytesIO(data)).read()
        except Exception:
            pass
    if isinstance(data, bytes):
        return data.decode('utf-8', errors='replace')
    return str(data)


class _DomainRedirectHandler(HTTPRedirectHandler):
    def __init__(self, allowed_domains):
        self._allowed = list(allowed_domains or [])

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not redirect_guard.redirect_target_allowed(newurl, self._allowed):
            redirect_guard.log_blocked_redirect(code, newurl, 'redirect hop blocked')
            return None
        return HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, headers, newurl)


def fetch(url, method='GET', headers=None, data=None, timeout=30, allowed_domains=None, verify=True):
    """
    Scraper/CDN fetch. Returns HttpResponse. Does not loop on msg_handler
    (use api_request for tagged API calls).
    """
    url = str(url or '')
    headers = dict(headers or {})
    if 'User-Agent' not in headers:
        headers['User-Agent'] = 'Mozilla/5.0 (Classy v4 HTTP client)'

    if allowed_domains:
        handlers = [HTTPSHandler(context=xbox_ssl.ssl_context(verify))]
        handlers.append(_DomainRedirectHandler(allowed_domains))
        opener = build_opener(*handlers)
    else:
        opener = _default_opener()

    req = Request(url, data=data, headers=headers, method=method.upper())
    try:
        resp = opener.open(req, timeout=int(timeout))
        status = getattr(resp, 'status', None) or getattr(resp, 'code', 200)
        final_url = resp.geturl() if hasattr(resp, 'geturl') else url
        if allowed_domains and not redirect_guard.redirect_target_allowed(final_url, allowed_domains):
            redirect_guard.log_blocked_redirect(status, final_url, 'final URL blocked')
            try:
                resp.close()
            except Exception:
                pass
            return HttpResponse(status=0, url=final_url, error='redirect_blocked')
        body = _read_body(resp)
        try:
            resp.close()
        except Exception:
            pass
        hdrs = dict(resp.info()) if hasattr(resp, 'info') else {}
        return HttpResponse(status=status, body=body, headers=hdrs, url=final_url)
    except HTTPError as exc:
        body = _read_body(exc)
        hdrs = dict(exc.headers) if exc.headers else {}
        return HttpResponse(status=exc.code, body=body, headers=hdrs, url=url, error=str(exc))
    except URLError as exc:
        return HttpResponse(status=0, url=url, error=str(exc.reason if exc.reason else exc))
    except Exception as exc:
        return HttpResponse(status=0, url=url, error=str(exc))


# --- API fetch (urllib + msg_handler loop) -----------------------------------
def api_request(
    api,
    url,
    method='GET',
    headers=None,
    json_body=None,
    data=None,
    timeout=30,
    retried=False,
):
    """
    Tagged API request. Non-2xx  ->  msg_handler.handle()  ->  at most one retry.
    Uses urllib (Kodi ships no standalone requests module for addons).
    """
    import json as _json

    headers = dict(headers or {})
    method = (method or 'GET').upper()
    post_data = None

    if api in (msg_handler.API_TMDB, msg_handler.API_FANART):
        http_policy.acquire_rate_limit(api)

    if json_body is not None:
        post_data = _json.dumps(json_body).encode('utf-8')
        headers.setdefault('Content-Type', 'application/json')
    elif data is not None:
        post_data = data if isinstance(data, bytes) else str(data).encode('utf-8')

    try:
        if method in ('GET', 'HEAD'):
            resp = fetch(url, method=method, headers=headers, timeout=timeout)
        elif method in ('POST', 'PUT', 'DELETE'):
            resp = fetch(url, method=method, headers=headers, data=post_data, timeout=timeout)
        else:
            resp = fetch(url, method=method, headers=headers, data=post_data, timeout=timeout)
    except Exception as exc:
        ctx = msg_handler.MessageContext(
            api=api, url=url, method=method, status=0, error=str(exc),
            headers=headers, payload=json_body, retried=retried,
        )
        action = msg_handler.handle(ctx)
        if action == msg_handler.Action.RETRY_ONCE and not retried:
            return api_request(api, url, method, headers, json_body, data, timeout, retried=True)
        return HttpResponse(status=0, url=url, error=str(exc))

    if resp.error and not resp.status:
        ctx = msg_handler.MessageContext(
            api=api, url=url, method=method, status=0, error=resp.error,
            headers=headers, payload=json_body, retried=retried,
        )
        action = msg_handler.handle(ctx)
        if action == msg_handler.Action.RETRY_ONCE and not retried:
            return api_request(api, url, method, headers, json_body, data, timeout, retried=True)
        return resp

    if resp.ok:
        return resp

    adapter = type('Resp', (), {'headers': resp.headers})()
    ctx = msg_handler.MessageContext(
        api=api,
        url=url,
        method=method,
        status=resp.status,
        response=adapter,
        headers=headers,
        payload=json_body,
        retried=retried,
    )
    action = msg_handler.handle(ctx)

    if action == msg_handler.Action.REFRESH_AUTH and not retried:
        headers = msg_handler.after_action(ctx, action, headers) or headers
        return api_request(api, url, method, headers, json_body, data, timeout, retried=True)

    if action == msg_handler.Action.RETRY_ONCE and not retried:
        return api_request(api, url, method, headers, json_body, data, timeout, retried=True)

    resp.error = resp.error or f'HTTP {resp.status}'
    return resp


# White CDN modules (crewstreamer etc.) hard-gate on Addon().getAddonInfo('id')
# == plugin.video.thecrew. Working-title Classy fails that check before search /
# resolve runs. Bridge until go-live rebrand (or White allows both ids).
_CDN_ALLOWED_ADDON_IDS = frozenset({
    'plugin.video.thecrew',
    'plugin.video.classy',
})


def _patch_cdn_addon_gate(module):
    '''Allow Classy addon id through White Crew-only CDN allowlists.'''
    if module is None or not hasattr(module, '_allowed'):
        return module
    try:
        cache = getattr(module, '_ALLOWED', None)
        if isinstance(cache, list):
            del cache[:]

        def _bridged_allowed():
            bucket = getattr(module, '_ALLOWED', None)
            if isinstance(bucket, list) and bucket:
                return bool(bucket[0])
            try:
                caller = xbmcaddon.Addon().getAddonInfo('id') or ''
            except Exception:
                caller = ''
            ok = caller in _CDN_ALLOWED_ADDON_IDS
            if isinstance(bucket, list):
                bucket.append(ok)
            if not ok:
                c.log(f'[Client] CDN blocked addon id={caller!r}', 1)
            return ok

        module._allowed = _bridged_allowed
        c.log(
            f'[Client] CDN allowlist bridged '
            f'({getattr(module, "__name__", "?")} accepts classy + thecrew)'
        )
    except Exception as exc:
        c.log(f'[Client] CDN allowlist bridge failed: {exc}', 1)
    return module


# --- CDN fetch / load --------------------------------------------------------
def cdn_fetch(uri, name):
    """
    Download remote .py to addon_data/cdn/{name}.py.
    On failure, leave existing cache in place and return path if present.
    """
    if not uri:
        return None
    cache_path = cdn_cache_file(name)
    resp = fetch(uri, timeout=45)
    if resp.ok and resp.body:
        try:
            with open(cache_path, 'w', encoding='utf-8') as handle:
                handle.write(resp.body)
            c.log(f'[Client] CDN fetch OK: {name}  ->  {cache_path}')
            return cache_path
        except Exception as exc:
            c.log(f'[Client] CDN write failed {name}: {exc}', 1)
    else:
        c.log(f'[Client] CDN fetch failed {name}: {resp.error or resp.status}', 1)

    if os.path.isfile(cache_path):
        c.log(f'[Client] CDN disk fallback: {cache_path}')
        return cache_path
    return None


def cdn_load(name):
    """Load and exec cached CDN module; returns module or None."""
    name = str(name or '').strip()
    if not name:
        return None
    path = cdn_cache_file(name)
    if not os.path.isfile(path):
        try:
            from ..lists.cdn import cdn_uri_for
            uri = cdn_uri_for(name)
        except Exception:
            uri = None
        if uri:
            path = cdn_fetch(uri, name)
    if not path or not os.path.isfile(path):
        return None
    modname = f'classy.cdn.{name}'
    loader = importlib.machinery.SourceFileLoader(modname, path)
    spec = importlib.util.spec_from_file_location(modname, path, loader=loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return _patch_cdn_addon_gate(module)


def cdn_import(uri, name):
    '''Crew control.cdnImport  -  fetch if needed, return loaded module.'''
    name = str(name or '').strip()
    if not name:
        raise FileNotFoundError('cdn_import: missing name')
    path = cdn_cache_file(name)
    if uri:
        fetched = cdn_fetch(uri, name)
        if fetched:
            path = fetched
    if not path or not os.path.isfile(path):
        raise FileNotFoundError(f'cdn_import: no cache for {name}')
    return load_source_from_path(f'classy.cdn.{name}', path)


def _cdn_resolve(name, url):
    '''
    Resolve via White CDN module. Always re-fetch like Crew control.cdnImport  - 
    stale disk cache missed host migrations (e.g. istreameast.app  ->  thestreameast.top).
    '''
    try:
        from ..lists.bridge import install_lists_ecosystem_shims
        from ..lists.cdn import cdn_uri_for

        install_lists_ecosystem_shims()
        uri = cdn_uri_for(name)
        if uri:
            module = cdn_import(uri, name)
        else:
            module = cdn_load(name)
        if module is None:
            c.log(f'[Client] CDN module unavailable: {name}')
            return None
        streamer = module.streamer()
        result = streamer.resolve(url)
        if not result:
            c.log(f'[Client] CDN {name}.resolve empty for {url!r}')
        return result
    except Exception as exc:
        c.log(f'[Client] CDN resolve failed {name} url={url!r}: {exc}', 1)
        return None


def external(url):
    return _cdn_resolve('crewstreamer', url)


def schedule(url):
    result = _cdn_resolve('crewschedule', url)
    if not result:
        c.log(f'[Client] schedule empty for {url!r}')
    return result


def replays(url):
    return _cdn_resolve('crewreplays', url)


def load_source_from_path(modname, filename):
    loader = importlib.machinery.SourceFileLoader(modname, filename)
    spec = importlib.util.spec_from_file_location(modname, filename, loader=loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return _patch_cdn_addon_gate(module)


# Crew-compatible scraper API (request, parseDom, agent, ...)
from .scraper_client import (  # noqa: E402
    agent,
    parseDOM,
    parseDom,
    randomagent,
    randommobileagent,
    replaceHTMLCodes,
    request,
)

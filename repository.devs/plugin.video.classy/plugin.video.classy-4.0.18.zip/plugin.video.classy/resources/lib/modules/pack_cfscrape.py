# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file pack_cfscrape.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Expose pack cfscrape modules (Cloudflare) to scrapers and the HTTP client.'''

import os
import sys

from .crewruntime import c

_CFSCRAPE = None
_INSTALLED = False

_PACK_CFSCRAPE_MODULES = (
    'cfscrape',
    'classyscrapers.modules.cfscrape',
    'cocoscrapers.modules.cfscrape',
    'gearsscrapers.modules.cfscrape',
    'viperscrapers.modules.cfscrape',
    'magneto.modules.cfscrape',
)


def _find_addons_dir():
    import os
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(10):
        if os.path.basename(cur).lower() == 'addons':
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None


def _import_cfscrape():
    global _CFSCRAPE
    if _CFSCRAPE is not None:
        return _CFSCRAPE

    addons_dir = _find_addons_dir()
    candidates = []
    if addons_dir:
        # Prefer first-party Classy Scrapers on Classy-only installs (no Crew module).
        candidates.extend([
            os.path.join(addons_dir, 'script.module.classyscrapers', 'lib'),
            os.path.join(addons_dir, 'script.module.gearsscrapers', 'lib'),
            os.path.join(addons_dir, 'script.module.cocoscrapers', 'lib'),
            os.path.join(addons_dir, 'script.module.magneto', 'lib'),
            os.path.join(addons_dir, 'script.module.thecrew', 'lib', 'resources', 'lib', 'modules'),
        ])

    last_exc = None
    mod_names = (
        'classyscrapers.modules.cfscrape',
        'gearsscrapers.modules.cfscrape',
        'cocoscrapers.modules.cfscrape',
        'magneto.modules.cfscrape',
        'cfscrape',
    )
    for lib_dir in candidates:
        if not os.path.isdir(lib_dir):
            continue
        if lib_dir not in sys.path:
            sys.path.insert(0, lib_dir)
        for mod_name in mod_names:
            try:
                mod = __import__(mod_name, fromlist=['cfscrape'])
                _CFSCRAPE = mod
                return _CFSCRAPE
            except Exception as exc:
                last_exc = exc
                continue

    if last_exc and getattr(c, 'devmode', False):
        c.log(f'[PackClient] cfscrape import failed: {last_exc}', 1)
    return None


def get_cfscrape():
    return _import_cfscrape()


def install_pack_cfscrape_shims(force=False):
    global _INSTALLED
    if _INSTALLED and not force:
        return get_cfscrape()

    mod = _import_cfscrape()
    if not mod:
        return None

    for name in _PACK_CFSCRAPE_MODULES:
        sys.modules[name] = mod
    _INSTALLED = True
    try:
        c.log('[Sources] Pack cfscrape shims installed')
    except Exception:
        pass
    return mod

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debrid.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Debrid via ResolveURL  -  tokens read from script.module.resolveurl settings.'''

import os
import re
import sys
import time
import traceback

import xbmcaddon
import xbmcgui

from .classy import c

_RESOLVEURL = None
_RESOLVEURL_ADDON = None

_DEBRID_PAIRS = (
    ('RealDebridResolver_enabled', 'RealDebridResolver_token'),
    ('AllDebridResolver_enabled', 'AllDebridResolver_token'),
    ('PremiumizeMeResolver_enabled', 'PremiumizeMeResolver_token'),
    ('TorBoxResolver_enabled', 'TorBoxResolver_apikey'),
)

_torbox_resolve_blocked_until = 0.0
TORBOX_RESOLVE_BACKOFF = 120


def is_torbox_resolve_blocked():
    return time.time() < _torbox_resolve_blocked_until


def mark_torbox_resolve_failed(reason='timeout'):
    global _torbox_resolve_blocked_until
    _torbox_resolve_blocked_until = time.time() + TORBOX_RESOLVE_BACKOFF
    c.log(f'[Debrid] TorBox resolve backoff {TORBOX_RESOLVE_BACKOFF}s ({reason})')


def _extract_magnet_hash(url):
    if not url:
        return None
    match = re.search(r'btih:([a-fA-F0-9]{40})', url, re.I)
    return match.group(1).lower() if match else None


def _torbox_cached_only_setting():
    try:
        return _resolveurl_addon().getSetting('TorBoxResolver_cached_only') == 'true'
    except Exception:
        return False


def _should_skip_torbox_resolve(url, debrid):
    '''Fast-fail uncached TB rows when ResolveURL cached-only is on (Crew parity).'''
    from . import debrid_names

    if not debrid_names.is_torbox(debrid):
        return False
    if is_torbox_resolve_blocked():
        c.log('[Debrid] TorBox skipped  -  session backoff after prior timeout/failure')
        return True
    if not _torbox_cached_only_setting():
        return False
    info_hash = _extract_magnet_hash(url)
    if not info_hash:
        return False
    try:
        from .debridcheck import torbox_hash_is_cached

        if torbox_hash_is_cached(info_hash, timeout=8):
            return False
        c.log(f'[Debrid] TorBox cached-only: {info_hash[:8]}... not cached  -  skipping')
        return True
    except Exception as exc:
        c.log(f'[Debrid] TorBox cache pre-check failed: {exc}', 1)
        return False


def _load_resolveurl():
    global _RESOLVEURL, _RESOLVEURL_ADDON
    if _RESOLVEURL is not None:
        return _RESOLVEURL
    try:
        _RESOLVEURL_ADDON = xbmcaddon.Addon('script.module.resolveurl')
        lib_path = os.path.join(_RESOLVEURL_ADDON.getAddonInfo('path'), 'lib')
        if lib_path not in sys.path:
            sys.path.insert(0, lib_path)
        import resolveurl
        _RESOLVEURL = resolveurl
        return resolveurl
    except Exception as exc:
        c.log(f'[Debrid] failed to load resolveurl: {exc}', 1)
        if c.devmode:
            c.log(traceback.format_exc(), 1)
        return None


def _resolveurl_addon():
    if _RESOLVEURL_ADDON is None:
        _load_resolveurl()
    return _RESOLVEURL_ADDON


def _normalize_resolver_name(name):
    return re.sub(r'[^a-z0-9]+', '', str(name or '').lower())


def get_debrid_resolvers():
    ru = _load_resolveurl()
    if not ru:
        return []
    try:
        return [r() for r in ru.relevant_resolvers(order_matters=True) if r.isUniversal()]
    except Exception as exc:
        c.log(f'[Debrid] get_debrid_resolvers failed: {exc}', 1)
        return []


def status(torrent=False):
    try:
        r_url = _resolveurl_addon()
        if not r_url:
            return False
        enabled = any(
            r_url.getSetting(enabled_key) == 'true' and r_url.getSetting(token_key)
            for enabled_key, token_key in _DEBRID_PAIRS
        )
    except Exception:
        enabled = bool(get_debrid_resolvers())
    if not enabled:
        return False
    if torrent:
        torrent_setting = c.get_setting('torrent.enabled')
        if torrent_setting and torrent_setting.lower() == 'false':
            return False
    return True


def resolver(url, debrid, season=None, episode=None):
    if not url or not debrid:
        return None
    if _should_skip_torbox_resolve(url, debrid):
        return None
    try:
        from . import debrid_names

        c.log(f'[Debrid] resolver {debrid} url={str(url)[:80]}... season={season} episode={episode}')

        # Magnet + S/E: pick the matching pack file ourselves (Crew parity).
        # ResolveURL alone often returns the wrong episode from multi-file packs.
        if (
            str(url).startswith('magnet:')
            and season is not None
            and episode is not None
            and debrid_names.is_pack_service(debrid)
        ):
            from .debrid_pack import resolve_pack

            c.log(
                f'[Debrid] Pack source  -  S{int(season):02d}E{int(episode):02d} '
                f'via {debrid_names.canonical(debrid)}'
            )
            pack_url = resolve_pack(
                url,
                debrid_names.canonical(debrid),
                season,
                episode,
            )
            if pack_url:
                c.log('[Debrid] Pack resolution successful')
                return pack_url
            # Do NOT fall through to ResolveURL  -  it has no reliable S/E pick
            # and will play whatever file RD last selected (often wrong episode).
            c.log(
                '[Debrid] Pack resolution failed  -  skipping ResolveURL fallback '
                'to avoid wrong episode',
                1,
            )
            return None

        target = _normalize_resolver_name(debrid)
        matching = [
            r for r in get_debrid_resolvers()
            if _normalize_resolver_name(getattr(r, 'name', '')) == target
        ]
        if not matching:
            c.log(f'[Debrid] no resolver for {debrid}', 1)
            return None

        debrid_resolver = matching[0]
        debrid_resolver.login()
        host, media_id = debrid_resolver.get_host_and_id(url)
        try:
            return debrid_resolver.get_media_url(host, media_id, season=season, episode=episode)
        except TypeError:
            return debrid_resolver.get_media_url(host, media_id)
    except Exception as exc:
        from . import debrid_names

        if debrid_names.is_torbox(debrid):
            mark_torbox_resolve_failed(str(exc)[:80])
        c.log(f'[Debrid] {debrid} resolve failed: {exc}', 1)
        if c.devmode:
            c.log(traceback.format_exc(), 1)
        return None


def _resolver_accepts_url(resolver_obj, url):
    try:
        if url.startswith('magnet:'):
            if resolver_obj.valid_url(url, ''):
                return True
            if resolver_obj.valid_url(url, None):
                return True
            return resolver_obj.valid_url(url, 'magnet')
        host, _media_id = resolver_obj.get_host_and_id(url)
        return resolver_obj.valid_url(url, host or '')
    except Exception:
        return url.startswith('magnet:')


def resolve_for_play(url, season=None, episode=None, quiet=False, debrid=None):
    if not url:
        return None
    if not status(torrent=url.startswith('magnet:')):
        c.log('[Debrid] resolve_for_play: no enabled debrid in ResolveURL', 1)
        return None

    ru = _load_resolveurl()
    if not ru:
        c.log('[Debrid] resolveurl not available  -  add script.module.resolveurl', 1)
        return None

    from . import debrid_names

    tagged = debrid_names.canonical(debrid) if debrid else ''
    c.log(
        f'[Debrid] resolve_for_play start url={str(url)[:80]}... '
        f'debrid={tagged or "auto"} resolvers={len(get_debrid_resolvers())}'
    )

    progress = None
    if not quiet:
        try:
            progress = xbmcgui.DialogProgress()
            progress.create(c.addon_id, 'Resolving debrid link...')
            progress.update(0, 'Contacting debrid services...')
        except Exception:
            progress = None

    def _cancelled():
        try:
            return bool(progress and progress.iscanceled())
        except Exception:
            return False

    try:
        season_val = int(season) if season not in (None, '') else None
    except (TypeError, ValueError):
        season_val = None
    try:
        episode_val = int(episode) if episode not in (None, '') else None
    except (TypeError, ValueError):
        episode_val = None

    is_pack_request = bool(
        str(url).startswith('magnet:')
        and season_val is not None
        and episode_val is not None
    )

    try:
        if tagged:
            if _cancelled():
                return None
            if progress:
                try:
                    progress.update(0, f'Trying {tagged}...')
                except Exception:
                    pass
            stream = resolver(url, tagged, season=season_val, episode=episode_val)
            if stream:
                c.log(f'[Debrid] resolved via tagged {tagged}: {str(stream)[:120]}...')
                return stream
            # Tagged pack service already refused ResolveURL fallback inside resolver().
            if is_pack_request and debrid_names.is_pack_service(tagged):
                c.log(
                    f'[Debrid] tagged pack resolve failed for {tagged}  -  '
                    'not falling through (wrong-episode guard)',
                    1,
                )
                return None

        for resolver_obj in get_debrid_resolvers():
            if _cancelled():
                c.log('[Debrid] resolve cancelled by user')
                return None
            name = getattr(resolver_obj, 'name', '') or 'Debrid'
            if tagged and _normalize_resolver_name(name) == _normalize_resolver_name(tagged):
                continue
            if not _resolver_accepts_url(resolver_obj, url):
                c.log(f'[Debrid] skip {name} (valid_url=False)', 2)
                continue
            if progress:
                try:
                    progress.update(0, f'Trying {name}...')
                except Exception:
                    pass
            stream = resolver(url, name, season=season_val, episode=episode_val)
            if stream:
                c.log(f'[Debrid] resolved via {name}: {str(stream)[:120]}...')
                return stream
            if is_pack_request and debrid_names.is_pack_service(name):
                # Pack path returned None  -  try next debrid, never ResolveURL.
                continue

        if _cancelled():
            c.log('[Debrid] resolve cancelled by user')
            return None

        # Magnets with S/E must not use blind ResolveURL resolve (wrong pack file).
        if is_pack_request:
            c.log(
                '[Debrid] all pack-aware resolvers exhausted  -  '
                'skipping resolveurl.resolve to avoid wrong episode',
                1,
            )
            return None

        if progress:
            try:
                progress.update(0, 'Resolving via ResolveURL...')
            except Exception:
                pass
        try:
            stream = ru.resolve(url)
            if stream and stream is not False:
                c.log(f'[Debrid] resolveurl.resolve OK: {str(stream)[:120]}...')
                return stream
            c.log('[Debrid] resolveurl.resolve returned no link', 1)
        except Exception as exc:
            c.log(f'[Debrid] resolveurl.resolve failed: {exc}', 1)

        c.log('[Debrid] all resolvers exhausted  -  no playable link', 1)
        return None
    finally:
        if progress:
            try:
                progress.close()
            except Exception:
                pass

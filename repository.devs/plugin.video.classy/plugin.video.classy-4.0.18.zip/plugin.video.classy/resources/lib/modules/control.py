# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file control.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Control shim  -  Crew-shaped API for scrapers, debrid, XML/CDN lists, cache.

Interim: infoLabel maps Container.PluginName to plugin.video.thecrew while the
addon id is still plugin.video.classy. Remove that bridge at rebrand.'''

import os
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .classy import c

# Upstream XML/CDN guards  -  delete at rebrand (4.0-BASELINE checklist).
_LEGACY_PLUGIN_ID = 'plugin.video.thecrew'

homeWindow = xbmcgui.Window(10000)
window = homeWindow  # Crew-shaped alias (TV Evening session props, etc.)
progressDialog = xbmcgui.DialogProgress()
progressDialogBG = xbmcgui.DialogProgressBG()
execute = xbmc.executebuiltin
dialog = xbmcgui.Dialog()

dataPath = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
transPath = xbmcvfs.translatePath
openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdirs
deleteFile = xbmcvfs.delete
deleteDir = xbmcvfs.rmdir
listDir = xbmcvfs.listdir


def _path(filename):
    return os.path.join(dataPath, filename)


cacheFile = _path('cache.db')
metacacheFile = _path('meta.cache')
providercacheFile = _path('providers.db')
dbFile = _path('debrid.cache')
searchFile = _path('search.db')
viewsFile = _path('views.db')
bookmarksFile = _path('bookmarks.db')

condVisibility = xbmc.getCondVisibility
skin = xbmc.getSkinDir()
monitor = xbmc.Monitor()


def setting(setting_id):
    return c.get_setting(setting_id) or ''


def setSetting(setting_id, value):
    return c.set_setting(setting_id, value)


def addon(addon_id):
    return xbmcaddon.Addon(addon_id)


def addonInfo(key):
    return xbmcaddon.Addon().getAddonInfo(key)


def lang(string_id):
    return c.lang(string_id)


def log(msg, trace=0):
    return c.log(msg, trace)


def infoLabel(key):
    value = xbmc.getInfoLabel(key)
    if key == 'Container.PluginName':
        if value == c.addon_id:
            return _LEGACY_PLUGIN_ID
        # Regex resolve / play callbacks often have no container  -  CDN guards need thecrew id.
        if not value:
            return _LEGACY_PLUGIN_ID
    return value


def infoDialog(message, heading=None, icon='', time=3000, sound=False):
    return c.infoDialog(message, heading=heading or c.addon_id, icon=icon, time=time, sound=sound)


def okDialog(message, heading=None):
    return dialog.ok(heading or c.addon_id, message)


def yesnoDialog(message, heading=None, nolabel='', yeslabel='', defaultbutton=None):
    return c.yesnoDialog(
        message,
        heading=heading,
        nolabel=nolabel,
        yeslabel=yeslabel,
        defaultbutton=defaultbutton,
    )


def selectDialog(item_list, heading=None, useDetails=False):
    del useDetails
    return dialog.select(heading or c.addon_id, item_list)


def busy():
    execute('ActivateWindow(busydialognocancel)')


def idle():
    execute('Dialog.Close(busydialognocancel)')


def six_decode(data, char='utf-8', errors='replace'):
    return c.to_str(data, encoding=char, errors=errors)


def six_encode(data, char='utf-8', errors='replace'):
    return c.to_bytes(data, encoding=char, errors=errors)


def cdnImport(uri, name):
    '''Load CDN resolver module  -  Crew-compatible entry for XML pyFunctions.'''
    from . import client
    return client.cdn_import(uri, name)


def sleep(ms):
    while ms > 0 and not monitor.abortRequested():
        xbmc.sleep(min(100, ms))
        ms -= 100


def getCurrentViewId():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return str(win.getFocusId())


def close_directory(handle=None, content_type=None, cacheToDisc=False, succeeded=True):
    idle()
    if handle is None:
        try:
            handle = int(sys.argv[1])
        except (IndexError, ValueError, TypeError):
            return False
    if content_type is not None:
        try:
            from . import kodi
            kodi.content(handle, content_type)
        except Exception:
            pass
    try:
        from . import kodi
        kodi.directory(handle, cacheToDisc=cacheToDisc, succeeded=succeeded)
    except TypeError:
        from . import kodi
        kodi.directory(handle, cacheToDisc=cacheToDisc)
    return True


def finish_dialog_route():
    '''End a dialog-only plugin route so Cursor.busy() does not stick.'''
    return close_directory(cacheToDisc=False)


def schedule_busy_dismiss(delays=(0.5, 2.0, 5.0)):
    '''Clear busy spinners after modal dialogs (Kodi 21 may re-show them on dismiss).'''

    def _worker():
        for delay in delays:
            time.sleep(delay)
            try:
                idle()
            except Exception:
                pass

    threading.Thread(target=_worker, name='ClassyBusyDismiss', daemon=True).start()

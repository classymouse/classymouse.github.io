# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file utils.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Minimal utils for cache key hashing.'''

def traverse(args):
    return args

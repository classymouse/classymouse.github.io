# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resolveurl_backup.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

ResolveURL settings.xml.backup / .bak vs intentional debrid clear (B1).

ResolveURL / Debrid Manager / wizard can empty live tokens without telling
Classy. We do not poll or watch that file. Instead:

  - boot reconcile: live empty  ->  scrub matching secret keys in backup+bak;
    live non-empty  ->  copy those keys into backup+bak (keeps shadows current
    after reauth without a watcher).
  - DebridAccountWorker wake (boot+20s / clear / auth / 12h safety): same
    reconcile again  -  catches mid-session ResolveURL clears without a
    dedicated backup poller.
  - Classy-owned clear (Tools): call scrub_provider() immediately.

Disaster recovery still uses backup only when live is corrupt/missing  -
never to resurrect an intentional empty live token.

B1 restore-path inventory (2026-11-15):
  ACTIVE risk (handled here): ResolveURL addon_data settings.xml.backup
    and settings.xml.bak (ResolveURL may keep both).
  NOT a Classy rehydrate path today: Classy addon_data has settings.xml
    only (no Classy settings_repair / health_backup_* / .bak restore on boot).
  STUB (no restore yet): classywizard keep-data menu  -  no rehydrate risk
    until implemented; when built, must never copy debrid tokens over an
    intentional empty live ResolveURL/Classy clear.
  OUT OF SCOPE here: Crew module settings_repair (plugin.video.thecrew /
    script.module.thecrew); thecrew_settings_backup used only by
    os_creds_import for OpenSubtitles ids (not debrid).
  LATER: Classy whole-file disaster restore (corpse/unparseable only);
    cloud browse.
'''

from __future__ import annotations

import os
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcvfs

from .classy import c

_RESOLVEURL_ID = 'script.module.resolveurl'

# Secret / auth keys only  -  never touch enabled/priority/cached_only.
_PROVIDER_KEYS = {
    'alldebrid': (
        'AllDebridResolver_auth',
        'AllDebridResolver_token',
    ),
    'premiumize': (
        'PremiumizeMeResolver_auth',
        'PremiumizeMeResolver_token',
    ),
    'realdebrid': (
        'RealDebridResolver_auth',
        'RealDebridResolver_token',
        'RealDebridResolver_refresh',
        'RealDebridResolver_client_id',
        'RealDebridResolver_client_secret',
    ),
    'torbox': (
        'TorBoxResolver_auth',
        'TorBoxResolver_user',
        'TorBoxResolver_apikey',
    ),
}

# Primary "is authorised?" key per provider (empty  =>  treat as cleared).
_PROVIDER_PRIMARY = {
    'alldebrid': 'AllDebridResolver_token',
    'premiumize': 'PremiumizeMeResolver_token',
    'realdebrid': 'RealDebridResolver_token',
    'torbox': 'TorBoxResolver_apikey',
}


def _profile_dir():
    try:
        if not xbmc.getCondVisibility(f'System.HasAddon({_RESOLVEURL_ID})'):
            return ''
        profile = xbmcaddon.Addon(_RESOLVEURL_ID).getAddonInfo('profile')
        return xbmcvfs.translatePath(profile) if profile else ''
    except Exception:
        return ''


def _live_path():
    root = _profile_dir()
    return os.path.join(root, 'settings.xml') if root else ''


def _backup_path():
    root = _profile_dir()
    return os.path.join(root, 'settings.xml.backup') if root else ''


def _bak_path():
    root = _profile_dir()
    return os.path.join(root, 'settings.xml.bak') if root else ''


def _shadow_paths():
    '''ResolveURL shadow copies that can resurrect cleared tokens.'''
    return [p for p in (_backup_path(), _bak_path()) if p]


def _read_xml(path):
    if not path or not xbmcvfs.exists(path):
        return None, ''
    try:
        raw = c.to_str(xbmcvfs.File(path, 'r').read())
    except Exception:
        return None, ''
    if not (raw or '').strip():
        return None, ''
    parse_src = raw
    if not parse_src.lstrip().startswith('<?xml'):
        parse_src = '<?xml version="1.0" encoding="utf-8"?>\n' + parse_src
    try:
        return ET.fromstring(parse_src), raw
    except ET.ParseError:
        return None, raw


def _setting_map(root):
    out = {}
    if root is None:
        return out
    for el in root:
        if el.tag != 'setting':
            continue
        sid = el.get('id') or ''
        if not sid:
            continue
        out[sid] = (el.text or '').strip()
    return out


def _setting_line(setting):
    attrs = dict(setting.attrib)
    text = setting.text or ''
    if text.strip():
        attrs.pop('default', None)
    else:
        attrs['default'] = 'true'
    attrs_str = ''.join(f' {k}="{v}"' for k, v in sorted(attrs.items()))
    if text.strip():
        escaped = (
            text.replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
        )
        return f'    <setting{attrs_str}>{escaped}</setting>'
    return f'    <setting{attrs_str} />'


def _write_root(path, root):
    lines = ['<settings version="2">']
    for el in root:
        if el.tag == 'setting':
            lines.append(_setting_line(el))
    lines.append('</settings>')
    body = '\n'.join(lines) + '\n'
    try:
        handle = xbmcvfs.File(path, 'w')
        handle.write(body)
        handle.close()
        return True
    except Exception as exc:
        c.log(f'[ResolveURL backup] write failed {path}: {exc}', 1)
        return False


def _set_keys(root, values):
    '''Apply id->text on settings elements. Empty text  =>  default="true" empty.'''
    changed = False
    by_id = {}
    for el in root:
        if el.tag == 'setting' and el.get('id'):
            by_id[el.get('id')] = el
    for sid, text in values.items():
        el = by_id.get(sid)
        if el is None:
            continue
        new_text = '' if text is None else str(text)
        old = el.text or ''
        if (old or '') == new_text:
            if not new_text.strip() and el.get('default') == 'true':
                continue
            if new_text.strip() and el.get('default') is None:
                continue
        el.text = new_text if new_text.strip() else None
        if new_text.strip():
            if 'default' in el.attrib:
                del el.attrib['default']
        else:
            el.set('default', 'true')
            el.text = None
        changed = True
    return changed


def scrub_provider(provider, *, log_label='tools'):
    '''Classy-owned clear: empty this provider's secret keys in ResolveURL shadows.'''
    key = str(provider or '').strip().lower()
    ids = _PROVIDER_KEYS.get(key)
    if not ids:
        return 0
    empties = {sid: '' for sid in ids}
    total = 0
    for path in _shadow_paths():
        root, _raw = _read_xml(path)
        if root is None:
            continue
        if not _set_keys(root, empties):
            continue
        if not _write_root(path, root):
            continue
        total += len(ids)
        c.log(
            f'[ResolveURL backup] scrubbed {key} ({len(ids)} key(s)) in '
            f'{os.path.basename(path)} after {log_label}'
        )
    return total


def _reconcile_one_shadow(live, shadow_root, shadow_path, *, log_label='boot'):
    '''Apply live empty/scrub or live sync patch onto one shadow file.'''
    shadow = _setting_map(shadow_root)
    patch = {}
    scrubbed = []
    synced = []

    for provider, ids in _PROVIDER_KEYS.items():
        primary = _PROVIDER_PRIMARY[provider]
        live_primary = (live.get(primary) or '').strip()
        if not live_primary:
            # Intentional clear (or never auth)  -  do not leave corpse in shadow.
            for sid in ids:
                if (shadow.get(sid) or '').strip():
                    patch[sid] = ''
                    if provider not in scrubbed:
                        scrubbed.append(provider)
        else:
            for sid in ids:
                live_val = live.get(sid) or ''
                if (shadow.get(sid) or '') != live_val:
                    patch[sid] = live_val
                    if provider not in synced:
                        synced.append(provider)

    if not patch:
        return 0
    if not _set_keys(shadow_root, patch):
        return 0
    if not _write_root(shadow_path, shadow_root):
        return 0

    bits = []
    if scrubbed:
        bits.append('scrubbed=' + ','.join(scrubbed))
    if synced:
        bits.append('synced=' + ','.join(synced))
    c.log(
        f'[ResolveURL backup] reconcile ({log_label}) '
        f'{os.path.basename(shadow_path)}: '
        + ('; '.join(bits) if bits else 'noop')
    )
    return len(patch)


def reconcile_backup_with_live(*, log_label='boot'):
    '''
    Boot / explicit reconcile  -  no file watcher.

    For each debrid provider, on each existing shadow (.backup and .bak):
      live primary empty  ->  scrub those keys in the shadow
      live primary set    ->  copy live secret keys into the shadow
    '''
    live_path = _live_path()
    live_root, _ = _read_xml(live_path)
    if live_root is None:
        return 0

    live = _setting_map(live_root)
    total = 0
    for path in _shadow_paths():
        shadow_root, _ = _read_xml(path)
        if shadow_root is None:
            continue
        total += _reconcile_one_shadow(
            live, shadow_root, path, log_label=log_label
        )
    return total

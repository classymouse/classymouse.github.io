# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file kodi.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import sys
import time

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

from .classy import c


execute = xbmc.executebuiltin
idle = execute('Dialog.Close(busydialognocancel)')

item = xbmcgui.ListItem
addItem = xbmcplugin.addDirectoryItem
addItems = xbmcplugin.addDirectoryItems
content = xbmcplugin.setContent
directory = xbmcplugin.endOfDirectory

setproperty = xbmcplugin.setProperty

# Home progress widgets  -  service-safe lifecycle (thecrew.* props).
WIDGET_ACTIVE_PROP = 'thecrew.widget.active'
WIDGET_ACTIVE_TS_PROP = 'thecrew.widget.active_ts'
WIDGET_WARM_PENDING_PROP = 'thecrew.widget.warm_pending'
WIDGET_WARM_REASON_PROP = 'thecrew.widget.warm_reason'
WIDGET_WARM_FORCE_PROP = 'thecrew.widget.warm_force'
WIDGET_ACTIVE_TTL_SEC = 3600


def _home_window():
    return xbmcgui.Window(10000)


def touch_widget_active():
    '''Heartbeat when a home-screen widget list is built (plugin GetDirectory).'''
    try:
        win = _home_window()
        win.setProperty(WIDGET_ACTIVE_PROP, '1')
        win.setProperty(WIDGET_ACTIVE_TS_PROP, str(time.time()))
    except Exception:
        pass


def in_widget(*, max_age_sec=WIDGET_ACTIVE_TTL_SEC):
    '''
    True when serving or recently served a home widget list.

    Plugin thread: current sys.argv may qualify via is_widget_listing().
    Service thread: uses thecrew.widget.active heartbeat (no sys.argv).
    '''
    try:
        if is_widget_listing():
            return True
    except Exception:
        pass
    try:
        win = _home_window()
        if win.getProperty(WIDGET_ACTIVE_PROP) != '1':
            return False
        if max_age_sec is None or max_age_sec <= 0:
            return True
        ts = float(win.getProperty(WIDGET_ACTIVE_TS_PROP) or 0)
        if not ts:
            return True
        return (time.time() - ts) <= float(max_age_sec)
    except Exception:
        return False


def set_widget_warm_pending(reason=''):
    try:
        win = _home_window()
        win.setProperty(WIDGET_WARM_PENDING_PROP, '1')
        if reason:
            win.setProperty(WIDGET_WARM_REASON_PROP, str(reason)[:120])
    except Exception:
        pass


def widget_warm_pending():
    try:
        return _home_window().getProperty(WIDGET_WARM_PENDING_PROP) == '1'
    except Exception:
        return False


def widget_warm_reason():
    try:
        return _home_window().getProperty(WIDGET_WARM_REASON_PROP) or ''
    except Exception:
        return ''


def clear_widget_warm_pending():
    try:
        win = _home_window()
        win.clearProperty(WIDGET_WARM_PENDING_PROP)
        win.clearProperty(WIDGET_WARM_REASON_PROP)
    except Exception:
        pass


def request_widget_warm_force():
    '''Skip worker interval  -  service picks this up on next monitor poll.'''
    try:
        _home_window().setProperty(WIDGET_WARM_FORCE_PROP, str(time.time()))
    except Exception:
        pass


def consume_widget_warm_force():
    try:
        win = _home_window()
        raw = win.getProperty(WIDGET_WARM_FORCE_PROP) or ''
        if not raw:
            return False
        win.clearProperty(WIDGET_WARM_FORCE_PROP)
        return True
    except Exception:
        return False


def get_widget_refresh_url():
  try:
    if len(sys.argv) > 2:
      return sys.argv[0] + sys.argv[2]
  except Exception:
    pass
  return ''


def schedule_widget_refresh(refresh_url=None):
  '''Ask the service thread to Container.Refresh after widget_rows warm.'''
  try:
    win = xbmcgui.Window(10000)
    if refresh_url is None:
      refresh_url = get_widget_refresh_url()
    win.setProperty('classy.widget.needs_refresh', '1')
    if refresh_url:
      win.setProperty('classy.widget.refresh_url', refresh_url)
  except Exception:
    pass


def maybe_refresh_widgets():
  '''Service-thread helper  -  run Container.Refresh once when requested.'''
  try:
    from .service_state import shutdown_requested
    if shutdown_requested():
      return False
    win = xbmcgui.Window(10000)
    if win.getProperty('classy.widget.needs_refresh') != '1':
      return False
    win.clearProperty('classy.widget.needs_refresh')
    url = win.getProperty('classy.widget.refresh_url') or ''
    win.clearProperty('classy.widget.refresh_url')
    if url:
      execute(f'Container.Refresh({url})')
      return True
  except Exception:
    pass
  return False


def is_widget_listing():
    '''True when Kodi invoked us as a home-screen widget (not in-addon browse).'''
    try:
        if len(sys.argv) > 2:
            query = sys.argv[2].lower()
            if 'widget=true' in query or 'reload=' in query:
                return True
    except Exception:
        pass
    # Shield / Android: Container.PluginName is often empty on Next Page while
    # sys.argv still points at this plugin. Treating that as a widget forced page=1
    # and broke Genres (and any discover) pagination. Trust plugin:// argv first.
    try:
        argv0 = (sys.argv[0] or '').lower()
        addon_id = (c.addon_id or '').lower()
        if argv0.startswith('plugin://') and addon_id and addon_id in argv0:
            return False
    except Exception:
        pass
    plugin_name = xbmc.getInfoLabel('Container.PluginName') or ''
    if not plugin_name:
        return True
    return 'plugin' not in plugin_name


def open_settings(query='', _id=c.addon_id):
    '''Open addon settings; optional query 'category.field' (0-based).

    Control IDs: Nexus/Matrix use START_BUTTONS=-100 / START_CONTROL=-80;
    Omega (Kodi 21+) uses -200 / -180. Addon.OpenSettings blocks until the
    dialog closes, so focus is applied from a short-lived thread while open.
    '''
    try:
        execute('Dialog.Close(busydialognocancel)')
    except Exception:
        pass

    cat_focus = None
    field_focus = None
    if query:
        try:
            e, f = query.split('.')
            # GUIDialogSettingsBase.h offsets
            if int(getattr(c, 'int_kodiversion', 0) or 0) > 20:
                cat_focus = int(e) - 200
                field_focus = int(f) - 180
            else:
                cat_focus = int(e) - 100
                field_focus = int(f) - 80
        except Exception:
            cat_focus = field_focus = None

    if cat_focus is not None:
        import threading

        def _focus_while_open():
            try:
                for _ in range(40):
                    if xbmc.getCondVisibility('Window.IsActive(addonsettings)'):
                        break
                    xbmc.sleep(50)
                xbmc.sleep(100)
                execute('SetFocus(%i)' % cat_focus)
                xbmc.sleep(50)
                if field_focus is not None:
                    execute('SetFocus(%i)' % field_focus)
            except Exception:
                pass

        threading.Thread(
            target=_focus_while_open,
            name='ClassySettingsFocus',
            daemon=True,
        ).start()

    try:
        execute('Addon.OpenSettings(%s)' % _id)
    except Exception:
        return

def notification(title, message, icon=None, time=3000):
    if title == 'default' or title is None:
        title = c.name
    if isinstance(title, int):
        title = c.lang(title)
    if icon is None:
        icon = c.icon
    xbmcgui.Dialog().notification(title, message, icon, time)

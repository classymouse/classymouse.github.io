# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file brand_gate.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Boot-time addon-id identity gate.

Compares sha256(salt + live_addon_id) to a baked allowlist of digests.
Never stores the expected ids in clear for the compare path.

Transition allowlist (two slots):
  - working-title package id (current tree)
  - go-live package id (rebrand cutover)

A branded fork (e.g. Homelander) replaces both slots with its own digest.'''

from __future__ import annotations

import hashlib

import xbmcaddon

from . import control
from .classy import c

# Internal gate  -  do not modify without regenerating digests.
_SALT = b'tc_brand_id_v1'
_K = b'tc_brand' + b'id_v1'

# XOR'd sha256 digests (salt + addon_id). Slot order: working-title, go-live.
_GATES = (
    bytes([
        117, 240, 248, 183, 139,  68, 112, 166,
        177,  56,  78, 207,  47,  98,   3, 220,
        170,   2,  29, 191, 243, 158,  95, 190,
         44, 160, 147, 186, 156, 183, 246, 225,
    ]),
    bytes([
        113, 148, 238, 231, 110,  39, 243, 241,
         58,  61, 150, 144, 217, 158, 218, 182,
         64, 168, 225, 161, 180,  94, 186,  92,
        136, 107,  45,  76, 179,  52,  42, 229,
    ]),
)


def _refs():
    out = []
    for gate in _GATES:
        out.append(bytes(gate[i] ^ _K[i % len(_K)] for i in range(len(gate))))
    return out


def _digest_for(addon_id: str) -> bytes:
    raw = (addon_id or '').strip().encode('utf-8')
    return hashlib.sha256(_SALT + raw).digest()


def identity_ok(addon_id=None) -> bool:
    '''True when live addon id matches a baked transition digest.'''
    if addon_id is None:
        try:
            addon_id = xbmcaddon.Addon().getAddonInfo('id') or ''
        except Exception:
            addon_id = getattr(c, 'addon_id', '') or ''
    dig = _digest_for(addon_id)
    return dig in _refs()


def assert_identity(*, show_dialog=True) -> bool:
    '''
    Gate boot on addon-id identity.

    On miss: optional dialog, log, return False. Caller must abort.
    '''
    try:
        live = xbmcaddon.Addon().getAddonInfo('id') or ''
    except Exception:
        live = getattr(c, 'addon_id', '') or ''

    if identity_ok(live):
        return True

    c.log(f'[BrandGate] identity miss for id={live!r}', 1)
    if show_dialog:
        try:
            control.okDialog(
                'This build is not a supported package.[CR]'
                'The addon will exit.',
                heading='Identity check failed',
            )
        except Exception:
            pass
    return False

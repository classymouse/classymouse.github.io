# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file redirect_guard.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Redirect / hijack guard for scraper HTTP (v4 fresh).'''

import re
from urllib.parse import urlparse

from .classy import c


REDIRECT_HOST_BLOCKLIST = (
    'torrentdownloads.pro',
    'casino', 'gambl', 'poker', 'betting', 'jackpot', 'slots',
    '1xbet', 'pin-up', 'pinup', 'mostbet',
    'porn', 'xxx', 'adult', 'sexchat',
)

SPAM_BODY_MARKERS = (
    'casino', 'gambling', 'online betting', 'bet now', 'slot machine',
    'jackpot', 'porn', 'xxx adult', 'live sex',
)

_INFO_HASH_RE = re.compile(r'<info_hash>([a-fA-F0-9]{40})</info_hash>')


def normalize_host(host):
    h = (host or '').lower().split(':')[0].strip('.')
    if h.startswith('www.'):
        h = h[4:]
    return h


def host_is_blocked(netloc) -> bool:
    h = normalize_host(netloc)
    if not h:
        return True
    return any(token in h for token in REDIRECT_HOST_BLOCKLIST)


def host_allowed_for_scraper(netloc, allowed_domains) -> bool:
    if not allowed_domains:
        return True
    h = normalize_host(netloc)
    if not h:
        return False
    for domain in allowed_domains:
        d = normalize_host(domain)
        if not d:
            continue
        if h == d or h.endswith('.' + d):
            return True
    return False


def redirect_target_allowed(url, allowed_domains) -> bool:
    try:
        host = urlparse(url).netloc
    except Exception:
        return False
    if host_is_blocked(host):
        return False
    return host_allowed_for_scraper(host, allowed_domains)


def log_blocked_redirect(code, url, reason):
    c.log(f'[RedirectGuard] Blocked {code}  ->  {url} ({reason})', 1)


def body_looks_like_spam_hijack(text) -> bool:
    if not text:
        return False
    lower = text.lower()
    return sum(1 for m in SPAM_BODY_MARKERS if m in lower) >= 2


def rss_looks_like_torrent_feed(text) -> bool:
    if not text:
        return False
    return bool(_INFO_HASH_RE.search(text))

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file downloader.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Local offline downloads (commute stick)  -  single downloads.path root.
Movies: Title/Title.ext
Episodes: Show/Season N/Show SxxExx.ext
'''

from __future__ import annotations

import json
import os
import re
import threading
from urllib import parse as urllib_parse
from urllib import request as urllib_request

import xbmc
import xbmcgui
import xbmcvfs

_SAFE_RE = re.compile(r'[\\/:*?"<>|]+')


def _control():
    from . import control
    return control


def _c():
    from .classy import c
    return c


def downloads_enabled():
    return str(_c().get_setting('downloads') or '').lower() == 'true'


def downloads_path():
    path = (_c().get_setting('downloads.path') or '').strip()
    if not path or path.lower() in ('true', 'false'):
        return ''
    return path


def downloads_ready():
    return downloads_enabled() and bool(downloads_path())


def _safe_name(text):
    cleaned = _SAFE_RE.sub(' ', str(text or '')).strip(' .')
    cleaned = ' '.join(cleaned.split())
    return cleaned or 'download'


def _file_title(request):
    if request is not None and getattr(request, 'is_episode', False):
        show = _safe_name(request.tvshowtitle or request.title or 'Show')
        return f'{show} S{int(request.season):02d}E{int(request.episode):02d}'
    title = ''
    if request is not None:
        title = request.title or request.tvshowtitle or ''
    return _safe_name(title or 'Movie')


def _dest_for_request(request, url):
    control = _control()
    root = control.transPath(downloads_path())
    if not root:
        return ''

    levels = ['../../../..', '../../..', '../..', '..']
    for level in levels:
        try:
            control.makeFile(os.path.abspath(os.path.join(root, level)))
        except Exception:
            pass
    control.makeFile(root)

    if request is not None and getattr(request, 'is_episode', False):
        show = _safe_name(request.tvshowtitle or request.title or 'Show')
        season = max(1, int(request.season or 1))
        dest = os.path.join(root, show)
        control.makeFile(dest)
        dest = os.path.join(dest, f'Season {season}')
        control.makeFile(dest)
        leaf = _file_title(request)
    else:
        leaf = _file_title(request)
        dest = os.path.join(root, leaf)
        control.makeFile(dest)

    ext = os.path.splitext(urllib_parse.urlparse(url.split('|', 1)[0]).path)[1][1:].lower()
    if ext not in ('mp4', 'mkv', 'flv', 'avi', 'mpg', 'm4v', 'mov'):
        ext = 'mp4'
    return os.path.join(dest, f'{leaf}.{ext}')


def download(name, image, url, request=None):
    '''Resolve already done  -  queue HTTP transfer on a daemon thread.'''
    control = _control()
    c = _c()
    if not url:
        return False
    if not downloads_ready():
        control.infoDialog(c.lang(30895), sound=True)
        return False

    try:
        headers = dict(urllib_parse.parse_qsl(url.rsplit('|', 1)[1]))
    except Exception:
        headers = {}
    clean_url = url.split('|', 1)[0]

    dest = _dest_for_request(request, clean_url)
    if not dest:
        control.infoDialog(c.lang(30895), sound=True)
        return False

    title = name or _file_title(request)
    # Thread keeps package imports; RunScript on this file has no parent package.
    worker = threading.Thread(
        target=doDownload,
        args=(clean_url, dest, title, image or '', headers),
        name='ClassyDownload',
        daemon=True,
    )
    worker.start()
    return True


def getResponse(url, headers, size):
    try:
        if size > 0:
            headers = dict(headers or {})
            headers['Range'] = 'bytes=%d-' % int(size)
        req = urllib_request.Request(url, headers=headers or {})
        return urllib_request.urlopen(req, timeout=30)
    except Exception:
        return None


def done(title, dest, downloaded):
    playing = xbmc.Player().isPlaying()
    text = xbmcgui.Window(10000).getProperty('GEN-DOWNLOADED') or ''
    if text:
        text += '[CR]'
    leaf = dest.rsplit(os.sep)[-1]
    if downloaded:
        text += '%s : [COLOR forestgreen]Download succeeded[/COLOR]' % leaf
    else:
        text += '%s : [COLOR red]Download failed[/COLOR]' % leaf
    xbmcgui.Window(10000).setProperty('GEN-DOWNLOADED', text)
    if (not downloaded) or (not playing):
        xbmcgui.Dialog().ok(title, text)
        xbmcgui.Window(10000).clearProperty('GEN-DOWNLOADED')


def doDownload(url, dest, title, image, headers):
    # Thread path passes raw values; optional quoted-string headers for callers.
    if isinstance(headers, str):
        headers = json.loads(urllib_parse.unquote_plus(headers))
        url = urllib_parse.unquote_plus(url)
        title = urllib_parse.unquote_plus(title)
        image = urllib_parse.unquote_plus(image)
        dest = urllib_parse.unquote_plus(dest)
    elif not isinstance(headers, dict):
        headers = {}
    file = dest.rsplit(os.sep, 1)[-1]

    resp = getResponse(url, headers, 0)
    if not resp:
        xbmcgui.Dialog().ok(title, dest + '[CR]Download failed[CR]No response from server')
        return

    try:
        content = int(resp.headers['Content-Length'])
    except Exception:
        content = 0
    try:
        resumable = 'bytes' in (resp.headers.get('Accept-Ranges') or '').lower()
    except Exception:
        resumable = False

    if content < 1:
        xbmcgui.Dialog().ok(title, file + '[CR]Unknown filesize[CR]Unable to download')
        return

    size = 1024 * 1024
    mb = content / (1024 * 1024)
    if content < size:
        size = content

    if not xbmcgui.Dialog().yesno(
        title + ' - Confirm Download',
        file + '[CR]Complete file is %dMB[CR]Continue with download?' % mb,
    ):
        return

    total = 0
    notify = 0
    errors = 0
    count = 0
    resume = 0
    sleep = 0
    handle = xbmcvfs.File(dest, 'w')
    chunks = []

    while True:
        downloaded = total + sum(len(piece) for piece in chunks)
        percent = min(100 * downloaded / content, 100)
        if percent >= notify:
            xbmcgui.Dialog().notification(
                'Download Progress: %s%% - %s' % (int(percent), title),
                dest,
                image or '',
                5000,
                False,
            )
            notify += 10

        chunk = None
        error = False
        try:
            chunk = resp.read(size)
            if not chunk:
                if percent < 99:
                    error = True
                else:
                    while chunks:
                        piece = chunks.pop(0)
                        handle.write(piece)
                        del piece
                    handle.close()
                    return done(title, dest, True)
        except Exception as e:
            error = True
            sleep = 10
            errno = getattr(e, 'errno', 0) or 0
            if errno in (10054, 11001):
                errors = 10
                sleep = 30

        if chunk:
            errors = 0
            chunks.append(chunk)
            if len(chunks) > 5:
                piece = chunks.pop(0)
                handle.write(piece)
                total += len(piece)
                del piece

        if error:
            errors += 1
            count += 1
            xbmc.sleep(sleep * 1000)

        if (resumable and errors > 0) or errors >= 10:
            if (not resumable and resume >= 50) or resume >= 500:
                try:
                    handle.close()
                except Exception:
                    pass
                return done(title, dest, False)
            resume += 1
            errors = 0
            if resumable:
                chunks = []
                resp = getResponse(url, headers, total)


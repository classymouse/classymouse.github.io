# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scraper_client.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Crew-compatible HTTP helpers for scrapers and external packs.

Wraps Classy fetch/urllib where needed so copied scrapers keep calling
client.request(), parseDom(), agent(), etc.'''

import gzip
import json
import os
import random
import re
import threading
from html import unescape
from io import BytesIO
from urllib.error import HTTPError, URLError
from urllib.parse import quote_plus, unquote, urlencode, urljoin, urlparse
from urllib.request import (
    HTTPHandler,
    HTTPRedirectHandler,
    HTTPCookieProcessor,
    HTTPSHandler,
    Request as URLRequest,
    build_opener,
)
from urllib.response import addinfourl

from . import dom_parser
from . import xbox_ssl
from .crewruntime import c

try:
    from http import cookiejar as cookielib
except Exception:
    import cookielib  # type: ignore

STRING_TYPES = (str, bytes)

AGENT_LIST = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.117 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.117 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.117 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:118.0) Gecko/20100101 Firefox/118.0',
]

_AGENTS = None

# Per play scrape  -  skip repeat HTTP to hosts that already timed out (3x knaben.eu, etc.).
_scrape_failed_hosts = {}
_scrape_fail_lock = threading.Lock()


def reset_scrape_host_failures():
    '''Call at scrape start  -  new title, fresh host list.'''
    with _scrape_fail_lock:
        _scrape_failed_hosts.clear()


def scrape_host_failure_summary():
    '''One-line dev summary when hosts were skipped after first failure.'''
    with _scrape_fail_lock:
        items = [
            (host, info.get('reason', ''), int(info.get('skipped') or 0))
            for host, info in _scrape_failed_hosts.items()
            if int(info.get('skipped') or 0) > 0
        ]
    if not items:
        return
    parts = [f'{host} ({reason}, skipped {skipped})' for host, reason, skipped in items[:6]]
    c.log(f'[ScraperClient] dead hosts this scrape: {"; ".join(parts)}')


def _request_host(url):
    try:
        parsed = urlparse(_ensure_text(url))
        return (parsed.hostname or '').lower()
    except Exception:
        return ''


def _mark_host_failed(host, reason):
    if not host:
        return
    with _scrape_fail_lock:
        entry = _scrape_failed_hosts.get(host)
        if entry:
            entry['skipped'] = int(entry.get('skipped') or 0) + 1
            return
        _scrape_failed_hosts[host] = {'reason': reason, 'skipped': 0}
    if getattr(c, 'devmode', False):
        c.log(f'[ScraperClient] {host} {reason}  -  skipping repeat scrapers this play')


def _host_failed(host):
    if not host:
        return False
    with _scrape_fail_lock:
        return host in _scrape_failed_hosts


def _ensure_text(value):
    if value is None:
        return ''
    if isinstance(value, bytes):
        return value.decode('utf-8', errors='replace')
    return str(value)


def _prepare_post(post):
    if post is None:
        return None
    if isinstance(post, bytes):
        return post
    if isinstance(post, str):
        return post.encode('utf-8')
    if isinstance(post, dict):
        return urlencode(post).encode('utf-8')
    return str(post).encode('utf-8')


def _decode_gzip(data, headers):
    if not data:
        return data
    encoding = None
    try:
        encoding = headers.get('Content-Encoding') if headers else None
    except Exception:
        pass
    if encoding == 'gzip' and isinstance(data, bytes):
        try:
            return gzip.GzipFile(fileobj=BytesIO(data)).read()
        except Exception:
            pass
    return data


def _read_response_content(response, limit=None, as_bytes=False):
    try:
        if limit:
            data = response.read(int(limit) * 1024)
        else:
            data = response.read(5 * 1024 * 1024)
    except Exception:
        return b'' if as_bytes else ''
    try:
        headers = response.info()
    except Exception:
        headers = {}
    data = _decode_gzip(data, headers)
    if as_bytes:
        return data
    if isinstance(data, bytes):
        return data.decode('utf-8', errors='replace')
    return str(data)


def _build_opener(redirect=True, verify=True):
    cj = cookielib.CookieJar()
    handlers = [
        HTTPSHandler(context=xbox_ssl.ssl_context(verify)),
        HTTPHandler(),
        HTTPCookieProcessor(cj),
    ]
    if not redirect:
        class NoRedirectHandler(HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None

            def http_error_302(self, req, fp, code, msg, headers):
                response = addinfourl(fp, headers, req.get_full_url())
                try:
                    response.code = code
                except Exception:
                    pass
                return response

            http_error_301 = http_error_303 = http_error_302

        handlers.append(NoRedirectHandler())
    return build_opener(*handlers), cj


def _normalize_headers(headers, url, referer, mobile, xhr, cookie, compression, limit):
    headers = dict(headers or {})
    if referer:
        headers.setdefault('Referer', referer)
    if cookie:
        headers.setdefault('Cookie', cookie)
    if mobile:
        headers['User-Agent'] = randommobileagent()
    elif 'User-Agent' not in headers:
        headers['User-Agent'] = agent()
    if xhr:
        headers.setdefault('X-Requested-With', 'XMLHttpRequest')
    if compression:
        headers.setdefault('Accept-Encoding', 'gzip')
    if limit:
        headers.setdefault('Range', f'bytes=0-{int(limit) * 1024}')
    return headers


def _response_headers_dict(response):
    try:
        info = response.info()
        return dict((item[0].title(), item[1]) for item in info.items())
    except Exception:
        try:
            return dict(response.headers)
        except Exception:
            return {}


def _extended_tuple(response, data, req_headers, cj, as_bytes=False):
    cookie_str = '; '.join([f'{i.name}={i.value}' for i in cj]) or (req_headers.get('Cookie') or '')
    status_code = getattr(response, 'code', None) or getattr(response, 'status', None) or ''
    response_headers = _response_headers_dict(response)
    # Classy/Coco/Gears/Viper/Magneto extended: (body, status, resp_headers, req_headers, cookie)
    return data, str(status_code), response_headers, dict(req_headers), cookie_str


def _try_cfscrape_retry(url, post, headers, timeout, as_bytes=False):
    from .pack_cfscrape import get_cfscrape

    cfs = get_cfscrape()
    if cfs is None:
        return None
    try:
        parsed = urlparse(_ensure_text(url))
        netloc = f'{parsed.scheme}://{parsed.netloc}'
    except Exception:
        netloc = _ensure_text(url)
    headers = dict(headers or {})
    ua = headers.get('User-Agent') or agent()
    cf = None
    try:
        from . import cache
        cf_res = cache.get(cfs.get_cookie_string, 1, netloc, ua)
        if cf_res:
            cf = cf_res[0] if isinstance(cf_res, (list, tuple)) else cf_res
    except Exception:
        cf = None
    if not cf:
        try:
            cf_res = cfs.get_cookie_string(netloc, ua)
            cf = cf_res[0] if isinstance(cf_res, (list, tuple)) else cf_res
        except Exception:
            cf = None
    if not cf:
        return None
    headers['Cookie'] = cf
    opener, _cj = _build_opener(redirect=True, verify=True)
    try:
        response = opener.open(URLRequest(url, data=post, headers=headers), timeout=int(timeout))
        raw = _read_response_content(response, as_bytes=as_bytes)
        response.close()
        return raw
    except Exception:
        return None


def request(
    url,
    close=True,
    redirect=True,
    error=False,
    verify=True,
    proxy=None,
    post=None,
    headers=None,
    mobile=False,
    XHR=False,
    limit=None,
    referer=None,
    cookie=None,
    compression=False,
    output='',
    timeout='30',
    username=None,
    password=None,
    as_bytes=False,
    flare=False,
    **kwargs,
):
    del kwargs
    if not url:
        return None
    url = _ensure_text(url)
    host = _request_host(url)
    if _host_failed(host):
        return None
    post = _prepare_post(post)

    opener, cj = _build_opener(redirect=redirect, verify=verify)
    headers = _normalize_headers(headers, url, referer, mobile, XHR, cookie, compression, limit)
    req = URLRequest(url, data=post, headers=headers)

    try:
        response = opener.open(req, timeout=int(timeout))
        status_code = getattr(response, 'code', None) or getattr(response, 'status', None)

        if output == 'headers':
            info = response.info()
            if close:
                response.close()
            return info

        if output == 'file_size':
            try:
                size = int(response.info().get('Content-Length') or 0)
            except Exception:
                size = 0
            if close:
                response.close()
            return size

        if output == 'response':
            raw = _read_response_content(response, limit=limit, as_bytes=True)
            if close:
                response.close()
            return (str(status_code), raw)

        if output == 'json':
            raw = _read_response_content(response, limit=limit, as_bytes=True)
            try:
                text = raw.decode('utf-8', errors='ignore') if isinstance(raw, (bytes, bytearray)) else _ensure_text(raw)
                return json.loads(text)
            finally:
                if close:
                    response.close()

        if output == 'cookie':
            try:
                cookie_str = '; '.join([f'{i.name}={i.value}' for i in cj]) or (headers.get('Cookie') or '')
                return cookie_str
            finally:
                if close:
                    response.close()

        if output == 'extended':
            try:
                data = _read_response_content(response, limit=limit, as_bytes=as_bytes)
                return _extended_tuple(response, data, headers, cj, as_bytes=as_bytes)
            finally:
                if close:
                    response.close()

        raw = _read_response_content(response, limit=limit, as_bytes=as_bytes)
        if close:
            response.close()
        return raw

    except HTTPError as he:
        code = getattr(he, 'code', None)
        if code in (403, 503) and (flare or code == 503):
            retry = _try_cfscrape_retry(url, post, headers, timeout, as_bytes=as_bytes)
            if retry is not None:
                if output == 'extended':
                    return retry, str(code), {}, dict(headers), headers.get('Cookie') or ''
                return retry
        if error:
            return he
        return None
    except URLError as exc:
        reason = str(exc.reason) if getattr(exc, 'reason', None) else str(exc)
        if 'timed out' in reason.lower():
            _mark_host_failed(host, 'timed out')
        elif getattr(c, 'devmode', False):
            c.log(f'[ScraperClient] URLError {host or url}: {reason}', 1)
        return None
    except Exception as exc:
        if getattr(c, 'devmode', False):
            c.log(f'[ScraperClient] request failed url=({url}): {exc}', 1)
        if error:
            return exc
        return None


def parseDom(html, name='', attrs=None, ret=False):
    if attrs:
        attrs = {k: re.compile(v + ('$' if v else '')) for k, v in attrs.items()}
    results = dom_parser.parse_dom(html, name, attrs, req=False)
    out = []
    if ret:
        for item in (results or []):
            try:
                if hasattr(item, 'attrs'):
                    key = ret.lower() if isinstance(ret, STRING_TYPES) else ret
                    out.append((getattr(item, 'attrs') or {}).get(key, ''))
                elif isinstance(item, dict):
                    out.append(item.get(ret, ''))
                else:
                    out.append(_ensure_text(getattr(item, ret, item)))
            except Exception:
                out.append('')
    else:
        for item in (results or []):
            try:
                content = getattr(item, 'content', None)
                if content is not None:
                    out.append(content)
                elif isinstance(item, dict):
                    out.append(item.get('content', ''))
                else:
                    out.append(_ensure_text(item))
            except Exception:
                out.append('')
    return out


parseDOM = parseDom


def replaceHTMLCodes(text):
    try:
        text = re.sub(r"(&#[0-9]+)([^;^0-9]+)", r'\1;\2', _ensure_text(text))
        text = unescape(text)
        for key, value in {
            '&quot;': '"', '&amp;': '&', '&lt;': '<', '&gt;': '>',
            '&#38;': '&', '&nbsp;': '', '&#8230;': '...', '&#8217;': "'", '&#8211;': '-',
        }.items():
            text = text.replace(key, value)
        return text.strip()
    except Exception:
        return _ensure_text(text)


def _load_agents():
    global _AGENTS
    if _AGENTS is not None:
        return _AGENTS
    try:
        path = os.path.join(os.path.dirname(__file__), 'user_agents.json')
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as handle:
                data = json.load(handle)
                if isinstance(data, list) and data:
                    _AGENTS = data
                    return _AGENTS
    except Exception:
        pass
    _AGENTS = AGENT_LIST
    return _AGENTS


def agent():
    return random.choice(_load_agents())


def randomagent():
    return agent()


def randommobileagent(mobile=None):
    return (
        'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4 like Mac OS X) '
        'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1'
    )

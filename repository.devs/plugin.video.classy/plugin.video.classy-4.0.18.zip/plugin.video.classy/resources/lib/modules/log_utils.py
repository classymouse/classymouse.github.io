# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file log_utils.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Minimal log_utils for source_utils / scrapers.'''

def error():
    pass

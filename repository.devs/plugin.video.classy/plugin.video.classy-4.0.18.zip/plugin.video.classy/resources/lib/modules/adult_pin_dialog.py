# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file adult_pin_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Custom numeric PIN dialog (TV Evening style).'''

import xbmcgui

from ..kodi.dialog_base import ClassyDialogBase
from . import control
from .classy import c


class AdultPINDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningNumericInput.xml'

    def __init__(self, *args, **kwargs):
        fanart = kwargs.pop('fanart', '')
        section_name = kwargs.pop('section_name', 'Adult Content')
        custom_subtitle = kwargs.pop('custom_subtitle', None)
        super().__init__(*args, **kwargs)
        self.fanart = fanart
        self.section_name = section_name
        self.custom_subtitle = custom_subtitle
        self.value = ''

    def onInit(self):
        try:
            self.set_properties({
                'tvevening.fanart': self.fanart or c.addon_fanart(),
            })

            try:
                self.getControl(201).setLabel('[COLOR orchid]PARENTAL CONTROL[/COLOR]')
            except Exception:
                pass

            try:
                subtitle = self.custom_subtitle or f'Enter PIN to access {self.section_name}'
                self.getControl(202).setLabel(subtitle)
            except Exception:
                pass

            for cid, digit in (
                (101, '1'), (102, '2'), (103, '3'), (104, '4'), (105, '5'),
                (106, '6'), (107, '7'), (108, '8'), (109, '9'), (100, '0'),
            ):
                self.getControl(cid).setLabel(digit)
            self.getControl(110).setLabel('<')
            self.getControl(111).setLabel('C')
            self.getControl(112).setLabel('OK')
            self.getControl(113).setLabel('Cancel')
            self.update_display()
            self.setFocusId(105)
        except Exception as exc:
            c.log(f'[Adult PIN] onInit error: {exc}', 1)

    def update_display(self):
        try:
            label = self.getControl(200)
            if not self.value:
                label.setLabel('[COLOR gray]Enter PIN[/COLOR]')
            else:
                label.setLabel('* ' * len(self.value))
        except Exception:
            pass

    def onClick(self, controlId):
        if self.closing:
            return

        if 100 <= controlId <= 109:
            digit = '0' if controlId == 100 else str(controlId - 100)
            if len(self.value) < 8:
                self.value += digit
            self.update_display()
        elif controlId == 110:
            self.value = self.value[:-1]
            self.update_display()
        elif controlId == 111:
            self.value = ''
            self.update_display()
        elif controlId == 112:
            if len(self.value) >= 4:
                self.close_with(112)
            else:
                control.infoDialog('PIN must be at least 4 digits', icon='ERROR')
        elif controlId == 113:
            self.close_with(113)

    def onAction(self, action):
        action_id = action.getId()

        if 58 <= action_id <= 67:
            digit = '0' if action_id == 58 else str(action_id - 58)
            if len(self.value) < 8:
                self.value += digit
                self.update_display()
            return

        if 61472 <= action_id <= 61481:
            digit = str(action_id - 61472)
            if len(self.value) < 8:
                self.value += digit
                self.update_display()
            return

        if action_id == 110:
            self.value = self.value[:-1]
            self.update_display()
            return

        if action_id in (7, 61453):
            if len(self.value) >= 4:
                self.close_with(112)
            else:
                control.infoDialog('PIN must be at least 4 digits', icon='ERROR')
            return

        if action_id in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.close_with(113)
            return


def show_adult_pin_dialog(section_name='Adult Content', fanart='', custom_subtitle=None):
    try:
        dialog = AdultPINDialog.run_modal(
            fanart=fanart,
            section_name=section_name,
            custom_subtitle=custom_subtitle,
        )
        try:
            if dialog.button_id == 112:
                return dialog.value
            return None
        finally:
            del dialog
    except Exception as exc:
        c.log(f'[Adult PIN] dialog error: {exc}', 1)
        return control.dialog.numeric(0, f'Enter PIN to access {section_name}')

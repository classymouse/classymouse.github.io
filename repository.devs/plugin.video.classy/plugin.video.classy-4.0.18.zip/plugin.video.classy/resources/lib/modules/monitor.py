# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file monitor.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

ClassyMonitor  -  background worker scheduler (xbmc.Monitor).

service.py only boots this loop; heavy work lives in modules/workers/*.
Add workers to DEFAULT_WORKERS as new background jobs land (Trakt sync,
widget row cache, TV Evening, playback, ...).'''

import time

import xbmc

from . import kodi
from .classy import c
from .service_state import clear_monitor, set_monitor, shutdown_requested
from .workers.base import Worker
from .workers.debrid_account import DebridAccountWorker
from .workers.progress_cache import ProgressCacheWorker

DEFAULT_WORKERS = (
    ProgressCacheWorker(),
    DebridAccountWorker(),
)

_SETTINGS_CHANGED_DEBOUNCE_SEC = 1.5

_monitor_singleton = None


def get_monitor():
    return _monitor_singleton


class ClassyMonitor(xbmc.Monitor):
    '''Single service-thread scheduler; workers run on tick, not in widget routes.'''

    def __init__(self, workers=None):
        global _monitor_singleton
        super().__init__()
        self._workers = list(workers if workers is not None else DEFAULT_WORKERS)
        self._worker_map = {w.name: w for w in self._workers}
        self._last_settings_changed_at = 0.0
        self._last_tracker_name = None
        _monitor_singleton = self
        set_monitor(self)
        try:
            from .. import tracker
            self._last_tracker_name = tracker.active_name()
        except Exception:
            self._last_tracker_name = None

    def worker(self, name):
        return self._worker_map.get(name)

    def onSettingsChanged(self):
        '''
        Mid-session tracker XOR: settings save must re-evaluate active backend.

        Classy reads settings live (no cache), but ProgressCacheWorker and widget
        warm must not keep ticking Trakt under leftover tokens after a Simkl flip.
        '''
        now = time.time()
        if now - self._last_settings_changed_at < _SETTINGS_CHANGED_DEBOUNCE_SEC:
            return
        self._last_settings_changed_at = now
        try:
            from .. import tracker

            name = tracker.active_name()
            label = tracker.display_label()
            live = tracker.live()
            flipped = name != self._last_tracker_name
            self._last_tracker_name = name
            c.log(
                f'[Monitor] settings changed  -  tracker={name} ({label}) '
                f'live={live} flipped={flipped}',
                1 if flipped else 0,
            )
            if flipped:
                worker = self.worker('progress_cache')
                if worker is not None:
                    worker.force_due()
                try:
                    from ..progress.widget_signals import notify_progress_changed
                    notify_progress_changed('tracker_flip')
                except Exception:
                    pass
                # Rebuild My Movies / My TV XOR rows (Trakt vs Simkl menus).
                try:
                    import xbmc
                    xbmc.executebuiltin('Container.Refresh')
                except Exception:
                    pass
                if tracker.is_trakt() and live:
                    kodi.schedule_widget_refresh()
        except Exception as exc:
            c.log(f'[Monitor] settings-changed tracker reconcile failed: {exc}', 1)

    def run(self, poll_seconds=0.5):
        names = ', '.join(w.name for w in self._workers) or 'none'
        c.log(f'[Monitor] started (workers={names}, poll={poll_seconds}s)')
        while True:
            if self.abortRequested():
                break
            if self.waitForAbort(poll_seconds):
                break
            if self.abortRequested():
                break
            if not shutdown_requested():
                kodi.maybe_refresh_widgets()
                try:
                    from ..playback import upnext as upnext_mod

                    upnext_mod.service_tick(self)
                except Exception as exc:
                    c.log(f'[Monitor] UpNext tick failed: {exc}', 1)
                try:
                    from ..playback import service_hooks

                    service_hooks.service_tick()
                except Exception as exc:
                    c.log(f'[Monitor] playback hooks tick failed: {exc}', 1)
                try:
                    from ..playback import intro_skip_dialog

                    intro_skip_dialog.dispatch_pending_dialog()
                except Exception as exc:
                    c.log(f'[Monitor] IntroSkip dialog tick failed: {exc}', 1)
                try:
                    from ..tvevening import bridge_dialog, countdown_dialog, complete_dialog

                    bridge_dialog.dispatch_pending()
                    countdown_dialog.dispatch_pending()
                    complete_dialog.dispatch_pending()
                except Exception as exc:
                    c.log(f'[Monitor] TV Evening dialog tick failed: {exc}', 1)
            now = time.time()
            for worker in self._workers:
                if self.abortRequested():
                    break
                if not isinstance(worker, Worker) or not worker.wants_tick(now):
                    continue
                try:
                    if c.devmode:
                        c.log(f'[Monitor] tick {worker.name}')
                    worker.tick(self)
                except Exception as exc:
                    c.log(f'[Monitor] worker {worker.name} failed: {exc}', 1)
                finally:
                    worker.mark_ran(now)
                if self.abortRequested():
                    break
        clear_monitor()
        global _monitor_singleton
        _monitor_singleton = None
        c.log('[Monitor] stopped')

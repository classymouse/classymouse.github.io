# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debrid_names.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Canonical debrid service name matching (TorBox / Real-Debrid casing).'''

from __future__ import annotations

import re

CANONICAL = {
    'realdebrid': 'Real-Debrid',
    'alldebrid': 'AllDebrid',
    'premiumizeme': 'Premiumize.me',
    'torbox': 'TorBox',
}

DEBRID_SLUG = {
    'realdebrid': 'real-debrid',
    'premiumizeme': 'premiumize.me',
    'alldebrid': 'alldebrid',
    'torbox': 'torbox',
    'debridlinkfr': 'debrid-link.fr',
    'linksnappy': 'linksnappy',
    'megadebrid': 'megadebrid',
    'zevera': 'zevera',
}

DEBRID_SHORT = {
    'realdebrid': 'RD',
    'premiumizeme': 'PM',
    'alldebrid': 'AD',
    'torbox': 'TB',
    'debridlinkfr': 'DL',
    'linksnappy': 'LS',
    'megadebrid': 'MD',
    'zevera': 'ZVR',
}

KNOWN_DEBRIDS = frozenset(CANONICAL.keys())


def normalize(name):
    return re.sub(r'[^a-z0-9]+', '', str(name or '').lower())


def is_known_debrid(name):
    return normalize(name) in KNOWN_DEBRIDS


def canonical(name):
    return CANONICAL.get(normalize(name), str(name or '').strip())


def slug(name):
    return DEBRID_SLUG.get(normalize(name), str(name or '').strip().lower())


def short_code(name):
    norm = normalize(name)
    if norm in DEBRID_SHORT:
        return DEBRID_SHORT[norm]
    text = str(name or '').strip()
    return text.upper()[:6] if text else ''


def is_torbox(name):
    return normalize(name) == 'torbox'


def is_pack_service(name):
    '''Services with Classy pack file-pick (RD / AD / PM).'''
    return normalize(name) in ('realdebrid', 'alldebrid', 'premiumizeme')


def is_realdebrid(name):
    return normalize(name) in ('realdebrid', 'rd')


def is_alldebrid(name):
    return normalize(name) == 'alldebrid'


def is_premiumize(name):
    return normalize(name) == 'premiumizeme'

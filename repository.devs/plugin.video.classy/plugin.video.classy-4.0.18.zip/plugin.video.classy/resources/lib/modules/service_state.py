# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file service_state.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Service-thread state shared without circular imports.'''

_monitor = None


def set_monitor(monitor):
    global _monitor
    _monitor = monitor


def clear_monitor():
    global _monitor
    _monitor = None


def shutdown_requested():
    '''True when Kodi is exiting and background work should stop immediately.'''
    return bool(_monitor and _monitor.abortRequested())

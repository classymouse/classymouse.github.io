# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file hunter.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

'''
 ***********************************************************
 * The Crew Add-on
 *
 * @file hunter.py
 * @package script.module.thecrew
 *
 * Hunter JavaScript Deobfuscator
 * Based on: https://technicology52263854.wordpress.com/2018/04/29/deobfuscating-hunter-javascript/
 *
 * @copyright (c) 2023-2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''

_ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/'


def __duf(data, radix, offset):
    digits = list(_ALPHABET)
    source_digits = digits[:radix]
    target_digits = digits[:offset]
    value = 0
    for index, char in enumerate(reversed(data)):
        if char in source_digits:
            value += source_digits.index(char) * (radix ** index)

    out = ''
    while value > 0:
        out = target_digits[value % offset] + out
        value = (value - (value % offset)) // offset
    return int(out) or 0


def hunter(h, u, n, t, e, r):
    del u, r  # CDN passes these; only h, n, t, e are used
    out = ''
    i = 0
    while i < len(h):
        j = 0
        s = ''
        while i < len(h) and h[i] != n[e]:
            s += h[i]
            i += 1

        while j < len(n):
            s = s.replace(n[j], str(j))
            j += 1

        out += ''.join(map(chr, [__duf(s, e, 10) - t]))
        i += 1

    return out

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debrid_pack.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Season/episode pack resolve  -  pick the matching file inside multi-file
torrents (Crew parity). ResolveURL alone often returns the wrong episode.
'''

from __future__ import annotations

import re
import time
import traceback

import requests
import xbmc
import xbmcaddon

from . import source_utils
from .classy import c

DEBRID_API_TIMEOUT = 10
PACK_PROCESS_DELAY = 2
STATUS_CHECK_DELAY = 1
RD_RATE_LIMIT_BACKOFF = 3
RD_RATE_LIMIT_RETRY_SLEEP = 3

_pack_resolution_active = {}
_rd_rate_limited_until = 0.0
_monitor = None


def _abort_requested():
    global _monitor
    try:
        if _monitor is None:
            _monitor = xbmc.Monitor()
        return bool(_monitor.abortRequested())
    except Exception:
        return False


def _interruptible_sleep(seconds):
    try:
        remaining = float(seconds)
    except (TypeError, ValueError):
        return True
    if remaining <= 0:
        return True
    global _monitor
    try:
        if _monitor is None:
            _monitor = xbmc.Monitor()
        return not _monitor.waitForAbort(remaining)
    except Exception:
        time.sleep(remaining)
        return True


def _ru_setting(key):
    try:
        return xbmcaddon.Addon('script.module.resolveurl').getSetting(key) or ''
    except Exception:
        return ''


def _ru_set_setting(key, value):
    try:
        xbmcaddon.Addon('script.module.resolveurl').setSetting(key, value)
    except Exception:
        pass


def _token(token_key):
    return (_ru_setting(token_key) or '').strip()


def resolve_pack(magnet_url, debrid_service, season, episode, progressDialog=None):
    '''Dispatch pack resolve for RD / AD / PM. Returns stream URL or None.'''
    hash_match = re.search(r'btih:([a-fA-F0-9]+)', magnet_url or '', re.I)
    torrent_hash = hash_match.group(1).lower() if hash_match else ''
    if torrent_hash:
        if torrent_hash in _pack_resolution_active:
            c.log('[Pack] Another resolution already in progress for this torrent  -  skip')
            return None
        _pack_resolution_active[torrent_hash] = True

    try:
        season = int(season)
        episode = int(episode)
    except (TypeError, ValueError):
        c.log('[Pack] Invalid season/episode', 1)
        return None

    try:
        c.log(f'[Pack] Resolving with {debrid_service} for S{season:02d}E{episode:02d}')
        key = re.sub(r'[^a-z0-9]+', '', str(debrid_service or '').lower())
        if key == 'realdebrid':
            return resolve_pack_realdebrid(magnet_url, season, episode, progressDialog)
        if key == 'alldebrid':
            return resolve_pack_alldebrid(magnet_url, season, episode, progressDialog)
        if key in ('premiumizeme', 'premiumize'):
            return resolve_pack_premiumize(magnet_url, season, episode, progressDialog)
        c.log(f'[Pack] Not implemented for {debrid_service}')
        return None
    except Exception as exc:
        c.log(f'[Pack] Resolution error: {exc}', 1)
        if c.devmode:
            c.log(traceback.format_exc(), 1)
        return None
    finally:
        if torrent_hash and torrent_hash in _pack_resolution_active:
            del _pack_resolution_active[torrent_hash]


def _rd_refresh_access_token():
    refresh_token = _ru_setting('RealDebridResolver_refresh')
    client_id = _ru_setting('RealDebridResolver_client_id') or 'X245A4XAIBGVM'
    client_secret = _ru_setting('RealDebridResolver_client_secret')
    if not refresh_token:
        return None
    try:
        response = requests.post(
            'https://api.real-debrid.com/oauth/v2/token',
            data={
                'client_id': client_id,
                'client_secret': client_secret or '',
                'code': refresh_token,
                'grant_type': 'http://oauth.net/grant_type/device/1.0',
            },
            timeout=15,
        )
        if response.status_code != 200:
            c.log(f'[RD Token Refresh] failed: {response.status_code}', 1)
            return None
        new_token = (response.json() or {}).get('access_token')
        if new_token:
            _ru_set_setting('RealDebridResolver_token', new_token)
            c.log('[RD Token Refresh] Access token refreshed')
            return new_token
    except Exception as exc:
        c.log(f'[RD Token Refresh] Exception: {exc}', 1)
    return None


def _filter_video_matches(files, season, episode, path_key='path'):
    video_extensions = source_utils.supported_video_extensions()
    video_files = []
    for item in files:
        path = item.get(path_key) or item.get('path') or item.get('filename') or item.get('name') or ''
        if any(str(path).lower().endswith(ext) for ext in video_extensions):
            video_files.append(item)
    matched = []
    for item in video_files:
        path = item.get(path_key) or item.get('path') or item.get('filename') or item.get('name') or ''
        if source_utils.seas_ep_filter(season, episode, path):
            matched.append(item)
            c.log(f'[Pack] Potential match: {path}')
    if not matched:
        return []
    non_sample = [
        f for f in matched
        if not any(
            x in (
                f.get(path_key) or f.get('path') or f.get('filename') or f.get('name') or ''
            ).lower()
            for x in ('sample', 'proof', '-trailer')
        )
    ]
    return non_sample or matched


def resolve_pack_realdebrid(magnet_url, season, episode, progressDialog=None, _reselect=False):
    '''Resolve pack via Real-Debrid API with S/E file pick + mismatch abort.'''
    global _rd_rate_limited_until
    c.log(f'[RD Pack] Starting resolution for S{season:02d}E{episode:02d}')
    try:
        if _abort_requested():
            return None
        rd_token = _token('RealDebridResolver_token')
        if not rd_token:
            c.log('[RD Pack] No Real-Debrid token in ResolveURL', 1)
            return None

        base_url = 'https://api.real-debrid.com/rest/1.0'
        headers = {'Authorization': f'Bearer {rd_token}'}

        if time.time() < _rd_rate_limited_until:
            remaining = _rd_rate_limited_until - time.time()
            c.log(f'[RD Pack] Rate-limit backoff  -  wait {remaining:.1f}s', 1)
            if not _interruptible_sleep(remaining):
                return None

        add_response = requests.post(
            f'{base_url}/torrents/addMagnet',
            data={'magnet': magnet_url},
            headers=headers,
            timeout=DEBRID_API_TIMEOUT,
        )
        if add_response.status_code == 451:
            c.log('[RD Pack] Hash blocked (451)', 1)
            return None
        if add_response.status_code == 429:
            c.log('[RD Pack] 429  -  sleep then retry once', 1)
            if not _interruptible_sleep(RD_RATE_LIMIT_RETRY_SLEEP):
                return None
            add_response = requests.post(
                f'{base_url}/torrents/addMagnet',
                data={'magnet': magnet_url},
                headers=headers,
                timeout=DEBRID_API_TIMEOUT,
            )
            if add_response.status_code == 429:
                _rd_rate_limited_until = time.time() + RD_RATE_LIMIT_BACKOFF
                c.log('[RD Pack] Still 429  -  backing off', 1)
                return None
        if add_response.status_code == 401:
            new_token = _rd_refresh_access_token()
            if not new_token:
                c.log('[RD Pack] Token refresh failed', 1)
                return None
            headers = {'Authorization': f'Bearer {new_token}'}
            add_response = requests.post(
                f'{base_url}/torrents/addMagnet',
                data={'magnet': magnet_url},
                headers=headers,
                timeout=DEBRID_API_TIMEOUT,
            )
        if add_response.status_code not in (201, 202):
            c.log(f'[RD Pack] addMagnet failed: {add_response.status_code}', 1)
            return None

        torrent_id = (add_response.json() or {}).get('id')
        if not torrent_id:
            c.log('[RD Pack] No torrent id', 1)
            return None

        if not _interruptible_sleep(PACK_PROCESS_DELAY):
            return None

        info_url = f'{base_url}/torrents/info/{torrent_id}'
        info_response = requests.get(info_url, headers=headers, timeout=DEBRID_API_TIMEOUT)
        if info_response.status_code == 429:
            c.log('[RD Pack] 429 on torrents/info', 1)
            return None
        if info_response.status_code != 200:
            c.log(f'[RD Pack] torrents/info failed: {info_response.status_code}', 1)
            return None

        torrent_info = info_response.json() or {}
        files = torrent_info.get('files') or []
        matched_files = _filter_video_matches(files, season, episode, path_key='path')
        if not matched_files:
            c.log('[RD Pack] No matching episode file found', 1)
            return None

        matched_file = source_utils.pick_best_pack_file(
            matched_files, path_key='path', size_key='bytes'
        )
        if not matched_file:
            return None
        c.log(f'[RD Pack] Selected: {matched_file.get("path")}')

        select_url = f'{base_url}/torrents/selectFiles/{torrent_id}'
        select_response = None
        for attempt in range(3):
            if _abort_requested():
                return None
            try:
                select_response = requests.post(
                    select_url,
                    data={'files': str(matched_file['id'])},
                    headers=headers,
                    timeout=DEBRID_API_TIMEOUT,
                )
                if select_response.status_code == 429:
                    c.log('[RD Pack] 429 on selectFiles', 1)
                    return None
                break
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
                if attempt < 2:
                    c.log(f'[RD Pack] selectFiles timeout ({attempt + 1}/3)')
                    if not _interruptible_sleep(2):
                        return None
                else:
                    c.log(f'[RD Pack] selectFiles failed: {exc}', 1)
                    return None

        if select_response is None or select_response.status_code not in (202, 204):
            code = select_response.status_code if select_response is not None else 'N/A'
            c.log(f'[RD Pack] selectFiles failed: {code}', 1)
            return None

        if not _interruptible_sleep(STATUS_CHECK_DELAY):
            return None

        info_response = requests.get(info_url, headers=headers, timeout=DEBRID_API_TIMEOUT)
        if info_response.status_code == 429:
            return None
        torrent_info = info_response.json() or {}
        status = torrent_info.get('status')
        c.log(f'[RD Pack] Status: {status}, progress: {torrent_info.get("progress", 0)}%')

        if status in ('downloading', 'queued', 'magnet_conversion', 'waiting_files_selection'):
            c.log(f'[RD Pack] Not cached (status={status})  -  try next source', 1)
            return None
        if status == 'error':
            c.log('[RD Pack] RD error status', 1)
            return None

        links = torrent_info.get('links') or []
        if not links:
            c.log('[RD Pack] No download links', 1)
            return None

        updated_files = torrent_info.get('files') or []
        selected_files_ordered = [f for f in updated_files if f.get('selected') == 1]
        link_index = None
        for i, row in enumerate(selected_files_ordered):
            if row.get('id') == matched_file.get('id'):
                link_index = i
                break

        if link_index is None:
            c.log(
                f'[RD Pack] Matched file not in selected set '
                f'({len(selected_files_ordered)} selected)  -  will not use links[0]',
                1,
            )
            if _reselect:
                c.log('[RD Pack] Already reselected once  -  abort', 1)
                return None
            try:
                requests.delete(
                    f'{base_url}/torrents/delete/{torrent_id}',
                    headers=headers,
                    timeout=DEBRID_API_TIMEOUT,
                )
            except Exception as exc:
                c.log(f'[RD Pack] delete for reselect failed: {exc}', 1)
                return None
            if not _interruptible_sleep(1):
                return None
            return resolve_pack_realdebrid(
                magnet_url, season, episode, progressDialog=progressDialog, _reselect=True
            )

        if link_index >= len(links):
            c.log(f'[RD Pack] link index {link_index} out of range', 1)
            return None

        unrestrict_response = requests.post(
            f'{base_url}/unrestrict/link',
            data={'link': links[link_index]},
            headers=headers,
            timeout=DEBRID_API_TIMEOUT,
        )
        if unrestrict_response.status_code == 429:
            return None
        if unrestrict_response.status_code != 200:
            c.log(f'[RD Pack] unrestrict failed: {unrestrict_response.status_code}', 1)
            return None

        unrestrict_info = unrestrict_response.json() or {}
        download_url = unrestrict_info.get('download')
        resolved_filename = unrestrict_info.get('filename') or ''
        if not download_url:
            return None

        if resolved_filename and not source_utils.seas_ep_filter(season, episode, resolved_filename):
            c.log(
                f'[RD Pack] MISMATCH: resolved "{resolved_filename}" does not match '
                f'S{season:02d}E{episode:02d}  -  aborting',
                1,
            )
            return None

        preferred = source_utils._preferred_pack_langs()
        if (
            resolved_filename
            and source_utils.pack_path_language_score(resolved_filename, preferred) < 0
            and source_utils.pack_path_language_score(matched_file.get('path') or '', preferred) >= 0
        ):
            c.log(
                f'[RD Pack] LANGUAGE MISMATCH: resolved "{resolved_filename}" vs preferred '
                f'{preferred}  -  aborting',
                1,
            )
            return None

        c.log(f'[RD Pack] Successfully resolved: {resolved_filename or download_url[:80]}')
        return download_url
    except requests.RequestException as exc:
        c.log(f'[RD Pack] Network error: {exc}', 1)
        return None
    except Exception as exc:
        c.log(f'[RD Pack] Exception: {exc}', 1)
        if c.devmode:
            c.log(traceback.format_exc(), 1)
        return None


def resolve_pack_alldebrid(magnet_url, season, episode, progressDialog=None):
    '''Resolve pack via AllDebrid API with S/E file pick.'''
    c.log(f'[AD Pack] Starting for S{season:02d}E{episode:02d}')
    try:
        ad_token = _token('AllDebridResolver_token')
        if not ad_token:
            c.log('[AD Pack] No AllDebrid token in ResolveURL', 1)
            return None

        ad_auth = {'agent': 'thecrew', 'apikey': ad_token}
        base_v4 = 'https://api.alldebrid.com/v4'

        add_response = requests.post(
            f'{base_v4}/magnet/upload',
            params=ad_auth,
            data={'magnets[]': magnet_url},
            timeout=DEBRID_API_TIMEOUT,
        )
        if add_response.status_code != 200:
            c.log(f'[AD Pack] magnet/upload failed: {add_response.status_code}', 1)
            return None
        add_data = add_response.json() or {}
        if add_data.get('status') != 'success':
            c.log(f'[AD Pack] magnet/upload error: {add_data}', 1)
            return None

        magnet_obj = (add_data.get('data') or {}).get('magnets', [{}])[0]
        if 'error' in magnet_obj:
            c.log(f'[AD Pack] Magnet error: {magnet_obj.get("error")}', 1)
            return None
        magnet_id = magnet_obj.get('id')
        if not magnet_obj.get('ready', False):
            c.log('[AD Pack] Not cached (ready=False)', 1)
            return None

        files_response = requests.post(
            f'{base_v4}/magnet/files',
            params=ad_auth,
            data={'id[]': magnet_id},
            timeout=DEBRID_API_TIMEOUT,
        )
        if files_response.status_code != 200:
            c.log(f'[AD Pack] magnet/files failed: {files_response.status_code}', 1)
            return None
        files_data = files_response.json() or {}
        if files_data.get('status') != 'success':
            c.log(f'[AD Pack] files fetch failed: {files_data}', 1)
            return None

        files_tree = (files_data.get('data') or {}).get('magnets', [{}])[0].get('files') or []

        def _flatten(nodes, prefix=''):
            result = []
            for node in nodes:
                name = node.get('n') or ''
                path = f'{prefix}/{name}' if prefix else name
                if 'e' in node:
                    result.extend(_flatten(node['e'], path))
                elif 'l' in node:
                    result.append({
                        'filename': name,
                        'path': path,
                        'link': node['l'],
                        'size': node.get('s', 0),
                    })
            return result

        all_files = _flatten(files_tree)
        matched_files = _filter_video_matches(all_files, season, episode, path_key='path')
        if not matched_files:
            # Also try basename-only for seas_ep when path folders confuse
            matched_files = []
            for item in all_files:
                check = item.get('path') or item.get('filename') or ''
                if source_utils.seas_ep_filter(season, episode, check):
                    matched_files.append(item)
            if matched_files:
                non_sample = [
                    f for f in matched_files
                    if not any(
                        x in (f.get('path') or f.get('filename') or '').lower()
                        for x in ('sample', 'proof', '-trailer')
                    )
                ]
                matched_files = non_sample or matched_files

        if not matched_files:
            c.log('[AD Pack] No matching episode file found', 1)
            return None

        matched_file = source_utils.pick_best_pack_file(
            matched_files, path_key='path', size_key='size'
        )
        if not matched_file or not matched_file.get('link'):
            return None
        c.log(f'[AD Pack] Selected: {matched_file.get("path") or matched_file.get("filename")}')

        unrestrict_response = requests.post(
            f'{base_v4}/link/unlock',
            params=ad_auth,
            data={'link': matched_file['link']},
            timeout=DEBRID_API_TIMEOUT,
        )
        if unrestrict_response.status_code != 200:
            c.log(f'[AD Pack] unlock failed: {unrestrict_response.status_code}', 1)
            return None
        unrestrict_data = unrestrict_response.json() or {}
        if unrestrict_data.get('status') != 'success':
            c.log(f'[AD Pack] unlock error: {unrestrict_data}', 1)
            return None
        download_url = (unrestrict_data.get('data') or {}).get('link')
        if download_url:
            c.log('[AD Pack] Successfully resolved pack file')
            return download_url
        return None
    except requests.RequestException as exc:
        c.log(f'[AD Pack] Network error: {exc}', 1)
        return None
    except Exception as exc:
        c.log(f'[AD Pack] Exception: {exc}', 1)
        if c.devmode:
            c.log(traceback.format_exc(), 1)
        return None


def resolve_pack_premiumize(magnet_url, season, episode, progressDialog=None):
    '''Resolve pack via Premiumize directdl with S/E file pick.'''
    c.log(f'[PM Pack] Starting for S{season:02d}E{episode:02d}')
    try:
        pm_token = _token('PremiumizeMeResolver_token')
        if not pm_token:
            c.log('[PM Pack] No Premiumize token in ResolveURL', 1)
            return None

        base_url = 'https://www.premiumize.me/api'
        headers = {'Authorization': f'Bearer {pm_token}'}
        btih_match = re.search(r'btih:([0-9a-fA-F]{32,40})', magnet_url or '', re.I)
        if not btih_match:
            c.log('[PM Pack] No btih in magnet', 1)
            return None
        btih_hash = btih_match.group(1).lower()

        cache_response = requests.get(
            f'{base_url}/cache/check',
            params={'items[]': btih_hash},
            headers=headers,
            timeout=DEBRID_API_TIMEOUT,
        )
        if cache_response.status_code != 200:
            c.log(f'[PM Pack] cache/check failed: {cache_response.status_code}', 1)
            return None
        cache_data = cache_response.json() or {}
        if cache_data.get('status') != 'success':
            c.log(f'[PM Pack] cache/check error: {cache_data}', 1)
            return None
        if not (cache_data.get('response') or [False])[0]:
            c.log('[PM Pack] Not cached', 1)
            return None

        directdl_response = requests.post(
            f'{base_url}/transfer/directdl',
            data={'src': magnet_url},
            headers=headers,
            timeout=DEBRID_API_TIMEOUT,
        )
        if directdl_response.status_code != 200:
            c.log(f'[PM Pack] directdl failed: {directdl_response.status_code}', 1)
            return None
        directdl_data = directdl_response.json() or {}
        if directdl_data.get('status') != 'success':
            c.log(f'[PM Pack] directdl error: {directdl_data}', 1)
            return None

        content = []
        for item in directdl_data.get('content') or []:
            path = item.get('path') or ''
            name = path.rsplit('/', 1)[-1] if '/' in path else path
            content.append({
                'name': name,
                'path': path or name,
                'size': item.get('size', 0),
                'link': item.get('stream_link') or item.get('link') or '',
            })

        matched_files = _filter_video_matches(content, season, episode, path_key='path')
        if not matched_files:
            c.log('[PM Pack] No matching episode file found', 1)
            return None

        matched_file = source_utils.pick_best_pack_file(
            matched_files, path_key='path', size_key='size'
        )
        download_url = (matched_file or {}).get('link')
        if download_url:
            c.log(
                f'[PM Pack] Successfully resolved: '
                f'{matched_file.get("path") or matched_file.get("name")}'
            )
            return download_url
        return None
    except requests.RequestException as exc:
        c.log(f'[PM Pack] Network error: {exc}', 1)
        return None
    except Exception as exc:
        c.log(f'[PM Pack] Exception: {exc}', 1)
        if c.devmode:
            c.log(traceback.format_exc(), 1)
        return None

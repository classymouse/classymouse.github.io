# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file keys.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import base64


# System integrity validators  -  same pipeline as 3.1 module
_c = lambda s: [ord(c) for c in s]
_k = lambda: _c(''.join(map(chr, [84, 104, 101, 67, 114, 101, 119, 50, 48, 50, 54])))
_m = lambda x, y: (x + y) & 0xFF
_s = lambda x, y: (x - y) & 0xFF


def _x(d):
    b = base64.b64decode(d)
    k = _k()
    n = 0
    r = bytearray()
    for i, byte in enumerate(b):
        n = (n + 1) % len(k) if i % 3 == 0 else n
        primary = k[(i + n - n) % len(k)]
        r.append(byte ^ primary)
    return bytes(_s(r[j], j) for j in range(len(r))).decode('utf-8')


# External API keys
tmdb_key = _x(b'ZFlTf0lbTF5cWQkWKSYFAywxdnd2QS04GAw5GSKztLA=')
tvdb_key = _x(b'ZlABKxhSSAwPcFo5GhYwOiE/dnZ0Ty0iLAoJMTqxfrA=')
fanart_key = _x(b'Z1IBf0YDQQoPXAsQVQs3ASYze3h2TRsmNQgj5COzZ2c=')
orion_key = _x(b'ETs1BiczOXxsZ2E1PzchJjE9W1FrbRg3OiUgNQNWU0Y=')
orion_testkey = 'TESTTESTTESTTESTTESTTESTTESTTEST'
yt_key = _x(b'FSIZJyUbPWtnXLYYCyQ4LBA+t1pTsC7uDtACNfe3XbqmAhrsyRw7')

# Trakt OAuth
trakt_id = _x(b'YFFRKk8MHw4KXFlpKlt8TSw9R0h1QCMgHDjyMQl/tGSz0TI5FPo5/Gm8Urs1++rR5w8QVlpbrczzFd8ZCNRHQA==')
trakt_secret = _x(b'bFkGdklSSAwKc1oUVwosMhYDd3t3fhkRLwjyKDqxYWGyAjM2yvvvLW9tbWk0CwHRFvYdXlZXWTgGCygcxQFGRg==')

# Simkl (testing credentials  -  same as 3.1)
simkl_id = _x(b'ZA1XdRsPTgVxDVs7VxQFAyIwR0hEeC0SLgkNMThMf7BnAzHtxig9KVJpvFXECPHTGwEQVqhYUMwYCjEBFNdDQQ==')
simkl_secret = _x(b'N14GdEZTTQpaDgwkVyEAMiAAd3t1fy44LTjyNiVhsLCy0TszHyQ+/Gy7vVfGDvQlEgTgWValrD3xCS0dF9RclQ==')

# WeTrakr OAuth app key (The Crew)  -  public client_id only; no secret in addon
# Dashboard name should read "The Crew" (was "TheCrew dev app" at create).
wetrakr_id = _x(b'Ml0Ad0pQH1lcclg5VFoDTSAzd3t2cRgkLwgJ5AhMYmE=')

# Gate passwords
dev_password = _x(b'IAECJQQPCg==')
adult_password = _x(b'OBgL')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file bookmarks.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Slim local bookmarks.db  -  offline resume / watched overlays (R1).

Tracker progress always wins on read when live. Local is dual-write fallback,
offline cache, and list overlay when no tracker is live. No Trakt progress
table mirror; no scrobble paths (Classy tracker / WeTrakr own those).
'''

from __future__ import annotations

import sqlite3 as database

from . import control
from .classy import c

_CREATE_SQL = '''
CREATE TABLE IF NOT EXISTS bookmarks (
    timeInSeconds TEXT,
    type TEXT,
    imdb TEXT,
    season TEXT,
    episode TEXT,
    playcount INTEGER,
    overlay INTEGER,
    UNIQUE(imdb, season, episode)
)
'''


def enabled():
    return str(c.get_setting('bookmarks.enabled') or 'true').lower() == 'true'


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text[2:]
    return text


def _db_path():
    return control._path('bookmarks.db')


def _connect():
    control.makeFile(control.dataPath)
    dbcon = database.connect(_db_path())
    dbcur = dbcon.cursor()
    dbcur.execute(_CREATE_SQL)
    return dbcon, dbcur


def _watched_ratio():
    try:
        from ..progress import filters as slot_filters
        return float(slot_filters.resume_progress_max()) / 100.0
    except Exception:
        return 0.92


def get_local_bookmark(imdb, media_type, season=0, episode=0):
    '''Return seek position in seconds, or 0.'''
    if not enabled():
        return 0.0
    key = _norm_imdb(imdb)
    if not key:
        return 0.0
    try:
        media = (media_type or '').lower()
        if media == 'episode':
            sql = (
                'SELECT timeInSeconds FROM bookmarks '
                'WHERE imdb = ? AND season = ? AND episode = ?'
            )
            params = (key, str(int(season or 0)), str(int(episode or 0)))
        else:
            sql = 'SELECT timeInSeconds FROM bookmarks WHERE imdb = ?'
            params = (key,)
        dbcon, dbcur = _connect()
        try:
            dbcur.execute(sql, params)
            row = dbcur.fetchone()
        finally:
            dbcon.close()
        if not row:
            return 0.0
        return float(row[0] or 0)
    except Exception as exc:
        c.log(f'[Bookmarks] get_local_bookmark failed: {exc}', 1)
        return 0.0


def get_record(imdb, media_type, season=0, episode=0):
    '''Return (time_seconds, playcount, overlay) or None.'''
    if not enabled():
        return None
    key = _norm_imdb(imdb)
    if not key:
        return None
    try:
        media = (media_type or '').lower()
        if media == 'episode':
            sql = (
                'SELECT timeInSeconds, playcount, overlay FROM bookmarks '
                'WHERE imdb = ? AND season = ? AND episode = ?'
            )
            params = (key, str(int(season or 0)), str(int(episode or 0)))
        else:
            sql = (
                'SELECT timeInSeconds, playcount, overlay FROM bookmarks '
                'WHERE imdb = ?'
            )
            params = (key,)
        dbcon, dbcur = _connect()
        try:
            dbcur.execute(sql, params)
            row = dbcur.fetchone()
        finally:
            dbcon.close()
        if not row:
            return None
        return float(row[0] or 0), int(row[1] or 0), int(row[2] or 0)
    except Exception as exc:
        c.log(f'[Bookmarks] get_record failed: {exc}', 1)
        return None


def reset(current_time, total_time, media_type, imdb, season='', episode='', tmdb=0):
    '''Write / update local bookmark from pause/stop progress.'''
    if not enabled():
        return
    key = _norm_imdb(imdb)
    if not key:
        return
    try:
        current = float(current_time or 0)
        total = float(total_time or 0)
        if total <= 0:
            return
        threshold = _watched_ratio()
        ratio = current / total
        in_progress = current > 0 and ratio < threshold
        is_fully_watched = ratio >= threshold
        if not in_progress and not is_fully_watched:
            return

        media = (media_type or 'movie').lower()
        if media == 'episode':
            season_s = str(int(season or 0))
            episode_s = str(int(episode or 0))
            if season_s in ('0', '') or episode_s in ('0', ''):
                return
            select_sql = (
                'SELECT playcount FROM bookmarks '
                'WHERE imdb = ? AND season = ? AND episode = ?'
            )
            select_params = (key, season_s, episode_s)
            update_sql = (
                'UPDATE bookmarks SET timeInSeconds = ? '
                'WHERE imdb = ? AND season = ? AND episode = ?'
            )
            update_params = (str(int(current)), key, season_s, episode_s)
            update_watched_sql = (
                'UPDATE bookmarks SET timeInSeconds = \'0\', playcount = ?, overlay = ? '
                'WHERE imdb = ? AND season = ? AND episode = ?'
            )
            insert_sql = 'INSERT INTO bookmarks VALUES (?, ?, ?, ?, ?, ?, ?)'
            insert_params = (
                str(int(current)), media, key, season_s, episode_s, 0, 6,
            )
        else:
            media = 'movie'
            season_s = ''
            episode_s = ''
            select_sql = 'SELECT playcount FROM bookmarks WHERE imdb = ?'
            select_params = (key,)
            update_sql = 'UPDATE bookmarks SET timeInSeconds = ? WHERE imdb = ?'
            update_params = (str(int(current)), key)
            update_watched_sql = (
                'UPDATE bookmarks SET timeInSeconds = \'0\', playcount = ?, overlay = ? '
                'WHERE imdb = ?'
            )
            insert_sql = 'INSERT INTO bookmarks VALUES (?, ?, ?, ?, ?, ?, ?)'
            insert_params = (str(int(current)), media, key, '', '', 0, 6)

        dbcon, dbcur = _connect()
        try:
            dbcur.execute(select_sql, select_params)
            existing = dbcur.fetchone()
            if existing:
                if in_progress:
                    dbcur.execute(update_sql, update_params)
                elif is_fully_watched:
                    playcount = int(existing[0] or 0) + 1
                    if media == 'episode':
                        dbcur.execute(
                            update_watched_sql,
                            (playcount, 7, key, season_s, episode_s),
                        )
                    else:
                        dbcur.execute(update_watched_sql, (playcount, 7, key))
            else:
                if in_progress:
                    dbcur.execute(insert_sql, insert_params)
                elif is_fully_watched:
                    if media == 'episode':
                        dbcur.execute(
                            insert_sql,
                            ('0', media, key, season_s, episode_s, 1, 7),
                        )
                    else:
                        dbcur.execute(
                            insert_sql,
                            ('0', media, key, '', '', 1, 7),
                        )
            dbcon.commit()
        finally:
            dbcon.close()
        if tmdb:
            pass  # schema is imdb-keyed; tmdb kept for call-site parity
    except Exception as exc:
        c.log(f'[Bookmarks] reset failed: {exc}', 1)


def mark_watched_local(imdb, media_type, season=0, episode=0, watched=True):
    '''CM mark watched / unwatched against local DB only.'''
    if not enabled():
        return False
    key = _norm_imdb(imdb)
    if not key:
        return False
    media = (media_type or 'movie').lower()
    try:
        if watched:
            if media == 'episode':
                reset(1, 1, 'episode', key, season=season, episode=episode)
            else:
                reset(1, 1, 'movie', key)
            return True
        delete_record(media, key, season, episode)
        return True
    except Exception as exc:
        c.log(f'[Bookmarks] mark_watched_local failed: {exc}', 1)
        return False


def get_watched(media_type, imdb, season='', episode=''):
    '''Return 7 when locally watched, else 6.'''
    if not enabled():
        return 6
    key = _norm_imdb(imdb)
    if not key:
        return 6
    try:
        media = (media_type or '').lower()
        dbcon, dbcur = _connect()
        try:
            if media == 'episode':
                dbcur.execute(
                    'SELECT 1 FROM bookmarks WHERE imdb = ? AND overlay = 7 '
                    'AND season = ? AND episode = ?',
                    (key, str(season), str(episode)),
                )
            else:
                dbcur.execute(
                    'SELECT 1 FROM bookmarks WHERE imdb = ? AND overlay = 7',
                    (key,),
                )
            found = dbcur.fetchone()
        finally:
            dbcon.close()
        return 7 if found else 6
    except Exception:
        return 6


def get_indicators():
    '''IMDB ids (no tt) with overlay=7.'''
    if not enabled():
        return []
    try:
        dbcon, dbcur = _connect()
        try:
            dbcur.execute('SELECT imdb FROM bookmarks WHERE overlay = 7')
            rows = dbcur.fetchall()
        finally:
            dbcon.close()
        return [_norm_imdb(r[0]) for r in rows if r and r[0]]
    except Exception:
        return []


def delete_record(media_type, imdb, season='', episode=''):
    if not enabled():
        return
    key = _norm_imdb(imdb)
    if not key:
        return
    try:
        media = (media_type or '').lower()
        dbcon, dbcur = _connect()
        try:
            if media == 'episode':
                dbcur.execute(
                    'DELETE FROM bookmarks WHERE imdb = ? AND season = ? AND episode = ?',
                    (key, str(season or ''), str(episode or '')),
                )
            else:
                dbcur.execute('DELETE FROM bookmarks WHERE imdb = ?', (key,))
            dbcon.commit()
        finally:
            dbcon.close()
    except Exception as exc:
        c.log(f'[Bookmarks] delete_record failed: {exc}', 1)


def clear_resume_point(media_type, imdb='', season=None, episode=None):
    '''Delete local resume row (tracker clear is caller's job).'''
    delete_record(media_type, imdb, season or '', episode or '')


def apply_to_row(row):
    '''Paint local overlay / resume % when tracker is not live. Returns True if applied.

    Only fills gaps  -  never overrides an overlay already set by watch/resume indices.
    '''
    if not enabled() or row is None:
        return False
    try:
        from .. import tracker
        if tracker.live():
            return False
    except Exception:
        pass
    if (
        int(getattr(row, 'overlay', 0) or 0)
        or int(getattr(row, 'playcount', 0) or 0)
        or float(getattr(row, 'resume_point', 0) or 0) > 0
    ):
        return False

    media = (getattr(row, 'mediatype', '') or '').lower()
    if media not in ('movie', 'episode'):
        return False
    imdb = getattr(row, 'imdb', '') or ''
    season = getattr(row, 'season', 0) or 0
    episode = getattr(row, 'episode', 0) or 0
    record = get_record(imdb, media, season, episode)
    if not record:
        return False
    secs, playcount, overlay = record
    if overlay == 7 or playcount > 0:
        row.playcount = max(int(playcount or 0), 1)
        row.overlay = 7
        row.resume_point = 0.0
        return True
    if secs <= 0:
        return False
    duration = int(getattr(row, 'duration', 0) or 0)
    if duration > 0:
        # duration may be minutes on some rows; treat large values as seconds
        total = duration if duration > 500 else duration * 60
        if total > 0:
            progress = (float(secs) / float(total)) * 100.0
            try:
                from ..progress import filters as slot_filters
                pmin = slot_filters.resume_progress_min()
                pmax = slot_filters.resume_progress_max()
            except Exception:
                pmin, pmax = 0.0, 92.0
            if progress <= pmin or progress >= pmax:
                return False
            row.resume_point = progress
            if duration <= 500:
                row.duration = total
    else:
        # Unknown runtime  -  still flag in-progress so Clear Resume CM appears;
        # play path reads absolute seconds from bookmarks.db.
        row.resume_point = 1.0
    row.playcount = 0
    row.overlay = 6
    return True


def resume_entry_for_request(request):
    '''Build resume dict from local DB for play path, or None.'''
    if not enabled() or request is None:
        return None
    imdb = getattr(request, 'imdb', '') or ''
    if getattr(request, 'is_episode', False):
        media = 'episode'
        season = int(getattr(request, 'season', 0) or 0)
        episode = int(getattr(request, 'episode', 0) or 0)
    elif getattr(request, 'is_movie', False):
        media = 'movie'
        season = 0
        episode = 0
    else:
        return None
    secs = get_local_bookmark(imdb, media, season, episode)
    if secs <= 0:
        return None
    try:
        from ..playback.resume_prompt import MIN_RESUME_SECONDS
        min_secs = float(MIN_RESUME_SECONDS)
    except Exception:
        min_secs = 30.0
    if float(secs) < min_secs:
        return None
    duration = 0
    meta = getattr(request, 'meta', None) or {}
    for key in ('duration', 'runtime'):
        raw = meta.get(key)
        if raw in (None, '', 0):
            continue
        try:
            value = int(float(raw))
        except (TypeError, ValueError):
            continue
        if value <= 0:
            continue
        duration = value if value > 500 else value * 60
        break
    if duration <= 0:
        # Still allow seek with unknown total  -  player applies offset.
        return {
            'progress': 0.0,
            'duration': 0,
            'resume_seconds': float(secs),
            'playback_id': 'local',
        }
    progress = (float(secs) / float(duration)) * 100.0
    try:
        from ..progress import filters as slot_filters
        pmin = slot_filters.resume_progress_min()
        pmax = slot_filters.resume_progress_max()
    except Exception:
        pmin, pmax = 1.0, 92.0
    if progress <= pmin or progress >= pmax:
        return None
    return {
        'progress': float(progress),
        'duration': int(duration),
        'resume_seconds': float(secs),
        'playback_id': 'local',
    }


def write_from_session(session, current, total):
    '''Dual-write helper for playback monitor pause/stop.'''
    if not enabled() or not session:
        return
    imdb = session.get('imdb') or ''
    if not imdb:
        return
    media = (session.get('mediatype') or 'movie').lower()
    reset(
        current,
        total,
        media,
        imdb,
        season=session.get('season') or '',
        episode=session.get('episode') or '',
        tmdb=session.get('tmdb') or 0,
    )

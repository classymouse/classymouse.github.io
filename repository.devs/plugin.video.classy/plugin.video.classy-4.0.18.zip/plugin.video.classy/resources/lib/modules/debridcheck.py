# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debridcheck.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Debrid cache probes  -  TB / AD / PM instant-cache labeling for source lists.'''

from __future__ import annotations

import datetime
import json
import os
import sqlite3 as database
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

import requests

from . import control
from . import debrid_names
from .classy import c

__r_url__ = control.addon('script.module.resolveurl')


def _chunks(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


# SQLite bind limit is 999; stay safely under for IN (...) queries.
_SQL_IN_CHUNK = 400

# Live API probes per scrape per service  -  rest stay unlabeled (uncached chip).
_LIVE_CHECK_CAP = 80
_TB_LIVE_CHECK_CAP = _LIVE_CHECK_CAP  # back-compat alias


def _tb_entry_cached(entry: Any) -> bool:
    if entry is None:
        return False
    if isinstance(entry, list):
        return len(entry) > 0
    if isinstance(entry, dict):
        return True
    return bool(entry)


def _ru_enabled(enabled_id, token_id):
    try:
        r = __r_url__
        return r.getSetting(enabled_id) == 'true' and bool(r.getSetting(token_id))
    except Exception:
        return False


def _ru_token(token_id):
    try:
        return __r_url__.getSetting(token_id) or ''
    except Exception:
        return ''


class TBapi:
    _BATCH_SIZE = 10

    def __init__(self):
        self.base_url = 'https://api.torbox.app/v1/api/'
        self.token = _ru_token('TorBoxResolver_apikey')

    def check_cache(self, hashes: List[str], timeout=30) -> Optional[Dict[str, bool]]:
        '''Return {hash: is_cached}.'''
        if not self.token:
            c.log('[debridcheck] TB: no API key in ResolveURL')
            return None
        if not hashes:
            return {}

        normalized = [h.lower() for h in hashes if h]
        merged: Dict[str, bool] = {}
        chunks = list(_chunks(normalized, self._BATCH_SIZE))
        for i, chunk in enumerate(chunks):
            batch = self._check_cache_batch(chunk, timeout=timeout)
            if batch is None:
                return None
            merged.update(batch)
            if i + 1 < len(chunks):
                time.sleep(0.05)
        return merged

    def _check_cache_batch(self, hashes: List[str], timeout=30) -> Optional[Dict[str, bool]]:
        try:
            url = self.base_url + 'torrents/checkcached'
            headers = {'Authorization': f'Bearer {self.token}'}
            params = {
                'hash': ','.join(hashes),
                'format': 'object',
                'list_files': 'false',
            }
            response = requests.get(url, params=params, headers=headers, timeout=timeout)
            data = json.loads(response.text)
            if data and data.get('success'):
                raw = data.get('data', {}) or {}
                return {h: _tb_entry_cached(raw.get(h)) for h in hashes}
            c.log(f'[debridcheck] TB check_cache failed: {data}', 1)
            return None
        except requests.exceptions.Timeout:
            if len(hashes) == 1:
                return None
            c.log('[debridcheck] TB batch timed out - checking hashes individually', 1)
            merged: Dict[str, bool] = {}
            for h in hashes:
                single = self._check_cache_batch([h], timeout=timeout)
                if single is None:
                    return None
                merged.update(single)
                time.sleep(0.3)
            return merged
        except Exception as exc:
            c.log(f'[debridcheck] TB check_cache error: {exc}', 1)
            return None


class PMapi:
    '''Premiumize.me /cache/check (ResolveURL token).'''

    _BATCH_SIZE = 40

    def __init__(self):
        self.base_url = 'https://www.premiumize.me/api/cache/check'
        self.token = _ru_token('PremiumizeMeResolver_token')

    def check_cache(self, hashes: List[str], timeout=30) -> Optional[Dict[str, bool]]:
        if not self.token:
            c.log('[debridcheck] PM: no token in ResolveURL')
            return None
        if not hashes:
            return {}

        normalized = [h.lower() for h in hashes if h]
        merged: Dict[str, bool] = {}
        chunks = list(_chunks(normalized, self._BATCH_SIZE))
        for i, chunk in enumerate(chunks):
            batch = self._check_cache_batch(chunk, timeout=timeout)
            if batch is None:
                return None
            merged.update(batch)
            if i + 1 < len(chunks):
                time.sleep(0.05)
        return merged

    def _check_cache_batch(self, hashes: List[str], timeout=30) -> Optional[Dict[str, bool]]:
        try:
            headers = {
                'User-Agent': 'The Crew/4.0',
                'Authorization': f'Bearer {self.token}',
            }
            params = [('items[]', h) for h in hashes]
            response = requests.get(
                self.base_url, params=params, headers=headers, timeout=timeout,
            )
            data = json.loads(response.text)
            if not data or data.get('status') != 'success':
                c.log(f'[debridcheck] PM check_cache failed: {data}', 1)
                return None
            flags = data.get('response') or []
            out: Dict[str, bool] = {}
            for idx, h in enumerate(hashes):
                flag = flags[idx] if idx < len(flags) else False
                out[h] = bool(flag)
            return out
        except Exception as exc:
            c.log(f'[debridcheck] PM check_cache error: {exc}', 1)
            return None


class ADapi:
    '''AllDebrid cache probe  -  /magnet/instant was removed (404 since ~2025).

    List labeling is not possible without uploading magnets (side effects).
    Kept as a stub so we do not silently mark every AD row uncached.
    '''

    def __init__(self):
        self.token = _ru_token('AllDebridResolver_token')

    def check_cache(self, hashes: List[str], timeout=30) -> Optional[Dict[str, bool]]:
        c.log(
            '[debridcheck] AD: /magnet/instant no longer exists (404) - '
            'skipping list cache labels (use play-time upload/ready instead)',
            1,
        )
        return None


class DebridCache:
    def __init__(self):
        self.dbfile = control.dbFile

    def check_database(self):
        try:
            if not os.path.exists(control.dataPath):
                control.makeFile(control.dataPath)
            with database.connect(self.dbfile) as dbcon:
                dbcur = dbcon.cursor()
                dbcur.execute(
                    '''
                    CREATE TABLE IF NOT EXISTS debrid_data (
                        hash TEXT NOT NULL,
                        debrid TEXT NOT NULL,
                        cached TEXT,
                        expires INTEGER,
                        UNIQUE (hash, debrid)
                    )
                    '''
                )
                dbcon.commit()
        except Exception as exc:
            c.log(f'[debridcheck] check_database error: {exc}', 1)

    def get_all(self, hash_list: List[str]) -> List[Tuple[str, str, bool]]:
        if not hash_list:
            return []
        now = int(time.time())
        out = []
        expired = []
        try:
            with database.connect(self.dbfile, timeout=40.0) as dbcon:
                dbcur = dbcon.cursor()
                for chunk in _chunks(list(hash_list), _SQL_IN_CHUNK):
                    placeholders = ', '.join('?' * len(chunk))
                    dbcur.execute(
                        f'SELECT hash, debrid, cached, expires FROM debrid_data '
                        f'WHERE hash IN ({placeholders})',
                        chunk,
                    )
                    for row in dbcur.fetchall():
                        hash_val, debrid, cached_str, expires = row
                        if int(expires or 0) > now:
                            is_cached = (
                                cached_str == 'True'
                                if isinstance(cached_str, str)
                                else bool(cached_str)
                            )
                            out.append((str(hash_val), str(debrid), is_cached))
                        else:
                            expired.append((hash_val,))
                if expired:
                    dbcur.executemany('DELETE FROM debrid_data WHERE hash=?', expired)
                    dbcon.commit()
        except Exception as exc:
            c.log(f'[debridcheck] get_all error: {exc}', 1)
        return out

    def set_many(self, hash_list: List[Tuple[str, bool]], debrid: str,
                 expiration: datetime.timedelta = datetime.timedelta(hours=1)):
        if not hash_list:
            return
        expires = int(time.mktime((datetime.datetime.now() + expiration).timetuple()))
        rows = [
            (hash_val, debrid, 'True' if is_cached else 'False', expires)
            for hash_val, is_cached in hash_list
        ]
        try:
            with database.connect(self.dbfile, timeout=40.0) as dbcon:
                dbcur = dbcon.cursor()
                dbcur.executemany(
                    'INSERT OR REPLACE INTO debrid_data VALUES (?, ?, ?, ?)',
                    rows,
                )
                dbcon.commit()
        except Exception as exc:
            c.log(f'[debridcheck] set_many error: {exc}', 1)


def torbox_hash_is_cached(info_hash, timeout=8):
    if not info_hash:
        return False
    h = str(info_hash).lower()
    try:
        for row in DebridCache().get_all([h]):
            if len(row) >= 3 and row[1] == 'tb' and row[2]:
                return True
    except Exception:
        pass
    try:
        result = TBapi().check_cache([h], timeout=timeout)
        if not result:
            return False
        cached = bool(result.get(h))
        if cached:
            DebridCache().set_many([(h, True)], 'tb')
        return cached
    except Exception as exc:
        c.log(f'[debridcheck] TorBox fast cache check error: {exc}', 1)
        return False


def _magnet_hash(candidate):
    from ..sources.filters import _magnet_hash as magnet_hash

    return magnet_hash(candidate)


def _debrid_slug_from_resolver(name):
    return debrid_names.slug(name)


def expand_debrid_sources(candidates):
    '''
    Duplicate magnet rows per enabled debrid resolver (Crew parity).

    One scraped magnet becomes one row per service (TB, RD, PM, ...) so the
    source list shows which debrid each link targets.
    '''
    from ..play.models import StreamCandidate
    from . import debrid as debrid_mod

    items = list(candidates or [])
    if not items or not debrid_mod.status(torrent=True):
        return items

    resolvers = debrid_mod.get_debrid_resolvers()
    if not resolvers:
        return items

    expanded = []
    magnets = 0
    for cand in items:
        url = (cand.url or '').strip()
        is_magnet = url.startswith('magnet:') or bool(cand.debridonly)
        if not is_magnet:
            expanded.append(cand)
            continue

        magnets += 1
        for resolver_obj in resolvers:
            name = getattr(resolver_obj, 'name', '') or ''
            slug = _debrid_slug_from_resolver(name)
            if not slug:
                continue
            clone = StreamCandidate.from_dict(cand.to_dict())
            if not clone:
                continue
            raw = dict(clone.raw or {})
            raw['debrid'] = slug
            clone.raw = raw
            expanded.append(clone)

    if magnets:
        c.log(
            f'[debridcheck] expanded {magnets} magnet(s) -> {len(expanded)} rows '
            f'({len(resolvers)} debrid service(s))'
        )
    return expanded or items


def _torbox_enabled():
    return _ru_enabled('TorBoxResolver_enabled', 'TorBoxResolver_apikey')


def _alldebrid_enabled():
    return _ru_enabled('AllDebridResolver_enabled', 'AllDebridResolver_token')


def _premiumize_enabled():
    return _ru_enabled('PremiumizeMeResolver_enabled', 'PremiumizeMeResolver_token')


# db_key, match(raw_debrid), enabled(), api factory
# AD omitted: /magnet/instant is 404; no safe batch alternative for list labeling.
_CACHE_SERVICES = (
    ('tb', debrid_names.is_torbox, _torbox_enabled, TBapi),
    ('pm', debrid_names.is_premiumize, _premiumize_enabled, PMapi),
)


def _unique_hashes(rows):
    hashes = []
    seen = set()
    for _, info_hash in rows:
        if info_hash in seen:
            continue
        seen.add(info_hash)
        hashes.append(info_hash)
    return hashes


def _purge_debrid_db_key(db_key):
    '''Drop poisoned/stale rows for a service (e.g. AD false-uncached from 404).'''
    try:
        db = DebridCache()
        db.check_database()
        with database.connect(db.dbfile, timeout=40.0) as dbcon:
            dbcur = dbcon.cursor()
            dbcur.execute('DELETE FROM debrid_data WHERE debrid=?', (db_key,))
            dbcon.commit()
        c.log(f'[debridcheck] purged local cache rows for {db_key}')
    except Exception as exc:
        c.log(f'[debridcheck] purge {db_key} failed: {exc}', 1)


def _probe_labels(db_key, rows, api_cls, label):
    '''DB + live API  ->  (cached_set, uncached_set). Unknown hashes omitted.'''
    if not rows:
        return set(), set()

    db = DebridCache()
    db.check_database()
    hashes = _unique_hashes(rows)
    cached_set = set()
    uncached_set = set()
    known = set()

    for row in db.get_all(hashes):
        if len(row) < 3 or row[1] != db_key:
            continue
        h = row[0].lower()
        known.add(h)
        if row[2]:
            cached_set.add(h)
        else:
            uncached_set.add(h)

    unchecked = [h for h in hashes if h not in known]
    if not unchecked:
        c.log(
            f'[debridcheck] {label} scrape labels: {len(cached_set)} cached / '
            f'{len(uncached_set)} uncached of {len(rows)} rows (db only)'
        )
        return cached_set, uncached_set

    api_batch = unchecked[:_LIVE_CHECK_CAP]
    skipped = len(unchecked) - len(api_batch)
    try:
        result = api_cls().check_cache(api_batch)
        if result is None:
            c.log(
                f'[debridcheck] {label} live check failed  -  leaving '
                f'{len(api_batch)} hash(es) unlabeled (not marking uncached)',
                1,
            )
        else:
            store = []
            for info_hash in api_batch:
                is_cached = bool(result.get(info_hash.lower()))
                store.append((info_hash, is_cached))
                if is_cached:
                    cached_set.add(info_hash)
                else:
                    uncached_set.add(info_hash)
            if store:
                db.set_many(store, db_key)
            extra = f', skipped {skipped} (cap)' if skipped else ''
            c.log(
                f'[debridcheck] {label} scrape labels: {len(cached_set)} cached / '
                f'{len(uncached_set)} uncached of {len(rows)} rows{extra}'
            )
    except Exception:
        c.log(f'[debridcheck] {label} annotate failed:\n{traceback.format_exc()}', 1)
    return cached_set, uncached_set


_AD_PURGE_DONE = False


def _cache_check_enabled():
    '''``check.torr.cache``  -  default off (Crew parity).'''
    try:
        from .classy import c
        return str(c.get_setting('check.torr.cache') or '').lower() == 'true'
    except Exception:
        return False


def _stamp_unknown_magnets(candidates):
    '''Honest UNKNOWN for magnet rows we did not label cached/uncached.'''
    out = []
    for cand in candidates or []:
        raw = dict(cand.raw or {})
        url = str(getattr(cand, 'url', None) or raw.get('url') or '')
        source = str(cand.source or raw.get('source') or '').strip().lower()
        if url.startswith('magnet:') and source in ('', 'torrent', 'magnet', 'pack'):
            cand.source = 'unknown torrent'
            raw['source'] = 'unknown torrent'
            cand.raw = raw
        out.append(cand)
    return out


def annotate_debrid_cache(candidates):
    '''Label TB/PM rows cached/uncached; cached first. AD has no list cache API.

    When ``check.torr.cache`` is off, return candidates unchanged.
    When on: probe TB/PM; stamp remaining magnets as unknown torrent (not uncached).
    '''
    global _AD_PURGE_DONE
    items = list(candidates or [])
    if not items:
        return items

    if not _cache_check_enabled():
        return items

    # One-shot: clear AD rows falsely stored as uncached while instant 404'd.
    if not _AD_PURGE_DONE:
        _purge_debrid_db_key('ad')
        _AD_PURGE_DONE = True

    active = []
    for db_key, match, enabled, api_cls in _CACHE_SERVICES:
        if enabled():
            active.append((db_key, match, api_cls))
    if not active:
        return _stamp_unknown_magnets(items)

    buckets = {db_key: [] for db_key, _, _ in active}
    other = []

    for cand in items:
        raw = cand.raw or {}
        debrid = raw.get('debrid', '')
        placed = False
        for db_key, match, _api_cls in active:
            if not match(debrid):
                continue
            info_hash = _magnet_hash(cand)
            if info_hash:
                raw = dict(raw)
                raw['info_hash'] = info_hash
                cand.raw = raw
                buckets[db_key].append((cand, info_hash))
            else:
                other.append(cand)
            placed = True
            break
        if not placed:
            other.append(cand)

    cached_rows = []
    uncached_rows = []
    labels = {'tb': 'TB', 'pm': 'PM'}
    probe_results = {}

    if active:
        with ThreadPoolExecutor(max_workers=min(2, len(active))) as pool:
            futures = {}
            for db_key, _match, api_cls in active:
                rows = buckets.get(db_key) or []
                if not rows:
                    continue
                label = labels.get(db_key, db_key)
                futures[pool.submit(_probe_labels, db_key, rows, api_cls, label)] = db_key
            for fut in as_completed(futures):
                db_key = futures[fut]
                try:
                    probe_results[db_key] = fut.result()
                except Exception:
                    c.log(
                        f'[debridcheck] {labels.get(db_key, db_key)} parallel probe failed',
                        1,
                    )
                    probe_results[db_key] = (set(), set())

    for db_key, _match, api_cls in active:
        rows = buckets.get(db_key) or []
        if not rows:
            continue
        cached_set, uncached_set = probe_results.get(db_key, (set(), set()))
        for cand, info_hash in rows:
            raw = dict(cand.raw or {})
            if info_hash in cached_set:
                cand.source = 'cached torrent'
                raw['source'] = 'cached torrent'
                cached_rows.append(cand)
            elif info_hash in uncached_set:
                cand.source = 'uncached torrent'
                raw['source'] = 'uncached torrent'
                uncached_rows.append(cand)
            else:
                cand.source = 'unknown torrent'
                raw['source'] = 'unknown torrent'
                other.append(cand)
            cand.raw = raw

    return cached_rows + uncached_rows + _stamp_unknown_magnets(other)

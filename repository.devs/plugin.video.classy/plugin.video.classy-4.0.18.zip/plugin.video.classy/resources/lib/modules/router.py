# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file router.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy v4 router  -  dict dispatch, room for hundreds of actions.

Pattern (same spirit as msg_handler.register):
  - register_route(action, handler, dev_only=False)
  - handlers: def handler(params) -> None
  - domain tables live in resources/lib/routes/*.py

No call_module magic. Explicit imports only.'''

import traceback

from .classy import c
from . import kodi


_ROUTES = {}
_ROUTES_LOADED = False


def register_route(action, handler, dev_only=False):
    """
    Register an action handler.

    action: str (use '' for default/root)
    handler: callable(params)
    dev_only: when True, blocked unless c.is_devmode()
    """
    key = '' if action is None else str(action)
    _ROUTES[key] = {
        'handler': handler,
        'dev_only': bool(dev_only),
    }


def register_route_alias(action, canonical_action):
    '''Legacy Crew action name  ->  same handler as canonical (3.x episode CM, widgets).'''
    canonical = '' if canonical_action is None else str(canonical_action)
    entry = _ROUTES.get(canonical)
    if not entry:
        raise ValueError(f'register_route_alias: unknown canonical action {canonical!r}')
    register_route(action, entry['handler'], dev_only=entry['dev_only'])


def route_registered(action):
    '''True when an action handler is registered (loads route tables on first call).'''
    _ensure_routes_loaded()
    key = '' if action is None else str(action)
    return key in _ROUTES


def _ensure_routes_loaded():
    global _ROUTES_LOADED
    if _ROUTES_LOADED:
        return
    from .. import routes  # noqa: F401  -  side effect: register_route calls
    _ROUTES_LOADED = True


def router(params):
    _ensure_routes_loaded()

    if params is None:
        params = {}
    if c.is_devmode():
        c.log(f'Router called with params: {params}')

    action = params.get('action', '')
    if action is None:
        action = ''

    entry = _ROUTES.get(action)
    if not entry:
        if action:
            c.log(f'Unknown action: {action}')
        else:
            # Should not happen if '' is registered
            c.log('Router: no handler for default action')
        return

    if entry['dev_only'] and not c.is_devmode():
        kodi.notification('The Crew', 'Dev password required')
        return

    try:
        return entry['handler'](params)
    except Exception as exc:
        c.log(f'Router handler failed action={action!r}: {exc}', 1)
        c.log(traceback.format_exc(), 1)
        raise

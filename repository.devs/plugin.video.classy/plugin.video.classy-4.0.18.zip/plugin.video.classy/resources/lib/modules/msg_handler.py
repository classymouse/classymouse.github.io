# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file msg_handler.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy v4  -  ONE msg_handler to rule them all.

Single entry: handle(ctx)  ->  Action

Add new APIs via register(api, handler) at the bottom EXTENSION block,
or append a _handle_* section in this file. Do not scatter status-code
logic in indexers, client, or service.'''

from . import http_policy
from .classy import c


# --- API identifiers (extend as needed) ------------------------------------
API_TRAKT = 'trakt'
API_TMDB = 'tmdb'
API_FANART = 'fanart'
API_TVDB = 'tvdb'
API_SIMKL = 'simkl'
API_WETRAKR = 'wetrakr'
API_MDBLIST = 'mdblist'
API_SCRAPER = 'scraper'
API_GENERIC = 'generic'


# --- Outcomes --------------------------------------------------------------
class Action:
    FAIL = 'fail'
    RETRY_ONCE = 'retry_once'
    REFRESH_AUTH = 'refresh_auth'


class MessageContext:
    """Everything msg_handler needs to decide  -  extend fields as APIs grow."""

    __slots__ = (
        'api', 'url', 'method', 'status', 'response', 'error',
        'headers', 'payload', 'retried', 'extra',
    )

    def __init__(
        self,
        api=API_GENERIC,
        url='',
        method='GET',
        status=0,
        response=None,
        error=None,
        headers=None,
        payload=None,
        retried=False,
        extra=None,
    ):
        self.api = api or API_GENERIC
        self.url = url or ''
        self.method = (method or 'GET').upper()
        self.status = int(status or 0)
        self.response = response
        self.error = error
        self.headers = dict(headers or {})
        self.payload = payload
        self.retried = bool(retried)
        self.extra = dict(extra or {})


# --- Registry (room for later APIs: simkl, orion, debrid, ...) ---------------
_HANDLERS = {}


def register(api, handler):
    """Register or replace an API-specific handler."""
    _HANDLERS[str(api)] = handler


def handle(ctx):
    """
    Central decision point for non-2xx / transport errors.

    Returns Action.RETRY_ONCE | Action.REFRESH_AUTH | Action.FAIL
    """
    if ctx is None:
        return Action.FAIL

    if ctx.error and not ctx.status:
        return _handle_transport_error(ctx)

    if http_policy.is_success(ctx.status):
        return Action.FAIL

    handler = _HANDLERS.get(ctx.api) or _HANDLERS.get(API_GENERIC) or _handle_generic
    try:
        return handler(ctx)
    except Exception as exc:
        c.log(f'[MsgHandler] handler error api={ctx.api} url={ctx.url}: {exc}', 1)
        return Action.FAIL


# --- Transport layer errors (no HTTP response) -----------------------------
def _handle_transport_error(ctx):
    c.log(f'[MsgHandler] transport error api={ctx.api} url={ctx.url}: {ctx.error}', 1)
    if ctx.retried:
        return Action.FAIL
    if http_policy.is_transport_transient(ctx.error):
        import time
        c.log('[MsgHandler] transient transport  -  sleep 0.5s then retry once')
        time.sleep(0.5)
        return Action.RETRY_ONCE
    if http_policy.is_transient(getattr(ctx, 'status', 0)):
        return Action.RETRY_ONCE
    return Action.FAIL


# --- Generic fallback ------------------------------------------------------
def _handle_generic(ctx):
    if ctx.retried:
        return Action.FAIL
    if http_policy.is_transient(ctx.status):
        c.log(f'[MsgHandler] transient {ctx.status} for {ctx.url}  -  retry once')
        return Action.RETRY_ONCE
    c.log(f'[MsgHandler] fail {ctx.status} for {ctx.url}')
    return Action.FAIL


# --- WeTrakr ---------------------------------------------------------------
def _handle_wetrakr(ctx):
    code = str(ctx.status)
    if code in ('401', '403'):
        if ctx.retried:
            return Action.FAIL
        c.log(f'[MsgHandler][WeTrakr] auth error {code} for {ctx.url}')
        return Action.REFRESH_AUTH
    # Device-flow poll returns 400 + authorization_pending until the user
    # finishes on the website  -  not a real failure; keep the log quiet.
    url = str(getattr(ctx, 'url', '') or '')
    if code == '400' and '/oauth/device/token' in url:
        return Action.FAIL
    return _handle_generic(ctx)


# --- Trakt -----------------------------------------------------------------
def _handle_trakt(ctx):
    code = str(ctx.status)

    if code in ('401', '403'):
        if ctx.retried:
            return Action.FAIL
        c.log(f'[MsgHandler][Trakt] auth error {code} for {ctx.url}')
        return Action.REFRESH_AUTH

    if code == '429':
        if ctx.retried:
            return Action.FAIL
        wait = http_policy.parse_retry_after(ctx.response, default_seconds=0)
        if wait <= 0:
            c.log('[MsgHandler][Trakt] 429 without Retry-After  -  no retry')
            return Action.FAIL
        c.log(f'[MsgHandler][Trakt] 429  -  sleep {wait:.1f}s then retry once')
        import time
        time.sleep(wait)
        return Action.RETRY_ONCE

    if code == '422':
        c.log(f'[MsgHandler][Trakt] validation error 422 for {ctx.url}', 1)
        return Action.FAIL

    if code == '423':
        c.log('[MsgHandler][Trakt] account locked (423)', 1)
        return Action.FAIL

    if code == '404':
        c.log(f'[MsgHandler][Trakt] not found {ctx.url}')
        return Action.FAIL

    if code == '405':
        c.log(f'[MsgHandler][Trakt] method not allowed {ctx.url}', 1)
        return Action.FAIL

    c.log(f'[MsgHandler][Trakt] HTTP {code} for {ctx.url}')
    return Action.FAIL


# --- TMDB (stub  -  extend when apis/tmdb lands) -----------------------------
def _handle_tmdb(ctx):
    if ctx.retried:
        return Action.FAIL
    if ctx.status == 429:
        wait = http_policy.parse_retry_after(ctx.response, default_seconds=2)
        c.log(f'[MsgHandler][TMDB] 429  -  sleep {wait:.1f}s')
        import time
        time.sleep(wait)
        return Action.RETRY_ONCE
    return _handle_generic(ctx)


# --- Scraper (stub  -  extend for hijack / captcha later) --------------------
def _handle_scraper(ctx):
    return _handle_generic(ctx)


# --- Post-decision hooks (optional extension point) ------------------------
def after_action(ctx, action, headers=None):
    """
    Run side effects after msg_handler decides REFRESH_AUTH.
    Returns updated headers dict or None.
    """
    if action != Action.REFRESH_AUTH:
        return headers
    if ctx.api == API_TRAKT:
        from ..trakt import auth as trakt_auth
        if trakt_auth.try_refresh(ctx, headers):
            return trakt_auth.build_auth_headers(headers)
    if ctx.api == API_WETRAKR:
        from ..apis import wetrakr
        if wetrakr.try_refresh_access_token(force=True):
            headers = dict(headers or {})
            token = wetrakr._token()
            if token:
                headers['Authorization'] = 'Bearer %s' % token
            client_id = wetrakr._client_id()
            if client_id:
                headers['wetrakr-api-key'] = client_id
            headers.setdefault('wetrakr-api-version', '1')
            return headers
    return headers


# ---------------------------------------------------------------------------
# EXTENSION  -  register APIs here (simkl, orion, debrid, ...)
# ---------------------------------------------------------------------------
register(API_GENERIC, _handle_generic)
register(API_TRAKT, _handle_trakt)
register(API_TMDB, _handle_tmdb)
register(API_FANART, _handle_tmdb)
register(API_TVDB, _handle_generic)
register(API_SIMKL, _handle_generic)
register(API_WETRAKR, _handle_wetrakr)
register(API_MDBLIST, _handle_generic)
register(API_SCRAPER, _handle_scraper)

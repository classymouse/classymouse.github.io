# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file settings_normalize.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Kodi 21/Omega userdata fixes  -  direct file edits only (never setSetting on boot).

Empty hidden text settings (e.g. adult_pin) must not be self-closing in userdata;
see The Crew settings_repair.normalize_omega_text_settings.'''

from __future__ import annotations

import os
import xml.etree.ElementTree as ET

import xbmcaddon
import xbmcvfs

from .classy import c

# Placeholder body when "no PIN"  -  Omega rejects empty text setting elements.
_EMPTY_TEXT_DEFAULTS = {
    'adult_pin': ' ',
}


def _userdata_path() -> str:
    return xbmcvfs.translatePath(
        os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), 'settings.xml')
    )


def _setting_line(setting: ET.Element) -> str:
    attrs = dict(setting.attrib)
    text = setting.text or ''
    if text.strip():
        attrs.pop('default', None)
    attrs_str = ''.join(f' {k}="{v}"' for k, v in sorted(attrs.items()))
    if text:
        escaped = (
            text.replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
        )
        return f'    <setting{attrs_str}>{escaped}</setting>'
    return f'    <setting{attrs_str} />'


def normalize_omega_text_settings(log=None) -> bool:
    """Ensure known text settings have a non-empty element body in userdata."""
    user_path = _userdata_path()
    if not xbmcvfs.exists(user_path):
        return False
    try:
        raw = c.to_str(xbmcvfs.File(user_path, 'r').read())
    except Exception:
        return False
    if not raw.strip():
        return False
    parse_src = raw
    if not parse_src.lstrip().startswith('<?xml'):
        parse_src = '<?xml version="1.0" encoding="utf-8"?>\n' + parse_src
    try:
        root = ET.fromstring(parse_src)
    except ET.ParseError:
        return False

    changed = False
    for setting in root:
        if setting.tag != 'setting':
            continue
        sid = setting.attrib.get('id')
        placeholder = _EMPTY_TEXT_DEFAULTS.get(sid)
        if placeholder is None:
            continue
        if (setting.text or '').strip():
            continue
        setting.text = placeholder
        setting.attrib.pop('default', None)
        changed = True

    if not changed:
        return False

    version = '2'
    if root.tag == 'settings' and root.attrib.get('version'):
        version = root.attrib['version']
    lines = [f'<settings version="{version}">']
    lines.extend(_setting_line(s) for s in root if s.tag == 'setting')
    lines.append('</settings>')
    try:
        payload = c.to_bytes('\n'.join(lines) + '\n')
        handle = xbmcvfs.File(user_path, 'w')
        handle.write(payload)
        handle.close()
    except Exception as exc:
        if log:
            log(f'[settings_normalize] write failed: {exc}')
        return False
    if log:
        log('[settings_normalize] Normalized empty text settings for Kodi 21')
    return True

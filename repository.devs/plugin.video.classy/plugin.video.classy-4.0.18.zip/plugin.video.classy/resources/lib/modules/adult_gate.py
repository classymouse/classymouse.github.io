# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file adult_gate.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Adult section visibility  -  master password gate (settings adult_pw).

Layer 1: row hidden until adult_pw matches the unlock code (Crew: "lol").
Layer 2: optional PIN via adult_pin.AdultPIN (checked on menu open).'''

from .classy import c
from .keys import adult_password
from ..indexers import menu_format

_DEFAULT_SECTION_NAME = 'Adult Content'


def _read_adult_pw():
    '''Master unlock password; auto-fix common swap with section display name.'''
    value = (c.get_setting('adult_pw') or '').strip()
    if value == adult_password:
        return value

    section_name = (c.get_setting('adult_section_name') or '').strip()
    if not value and section_name == adult_password:
        c.set_setting('adult_pw', adult_password)
        c.set_setting('adult_section_name', _DEFAULT_SECTION_NAME)
        c.log('[Adult gate] unlock code was in display name  -  moved to adult_pw')
        return adult_password

    return value


def is_adult_section_enabled():
    '''True when the user entered the master unlock password in settings.'''
    value = _read_adult_pw()
    enabled = value == adult_password
    if c.get_setting('addon_debug') == 'true' or c.is_devmode():
        c.log(f'[Adult gate] adult_pw configured={bool(value)} menu_visible={enabled}')
    return enabled


def section_menu_label():
    '''Formatted root row label from adult_section_name setting.'''
    name = (c.get_setting('adult_section_name') or '').strip()
    if not name or name == adult_password:
        name = _DEFAULT_SECTION_NAME
    return menu_format.menu_item(name)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file http_policy.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy v4  -  HTTP policy helpers only (no retry decisions).

Decisions live in msg_handler.py.'''

import email.utils
import threading
import time


class RateLimiter:
    '''Token bucket  -  smooth API bursts (TMDB DNS / resolver friendly).'''

    def __init__(self, rate=10, per=2.0):
        self.rate = float(rate)
        self.per = float(per)
        self.tokens = self.rate
        self.updated = time.time()
        self.lock = threading.Lock()

    def acquire(self):
        with self.lock:
            now = time.time()
            elapsed = now - self.updated
            self.tokens = min(self.rate, self.tokens + elapsed * (self.rate / self.per))
            self.updated = now
            if self.tokens >= 1:
                self.tokens -= 1
                return
            wait = (1 - self.tokens) * self.per / self.rate
        if wait > 0:
            time.sleep(wait)
        with self.lock:
            self.tokens = max(0.0, self.tokens - 1)


_LIMITERS = {
    'tmdb': RateLimiter(rate=10, per=2.0),
    'fanart': RateLimiter(rate=6, per=2.0),
}


def acquire_rate_limit(api):
    limiter = _LIMITERS.get(str(api or ''))
    if limiter:
        limiter.acquire()


def is_success(status) -> bool:
    try:
        code = int(status)
    except (TypeError, ValueError):
        return False
    return 200 <= code <= 299


def is_transient(status) -> bool:
    try:
        code = int(status)
    except (TypeError, ValueError):
        return False
    return code in (408, 500, 502, 503, 504)


def is_transport_transient(error) -> bool:
    """DNS / socket blips before any HTTP status (urllib URLError, etc.)."""
    if not error:
        return False
    msg = str(error).lower()
    needles = (
        'getaddrinfo failed',
        'name or service not known',
        'temporary failure in name resolution',
        'timed out',
        'timeout',
        'connection reset',
        'connection aborted',
        'eof occurred',
        'network is unreachable',
    )
    return any(needle in msg for needle in needles)


def parse_retry_after(response, default_seconds=60) -> float:
    """Parse Retry-After header (seconds or HTTP-date)."""
    if response is None:
        return float(default_seconds)
    headers = getattr(response, 'headers', None) or {}
    raw = headers.get('Retry-After') or headers.get('retry-after')
    if not raw:
        return float(default_seconds)
    raw = str(raw).strip()
    try:
        return max(0.0, float(raw))
    except ValueError:
        pass
    try:
        when = email.utils.parsedate_to_datetime(raw)
        return max(0.0, when.timestamp() - time.time())
    except Exception:
        return float(default_seconds)

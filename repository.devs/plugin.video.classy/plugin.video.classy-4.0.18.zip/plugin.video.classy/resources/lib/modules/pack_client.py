# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file pack_client.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

External pack client bridge  -  route Coco/Gears/Viper/Magneto HTTP through Classy scraper client.

Pack addon settings (TorBox token, Prowlarr URL, etc.) are read by each pack's native
``modules.control`` once its lib dir is on sys.path  -  do not replace those modules.'''

import sys
import types

from .crewruntime import c
from .pack_cfscrape import install_pack_cfscrape_shims

_PACK_CLIENT_MODULES = (
    'classyscrapers.modules.client',
    'cocoscrapers.modules.client',
    'gearsscrapers.modules.client',
    'viperscrapers.modules.client',
    'magneto.modules.client',
)

_adapter = None
_installed = False


def _build_adapter(http_client):
    mod = types.ModuleType('classy.pack_client_adapter')

    def request(url, close=True, redirect=True, error=False, proxy=None, post=None, headers=None,
                mobile=False, XHR=False, limit=None, referer=None, cookie=None, compression=True,
                output='', timeout='30', verifySsl=True, flare=True, ignoreErrors=None, as_bytes=False, **kwargs):
        if not url:
            return None
        if ignoreErrors:
            error = True
        try:
            return http_client.request(
                url, close=close, redirect=redirect, error=error, verify=verifySsl, proxy=proxy,
                post=post, headers=headers, mobile=mobile, XHR=XHR, limit=limit, referer=referer,
                cookie=cookie, compression=compression, output=output, timeout=timeout,
                as_bytes=as_bytes, flare=flare, **kwargs,
            )
        except Exception as exc:
            if error or ignoreErrors:
                return exc if error else None
            if getattr(c, 'devmode', False):
                c.log(f'[PackClient] request failed url=({url}): {exc}', 1)
            return None

    mod.request = request
    mod.parseDOM = http_client.parseDom
    mod.parseDom = http_client.parseDom
    mod.replaceHTMLCodes = http_client.replaceHTMLCodes
    mod.agent = http_client.agent
    mod.randomagent = http_client.randomagent
    for name in ('parseHTML', 'selectHTML', 'randommobileagent'):
        if hasattr(http_client, name):
            setattr(mod, name, getattr(http_client, name))
    return mod


def install_pack_client_shims(force=False):
    global _adapter, _installed
    if _installed and not force:
        return _adapter

    install_pack_cfscrape_shims(force=force)

    from . import scraper_client as http_client

    _adapter = _build_adapter(http_client)
    for target in _PACK_CLIENT_MODULES:
        sys.modules[target] = _adapter
    _installed = True
    try:
        c.log('[Sources] External pack client shims installed (Classy scraper client)')
    except Exception:
        pass
    return _adapter


def install_magneto_module_shims(magneto_lib=None):
    '''Install HTTP client shim for magneto.modules.client (used by pack_client).'''
    install_pack_client_shims()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file progress_cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Progress widget cache worker  -  warm prepared rows off the GetDirectory thread.

Event-driven via progress.widget_signals (scrobble/CM). Interval tick only
when a warm is pending  -  not while Home merely sits with widgets mounted.'''

from ..classy import c
from ...progress import widget_cache
from ...modules import kodi
from .base import Worker


class ProgressCacheWorker(Worker):
    name = 'progress_cache'
    interval = 90

    def __init__(self):
        super().__init__()
        # Avoid racing home widgets on Kodi boot  -  let the first paint own cold build.
        self.mark_ran()

    def wants_tick(self, now):
        # Event path: scrobble/CM sets force + pending.
        if kodi.consume_widget_warm_force():
            return True
        if not self.is_due(now):
            return False
        # Do NOT tick on bare in_widget()  -  that re-warmed all 3 routes every
        # 90s while Home sat idle and burned the WeTrakr daily quota (B0).
        return kodi.widget_warm_pending()

    def tick(self, monitor):
        if monitor.abortRequested():
            return
        reason = kodi.widget_warm_reason()
        if not self._active_progress_tracker():
            if reason or kodi.widget_warm_pending():
                kodi.clear_widget_warm_pending()
            return
        if reason and c.devmode:
            c.log(f'[Widget] progress_cache warm ({reason})')
        try:
            from ...tracker.gate import is_wetrakr, live
            if is_wetrakr() and live():
                from ...apis import wetrakr as wt_api
                if wt_api.is_rate_limited():
                    c.log('[Widget] progress_cache deferred  -  WeTrakr rate-limited')
                    # Keep warm pending so the next interval retries after cooldown.
                    return
        except Exception:
            pass
        # force=True only on this event path  -  WeTrakr fingerprints can stay
        # stable while next-ep slots moved; rewrite prepared rows anyway.
        updated = widget_cache.warm_all(log_label='progress_cache', force=True)
        kodi.clear_widget_warm_pending()
        if updated and not monitor.abortRequested():
            kodi.schedule_widget_refresh()

    @staticmethod
    def _active_progress_tracker():
        try:
            fn = getattr(widget_cache, '_has_live_progress_tracker', None)
            if callable(fn):
                return bool(fn())
        except Exception:
            pass
        # Stale widget_cache module (pre-B0)  -  fall back to live gate.
        try:
            from ...tracker.gate import is_trakt, is_simkl, is_wetrakr, live
            if not live():
                return False
            if is_wetrakr():
                from ...wetrakr import auth as wt_auth
                return wt_auth.has_credentials()
            if is_simkl():
                from ...simkl import auth as simkl_auth
                return simkl_auth.has_credentials()
            if is_trakt():
                from ...trakt import auth as trakt_auth
                return trakt_auth.has_credentials()
        except Exception:
            return False
        return False

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debrid_account.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Secondary worker: thin debrid account info into SQLite (last-good), plus
B1 ResolveURL backup reconcile on the same wake (not a dedicated watcher).

Boot: first tick after BOOT_DELAY_SEC. Then idle until force_due (clear /
authorize / Tools refresh). Long safety interval re-runs both jobs.
'''

from __future__ import annotations

import time

from ..classy import c
from .base import Worker

BOOT_DELAY_SEC = 20
# Safety re-pull if Kodi stays up for days without a clear/auth event.
SAFETY_INTERVAL_SEC = 12 * 3600


class DebridAccountWorker(Worker):
    name = 'debrid_account'
    interval = SAFETY_INTERVAL_SEC

    def __init__(self):
        super().__init__()
        self._boot_at = time.time()
        self._pending = True
        # Do not race service boot / Home paint.
        self.mark_ran()

    def force_due(self):
        self._pending = True
        super().force_due()

    def wants_tick(self, now):
        if self._pending and (now - self._boot_at) >= BOOT_DELAY_SEC:
            return True
        if self._pending and self.is_due(now):
            return True
        # Quiet safety refresh while session lives long.
        return (not self._pending) and self.is_due(now)

    def tick(self, monitor):
        if monitor.abortRequested():
            return
        # B1: live empty -> scrub backup; live auth -> sync backup.
        # Same wake as account fetch  -  no separate backup poller.
        try:
            from .. import resolveurl_backup
            resolveurl_backup.reconcile_backup_with_live(
                log_label='debrid_account',
            )
        except Exception as exc:
            c.log(f'[DebridAccount] backup reconcile failed: {exc}', 1)
        if monitor.abortRequested():
            return
        try:
            from ...debrid import account_fetch

            n = account_fetch.refresh_all(
                abort_check=monitor.abortRequested,
            )
            if c.devmode:
                c.log(f'[DebridAccount] worker refreshed {n} provider(s)')
        except Exception as exc:
            c.log(f'[DebridAccount] worker failed: {exc}', 1)
        finally:
            self._pending = False

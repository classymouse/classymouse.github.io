# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file base.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Base worker contract for ClassyMonitor.'''

import time


class Worker:
    '''
    Periodic background job. Keep tick() short; chunk heavy work across ticks.

    Subclasses set name + interval (seconds). Monitor calls tick() when due.
    '''

    name = 'worker'
    interval = 300

    def __init__(self):
        self._last_run = 0.0

    def is_due(self, now=None):
        now = now if now is not None else time.time()
        return (now - self._last_run) >= float(self.interval)

    def mark_ran(self, now=None):
        self._last_run = now if now is not None else time.time()

    def force_due(self):
        '''Schedule this worker on the next monitor poll.'''
        self._last_run = 0.0

    def wants_tick(self, now):
        return self.is_due(now)

    def tick(self, monitor):
        '''Override: one unit of background work. Must respect monitor.abortRequested().'''
        raise NotImplementedError

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file unaired.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Unaired season/episode/show coloring  -  Crew showunaired + unaired.identify parity.'''

import re
from datetime import datetime

from .classy import c
from ..metadata.resume_label import resume_remaining_suffix

# settings.xml lvalues order (plugin.video.thecrew)
COLOR_STRING_IDS = (32753, 32754, 32755, 32756, 32757, 32758, 32759, 32760, 32761, 32762)

# Fallback when strings.po entries are missing
_COLOR_TEMPLATES = (
    '[COLOR blue][I]%s[/I][/COLOR]',
    '[COLOR red][I]%s[/I][/COLOR]',
    '[COLOR yellow][I]%s[/I][/COLOR]',
    '[COLOR deeppink][I]%s[/I][/COLOR]',
    '[COLOR cyan][I]%s[/I][/COLOR]',
    '[COLOR lawngreen][I]%s[/I][/COLOR]',
    '[COLOR gold][I]%s[/I][/COLOR]',
    '[COLOR magenta][I]%s[/I][/COLOR]',
    '[COLOR yellowgreen][I]%s[/I][/COLOR]',
    '%s',
)

_UPCOMING_STATUSES = frozenset({'Upcoming', 'In Production', 'Planned'})


def show_unaired_enabled():
    value = c.get_setting('showunaired')
    if value is None or value == '':
        return True
    return str(value).lower() not in ('false', '0', 'no')


def _color_index():
    raw = c.get_setting('unaired.identify')
    if raw is None or raw == '':
        return 1
    text = str(raw).strip()
    try:
        idx = int(text)
        if 0 <= idx < len(COLOR_STRING_IDS):
            return idx
        if idx in COLOR_STRING_IDS:
            return COLOR_STRING_IDS.index(idx)
    except (TypeError, ValueError):
        pass
    return 1


def _date_num(value):
    digits = re.sub(r'[^0-9]', '', str(value or ''))
    if len(digits) < 8:
        return 0
    try:
        return int(digits[:8])
    except ValueError:
        return 0


def _today_num():
    return _date_num(datetime.now().strftime('%Y-%m-%d'))


def is_unaired(row):
    '''True when air/release date is in the future (or unknown upcoming status).'''
    status = (getattr(row, 'status', '') or '').strip()
    premiered = (getattr(row, 'premiered', '') or '').strip()
    mediatype = (getattr(row, 'mediatype', '') or '').strip().lower()
    today = _today_num()

    if premiered in ('', '0'):
        if mediatype in ('tvshow', 'movie') and status in _UPCOMING_STATUSES:
            return True
        return False

    if status == 'Ended' and mediatype in ('season', 'episode'):
        return False

    return _date_num(premiered) > today


def _color_template():
    idx = _color_index()
    if COLOR_STRING_IDS[idx] == 32762:
        return '%s'

    raw = c.lang(COLOR_STRING_IDS[idx])
    if not raw or str(raw) == str(COLOR_STRING_IDS[idx]):
        return _COLOR_TEMPLATES[idx]

    template = re.sub(r'\][\w\s]*\[', '][I]%s[/I][', raw)
    if '%s' not in template:
        return _COLOR_TEMPLATES[idx]
    return template


def _premiere_suffix(premiered):
    premiered = (premiered or '').strip()
    if not premiered or premiered == '0':
        return ''
    if _date_num(premiered) <= _today_num():
        return ''
    try:
        release_dt = datetime.strptime(premiered[:10], '%Y-%m-%d')
        return f' [COLOR cyan]({release_dt.strftime("%b %d, %Y")})[/COLOR]'
    except ValueError:
        return ''


def style_unaired_label(label, *, premiered=''):
    text = str(label or '')
    if premiered:
        text += _premiere_suffix(premiered)
    template = _color_template()
    if template == '%s':
        return text
    try:
        styled = template % text
        if styled.strip():
            return styled
    except Exception:
        pass
    return f'[COLOR red][I]{text}[/I][/COLOR]'


def display_label(row):
    '''List label with unaired color when applicable.'''
    premiered = getattr(row, 'premiered', '')
    base = row.label or row._default_label()
    if is_unaired(row) and show_unaired_enabled():
        base = style_unaired_label(base, premiered=premiered)
    # Crew parity  -  cyan future release date even when showunaired is off.
    elif getattr(row, 'mediatype', '') == 'movie' and premiered:
        suffix = _premiere_suffix(premiered)
        if suffix:
            base = base + suffix
    return base + resume_remaining_suffix(row)

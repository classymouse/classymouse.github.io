# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file classy.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy runtime  -  single `c` instance for the addon.
Keep this lean; add methods only when multiple call sites need them.'''

import datetime
import os
import re
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from inspect import getframeinfo, stack
from io import open

from . import keys
from .uwp_compat import platform_label


class Classy:
    def __init__(self):
        self.init_vars()

    def init_vars(self):
        addon = xbmcaddon.Addon()
        self.addon = xbmcaddon.Addon
        self.language = addon.getLocalizedString
        self.addon_id = addon.getAddonInfo('id')
        self.version = addon.getAddonInfo('version')
        self.name = self.addon_id
        self.path = addon.getAddonInfo('path')
        self.theme = self.appearance()
        self.art_path = self.get_art_path()
        self.platform = self._get_current_platform()
        self.cpu_count = os.cpu_count() or 1
        self.kodiversion = self._get_kodi_version(as_string=True, as_full=True)
        self.int_kodiversion = self._get_kodi_version(as_string=False, as_full=False)
        self.icon = self.addon_icon()
        self.fanart = self.addon_fanart()
        self.devmode = self.is_devmode()

    def lang(self, id):
        try:
            return self.language(id)
        except Exception:
            return id

    def _get_current_platform(self):
        # Xbox UWP: platform.uname() crashes (missing CreateProcess).
        try:
            return platform_label()
        except Exception:
            bits = '64bits' if sys.maxsize > 2**32 else '32bits'
            try:
                info = (xbmc.getInfoLabel('System.OSVersionInfo') or '').strip()
                if info:
                    return f'{info} ({bits})'
            except Exception:
                pass
            return f'Unknown ({bits})'

    def _get_kodi_version(self, as_string=False, as_full=False):
        version_raw = xbmc.getInfoLabel('System.BuildVersion').split(' ')
        v_temp = version_raw[0]
        if as_full is False:
            version = v_temp.split('.')[0]
            fversion = ''
        else:
            parts = v_temp.split('.')
            fversion = f'{parts[0]}.{parts[1]}' if len(parts) > 1 else parts[0]
            version = ''
        if as_string:
            return version if not as_full else fversion
        return int(version)

    def scraper_error(self, msg, scraper=None, exc_info=None):
        if not self._debug_enabled() and not self.devmode:
            return
        label = scraper or 'scraper'
        if exc_info is not None and isinstance(exc_info, BaseException):
            import traceback
            detail = ''.join(traceback.format_exception(type(exc_info), exc_info, exc_info.__traceback__))
            self.log(f'[SCRAPER ERROR] {label}: {msg}\n{detail}', 1)
            return
        self.log(f'[SCRAPER ERROR] {label}: {msg}', 1)

    def _debug_enabled(self):
        try:
            return str(self.get_setting('addon_debug') or '').lower() == 'true'
        except Exception:
            # Addon disabled / Addon() unavailable during service teardown
            return False

    def _append_log_line(self, log_file, text):
        '''Prefer native open; fall back to xbmcvfs (Xbox / sandboxed logpath).'''
        try:
            if not os.path.exists(log_file):
                with open(log_file, 'w', encoding='utf-8') as handle:
                    handle.write(
                        '=======================================================\n'
                        'The Crew started this file\n'
                        '=======================================================\n\n'
                    )
            with open(log_file, 'a', encoding='utf-8') as handle:
                handle.write(text)
            return
        except Exception:
            pass

        header = (
            '=======================================================\n'
            'The Crew started this file\n'
            '=======================================================\n\n'
        )
        if not xbmcvfs.exists(log_file):
            handle = xbmcvfs.File(log_file, 'w')
            try:
                handle.write(header)
            finally:
                handle.close()
        handle = xbmcvfs.File(log_file, 'a')
        try:
            handle.write(text)
        finally:
            handle.close()

    def log(self, msg, trace=0):
        try:
            debug_on = self._debug_enabled()
        except Exception:
            debug_on = False
        if not debug_on and not getattr(self, 'devmode', False):
            return
        try:
            if not isinstance(msg, str):
                raise TypeError('c.log() msg must be str')

            log_file = os.path.join(
                xbmcvfs.translatePath('special://logpath'),
                'classy.log',
            )
            addon_id = getattr(self, 'addon_id', 'plugin.video.classy')
            version = getattr(self, 'version', '?')
            if trace == 1:
                caller = getframeinfo(stack()[1][0])
                prefix = f' DEBUG [{addon_id} | v.{version}]'
                line = (
                    f'{prefix}: {msg}\n'
                    f'     --> {caller.filename} @ {caller.lineno}'
                )
            else:
                prefix = f' INFO [{addon_id} v.{version}]'
                line = f'{prefix}: {msg}'

            stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self._append_log_line(log_file, f'{stamp} {line.rstrip()}\n')
            # File-only when debug is on  -  do not mirror every line into kodi.log
            # (Crew parity: debug.location=file). Failures still hit xbmc.log below.
        except Exception as exc:
            xbmc.log(f'[ {getattr(self, "addon_id", "plugin.video.classy")} ] Logging Failure: {exc}', 1)

    def in_addon(self):
        return xbmc.getInfoLabel('Container.PluginName') == self.addon_id

    def get_setting(self, setting):
        try:
            return xbmcaddon.Addon(self.addon_id).getSetting(id=setting)
        except Exception:
            # Disabled / uninstalling: Addon() raises Unknown addon id
            return ''

    def set_setting(self, setting, val):
        try:
            return xbmcaddon.Addon(self.addon_id).setSetting(id=setting, value=val)
        except Exception:
            return None

    def is_devmode(self):
        return self.get_setting('dev_pw') == keys.dev_password

    @staticmethod
    def to_str(data, encoding='utf-8', errors='replace'):
        if isinstance(data, str):
            return data
        if isinstance(data, bytes):
            return data.decode(encoding, errors)
        return str(data)

    @staticmethod
    def to_bytes(data, encoding='utf-8', errors='replace'):
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return data.encode(encoding, errors)
        return str(data).encode(encoding, errors)

    def yesnoDialog(self, message, heading=None, nolabel='', yeslabel='', defaultbutton=None):
        kwargs = {'nolabel': nolabel, 'yeslabel': yeslabel}
        if defaultbutton is not None:
            kwargs['defaultbutton'] = defaultbutton
        return xbmcgui.Dialog().yesno(heading or self.addon_id, message, **kwargs)

    def infoDialog(self, message, heading=None, icon='', time=3000, sound=False):
        heading = heading or self.addon_id
        if sound:
            xbmcgui.Dialog().ok(heading, message)
        else:
            xbmcgui.Dialog().notification(heading, message, icon or self.icon, time)

    def get_max_threads(self, total_items, default_cap=None):
        try:
            total = int(total_items)
        except (TypeError, ValueError):
            total = 0
        if total <= 0:
            return 0
        try:
            user_defined = int(self.get_setting('max_threads') or 0)
        except (ValueError, TypeError):
            user_defined = 0
        thread_count = user_defined if user_defined > 0 else self.cpu_count * 2
        if default_cap is not None:
            try:
                thread_count = min(thread_count, int(default_cap))
            except (TypeError, ValueError):
                pass
        return max(1, min(thread_count, total))

    def get_progress_workers(self, total_items, *, is_widget=False, background=False):
        return self.get_max_threads(total_items)

    def addon_icon(self):
        if self.art_path:
            return os.path.join(self.art_path, 'icon.png')
        return xbmcaddon.Addon().getAddonInfo('icon')

    def addon_thumb(self):
        if self.art_path:
            return os.path.join(self.art_path, 'thumb.jpg')
        return ''

    def addon_poster(self):
        if self.art_path:
            return os.path.join(self.art_path, 'poster.png')
        return 'DefaultVideo.png'

    def addon_banner(self):
        if self.art_path:
            return os.path.join(self.art_path, 'banner.png')
        return 'DefaultVideo.png'

    def addon_fanart(self):
        if self.art_path:
            return os.path.join(self.art_path, 'fanart.jpg')
        return xbmcaddon.Addon().getAddonInfo('fanart')

    def addon_clearart(self):
        return os.path.join(self.art_path, 'clearart.png') if self.art_path else ''

    def addon_discart(self):
        return os.path.join(self.art_path, 'discart.png') if self.art_path else ''

    def addon_clearlogo(self):
        return os.path.join(self.art_path, 'clearlogo.png') if self.art_path else ''

    def addon_next(self):
        if self.art_path:
            return os.path.join(self.art_path, 'next.png')
        return 'DefaultVideo.png'

    def addon_adult_icon(self):
        if self.art_path:
            path = os.path.join(self.art_path, 'adult.png')
            if os.path.isfile(path):
                return path
            return os.path.join(self.art_path, 'main_pinkhat.png')
        return self.addon_icon()

    def get_art_path(self):
        '''Menu PNGs  -  single in-addon pack resources/lib/artwork/thecrew.'''
        path = os.path.join(self.path, 'resources', 'lib', 'artwork', 'thecrew')
        if os.path.isdir(path):
            return path
        # Legacy folder name from pre-consolidation builds.
        legacy = os.path.join(self.path, 'resources', 'lib', 'artwork', 'modern')
        if os.path.isdir(legacy):
            return legacy
        return path

    def appearance(self):
        '''Active dialog skin / artwork folder name (thecrew only).'''
        theme = (self.get_setting('appearance.1') or '').strip().lower()
        # Legacy values map onto the consolidated thecrew pack.
        if theme in ('thecrew', 'modern', 'stylish'):
            return 'thecrew'
        try:
            if int(self.get_setting('theme') or 0) == 0:
                return 'thecrew'
        except (TypeError, ValueError):
            pass
        return 'thecrew'

    def resolve_dialog_skin(self, xml_filename, preferred=None):
        '''Return (addon_path, skin) for WindowXMLDialog  -  bundled under resources/skins/.'''
        # Single shipped skin: thecrew. Accept legacy modern/stylish preferred names.
        candidates = ['thecrew']
        preferred = (preferred or '').strip().lower()
        if preferred == 'modern' and 'modern' not in candidates:
            candidates.append('modern')
        for candidate in candidates:
            path = os.path.join(
                self.path, 'resources', 'skins', candidate, '1080i', xml_filename,
            )
            if os.path.isfile(path):
                return self.path, candidate
        return self.path, 'thecrew'

    def artwork(self):
        xbmc.executebuiltin('RunPlugin(plugin://script.thecrew.artwork)')


c = Classy()

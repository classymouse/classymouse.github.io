# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scraper_trakt.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt genre helper stub for source_utils (Classy Trakt lives under resources.lib.trakt).'''

def getGenre(content_type, content_id, genre_type):
    return []

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file thread_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import concurrent.futures
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

from .classy import c

execute = xbmc.executebuiltin
idle = execute('Dialog.Close(busydialognocancel)')

item = xbmcgui.ListItem
addItem = xbmcplugin.addDirectoryItem
addItems = xbmcplugin.addDirectoryItems
content = xbmcplugin.setContent
directory = xbmcplugin.endOfDirectory
setproperty = xbmcplugin.setProperty


def open_settings(query: str = '', _id: str = c.addon_id) -> None:
    try:
        idle
        execute(f'Addon.OpenSettings({_id})')

        if not query:
            raise ValueError("No query string provided for focus targeting.")
        e, f = query.split('.')

        execute(f'SetFocus({int(e) - 100})')
        execute(f'SetFocus({int(f) - 80})')
    except Exception as e:
        c.log(f"[kodi.py] Failed to open settings: {e}", level="error")


def notification(title, message, icon=None, time=3000) -> None:
    if not title or title == 'default':
        title = c.name
    if isinstance(title, int):
        title = c.lang(title)
    if icon is None:
        icon = c.icon
    xbmcgui.Dialog().notification(title, message, icon, time)


def get_max_threads(total_items: int, default_cap=None) -> int:
    '''Delegate to c  -  kept for dev tools and legacy callers.'''
    return c.get_max_threads(total_items, default_cap=default_cap)


def get_progress_workers(total_items: int, *, is_widget: bool = False, background: bool = False) -> int:
    return c.get_progress_workers(total_items, is_widget=is_widget, background=background)

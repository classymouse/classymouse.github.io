# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file workers.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Thread helper for White CDN modules (crewschedule / crewstreamer).'''

from threading import Thread as _Thread
from typing import Any, Callable


class Thread(_Thread):
    def __init__(self, target_function: Callable[..., Any], *function_args: Any) -> None:
        if not callable(target_function):
            raise ValueError('target_function must be callable')
        self.target_function = target_function
        self.args = function_args
        super().__init__(target=target_function, args=function_args)

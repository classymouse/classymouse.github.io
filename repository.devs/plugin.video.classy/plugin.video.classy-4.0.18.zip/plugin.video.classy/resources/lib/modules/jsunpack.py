# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file jsunpack.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

P.A.C.K.E.R. JavaScript unpacker  -  CDN import shim.

Required by remote crewstreamer / crewreplays / crewschedule modules
(`from resources.lib.modules import jsunpack`). Algorithm unchanged from
urlresolver (2013) / js-beautify packer  -  still matches legacy host pages.

API: detect(source) -> bool, unpack(source) -> str'''

import re


_PACKER_RE = re.compile(r'eval\(function\(p,a,c,k,e,(?:r|d)')
_ARGS_RE = re.compile(
    r"}\s*\('(.*)',\s*(.*?),\s*(\d+),\s*'(.*?)'\.split\('\|'\)",
    re.DOTALL,
)
_STRING_TABLE_RE = re.compile(r'var *(_\w+)\=\["(.*?)"\];', re.DOTALL)
_WORD_RE = re.compile(r'\b\w+\b')


def detect(source):
    """Return True when source looks like P.A.C.K.E.R.-packed JavaScript."""
    return bool(_PACKER_RE.search(source.replace(' ', '')))


def unpack(source):
    """Unpack P.A.C.K.E.R. packed JavaScript."""
    payload, symtab, radix, count = _filterargs(source)

    if count != len(symtab):
        raise UnpackingError('Malformed p.a.c.k.e.r. symtab.')

    try:
        unbase = Unbaser(radix)
    except TypeError as exc:
        raise UnpackingError('Unknown p.a.c.k.e.r. encoding.') from exc

    def lookup(match):
        word = match.group(0)
        return symtab[unbase(word)] or word

    source = _WORD_RE.sub(lookup, payload)
    return _replacestrings(source)


def _filterargs(source):
    """Extract payload, radix, count, and symbol table from packed source."""
    match = _ARGS_RE.search(source)
    if not match:
        raise UnpackingError('Corrupted p.a.c.k.e.r. data.')
    payload, radix, count, symtab = match.groups()
    try:
        radix = 36 if not radix.isdigit() else int(radix)
        return payload, symtab.split('|'), radix, int(count)
    except ValueError as exc:
        raise UnpackingError('Corrupted p.a.c.k.e.r. data.') from exc


def _replacestrings(source):
    """Strip string lookup table and substitute indexed string refs."""
    match = _STRING_TABLE_RE.search(source)
    if not match:
        return source

    varname, strings = match.groups()
    startpoint = len(match.group(0))
    lookup = strings.split('","')
    variable = f'{varname}[%d]'
    for index, value in enumerate(lookup):
        source = source.replace(variable % index, f'"{value}"')
    return source[startpoint:]


class Unbaser:
    """Convert packed base-N tokens to integers."""

    ALPHABET = {
        62: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        95: (
            ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            r'[\]^_`abcdefghijklmnopqrstuvwxyz{|}~'
        ),
    }

    def __init__(self, base):
        self.base = base
        if 2 <= base <= 36:
            self.unbase = lambda string: int(string, base)
            return

        if base < 62:
            self.ALPHABET[base] = self.ALPHABET[62][:base]
        elif 62 < base < 95:
            self.ALPHABET[base] = self.ALPHABET[95][:base]

        try:
            self.dictionary = {
                cipher: index for index, cipher in enumerate(self.ALPHABET[base])
            }
        except KeyError as exc:
            raise TypeError('Unsupported base encoding.') from exc
        self.unbase = self._dictunbaser

    def __call__(self, string):
        return self.unbase(string)

    def _dictunbaser(self, string):
        ret = 0
        for index, cipher in enumerate(string[::-1]):
            ret += (self.base ** index) * self.dictionary[cipher]
        return ret


class UnpackingError(Exception):
    """Packed source could not be decoded."""

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file path_resolve.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Shared path-template resolver for Trakt / TMDB path registries.'''

def resolve_path(root, keys, fmt=None, *, label='path'):
    '''
    Walk a nested dict of path templates; optional .format(**fmt) on the leaf.

    resolve_path(TRAKT_PATHS, ('sync', 'last_activities'))
    resolve_path(TMDB_PATHS, ('detail', 'tv'), {'tmdb_id': 123})
    '''
    node = root
    key_list = tuple(keys)
    for key in key_list:
        if not isinstance(node, dict) or key not in node:
            raise KeyError(f'Unknown {label}: {".".join(key_list)}')
        node = node[key]
    if not isinstance(node, str):
        raise KeyError(f'{label} not a string: {".".join(key_list)}')
    if fmt:
        return node.format(**fmt)
    return node

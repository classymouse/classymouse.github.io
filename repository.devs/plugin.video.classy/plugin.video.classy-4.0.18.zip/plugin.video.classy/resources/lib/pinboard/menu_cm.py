# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file menu_cm.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Context menu helpers for My Crew  -  called via kodi/context_menus.py hub.'''

from __future__ import annotations

import sys
from urllib.parse import quote_plus, urlencode

from ..modules.classy import c
from . import store as pinboard_store

# Actions that must not offer pin (self, section headers, dev, manage).
_SKIP_ACTIONS = frozenset({
    '',
    'pinboardNavigator',
    'myCrewManage',
    'whatsOnSection',
    'developers',
    'testings',
    'developer',
    'porn_check_pin',
    'pinToMyCrew',
    'removeFromMyCrew',
    'renameMyCrewItem',
    'moveMyCrewItem',
})


def _plugin_root():
    if len(sys.argv) > 0 and sys.argv[0]:
        return sys.argv[0]
    return f'plugin://{c.addon_id}/'


def _run_plugin(action, **params):
    query = {'action': action}
    for key, value in params.items():
        if value is None or value == '':
            continue
        query[key] = str(value)
    return f'RunPlugin({_plugin_root()}?{urlencode(query)})'


def is_pinnable(action):
    action = pinboard_store.normalize_action(action)
    if not action or action in _SKIP_ACTIONS:
        return False
    if action.startswith('pin') or action.startswith('myCrew'):
        return False
    return True


def pin_menu_items(action, label='', icon=''):
    '''Return [(label, RunPlugin(...)), ...] for navigator rows.'''
    action = pinboard_store.normalize_action(action)
    if not is_pinnable(action):
        return []

    items = []
    if pinboard_store.is_pinned(action):
        items.append((
            _lang(90230, 'Remove from My Crew'),
            _run_plugin('removeFromMyCrew', target=quote_plus(action)),
        ))
    else:
        items.append((
            _lang(90229, 'Pin to My Crew'),
            _run_plugin(
                'pinToMyCrew',
                target=quote_plus(action),
                label=quote_plus(pinboard_store.strip_label_markup(label)),
                icon=quote_plus(str(icon or '')),
            ),
        ))
    return items


def my_crew_row_items(item_id):
    '''Context menu when browsing shortcuts inside My Crew.'''
    item_id = int(item_id)
    return [
        (_lang(90231, 'Rename'), _run_plugin('renameMyCrewItem', item_id=item_id)),
        (_lang(90232, 'Move up'), _run_plugin('moveMyCrewItem', item_id=item_id, direction=-1)),
        (_lang(90233, 'Move down'), _run_plugin('moveMyCrewItem', item_id=item_id, direction=1)),
        (_lang(90230, 'Remove from My Crew'), _run_plugin('removeFromMyCrew', item_id=item_id)),
    ]


def _lang(string_id, fallback):
    try:
        text = c.lang(string_id)
        if text and str(text) != str(string_id):
            return text
    except Exception:
        pass
    return fallback

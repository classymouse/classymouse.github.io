# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file store.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

SQLite store for My Crew shortcuts  -  label, action query, icon, sort order.'''

from __future__ import annotations

import os
import re
import sqlite3

from ..modules import control
from ..modules.classy import c

_DB_NAME = 'pinboard.db'
_INITIALIZED = 'pinboard.initialized'

# Ship ~4 sensible defaults on first install (user can edit/remove).
_DEFAULTS = (
    {
        'label': 'Trending Movies',
        'action': 'movies&url=trending',
        'icon': 'trending.png',
    },
    {
        'label': 'Continue Watching',
        'action': 'movieProgress',
        'icon': 'mymovies.png',
    },
    {
        'label': 'In Progress Shows',
        'action': 'progress_shows',
        'icon': 'mytvshows.png',
    },
    {
        'label': 'Search',
        'action': 'searchNavigator',
        'icon': 'search.png',
    },
)

_COLOR_TAG = re.compile(r'\[/?[^\]]+\]', re.IGNORECASE)


def _db_path():
    return os.path.join(control.dataPath, _DB_NAME)


def _connect():
    # Android/Shield: profile dir may not exist until first write  -  mkdir or sqlite fails.
    try:
        control.makeFile(control.dataPath)
    except Exception:
        pass
    try:
        os.makedirs(control.dataPath, exist_ok=True)
    except Exception:
        pass
    conn = sqlite3.connect(_db_path(), timeout=30.0)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_schema(conn):
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS pinboard_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            label TEXT NOT NULL,
            action TEXT NOT NULL,
            icon TEXT NOT NULL DEFAULT '',
            sort_order INTEGER NOT NULL DEFAULT 0
        )
        '''
    )
    conn.execute(
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_pinboard_action ON pinboard_items(action)'
    )


def strip_label_markup(label):
    text = _COLOR_TAG.sub('', str(label or ''))
    return ' '.join(text.split()).strip()


def normalize_action(action):
    return str(action or '').strip()


def ensure_defaults():
    '''Seed default shortcuts once per profile.'''
    if c.get_setting(_INITIALIZED) == 'true':
        return
    try:
        conn = _connect()
    except sqlite3.OperationalError as exc:
        c.log(f'[MyCrew] ensure_defaults skipped (db): {exc}', 1)
        return
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM pinboard_items')
        if int(cur.fetchone()[0] or 0) > 0:
            c.set_setting(_INITIALIZED, 'true')
            conn.commit()
            return
        for idx, row in enumerate(_DEFAULTS):
            cur.execute(
                'INSERT OR IGNORE INTO pinboard_items (label, action, icon, sort_order) '
                'VALUES (?, ?, ?, ?)',
                (row['label'], row['action'], row['icon'], idx),
            )
        conn.commit()
        c.set_setting(_INITIALIZED, 'true')
        c.log('[MyCrew] seeded default shortcuts')
    except sqlite3.Error as exc:
        c.log(f'[MyCrew] ensure_defaults failed: {exc}', 1)
    finally:
        conn.close()


def list_items():
    ensure_defaults()
    conn = _connect()
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        cur.execute(
            'SELECT id, label, action, icon, sort_order FROM pinboard_items '
            'ORDER BY sort_order ASC, id ASC'
        )
        return [dict(row) for row in cur.fetchall()]
    finally:
        conn.close()


def find_by_action(action):
    action = normalize_action(action)
    if not action:
        return None
    try:
        conn = _connect()
    except sqlite3.OperationalError as exc:
        c.log(f'[MyCrew] db open failed: {exc}', 1)
        return None
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        cur.execute(
            'SELECT id, label, action, icon, sort_order FROM pinboard_items WHERE action = ?',
            (action,),
        )
        row = cur.fetchone()
        return dict(row) if row else None
    except sqlite3.Error as exc:
        c.log(f'[MyCrew] find_by_action failed: {exc}', 1)
        return None
    finally:
        conn.close()


def is_pinned(action):
    return find_by_action(action) is not None


def add_item(label, action, icon=''):
    action = normalize_action(action)
    label = strip_label_markup(label) or action
    if not action:
        return False, 'missing action'
    if is_pinned(action):
        return False, 'already pinned'

    conn = _connect()
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        cur.execute('SELECT COALESCE(MAX(sort_order), -1) + 1 FROM pinboard_items')
        sort_order = int(cur.fetchone()[0] or 0)
        cur.execute(
            'INSERT INTO pinboard_items (label, action, icon, sort_order) '
            'VALUES (?, ?, ?, ?)',
            (label, action, str(icon or '').strip(), sort_order),
        )
        conn.commit()
        c.log(f'[MyCrew] pinned {label!r} -> {action!r}')
        return True, ''
    except sqlite3.IntegrityError:
        return False, 'already pinned'
    finally:
        conn.close()


def remove_item(item_id):
    conn = _connect()
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        cur.execute('DELETE FROM pinboard_items WHERE id = ?', (int(item_id),))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def remove_by_action(action):
    row = find_by_action(action)
    if not row:
        return False
    return remove_item(row['id'])


def rename_item(item_id, label):
    label = strip_label_markup(label)
    if not label:
        return False
    conn = _connect()
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        cur.execute(
            'UPDATE pinboard_items SET label = ? WHERE id = ?',
            (label, int(item_id)),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def move_item(item_id, direction):
    '''direction: -1 up, +1 down'''
    items = list_items()
    ids = [int(row['id']) for row in items]
    try:
        idx = ids.index(int(item_id))
    except ValueError:
        return False
    swap = idx + int(direction)
    if swap < 0 or swap >= len(ids):
        return False

    ids[idx], ids[swap] = ids[swap], ids[idx]
    conn = _connect()
    try:
        _ensure_schema(conn)
        cur = conn.cursor()
        for order, row_id in enumerate(ids):
            cur.execute(
                'UPDATE pinboard_items SET sort_order = ? WHERE id = ?',
                (order, row_id),
            )
        conn.commit()
        return True
    finally:
        conn.close()

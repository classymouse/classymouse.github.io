# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file next_episode.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Resolve the true next episode after the furthest watched S/E.

Regular case: S01E04  ->  S01E05.

Exceptions (3.x pain  -  The Rookie S07E18 finale  ->  not S07E19):
- Last watched episode_type finale (TMDB) / season_finale (Trakt)  ->  try S+1 E01
- Never use Trakt progress/watched ``next_episode`` (naive E+1  ->  wrong S07E19)
- Candidate S/E missing on TMDB (404)  ->  try S+1 E01
- Show ended/canceled/pilot (TMDB or Trakt)  ->  no next (UpNext / progress drop)

Status vocabulary: metadata/tv_status.py (TMDB + Trakt official values).'''

from ..metadata import tv_status
from ..modules.classy import c


def furthest_watched_episode(positive_seasons):
    '''
    Highest S/E among watched episodes in Trakt progress payload.

    Returns dict season, episode, last_watched_at  -  or None.
    '''
    max_season = 0
    max_episode = 0
    last_watched_at = None

    for season in positive_seasons or []:
        eps = season.get('episodes') or []
        if not eps:
            continue
        sn = int(season.get('number') or 0)
        max_ep = max(int(e.get('number') or 0) for e in eps)
        if sn > max_season or (sn == max_season and max_ep > max_episode):
            max_season = sn
            max_episode = max_ep
            last_watched_at = None
            for ep in eps:
                if int(ep.get('number') or 0) == max_ep:
                    ts = ep.get('last_watched_at')
                    if ts and (last_watched_at is None or ts > last_watched_at):
                        last_watched_at = ts
                    break

    if max_season <= 0 or max_episode <= 0:
        return None

    return {
        'season': max_season,
        'episode': max_episode,
        'last_watched_at': last_watched_at,
    }


def _default_fetch_episode(tmdb_id, season, episode):
    from ..apis import tmdb as tmdb_api
    return tmdb_api.get_tv_episode(tmdb_id, season, episode)


def _default_fetch_show(tmdb_id):
    from ..apis import tmdb as tmdb_api
    return tmdb_api.get_tv(tmdb_id)


def _episode_exists(fetch_episode, tmdb_id, season, episode):
    try:
        data = fetch_episode(tmdb_id, season, episode)
    except Exception as exc:
        c.log(f'[NextEp] TMDB probe S{season:02d}E{episode:02d} tmdb={tmdb_id}: {exc}', 1)
        return False
    return isinstance(data, dict) and bool(data.get('id') or data.get('name'))


def _next_from_show_root(fetch_show, tmdb_id, show_title=''):
    '''Use TMDB next_episode_to_air when season boundary is known.'''
    try:
        show = fetch_show(tmdb_id)
    except Exception as exc:
        c.log(f'[NextEp] TMDB show root tmdb={tmdb_id}: {exc}', 1)
        return None

    if not isinstance(show, dict):
        return None

    if tv_status.tmdb_show_blocks_next(show):
        c.log(f'[NextEp] {show_title or tmdb_id}: show ended (TMDB)')
        return None

    nxt = show.get('next_episode_to_air')
    if isinstance(nxt, dict) and nxt.get('season_number') and nxt.get('episode_number'):
        return int(nxt['season_number']), int(nxt['episode_number'])

    return None


def resolve_next_season_episode(
    tmdb_id,
    last_season,
    last_episode,
    show_data=None,
    show_title='',
    *,
    fetch_episode=None,
    fetch_show=None,
):
    '''
    Return (season, episode) for the episode after last watched, or None.

    Injectable fetch_* for offline probes/tests.
    '''
    fetch_episode = fetch_episode or _default_fetch_episode
    fetch_show = fetch_show or _default_fetch_show

    try:
        last_season = int(last_season)
        last_episode = int(last_episode)
    except (TypeError, ValueError):
        return None

    if not tmdb_id or str(tmdb_id) in ('0', 'None', ''):
        return None

    label = show_title or f'tmdb={tmdb_id}'

    if show_data and tv_status.trakt_show_blocks_next(show_data):
        c.log(f'[NextEp] {label}: show ended (Trakt)')
        return None

    # Read last watched episode on TMDB  -  episode_type finale is authoritative.
    last_meta = None
    try:
        last_meta = fetch_episode(tmdb_id, last_season, last_episode)
    except Exception as exc:
        c.log(f'[NextEp] {label}: last ep meta S{last_season:02d}E{last_episode:02d}: {exc}', 1)

    if isinstance(last_meta, dict):
        ep_type = last_meta.get('episode_type') or ''
        if tv_status.episode_type_is_season_finale(ep_type):
            cand_s, cand_e = last_season + 1, 1
            if _episode_exists(fetch_episode, tmdb_id, cand_s, cand_e):
                c.log(
                    f'[NextEp] {label}: S{last_season:02d}E{last_episode:02d} '
                    f'is finale  ->  S{cand_s:02d}E{cand_e:02d}'
                )
                return cand_s, cand_e
            rooted = _next_from_show_root(fetch_show, tmdb_id, label)
            if rooted:
                c.log(f'[NextEp] {label}: finale  ->  TMDB next_episode_to_air S{rooted[0]:02d}E{rooted[1]:02d}')
                return rooted
            c.log(f'[NextEp] {label}: finale but no next season on TMDB yet')
            return None

    # Default linear step: same season, episode + 1
    cand_s, cand_e = last_season, last_episode + 1
    if _episode_exists(fetch_episode, tmdb_id, cand_s, cand_e):
        return cand_s, cand_e

    # Candidate missing  -  season boundary (finale not tagged, or gap in TMDB data)
    if cand_e > 1 or last_episode > 0:
        bump_s, bump_e = last_season + 1, 1
        if _episode_exists(fetch_episode, tmdb_id, bump_s, bump_e):
            c.log(
                f'[NextEp] {label}: S{cand_s:02d}E{cand_e:02d} missing  ->  '
                f'S{bump_s:02d}E{bump_e:02d}'
            )
            return bump_s, bump_e

        rooted = _next_from_show_root(fetch_show, tmdb_id, label)
        if rooted:
            c.log(f'[NextEp] {label}: probe miss  ->  TMDB next_episode_to_air S{rooted[0]:02d}E{rooted[1]:02d}')
            return rooted

    c.log(f'[NextEp] {label}: no next after S{last_season:02d}E{last_episode:02d}')
    return None


def resolve_next_for_watched_item(item, *, fetch_episode=None, fetch_show=None):
    '''
    Build a next-episode slot dict from one Trakt watched/shows row, or None.
    '''
    try:
        show_data = item.get('show', {}) or {}
        seasons = item.get('seasons', [])
        if isinstance(seasons, dict):
            seasons = list(seasons.values())

        positive_seasons = [s for s in seasons if s.get('number', 0) > 0]
        num_watched = sum(len(s.get('episodes') or []) for s in positive_seasons)
        if num_watched == 0:
            return None

        aired_episodes = int(show_data.get('aired_episodes', 0) or 0)
        if aired_episodes > 0 and num_watched >= aired_episodes:
            return None

        furthest = furthest_watched_episode(positive_seasons)
        if not furthest:
            return None

        show_ids = show_data.get('ids') or {}
        showtmdb = str(show_ids.get('tmdb') or '0')
        if not showtmdb or showtmdb in ('None', '0'):
            return None

        show_title = (show_data.get('title') or '').strip()
        resolved = resolve_next_season_episode(
            showtmdb,
            furthest['season'],
            furthest['episode'],
            show_data=show_data,
            show_title=show_title,
            fetch_episode=fetch_episode,
            fetch_show=fetch_show,
        )
        if not resolved:
            return None

        next_season, next_episode = resolved
        return {
            'show_data': show_data,
            'season': next_season,
            'episode': next_episode,
            'last_watched_at': furthest.get('last_watched_at'),
        }
    except Exception as exc:
        c.log(f'[NextEp] watched item error: {exc}', 1)
        return None

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file filters.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Composable slot filters for progress lists (next episodes, in-progress shows).

Indexers call slot builders only  -  apply route-specific filter chains here.'''

from ..apis import tmdb as tmdb_api
from ..metadata import tv_status
from ..modules.classy import c


class FilterStats:
    __slots__ = ('dropped',)

    def __init__(self):
        self.dropped = {}

    def record(self, reason):
        if not reason:
            return
        self.dropped[reason] = self.dropped.get(reason, 0) + 1

    @property
    def total(self):
        return sum(self.dropped.values())

    def summary(self):
        if not self.dropped:
            return ''
        parts = [f'{reason}={count}' for reason, count in sorted(self.dropped.items())]
        return ', '.join(parts)


# Partially watched  -  default matches Crew (~92%). Overridable via
# playback.watched_percent (resume hide + tracker watched / WeTrakr min_progress).
# Ignore accidental early pauses (buffer / dialog noise) on lists + play lookup.
RESUME_PROGRESS_MIN = 1.0
RESUME_PROGRESS_MAX_DEFAULT = 92.0
RESUME_PROGRESS_MAX = RESUME_PROGRESS_MAX_DEFAULT  # legacy alias; prefer resume_progress_max()


def resume_progress_max():
    '''% at/above which progress counts as finished (no resume; scrobble watched).'''
    try:
        value = float(c.get_setting('playback.watched_percent') or RESUME_PROGRESS_MAX_DEFAULT)
    except (TypeError, ValueError):
        value = RESUME_PROGRESS_MAX_DEFAULT
    return max(80.0, min(99.0, value))


def resume_progress_min():
    return RESUME_PROGRESS_MIN


def next_episode_key(slot):
    show_data = slot.get('show_data') or {}
    ids = show_data.get('ids') or {}
    tmdb = str(ids.get('tmdb') or '').strip()
    return (tmdb, int(slot.get('season') or 0), int(slot.get('episode') or 0))


def show_slot_trakt_id(slot):
    item = slot.get('item') if isinstance(slot.get('item'), dict) else slot
    show = item.get('show') if isinstance(item.get('show'), dict) else {}
    ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
    return str(ids.get('trakt') or '').strip()


def _episode_exists_on_tmdb(tmdb_id, season, episode):
    try:
        data = tmdb_api.get_tv_episode(tmdb_id, season, episode)
    except Exception:
        return False
    return isinstance(data, dict) and bool(data.get('id') or data.get('name'))


def filter_next_episode_slots(slots, *, hidden_trakt=None, check_tmdb=False, stats=None):
    '''
    Next-episode list filters: dedup  ->  hidden  ->  ended show  ->  optional TMDB ghost probe.
    '''
    if not slots:
        return []

    hidden_trakt = hidden_trakt or set()
    stats = stats or FilterStats()
    seen = set()
    kept = []

    for slot in slots:
        key = next_episode_key(slot)
        tmdb, season, episode = key

        if not tmdb or season <= 0 or episode <= 0:
            stats.record('invalid')
            continue

        if key in seen:
            stats.record('dedup')
            continue
        seen.add(key)

        show_data = slot.get('show_data') or {}
        trakt_id = str((show_data.get('ids') or {}).get('trakt') or '').strip()
        if trakt_id and trakt_id in hidden_trakt:
            stats.record('hidden')
            continue

        if tv_status.trakt_show_blocks_next(show_data):
            stats.record('ended')
            continue

        if check_tmdb and not _episode_exists_on_tmdb(tmdb, season, episode):
            stats.record('ghost')
            continue

        kept.append(slot)

    return kept


def filter_in_progress_show_slots(slots, *, hidden_trakt=None, stats=None):
    '''In-progress show slots: hidden filter only (scan rules already applied).'''
    if not slots:
        return []

    hidden_trakt = hidden_trakt or set()
    stats = stats or FilterStats()
    kept = []

    for slot in slots:
        trakt_id = show_slot_trakt_id(slot)
        if trakt_id and trakt_id in hidden_trakt:
            stats.record('hidden')
            continue
        kept.append(slot)

    return kept


def filter_in_progress_episode_slots(slots, *, hidden_trakt=None, stats=None):
    '''Resume slots: dedup  ->  hidden (scan already drops finished / invalid progress).'''
    if not slots:
        return []

    hidden_trakt = hidden_trakt or set()
    stats = stats or FilterStats()
    seen = set()
    kept = []

    for slot in slots:
        key = next_episode_key(slot)
        tmdb, season, episode = key

        if not tmdb or season <= 0 or episode <= 0:
            stats.record('invalid')
            continue

        if key in seen:
            stats.record('dedup')
            continue
        seen.add(key)

        show_data = slot.get('show_data') or {}
        trakt_id = str((show_data.get('ids') or {}).get('trakt') or '').strip()
        if trakt_id and trakt_id in hidden_trakt:
            stats.record('hidden')
            continue

        kept.append(slot)

    return kept


def log_filter_stats(route, stats, before, after):
    if not stats or not stats.total:
        return
    c.log(
        f'[Progress] {route} filters: {before}  ->  {after} '
        f'(dropped {stats.total}: {stats.summary()})'
    )

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file widget_signals.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Event-driven progress widget cache invalidation.

Prefer notify_progress_changed() over blind worker polling:
  scrobble stop/pause, mark watched CM, tracker flip  ->  pending warm
  in_widget()  ->  force worker + Container.Refresh

A1d: when browsing Classy (not home widget) and video is not playing,
also Container.Refresh so season/episode resume ticks paint without reopen.'''

import xbmc

from ..modules import kodi
from ..modules.classy import c
from ..trakt import activity


def notify_progress_changed(reason=''):
    '''
    Progress / watched data changed  -  queue widget cache rebuild.

    Do NOT wipe prepared blobs here. Eager delete + WeTrakr 429 left Home on
    "No next episodes". Keep last good shelf; ProgressCacheWorker force-warm
    overwrites only when a rebuild returns rows (B0).

    When home widgets are mounted (in_widget), forces an immediate warm on the
    service worker. Otherwise only sets pending; next widget open rebuilds inline.
    In-addon Classy browse also gets a scoped Container.Refresh (A1d).
    '''
    try:
        activity.clear_probe_cache()
    except Exception:
        pass
    kodi.set_widget_warm_pending(reason)
    if kodi.in_widget():
        # Widget heartbeat TTL can stay hot for an hour  -  still refresh the
        # in-addon Videos list when one is showing (A1d).
        c.log(f'[Widget] progress changed ({reason or "?"})  -  force warm')
        kodi.request_widget_warm_force()
        kodi.schedule_widget_refresh()
    elif c.devmode:
        c.log(f'[Widget] progress changed ({reason or "?"})  -  warm pending')
    _maybe_refresh_classy_container(reason)


def _maybe_refresh_classy_container(reason=''):
    '''Scoped list refresh after scrobble/CM  -  mid-play skipped.

    sourceList: refresh stashed origin folder (season/episodes) when present so
    Stop->Back is not required for the resume chip to appear on return.
    '''
    try:
        if xbmc.Player().isPlayingVideo():
            return
    except Exception:
        return

    try:
        plugin = (xbmc.getInfoLabel('Container.PluginName') or '').strip().lower()
        folder = (xbmc.getInfoLabel('Container.FolderPath') or '').strip()
    except Exception:
        return

    addon_id = (c.addon_id or '').strip().lower()
    if not addon_id:
        return

    folder_l = folder.lower()
    ours = False
    if plugin == addon_id:
        ours = True
    elif f'plugin://{addon_id}' in folder_l:
        ours = True
    if not ours:
        return

    # Directory play leaves FolderPath on sourceList; collapse to origin episodes.
    if 'action=sourcelist' in folder_l:
        try:
            from ..sources.directory import collapse_to_origin
            collapse_to_origin(reason=reason or 'progress')
        except Exception:
            pass
        return

    try:
        xbmc.executebuiltin('Container.Refresh')
        c.log(f'[Widget] Classy container refresh ({reason or "?"})')
    except Exception:
        pass

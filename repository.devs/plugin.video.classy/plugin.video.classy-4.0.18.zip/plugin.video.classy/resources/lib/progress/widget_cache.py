# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file widget_cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Prepared progress widget rows  -  disk cache for home-screen GetDirectory.

Worker or first widget warm builds: slots  ->  VideoRow  ->  watch overlay  ->  enrich  ->  SQLite.
Widget route reads rows only (no Trakt bulk, no TMDB on the UI thread when warm).'''

import time

from .. import cache as disk_cache
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from ..modules.service_state import shutdown_requested
from ..trakt import activity
from ..trakt.browse_context import TVBrowseContext
from . import slots as progress_slots

NS_WIDGET = 'widget'
_SCHEMA = 1

ROUTE_NEXT_EPISODES = 'progress_next_episodes'
ROUTE_IN_PROGRESS_SHOWS = 'progress_shows'
ROUTE_IN_PROGRESS_EPISODES = 'progress_in_progress_episodes'

_ALL_ROUTES = (
    ROUTE_NEXT_EPISODES,
    ROUTE_IN_PROGRESS_SHOWS,
    ROUTE_IN_PROGRESS_EPISODES,
)


def _cache_key(route):
    return str(route or '').strip()


def _rows_have_art(rows):
    if not rows:
        return False
    for row in rows:
        if isinstance(row, dict):
            if row.get('poster') or row.get('thumb') or row.get('tmdb_poster_path'):
                return True
        elif isinstance(row, VideoRow):
            if row.has_poster():
                return True
    return False


def read_prepared_rows(route, *, invalidation=None, allow_stale=True):
    '''
    Return list[VideoRow] on hit, else None.

    When invalidation is given, exact match wins; allow_stale serves last blob anyway.
    '''
    key = _cache_key(route)
    if not key:
        return None

    if invalidation:
        blob = disk_cache.get_json(NS_WIDGET, key, invalidation=invalidation)
        if isinstance(blob, dict):
            rows = _unwrap_blob(blob)
            if rows:
                c.log(f'[WidgetCache] hit {key} inv={str(invalidation)[:8]}... ({len(rows)} rows)')
                return rows

    if not allow_stale:
        return None

    blob = disk_cache.get_json(NS_WIDGET, key, invalidation=None, ttl_ok=True)
    if not isinstance(blob, dict):
        return None
    rows = _unwrap_blob(blob)
    if not rows:
        return None
    inv = str(blob.get('inv') or '')
    c.log(
        f'[WidgetCache] stale hit {key} inv={inv[:8] + "..." if inv else " - "} '
        f'({len(rows)} rows)'
    )
    return rows


def write_prepared_rows(route, invalidation, rows):
    key = _cache_key(route)
    if not key or not invalidation or not rows:
        return False
    payload = {
        'v': _SCHEMA,
        'route': key,
        'inv': str(invalidation),
        'built_at': time.time(),
        'rows': [
            row.to_dict() if isinstance(row, VideoRow) else dict(row)
            for row in rows
        ],
    }
    ok = disk_cache.put_json(NS_WIDGET, key, payload, invalidation=str(invalidation))
    if ok and c.devmode:
        c.log(f'[WidgetCache] wrote {key} inv={str(invalidation)[:8]}... ({len(rows)} rows)')
    return ok


def invalidate_prepared_routes(reason=''):
    '''Drop prepared home-widget blobs so the next GetDirectory rebuilds.

    Progress change used to leave the last blob in place; readers call
    read_prepared_rows without an invalidation stamp and allow_stale=True, so
    Home kept serving Treasure-Island-stale Next Episodes until cache clear.
    '''
    dropped = 0
    for route in _ALL_ROUTES:
        try:
            if disk_cache.delete(NS_WIDGET, _cache_key(route)):
                dropped += 1
        except Exception:
            pass
    if dropped:
        c.log(
            f'[WidgetCache] invalidated {dropped} route(s)'
            f'{f" ({reason})" if reason else ""}'
        )
    return dropped


def _unwrap_blob(blob):
    if int(blob.get('v') or 0) < _SCHEMA:
        return None
    raw = blob.get('rows')
    if not isinstance(raw, list) or not raw:
        return None
    return [VideoRow.from_dict(item) for item in raw]


def _progress_invalidation(probe=None, *, fallback='progress'):
    '''Trakt ActivityProbe fingerprint, or WeTrakr/Simkl activity stamp.'''
    if probe is not None:
        try:
            fp = probe.progress_fingerprint()
            if fp:
                return fp
        except Exception:
            pass
        try:
            fp = probe.fingerprint('episodes')
            if fp:
                return fp
        except Exception:
            pass
    try:
        from .. import tracker
        if tracker.is_wetrakr() and tracker.live():
            from ..wetrakr import sync as wt_sync
            return wt_sync.activity_stamp('episodes') or 'wetrakr'
        if tracker.is_simkl() and tracker.live():
            return 'simkl'
    except Exception:
        pass
    return fallback


def build_next_episode_rows(*, log_label='widget_next', probe=None):
    ctx = TVBrowseContext.load(log_label=log_label, probe=probe, clear_probe=True)
    top_slots, _total, fp, _unchanged = progress_slots.next_episode_slots(
        limit=progress_slots.PAGE_SIZE,
        log_label=log_label,
        widget=True,
        probe=ctx.probe,
        watched=ctx.watched,
    )
    inv = fp or _progress_invalidation(ctx.probe, fallback='wetrakr')
    if not top_slots:
        return inv, []
    rows = [progress_slots.slot_to_video_row(slot) for slot in top_slots]
    for row in rows:
        ctx.apply_watch(row)
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=True)
    for row in rows:
        row.thumb = ''
    return inv, rows


def build_in_progress_show_rows(*, log_label='widget_shows', probe=None):
    ctx = TVBrowseContext.load(log_label=log_label, probe=probe, clear_probe=True)
    top_slots, _total, fp, _unchanged, _filtered = progress_slots.in_progress_show_slots(
        limit=progress_slots.PAGE_SIZE,
        log_label=log_label,
        widget=True,
        probe=ctx.probe,
        watched=ctx.watched,
    )
    inv = fp or _progress_invalidation(ctx.probe, fallback='wetrakr')
    if not top_slots:
        return inv, []
    rows = [progress_slots.slot_to_show_row(slot) for slot in top_slots]
    ctx.apply_watch_rows(rows)
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=True)
    return inv, rows


def build_in_progress_episode_rows(*, log_label='widget_resume', probe=None):
    if probe is None:
        try:
            from .. import tracker
            if tracker.is_trakt() and tracker.live():
                activity.clear_probe_cache()
                probe = activity.probe_last_activities(log_label=log_label)
        except Exception:
            probe = None
    top_slots, _total, fp, _unchanged, _filtered = progress_slots.in_progress_episode_slots(
        limit=progress_slots.PAGE_SIZE,
        log_label=log_label,
        widget=True,
        probe=probe,
    )
    inv = fp or _progress_invalidation(probe, fallback='wetrakr')
    if not top_slots:
        return inv, []
    rows = [progress_slots.slot_to_resume_row(slot) for slot in top_slots]
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=True)
    for row in rows:
        row.thumb = ''
    return inv, rows


_BUILDERS = {
    ROUTE_NEXT_EPISODES: build_next_episode_rows,
    ROUTE_IN_PROGRESS_SHOWS: build_in_progress_show_rows,
    ROUTE_IN_PROGRESS_EPISODES: build_in_progress_episode_rows,
}


def warm_route(route, *, log_label=None, probe=None, force=False):
    '''Build one widget route and persist rows. Returns True when cache updated.'''
    builder = _BUILDERS.get(_cache_key(route))
    if not builder:
        return False
    label = log_label or f'warm_{route}'
    inv, rows = builder(log_label=label, probe=probe)
    if not rows:
        return False
    if not force:
        cached = disk_cache.get_json(NS_WIDGET, _cache_key(route), invalidation=inv)
        if isinstance(cached, dict) and _unwrap_blob(cached):
            return False
    return write_prepared_rows(route, inv, rows)


def warm_all(*, log_label='widget_cache', force=False):
    '''Service worker entry  -  refresh stale or missing widget rows.'''
    if shutdown_requested() or not _has_live_progress_tracker():
        return 0
    try:
        from .. import tracker
        if tracker.is_wetrakr() and tracker.live():
            from ..apis import wetrakr as wt_api
            if wt_api.is_rate_limited():
                c.log('[WidgetCache] warm_all skipped  -  WeTrakr rate-limited')
                return 0
    except Exception:
        pass
    probe = None
    try:
        from .. import tracker
        if tracker.is_trakt() and tracker.live():
            activity.clear_probe_cache()
            probe = activity.probe_last_activities(log_label=log_label)
    except Exception:
        probe = None
    updated = 0
    for route in _ALL_ROUTES:
        if shutdown_requested():
            break
        try:
            if warm_route(route, log_label=log_label, probe=probe, force=force):
                updated += 1
        except Exception as exc:
            c.log(f'[WidgetCache] warm {route} failed: {exc}', 1)
    if updated and c.devmode:
        c.log(f'[WidgetCache] warm_all updated {updated} route(s)')
    return updated


def save_after_widget_render(route, invalidation, rows):
    '''Write-through after inline widget build so the next reload is cache-hot.'''
    if not rows or not invalidation:
        return
    if not _rows_have_art(rows):
        return
    write_prepared_rows(route, invalidation, rows)


def _has_live_progress_tracker():
    '''True when home progress widgets have a live tracker to warm from.'''
    try:
        from ..tracker.gate import is_trakt, is_simkl, is_wetrakr, live
        if not live():
            return False
        if is_wetrakr():
            from ..wetrakr import auth as wt_auth
            return wt_auth.has_credentials()
        if is_simkl():
            from ..simkl import auth as simkl_auth
            return simkl_auth.has_credentials()
        if is_trakt():
            from ..trakt import auth as trakt_auth
            return trakt_auth.has_credentials()
    except Exception:
        return False
    return False

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file slots.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Next-episode slots from Trakt watched/shows  -  no TMDB, no Kodi UI.'''

import heapq

from ..metadata.video_row import VideoRow
from ..modules.classy import c
from .. import tracker
from ..trakt import activity
from ..trakt import hidden as trakt_hidden
from ..trakt import store
from ..trakt import sync
from . import filters as slot_filters
from . import next_episode as next_episode_resolver

PAGE_SIZE = 25


def last_watched_sort_key(slot):
    return slot.get('last_watched_at') or '1900-01-01T00:00:00.000Z'


def scan_watched_for_next_episodes(result):
    '''Phase 0 slots  -  next after furthest watched, with finale/404 resolution.'''
    next_items = []
    for item in result or []:
        slot = next_episode_resolver.resolve_next_for_watched_item(item)
        if slot:
            next_items.append(slot)
    return next_items


def _finalize_next_episode_slots(slots, *, log_label='next_episodes', check_tmdb=False):
    hidden_trakt = trakt_hidden.hidden_show_trakt_ids(log_label=log_label)
    before = len(slots or [])
    stats = slot_filters.FilterStats()
    filtered = slot_filters.filter_next_episode_slots(
        slots or [],
        hidden_trakt=hidden_trakt,
        check_tmdb=check_tmdb,
        stats=stats,
    )
    slot_filters.log_filter_stats('next_episodes', stats, before, len(filtered))
    return filtered


def _finalize_in_progress_show_slots(slots, *, log_label='in_progress_shows'):
    hidden_trakt = trakt_hidden.hidden_show_trakt_ids(log_label=log_label)
    before = len(slots or [])
    stats = slot_filters.FilterStats()
    filtered = slot_filters.filter_in_progress_show_slots(
        slots or [],
        hidden_trakt=hidden_trakt,
        stats=stats,
    )
    slot_filters.log_filter_stats('in_progress_shows', stats, before, len(filtered))
    return filtered, stats.total


def resolve_next_episode_slots(watched=None, *, log_label='next_episodes', probe=None):
    if probe is None:
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.progress_fingerprint()

    cached = store.read_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] next-episode slots cache hit '
            f'({len(cached)} slots, inv={inv[:8]}...)'
        )
        cached = _finalize_next_episode_slots(cached, log_label=log_label)
        return cached

    if watched is None:
        watched = sync.get_watched_shows_extended(log_label, probe=probe)

    slots = scan_watched_for_next_episodes(watched)
    slots = _finalize_next_episode_slots(slots, log_label=log_label)
    c.log(
        f'[Progress] scanned {len(watched or [])} shows  ->  {len(slots)} next-episode slots'
    )
    if inv and slots:
        store.write_slots_cache(inv, slots)
    return slots


def top_slots(slots, limit=PAGE_SIZE):
    if not slots:
        return []
    if len(slots) <= limit:
        return sorted(slots, key=last_watched_sort_key, reverse=True)
    return heapq.nlargest(limit, slots, key=last_watched_sort_key)


def slot_to_video_row(slot):
    show_data = slot.get('show_data') or {}
    show_ids = show_data.get('ids') or {}
    return VideoRow(
        mediatype='episode',
        title='',
        tvshowtitle=(show_data.get('title') or '').strip(),
        season=int(slot.get('season') or 0),
        episode=int(slot.get('episode') or 0),
        imdb=str(show_ids.get('imdb') or ''),
        tmdb=str(show_ids.get('tmdb') or ''),
        tvdb=str(show_ids.get('tvdb') or ''),
        trakt=str(show_ids.get('trakt') or ''),
    )


def next_episode_slots(
    page=1,
    limit=PAGE_SIZE,
    log_label='next_episodes',
    widget=False,
    probe=None,
    watched=None,
):
    if tracker.is_simkl() and tracker.live():
        from ..simkl import progress as simkl_progress
        slots = simkl_progress.next_episode_sessions()
        slots = _finalize_next_episode_slots(slots, log_label=log_label, check_tmdb=False)
        if widget:
            return top_slots(slots, limit), len(slots), 'simkl', False
        page_items, total, page = page_slots(slots, page=page, page_size=limit)
        return page_items, total, 'simkl', False
    if tracker.is_wetrakr() and tracker.live():
        from ..wetrakr import progress as wetrakr_progress
        slots = wetrakr_progress.next_episode_sessions()
        slots = _finalize_next_episode_slots(slots, log_label=log_label, check_tmdb=False)
        if widget:
            return top_slots(slots, limit), len(slots), 'wetrakr', False
        page_items, total, page = page_slots(slots, page=page, page_size=limit)
        return page_items, total, 'wetrakr', False
    '''
    Activity probe  ->  slots (SQLite)  ->  top N or page by last watched.

    Returns (slots, total, invalidation_fp, activities_unchanged).
    '''
    if probe is None:
        activity.clear_probe_cache()
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.progress_fingerprint()
    unchanged = probe.progress_unchanged()

    cached = store.read_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] skipping watched/shows fetch (derived slots cache, '
            f'{len(cached)} slots)'
        )
        cached = _finalize_next_episode_slots(cached, log_label=log_label)
        if widget:
            return top_slots(cached, limit), len(cached), inv, unchanged
        page_items, total, page = page_slots(cached, page=page, page_size=limit)
        return page_items, total, inv, unchanged

    if watched is None:
        watched = sync.get_watched_shows_extended(log_label, probe=probe)
    slots = resolve_next_episode_slots(watched, log_label=log_label, probe=probe)
    if widget:
        return top_slots(slots, limit), len(slots), inv, unchanged
    page_items, total, page = page_slots(slots, page=page, page_size=limit)
    return page_items, total, inv, unchanged


def scan_in_progress_show_slots(result):
    '''Build in-progress show slots from watched payload (business rules only).'''
    show_slots = []
    filtered_count = 0
    for item in result or []:
        try:
            show_data = item.get('show', {})
            aired_episodes = int(show_data.get('aired_episodes', 0) or 0)
            show_ids = show_data.get('ids') or {}
            showtmdb = str(show_ids.get('tmdb') or '0')

            seasons = item.get('seasons', [])
            if isinstance(seasons, dict):
                seasons = list(seasons.values())
            positive_seasons = [s for s in seasons if s.get('number', 0) > 0]
            watched_count = sum(len(s.get('episodes') or []) for s in positive_seasons)
            if watched_count == 0:
                filtered_count += 1
                continue
            if watched_count >= aired_episodes and aired_episodes > 0:
                filtered_count += 1
                continue

            if not showtmdb or showtmdb in ('None', '0'):
                continue

            last_timestamp = None
            for season in positive_seasons:
                for ep in (season.get('episodes') or []):
                    ts = ep.get('last_watched_at')
                    if ts and (last_timestamp is None or ts > last_timestamp):
                        last_timestamp = ts

            show_slots.append({
                'item': item,
                'last_watched_at': last_timestamp,
            })
        except Exception as exc:
            c.log(f'[Progress] in-progress show scan error: {exc}', 1)
    return show_slots, filtered_count


def resolve_in_progress_show_slots(watched=None, *, log_label='in_progress_shows', probe=None):
    if probe is None:
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.progress_fingerprint()

    cached = store.read_show_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] in-progress show slots cache hit '
            f'({len(cached)} slots, inv={inv[:8]}...)'
        )
        cached, hidden_dropped = _finalize_in_progress_show_slots(
            cached, log_label=log_label,
        )
        return cached, hidden_dropped

    if watched is None:
        watched = sync.get_watched_shows_extended(log_label, probe=probe)

    slots, filtered_count = scan_in_progress_show_slots(watched)
    slots, hidden_dropped = _finalize_in_progress_show_slots(slots, log_label=log_label)
    filtered_count += hidden_dropped
    c.log(
        f'[Progress] scanned {len(watched or [])} shows  ->  '
        f'{len(slots)} in-progress show slots'
    )
    if inv and slots:
        store.write_show_slots_cache(inv, slots)
    return slots, filtered_count


def page_slots(slots, page=1, page_size=PAGE_SIZE):
    ordered = sorted(slots, key=last_watched_sort_key, reverse=True)
    total = len(ordered)
    try:
        page = max(1, int(page))
    except (TypeError, ValueError):
        page = 1
    start = (page - 1) * page_size
    end = start + page_size
    return ordered[start:end], total, page


def slot_to_show_row(slot):
    return VideoRow.from_trakt_watched_show(slot.get('item') or {})


def in_progress_show_slots(
    page=1,
    limit=PAGE_SIZE,
    log_label='in_progress_shows',
    widget=False,
    probe=None,
    watched=None,
):
    if (tracker.is_simkl() or tracker.is_wetrakr()) and tracker.live():
        if tracker.is_wetrakr():
            from ..wetrakr import progress as _tracker_progress
            _src = 'wetrakr'
        else:
            from ..simkl import progress as _tracker_progress
            _src = 'simkl'
        items = _tracker_progress.watching_show_items()
        # Convert Trakt-shaped show items into show slots (item + show_data).
        slots = []
        for item in items:
            show = item.get('show') if isinstance(item, dict) else None
            if not isinstance(show, dict):
                continue
            slots.append({
                'item': item,
                'show_data': show,
                'last_watched_at': '',
            })
        ordered = sorted(slots, key=last_watched_sort_key, reverse=True)
        page_items, total, page = page_slots(ordered, page=page, page_size=limit)
        return page_items, total, _src, False, 0
    if probe is None:
        activity.clear_probe_cache()
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.progress_fingerprint()
    unchanged = probe.progress_unchanged()
    filtered_count = 0

    cached = store.read_show_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] skipping watched/shows fetch (derived show slots cache, '
            f'{len(cached)} slots)'
        )
        cached, hidden_dropped = _finalize_in_progress_show_slots(
            cached, log_label=log_label,
        )
        filtered_count = hidden_dropped
        if widget:
            return top_slots(cached, limit), len(cached), inv, unchanged, filtered_count
        page_items, total, page = page_slots(cached, page=page, page_size=limit)
        return page_items, total, inv, unchanged, filtered_count

    if watched is None:
        watched = sync.get_watched_shows_extended(log_label, probe=probe)
    slots, filtered_count = resolve_in_progress_show_slots(
        watched,
        log_label=log_label,
        probe=probe,
    )
    if widget:
        return top_slots(slots, limit), len(slots), inv, unchanged, filtered_count
    page_items, total, page = page_slots(slots, page=page, page_size=limit)
    return page_items, total, inv, unchanged, filtered_count


def paused_at_sort_key(slot):
    return slot.get('paused_at') or slot.get('last_watched_at') or '1900-01-01T00:00:00.000Z'


def scan_in_progress_episode_slots(playback_items):
    '''Build resume slots from Trakt playback/episodes (partial watch only).'''
    slots = []
    filtered_count = 0
    pmin = slot_filters.resume_progress_min()
    pmax = slot_filters.resume_progress_max()

    for item in playback_items or []:
        try:
            progress = float(item.get('progress', 0) or 0)
            if progress <= pmin or progress >= pmax:
                filtered_count += 1
                continue

            episode_data = item.get('episode') if isinstance(item.get('episode'), dict) else {}
            show_data = item.get('show') if isinstance(item.get('show'), dict) else {}
            season = int(episode_data.get('season') or 0)
            episode = int(episode_data.get('number') or 0)
            if season <= 0 or episode <= 0:
                filtered_count += 1
                continue

            show_ids = show_data.get('ids') if isinstance(show_data.get('ids'), dict) else {}
            showtmdb = str(show_ids.get('tmdb') or '0')
            if not showtmdb or showtmdb in ('None', '0'):
                filtered_count += 1
                continue

            paused_at = item.get('paused_at') or ''
            slots.append({
                'item': item,
                'show_data': show_data,
                'season': season,
                'episode': episode,
                'progress': progress,
                'paused_at': paused_at,
                'last_watched_at': paused_at,
            })
        except Exception as exc:
            c.log(f'[Progress] in-progress episode scan error: {exc}', 1)
    return slots, filtered_count


def _finalize_in_progress_episode_slots(slots, *, log_label='in_progress_episodes'):
    hidden_trakt = trakt_hidden.hidden_show_trakt_ids(log_label=log_label)
    before = len(slots or [])
    stats = slot_filters.FilterStats()
    filtered = slot_filters.filter_in_progress_episode_slots(
        slots or [],
        hidden_trakt=hidden_trakt,
        stats=stats,
    )
    slot_filters.log_filter_stats('in_progress_episodes', stats, before, len(filtered))
    return filtered, stats.total


def resolve_in_progress_episode_slots(playback=None, *, log_label='in_progress_episodes', probe=None):
    if probe is None:
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.fingerprint('episodes')

    cached = store.read_episode_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] in-progress episode slots cache hit '
            f'({len(cached)} slots, inv={inv[:8]}...)'
        )
        cached, hidden_dropped = _finalize_in_progress_episode_slots(
            cached, log_label=log_label,
        )
        return cached, hidden_dropped

    if playback is None:
        playback = sync.get_playback_episodes_extended(log_label, probe=probe)

    slots, filtered_count = scan_in_progress_episode_slots(playback)
    slots, hidden_dropped = _finalize_in_progress_episode_slots(slots, log_label=log_label)
    filtered_count += hidden_dropped
    c.log(
        f'[Progress] scanned {len(playback or [])} playback rows  ->  '
        f'{len(slots)} in-progress episode slots'
    )
    if inv and slots:
        store.write_episode_slots_cache(inv, slots)
    return slots, filtered_count


def top_resume_slots(slots, limit=PAGE_SIZE):
    if not slots:
        return []
    if len(slots) <= limit:
        return sorted(slots, key=paused_at_sort_key, reverse=True)
    return heapq.nlargest(limit, slots, key=paused_at_sort_key)


def slot_to_resume_row(slot):
    row = VideoRow.from_trakt_episode(slot.get('item') or {})
    row.resume_point = float(slot.get('progress') or row.resume_point or 0)
    row.playcount = 0
    row.overlay = 6  # unwatched / in-progress  -  resume arrow via setResumePoint
    return row


def in_progress_episode_slots(
    page=1,
    limit=PAGE_SIZE,
    log_label='in_progress_episodes',
    widget=False,
    probe=None,
    playback=None,
):
    if (tracker.is_simkl() or tracker.is_wetrakr()) and tracker.live():
        if tracker.is_wetrakr():
            from ..wetrakr import progress as _tracker_progress
            _src = 'wetrakr'
        else:
            from ..simkl import progress as _tracker_progress
            _src = 'simkl'
        if playback is None:
            playback = _tracker_progress.episode_playback_items()
        slots, filtered_count = scan_in_progress_episode_slots(playback)
        slots, hidden_dropped = _finalize_in_progress_episode_slots(
            slots, log_label=log_label,
        )
        filtered_count += hidden_dropped
        ordered = sorted(slots, key=paused_at_sort_key, reverse=True)
        if widget:
            return (
                top_resume_slots(ordered, limit), len(ordered),
                _src, False, filtered_count,
            )
        page_items, total, page = page_slots(ordered, page=page, page_size=limit)
        return page_items, total, _src, False, filtered_count
    if probe is None:
        activity.clear_probe_cache()
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.fingerprint('episodes')
    unchanged = probe.stored_fingerprint('episodes') == inv if inv else False
    filtered_count = 0

    cached = store.read_episode_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] skipping playback fetch (derived episode slots cache, '
            f'{len(cached)} slots)'
        )
        cached, hidden_dropped = _finalize_in_progress_episode_slots(
            cached, log_label=log_label,
        )
        filtered_count = hidden_dropped
        ordered = sorted(cached, key=paused_at_sort_key, reverse=True)
        if widget:
            return top_resume_slots(ordered, limit), len(ordered), inv, unchanged, filtered_count
        page_items, total, page = page_slots(ordered, page=page, page_size=limit)
        return page_items, total, inv, unchanged, filtered_count

    if playback is None:
        playback = sync.get_playback_episodes_extended(log_label, probe=probe)
    slots, filtered_count = resolve_in_progress_episode_slots(
        playback,
        log_label=log_label,
        probe=probe,
    )
    ordered = sorted(slots, key=paused_at_sort_key, reverse=True)
    if widget:
        return top_resume_slots(ordered, limit), len(ordered), inv, unchanged, filtered_count
    page_items, total, page = page_slots(ordered, page=page, page_size=limit)
    return page_items, total, inv, unchanged, filtered_count


def scan_in_progress_movie_slots(playback_items):
    '''Build resume slots from Trakt playback/movies (partial watch only).'''
    slots = []
    filtered_count = 0
    seen = set()
    pmin = slot_filters.resume_progress_min()
    pmax = slot_filters.resume_progress_max()

    for item in playback_items or []:
        try:
            progress = float(item.get('progress', 0) or 0)
            if progress <= pmin or progress >= pmax:
                filtered_count += 1
                continue

            movie_data = item.get('movie') if isinstance(item.get('movie'), dict) else {}
            ids = movie_data.get('ids') if isinstance(movie_data.get('ids'), dict) else {}
            tmdb = str(ids.get('tmdb') or '').strip()
            imdb = str(ids.get('imdb') or '').strip()
            if not tmdb and not imdb:
                filtered_count += 1
                continue

            dedupe = ('tmdb', tmdb) if tmdb else ('imdb', imdb)
            if dedupe in seen:
                filtered_count += 1
                continue
            seen.add(dedupe)

            paused_at = item.get('paused_at') or ''
            slots.append({
                'item': item,
                'progress': progress,
                'paused_at': paused_at,
                'last_watched_at': paused_at,
            })
        except Exception as exc:
            c.log(f'[Progress] in-progress movie scan error: {exc}', 1)
    return slots, filtered_count


def resolve_in_progress_movie_slots(playback=None, *, log_label='movie_progress', probe=None):
    if probe is None:
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.fingerprint('movies')

    cached = store.read_movie_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] in-progress movie slots cache hit '
            f'({len(cached)} slots, inv={inv[:8]}...)'
        )
        return cached, 0

    if playback is None:
        playback = sync.get_playback_movies_extended(log_label, probe=probe)

    slots, filtered_count = scan_in_progress_movie_slots(playback)
    c.log(
        f'[Progress] scanned {len(playback or [])} movie playback rows  ->  '
        f'{len(slots)} continue-watching slots'
    )
    if inv and slots:
        store.write_movie_slots_cache(inv, slots)
    return slots, filtered_count


def slot_to_movie_resume_row(slot):
    row = VideoRow.from_trakt_movie(slot.get('item') or {})
    row.resume_point = float(slot.get('progress') or row.resume_point or 0)
    row.playcount = 0
    row.overlay = 6
    movie = (slot.get('item') or {}).get('movie') or {}
    runtime_min = int(movie.get('runtime') or 0)
    if runtime_min > 0 and not int(row.duration or 0):
        row.duration = runtime_min * 60
    return row


def in_progress_movie_slots(
    page=1,
    limit=PAGE_SIZE,
    log_label='movie_progress',
    probe=None,
    playback=None,
):
    if (tracker.is_simkl() or tracker.is_wetrakr()) and tracker.live():
        if tracker.is_wetrakr():
            from ..wetrakr import progress as _tracker_progress
            _src = 'wetrakr'
        else:
            from ..simkl import progress as _tracker_progress
            _src = 'simkl'
        if playback is None:
            playback = _tracker_progress.movie_playback_items()
        slots, filtered_count = scan_in_progress_movie_slots(playback)
        ordered = sorted(slots, key=paused_at_sort_key, reverse=True)
        page_items, total, page = page_slots(ordered, page=page, page_size=limit)
        return page_items, total, _src, False, filtered_count
    if probe is None:
        activity.clear_probe_cache()
        probe = activity.probe_last_activities(log_label=log_label)
    inv = probe.fingerprint('movies')
    unchanged = probe.stored_fingerprint('movies') == inv if inv else False
    filtered_count = 0

    cached = store.read_movie_slots_cache(inv)
    if cached is not None:
        c.log(
            f'[Progress] skipping movie playback fetch (derived movie slots cache, '
            f'{len(cached)} slots)'
        )
        ordered = sorted(cached, key=paused_at_sort_key, reverse=True)
        page_items, total, page = page_slots(ordered, page=page, page_size=limit)
        return page_items, total, inv, unchanged, filtered_count

    if playback is None:
        playback = sync.get_playback_movies_extended(log_label, probe=probe)
    slots, filtered_count = resolve_in_progress_movie_slots(
        playback,
        log_label=log_label,
        probe=probe,
    )
    ordered = sorted(slots, key=paused_at_sort_key, reverse=True)
    page_items, total, page = page_slots(ordered, page=page, page_size=limit)
    return page_items, total, inv, unchanged, filtered_count

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi dev smoke tests (Developers menu).'''

from . import dev_apis_test
from . import dev_client_test
from . import dev_metadata_test
from . import dev_progress_test
from . import dev_trakt_test

__all__ = (
    'dev_apis_test',
    'dev_client_test',
    'dev_metadata_test',
    'dev_progress_test',
    'dev_trakt_test',
)

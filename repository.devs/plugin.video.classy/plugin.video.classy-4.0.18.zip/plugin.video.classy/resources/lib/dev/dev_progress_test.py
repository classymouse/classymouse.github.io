# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_progress_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi progress smoke test  -  gate + slot sanity (next episodes + shows).'''

from ..progress import slots as progress_slots
from ..trakt import activity
from ..trakt import auth
from ..modules.classy import c


def _slot_label(slot, *, shows=False):
    if shows:
        row = progress_slots.slot_to_show_row(slot)
        return f'{row.tvshowtitle!r} tmdb={row.tmdb}'
    row = progress_slots.slot_to_video_row(slot)
    return (
        f'{row.tvshowtitle!r} S{row.season:02d}E{row.episode:02d} '
        f'tmdb={row.tmdb}'
    )


def run():
    lines = []

    if not auth.has_credentials():
        lines.append('progress: auth SKIP (no token)')
        summary = ' | '.join(lines)
        c.log(f'[DevProgressTest] {summary}')
        return summary

    probe = activity.probe_last_activities(log_label='dev_progress')
    if isinstance(probe.payload, dict) and probe.payload.get('episodes') is not None:
        unchanged = probe.progress_unchanged()
        fp = probe.progress_fingerprint()
        changed = probe.changed_domains()
        extra = f', changed={",".join(changed) or "none"}' if not unchanged else ''
        lines.append(f'progress: gate OK ({("unchanged" if unchanged else "changed")}, fp={fp[:8]}...{extra})')
    else:
        lines.append('progress: gate FAIL')
        c.log('[DevProgressTest] last_activities gate FAIL', 1)
        summary = ' | '.join(lines)
        c.log(f'[DevProgressTest] {summary}')
        return summary

    top, total, slot_fp, slot_unchanged = progress_slots.next_episode_slots(
        limit=25, log_label='dev_progress', widget=True,
    )
    if top:
        pilots = sum(1 for s in top if s.get('season') == 1 and s.get('episode') == 1)
        lines.append(f'progress: next slots OK ({len(top)} of {total}, S01E01={pilots})')
        if pilots > len(top) // 2:
            c.log(
                f'[DevProgressTest] WARN many S01E01 slots ({pilots}/{len(top)})  -  '
                'check scan or clear derived slot cache',
                1,
            )
        for slot in top[:8]:
            c.log(f'[DevProgressTest] next {_slot_label(slot)}')
        if len(top) > 8:
            c.log(f'[DevProgressTest] ... and {len(top) - 8} more next-episode slots')
    else:
        lines.append('progress: next slots EMPTY')
        c.log('[DevProgressTest] no next-episode slots', 1)

    show_top, show_total, _, _, _ = progress_slots.in_progress_show_slots(
        limit=10, log_label='dev_progress_shows', widget=True,
    )
    if show_top:
        lines.append(f'progress: show slots OK ({len(show_top)} of {show_total})')
        for slot in show_top[:5]:
            c.log(f'[DevProgressTest] show {_slot_label(slot, shows=True)}')
    else:
        lines.append('progress: show slots EMPTY')

    resume_top, resume_total, _, _, _ = progress_slots.in_progress_episode_slots(
        limit=10, log_label='dev_progress_resume', widget=True,
    )
    if resume_top:
        lines.append(f'progress: resume slots OK ({len(resume_top)} of {resume_total})')
        for slot in resume_top[:5]:
            row = progress_slots.slot_to_resume_row(slot)
            c.log(
                f'[DevProgressTest] resume {row.tvshowtitle!r} '
                f'S{row.season:02d}E{row.episode:02d} {row.resume_point:.0f}%'
            )
    else:
        lines.append('progress: resume slots EMPTY')

    if slot_fp:
        lines.append(f'progress: fp={slot_fp[:8]}...')

    summary = ' | '.join(lines)
    c.log(f'[DevProgressTest] {summary}')
    return summary

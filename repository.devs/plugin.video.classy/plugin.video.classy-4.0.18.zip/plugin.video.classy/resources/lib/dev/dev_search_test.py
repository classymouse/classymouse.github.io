# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_search_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi smoke test  -  TMDB search + SQLite history (grep classy.log for [DevSearchTest]).'''

from ..apis.tmdb import tmdb
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from ..search import history


def _sample_titles(data, factory, limit=3):
    out = []
    for item in (data or {}).get('results') or []:
        if not isinstance(item, dict):
            continue
        row = factory(item)
        label = row.title or row.tvshowtitle or '?'
        year = row.year or ''
        out.append(f'{label} ({year})' if year else label)
        if len(out) >= limit:
            break
    return out


def run():
    lines = []
    probe = 'classy-search-probe'

    for mediatype, factory, query in (
        ('movie', VideoRow.from_tmdb_movie, 'matrix'),
        ('tvshow', VideoRow.from_tmdb_tv, 'breaking bad'),
    ):
        data = tmdb.search(mediatype, query, page=1)
        if not data or not data.get('results'):
            msg = f'{mediatype}: TMDB search FAIL ({query!r})'
            lines.append(msg)
            c.log(f'[DevSearchTest] {msg}', 1)
            continue
        total = int(data.get('total_results') or len(data['results']))
        pages = int(data.get('total_pages') or 1)
        samples = _sample_titles(data, factory)
        msg = f'{mediatype}: {total} hit(s) p1/{pages}  -  {", ".join(samples)}'
        lines.append(msg)
        c.log(f'[DevSearchTest] {msg}')

        if pages > 1:
            page2 = tmdb.search(mediatype, query, page=2)
            p2_count = len((page2 or {}).get('results') or [])
            if p2_count:
                lines.append(f'{mediatype}: page2 OK ({p2_count} row(s))')
                c.log(f'[DevSearchTest] {mediatype}: page2 OK ({p2_count} row(s))')
            else:
                lines.append(f'{mediatype}: page2 FAIL')
                c.log(f'[DevSearchTest] {mediatype}: page2 FAIL', 1)

    empty = tmdb.search('movie', 'zzzznonexistenttitle99999xyz', page=1)
    empty_count = len((empty or {}).get('results') or [])
    if empty_count == 0:
        lines.append('empty query: OK')
        c.log('[DevSearchTest] empty query returns 0 results OK')
    else:
        lines.append('empty query: unexpected hits')
        c.log(f'[DevSearchTest] empty query unexpected: {empty_count}', 1)

    people = tmdb.search_person('cruise', page=1)
    if not people or not people.get('results'):
        msg = 'person: TMDB search FAIL'
        lines.append(msg)
        c.log(f'[DevSearchTest] {msg}', 1)
    else:
        names = [
            str(item.get('name') or '?')
            for item in people['results'][:3]
            if isinstance(item, dict)
        ]
        msg = f'person: {len(people["results"])} hit(s)  -  {", ".join(names)}'
        lines.append(msg)
        c.log(f'[DevSearchTest] {msg}')

    history.touch_term('movie', probe)
    history.touch_term('tvshow', probe)
    movie_terms = [t for _, t in history.list_terms('movie')]
    tv_terms = [t for _, t in history.list_terms('tvshow')]
    if probe in movie_terms and probe in tv_terms:
        lines.append('history: touch + list OK')
        c.log('[DevSearchTest] history touch + list OK')
    else:
        lines.append('history: FAIL')
        c.log(f'[DevSearchTest] history FAIL movie={movie_terms} tv={tv_terms}', 1)

    for mediatype in ('movie', 'tvshow'):
        terms = history.list_terms(mediatype)
        if not terms:
            continue
        term_id, term = terms[0]
        if term == probe:
            history.delete_term(mediatype, term_id)
    if probe not in [t for _, t in history.list_terms('movie')]:
        lines.append('history: delete OK')
        c.log('[DevSearchTest] history delete OK')

    summary = ' | '.join(lines)
    c.log(f'[DevSearchTest] {summary}')
    return summary

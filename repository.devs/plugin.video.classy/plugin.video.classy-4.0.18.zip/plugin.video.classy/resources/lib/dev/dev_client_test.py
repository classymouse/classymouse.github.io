# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_client_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Phase 0 dev tests  -  client + msg_handler + CDN.

Run from Developers  ->  Test 2 (devmode).'''

from ..modules.classy import c
from ..modules import client
from ..modules import msg_handler


CDN_TEST_URI = 'https://raw.githubusercontent.com/posadka/xmls2/main/crewreplays.xml'
CDN_TEST_NAME = 'crewreplays_test'
FETCH_TEST_URL = 'https://httpbin.org/get'
API_TEST_URL = 'https://httpbin.org/get'


def run():
    lines = []

    # 1  -  plain fetch
    resp = client.fetch(FETCH_TEST_URL, timeout=20)
    if resp.ok or resp.status:
        lines.append(f'fetch: HTTP {resp.status} ({len(resp.body)} bytes)')
        c.log(f'[DevClientTest] fetch OK status={resp.status}')
    else:
        lines.append(f'fetch FAIL: {resp.error}')
        c.log(f'[DevClientTest] fetch FAIL: {resp.error}', 1)

    # 2  -  api_request through msg_handler (Trakt public endpoint)
    api_resp = client.api_request(
        msg_handler.API_GENERIC,
        API_TEST_URL,
    )
    if api_resp.ok:
        lines.append(f'api_request: HTTP {api_resp.status}')
    else:
        lines.append(f'api_request: HTTP {api_resp.status} ({api_resp.error or "handled"})')

    # 3  -  msg_handler smoke (429 path registration exists)
    lines.append(f'msg_handler APIs: {", ".join(sorted(_registered_apis()))}')

    # 4  -  CDN fetch
    cache_path = client.cdn_fetch(CDN_TEST_URI, CDN_TEST_NAME)
    if cache_path:
        lines.append(f'cdn_fetch: {cache_path}')
    else:
        lines.append('cdn_fetch: failed (no cache)')

    summary = ' | '.join(lines)
    c.log(f'[DevClientTest] {summary}')
    return summary


def _registered_apis():
    from ..modules import msg_handler as mh
    # registry is private  -  report known constants
    return (
        mh.API_TRAKT,
        mh.API_TMDB,
        mh.API_SCRAPER,
        mh.API_GENERIC,
    )

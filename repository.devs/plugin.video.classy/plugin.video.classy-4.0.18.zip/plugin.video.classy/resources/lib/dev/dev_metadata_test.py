# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_metadata_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi metadata phase 1b smoke test.'''

from ..metadata.enrich import (
    NEED_CREW, NEED_PLOT, NEED_POSTER, NEED_THUMB,
    apply_tmdb_episode,
    enrich,
)
from ..metadata.video_row import VideoRow
from ..kodi.video_listitem import VideoListItem
from ..modules.classy import c

# Breaking Bad S01E01  -  stable TMDB ids
_SAMPLE = {
    'tmdb': '1396',
    'season': 1,
    'episode': 1,
    'tvshowtitle': 'Breaking Bad',
}

_FIXTURE_EP = {
    'name': 'Pilot',
    'overview': 'Fixture plot.',
    'still_path': '/x.jpg',
    'credits': {'crew': [{'name': 'Vince Gilligan', 'job': 'Director'}], 'cast': []},
    'videos': {'results': []},
}


def _fixture_checks():
    row = VideoRow(mediatype='episode')
    apply_tmdb_episode(row, _FIXTURE_EP)
    ok = (
        row.title == 'Pilot'
        and row.plot == 'Fixture plot.'
        and row.director == 'Vince Gilligan'
        and row.thumb.endswith('/x.jpg')
    )
    return ok, f'fixture director={row.director!r} thumb={row.thumb!r}'


def run():
    lines = []

    ok, detail = _fixture_checks()
    if ok:
        lines.append('metadata: fixture OK')
    else:
        lines.append('metadata: fixture FAIL')
        c.log(f'[DevMetadataTest] fixture FAIL {detail}', 1)

    row = VideoRow(
        mediatype='episode',
        title='',
        tvshowtitle=_SAMPLE['tvshowtitle'],
        tmdb=_SAMPLE['tmdb'],
        season=_SAMPLE['season'],
        episode=_SAMPLE['episode'],
    )
    enrich(row, needs=(NEED_PLOT, NEED_CREW, NEED_POSTER, NEED_THUMB))

    if row.has_plot() and row.has_crew() and (row.poster or row.thumb):
        lines.append('metadata: enrich OK')
        c.log(
            f'[DevMetadataTest] enrich plot={len(row.plot)} chars '
            f'director={row.director!r} poster={bool(row.poster)} thumb={bool(row.thumb)}'
        )
    else:
        lines.append('metadata: enrich FAIL')
        c.log(
            f'[DevMetadataTest] enrich FAIL plot={row.plot!r} director={row.director!r}',
            1,
        )

    try:
        vli = VideoListItem.from_row(row)
        li = vli.listitem()
        if li.getLabel():
            lines.append('metadata: VideoListItem OK')
        else:
            lines.append('metadata: VideoListItem FAIL')
    except Exception as exc:
        lines.append('metadata: VideoListItem FAIL')
        c.log(f'[DevMetadataTest] VideoListItem: {exc}', 1)

    summary = ' | '.join(lines)
    c.log(f'[DevMetadataTest] {summary}')
    return summary

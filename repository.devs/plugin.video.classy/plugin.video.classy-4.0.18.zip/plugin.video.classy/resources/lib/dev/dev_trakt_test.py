# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_trakt_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi smoke test for trakt/  -  public + auth endpoints.'''

from ..trakt import auth
from ..trakt import paths
from ..trakt import transport
from ..modules.classy import c


def run():
    lines = []

    # 1) Public  -  no token; validates client_id + transport
    trending = transport.get_json(
        paths.path('movies', 'trending'),
        params={'limit': 1},
        with_auth=False,
    )
    if isinstance(trending, list) and trending:
        lines.append('trakt: trending OK')
    else:
        lines.append('trakt: trending FAIL')
        c.log(f'[DevTraktTest] trending FAIL status={transport.last_status()}', 1)

    if not auth.has_credentials():
        lines.append('trakt: auth SKIP (no token)')
        summary = ' | '.join(lines)
        c.log(f'[DevTraktTest] {summary}')
        return summary

    # 2) Auth  -  profile (cheap, confirms Bearer header)
    me = transport.get_json(paths.path('users', 'me'))
    username = (me or {}).get('username') if isinstance(me, dict) else None
    if username:
        lines.append(f'trakt: me OK ({username})')
    else:
        lines.append('trakt: me FAIL')
        c.log(f'[DevTraktTest] /users/me FAIL status={transport.last_status()}', 1)

    # 3) Auth  -  sync gate (mirror heartbeat; more useful than next_episode for infra)
    activities = transport.get_json(paths.path('sync', 'last_activities'))
    if isinstance(activities, dict) and activities.get('movies') is not None:
        lines.append('trakt: last_activities OK')
    else:
        lines.append('trakt: last_activities FAIL')
        c.log(
            f'[DevTraktTest] last_activities FAIL status={transport.last_status()}',
            1,
        )

    summary = ' | '.join(lines)
    c.log(f'[DevTraktTest] {summary}')
    return summary

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_lists_fetch_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Dev probe  -  remote list fetch (classy + one sport XML).'''

from ..lists.fetch import fetch_registry
from ..modules.classy import c


def run():
    lines = []
    for key in ('classy', 'nba'):
        body = fetch_registry(key)
        if body:
            head = body.strip()[:60].replace('\r', '').replace('\n', ' ')
            lines.append(f'{key}: OK {len(body)}b starts={head!r}')
        else:
            lines.append(f'{key}: FAIL')

    summary = '; '.join(lines)
    c.log(f'[Probe lists fetch] {summary}')
    return summary

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_lists_bridge_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Dev probe  -  lists ecosystem bridge + CDN module load.'''

from ..lists.bridge import install_lists_ecosystem_shims
from ..lists.cdn import CDN_MODULES
from ..modules import client
from ..modules.classy import c


def run():
    lines = []
    install_lists_ecosystem_shims()

    from ..modules import control
    from ..lists.fetch import fetch_list
    from ..lists.parse import parse_list
    from ..lists.registry import ROOT_URLS

    plugin = control.infoLabel('Container.PluginName')
    lines.append('bridge: active')
    lines.append(f'infoLabel PluginName: {plugin!r}')

    for label, url in (
        ('classy', ROOT_URLS['classy']),
        ('nba', ROOT_URLS['nba']),
    ):
        body = fetch_list(url)
        n = len(body) if body else 0
        ok = n > 0 and ('<?xml' in (body or '') or '<item>' in (body or ''))
        items, _rx = parse_list(body or '', source_url=url) if body else ([], [])
        lines.append(f'{label}: bytes={n} xml={ok} items={len(items)}')

    try:
        yt = control.addon('plugin.video.youtube')
        yt_key = bool((yt.getSetting('youtube.api.key') or '').strip())
        lines.append(f'youtube: installed api_key={yt_key}')
    except Exception:
        lines.append('youtube: not installed')

    for name in ('crewstreamer', 'crewschedule', 'crewreplays'):
        uri = CDN_MODULES.get(name, '')
        path = client.cdn_fetch(uri, name) if uri else None
        lines.append(f'{name}: cache={path or "miss"}')
        if path:
            try:
                mod = client.cdn_load(name)
                lines.append(f'  load: {mod.__name__ if mod else "fail"}')
            except Exception as exc:
                lines.append(f'  load error: {exc}')

    summary = '; '.join(lines)
    c.log(f'[Probe lists bridge] {summary}')
    return summary

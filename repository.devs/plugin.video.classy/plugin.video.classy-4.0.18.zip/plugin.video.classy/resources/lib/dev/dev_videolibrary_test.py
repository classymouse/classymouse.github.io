# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_videolibrary_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi VideoLibrary probe  -  read-only JSON-RPC soak.'''

from __future__ import annotations

import json

from ..kodi import library_strm
from ..kodi import videolibrary
from ..modules.classy import c


def _fmt_ids(ids: dict) -> str:
    parts = []
    if ids.get('imdb'):
        parts.append(f'imdb={ids["imdb"]}')
    if ids.get('tmdb'):
        parts.append(f'tmdb={ids["tmdb"]}')
    return ','.join(parts) or 'no-ids'


def run(params=None):
    params = params or {}
    lines = []
    sample_limit = 5
    try:
        sample_limit = max(1, min(20, int(params.get('limit') or sample_limit)))
    except (TypeError, ValueError):
        pass

    try:
        snapshot = videolibrary.probe_library(sample_limit=sample_limit)
    except videolibrary.JsonRpcError as exc:
        msg = f'videolib: RPC FAIL ({exc})'
        c.log(f'[DevVideoLibrary] {msg}', 1)
        return msg
    except Exception as exc:
        msg = f'videolib: FAIL ({exc})'
        c.log(f'[DevVideoLibrary] {msg}', 1)
        return msg

    mc = snapshot['movie_count']
    sc = snapshot['show_count']
    cov_m = snapshot['coverage']['movies']
    cov_s = snapshot['coverage']['shows']
    lines.append(f'videolib: {mc} movies, {sc} shows')
    lines.append(
        'cov movies '
        f'{cov_m["with_imdb"]}/{cov_m["scanned"]} imdb, '
        f'{cov_m["with_tmdb"]}/{cov_m["scanned"]} tmdb '
        f'(scan<={cov_m.get("scan_limit")}, lib={cov_m.get("library_total")}'
        f'{", partial" if cov_m.get("partial") else ""})'
    )
    lines.append(
        'cov shows '
        f'{cov_s["with_imdb"]}/{cov_s["scanned"]} imdb, '
        f'{cov_s["with_tmdb"]}/{cov_s["scanned"]} tmdb '
        f'(scan<={cov_s.get("scan_limit")}, lib={cov_s.get("library_total")}'
        f'{", partial" if cov_s.get("partial") else ""})'
    )

    c.log(f'[DevVideoLibrary] Kodi {snapshot.get("kodi_version")}  -  {mc} movies, {sc} shows')
    for row in snapshot.get('sample_movies') or []:
        c.log(
            f'[DevVideoLibrary] movie id={row.get("id")} '
            f'{row.get("title")!r} ({row.get("year")}) {_fmt_ids(row.get("ids") or {})} '
            f'playcount={row.get("playcount")} file={bool(row.get("file"))}'
        )
    for row in snapshot.get('sample_shows') or []:
        c.log(
            f'[DevVideoLibrary] show id={row.get("id")} '
            f'{row.get("title")!r} ({row.get("year")}) {_fmt_ids(row.get("ids") or {})} '
            f'playcount={row.get("playcount")}'
        )
    for row in snapshot.get('sample_episodes') or []:
        c.log(
            f'[DevVideoLibrary] episode S{row.get("season"):02d}E{row.get("episode"):02d} '
            f'{row.get("title")!r} {_fmt_ids(row.get("ids") or {})} '
            f'resume={row.get("resume")}'
        )

    movie_path = params.get('movie_path') or ''
    tv_path = params.get('tv_path') or ''
    if not movie_path and not tv_path:
        guessed = library_strm.guess_crew_library_paths()
        movie_path = guessed.get('library.movie', '')
        tv_path = guessed.get('library.tv', '')

    strm_checks = 0
    for label, root in (('movie', movie_path), ('tv', tv_path)):
        if not root:
            lines.append(f'strm {label}: no path')
            continue
        resolved = library_strm.display_vfs_path(root)
        records = library_strm.scan_strm_folder(root, limit=sample_limit)
        if not records:
            lines.append(f'strm {label}: 0 under {resolved or root}')
            continue
        report = library_strm.cross_check_strm_records(
            records,
            find_movies=videolibrary.find_movies,
            find_tvshows=videolibrary.find_tvshows,
            get_episodes_for_show=videolibrary.get_episodes_for_show,
        )
        found = sum(1 for r in report if r.get('status') == 'found')
        missing = sum(1 for r in report if r.get('status') in ('missing', 'show_missing', 'episode_missing'))
        strm_checks += len(report)
        lines.append(f'strm {label}: {found}/{len(report)} in Kodi')
        for item in report:
            rec = item.get('strm') or {}
            c.log(
                f'[DevVideoLibrary] strm {item.get("status")} '
                f'{rec.get("kind")} {rec.get("path")} '
                f'imdb={rec.get("imdb")} tmdb={rec.get("tmdb")}'
            )
        if missing:
            c.log(f'[DevVideoLibrary] WARN {missing} strm files not matched in Kodi DB', 1)

    if strm_checks:
        lines.append(f'strm checked={strm_checks}')
    elif not movie_path and not tv_path:
        lines.append('strm: skip (no paths configured)')

    c.log(f'[DevVideoLibrary] snapshot={json.dumps(snapshot, default=str)[:4000]}')
    summary = ' | '.join(lines)
    c.log(f'[DevVideoLibrary] {summary}')
    return summary

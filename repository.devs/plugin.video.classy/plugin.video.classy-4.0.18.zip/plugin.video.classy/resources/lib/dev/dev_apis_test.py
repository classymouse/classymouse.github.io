# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_apis_test.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

In-Kodi smoke test for apis/ package.'''

from ..apis import tmdb, fanart, tvdb, simkl
from ..modules.classy import c


def run():
    lines = []

    cfg = tmdb.configuration()
    if cfg and cfg.get('images'):
        lines.append('tmdb: configuration OK')
        c.log('[DevApisTest] TMDB configuration OK')
    else:
        lines.append('tmdb: configuration FAIL')
        c.log('[DevApisTest] TMDB configuration FAIL', 1)

    if tvdb.login():
        lines.append('tvdb: login OK')
    else:
        lines.append('tvdb: login FAIL')

    trends = simkl.ping()
    if trends:
        lines.append('simkl: ping OK')
    else:
        lines.append('simkl: ping FAIL')

    # Fanart needs a real id  -  skip hard fail if offline
    lines.append('fanart: ready (call get_tv when tvdb id known)')

    summary = ' | '.join(lines)
    c.log(f'[DevApisTest] {summary}')
    return summary

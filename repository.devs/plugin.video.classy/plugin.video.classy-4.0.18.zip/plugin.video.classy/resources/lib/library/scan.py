# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scan.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trigger Kodi VideoLibrary scan after strm writes.'''

import xbmc

from ..modules import control
from ..modules.classy import c


def _setting_true(setting_id: str, *, default: bool = True) -> bool:
    value = c.get_setting(setting_id)
    if value is None or value == '':
        return default
    return str(value).lower() != 'false'


def should_auto_update() -> bool:
    return _setting_true('library.update', default=True)


def trigger_video_library_update(*, force: bool = False) -> bool:
    if not force and not should_auto_update():
        return False
    if xbmc.getCondVisibility('Library.IsScanningVideo'):
        c.log('[Library] skip UpdateLibrary  -  scan already running')
        return False
    c.log('[Library] UpdateLibrary(video)')
    control.execute('UpdateLibrary(video)')
    return True

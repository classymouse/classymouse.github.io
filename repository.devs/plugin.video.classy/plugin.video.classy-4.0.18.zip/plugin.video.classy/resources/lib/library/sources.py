# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file sources.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Register Classy library folders in Kodi sources.xml.'''

from __future__ import annotations

import xml.etree.ElementTree as ET

from ..modules import control
from ..modules.classy import c
from . import paths


def setup_library_sources() -> bool:
    try:
        movies_path = paths.transpath(
            paths.setting_path(
                'library.movie',
                default='special://profile/addon_data/plugin.video.classy/Movies',
            ),
        )
        tv_path = paths.transpath(
            paths.setting_path(
                'library.tv',
                default='special://profile/addon_data/plugin.video.classy/TVShows',
            ),
        )
        sources_file = paths.transpath('special://userdata/sources.xml')

        c.log(f'[Library] setup sources Movies={movies_path} TV={tv_path}')
        paths.ensure_folder(movies_path)
        paths.ensure_folder(tv_path)

        try:
            tree = ET.parse(sources_file)
            root = tree.getroot()
        except Exception:
            c.log('[Library] creating new sources.xml')
            root = ET.Element('sources')
            tree = ET.ElementTree(root)

        video = root.find('video')
        if video is None:
            video = ET.SubElement(root, 'video')
            default = ET.SubElement(video, 'default')
            default.set('pathversion', '1')

        existing = [
            (s.find('path').text or '').strip()
            for s in video.findall('source')
            if s.find('path') is not None
        ]

        def _add_source(name: str, folder: str) -> None:
            if folder in existing:
                return
            c.log(f'[Library] add source {name}: {folder}')
            source = ET.SubElement(video, 'source')
            ET.SubElement(source, 'name').text = name
            path_el = ET.SubElement(source, 'path')
            path_el.set('pathversion', '1')
            path_el.text = folder
            ET.SubElement(source, 'allowsharing').text = 'true'

        _add_source('Classy Movies', movies_path)
        _add_source('Classy TV Shows', tv_path)

        tree.write(sources_file, encoding='utf-8', xml_declaration=True)
        # infoDialog is a 1-line toast  -  multi-step instructions need okDialog + [CR].
        control.okDialog(
            'Library sources added.[CR][CR]'
            'In Kodi: Settings -> Media -> Library -> Videos[CR]'
            'set content type for:[CR]'
            '- Classy Movies -> Movies[CR]'
            '- Classy TV Shows -> TV Shows',
            heading=c.lang(30752) or 'Setup library sources',
        )
        return True
    except Exception as exc:
        c.log(f'[Library] setup sources failed: {exc}', 1)
        c.infoDialog('Failed to setup library sources. Add folders manually.', time=5000)
        return False

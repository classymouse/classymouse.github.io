# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tvshows.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Add a TV show (all aired episodes) via TMDB season data.'''

from __future__ import annotations

import datetime
import re

import xbmc

from ..apis.tmdb import tmdb as tmdb_api
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from . import duplicate, scan, strm



def _setting_true(setting_id: str, *, default: bool = True) -> bool:
    value = c.get_setting(setting_id)
    if value is None or value == '':
        return default
    return str(value).lower() != 'false'


def _import_cutoff_date() -> str:
    now = datetime.datetime.now()
    if _setting_true('library.importdelay', default=False):
        now = now - datetime.timedelta(hours=24)
    return now.strftime('%Y%m%d')


def _episode_aired(premiered: str, *, include_unknown: bool, cutoff: str) -> bool:
    text = c.to_str(premiered).strip()
    if not text or text == '0':
        return include_unknown
    digits = re.sub(r'[^0-9]', '', text)
    if not digits:
        return include_unknown
    return int(digits) <= int(cutoff)


def _busy_start() -> bool:
    if xbmc.getCondVisibility('Window.IsVisible(infodialog)'):
        return False
    if xbmc.getCondVisibility('Player.HasVideo'):
        return False
    msg = c.lang(33512) or 'Adding to library...'
    c.infoDialog(msg, time=10000000)
    return True


def _busy_end(started: bool) -> None:
    if not started:
        return
    msg = c.lang(33513) or 'Process complete'
    c.infoDialog(msg, time=1500)


def _season_numbers(tmdb_id: str) -> list:
    show = tmdb_api.get_tv(tmdb_id)
    if not isinstance(show, dict):
        return []
    out = []
    for season in show.get('seasons') or []:
        if not isinstance(season, dict):
            continue
        num = int(season.get('season_number') or 0)
        if num > 0:
            out.append(num)
    return sorted(out)


def _episode_rows(
    *,
    tvshowtitle: str,
    year: str,
    imdb: str,
    tmdb: str,
    season: int,
) -> list:
    data = tmdb_api.get_tv_season(tmdb, season)
    if not isinstance(data, dict):
        return []
    rows = []
    for ep in data.get('episodes') or []:
        if not isinstance(ep, dict):
            continue
        en = int(ep.get('episode_number') or 0)
        if en <= 0:
            continue
        aired = (ep.get('air_date') or '')[:10]
        rows.append(VideoRow(
            mediatype='episode',
            title=(ep.get('name') or '').strip() or f'Episode {en}',
            tvshowtitle=tvshowtitle,
            year=year or (aired[:4] if aired else ''),
            season=season,
            episode=en,
            premiered=aired,
            imdb=imdb,
            tmdb=tmdb,
        ))
    return rows


def add_tvshow(
    *,
    tvshowtitle: str = '',
    year: str = '',
    imdb: str = '',
    tmdb: str = '',
    silent: bool = False,
    defer_scan: bool = False,
) -> int:
    title = (tvshowtitle or '').strip()
    tmdb_id = c.to_str(tmdb).strip()
    if not title or not tmdb_id:
        c.log('[Library] tv add: missing title or tmdb', 1)
        return 0

    if duplicate.tvshow_in_kodi(imdb=imdb, tmdb=tmdb_id, title=title, year=year):
        c.log(f'[Library] tv show already in Kodi: {title}')

    include_unknown = _setting_true('library.include_unknown', default=True)
    cutoff = _import_cutoff_date()
    seasons = _season_numbers(tmdb_id)
    if not seasons:
        c.log(f'[Library] no TMDB seasons for {title} tmdb={tmdb_id}', 1)
        return 0

    busy = False
    if not silent:
        busy = _busy_start()

    written = 0
    for season in seasons:
        for row in _episode_rows(
            tvshowtitle=title,
            year=year,
            imdb=imdb,
            tmdb=tmdb_id,
            season=season,
        ):
            if not _episode_aired(row.premiered, include_unknown=include_unknown, cutoff=cutoff):
                continue
            if duplicate.episode_in_kodi(
                tvshowtitle=title,
                season=row.season,
                episode=row.episode,
            ):
                continue
            if duplicate.episode_strm_exists(title, year, row.season, row.episode):
                continue
            if strm.write_episode(row):
                written += 1

    c.log(f'[Library] tv {title}: wrote {written} episode strms')
    if written and not defer_scan:
        scan.trigger_video_library_update()

    if not silent:
        _busy_end(busy)
    return written


def add_from_params(params: dict) -> int:
    p = params or {}
    return add_tvshow(
        tvshowtitle=p.get('tvshowtitle') or p.get('title') or '',
        year=p.get('year') or '',
        imdb=p.get('imdb') or '',
        tmdb=p.get('tmdb') or '',
    )

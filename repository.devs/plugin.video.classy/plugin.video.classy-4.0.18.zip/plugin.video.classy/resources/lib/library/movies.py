# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movies.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Add a single movie to the library (.strm + optional Kodi scan).'''

from __future__ import annotations

import xbmc

from ..metadata.video_row import VideoRow
from ..modules.classy import c
from . import duplicate, paths, scan, strm


def _busy_start() -> bool:
    if xbmc.getCondVisibility('Window.IsVisible(infodialog)'):
        return False
    if xbmc.getCondVisibility('Player.HasVideo'):
        return False
    msg = c.lang(33512) or 'Adding to library...'
    c.infoDialog(msg, time=10000000)
    return True


def _busy_end(started: bool) -> None:
    if not started:
        return
    msg = c.lang(33513) or 'Process complete'
    c.infoDialog(msg, time=1500)


def add_movie(
    *,
    name: str = '',
    title: str = '',
    year: str = '',
    imdb: str = '',
    tmdb: str = '',
    silent: bool = False,
    defer_scan: bool = False,
) -> bool:
    title = (title or name or '').strip()
    if not title:
        c.log('[Library] movie add: missing title', 1)
        return False

    row = VideoRow(
        mediatype='movie',
        title=title,
        year=c.to_str(year).strip(),
        imdb=c.to_str(imdb).strip(),
        tmdb=c.to_str(tmdb).strip(),
    )

    if duplicate.movie_in_kodi(
        imdb=row.imdb, tmdb=row.tmdb, title=row.title, year=row.year,
    ) or duplicate.movie_strm_exists(row.title, row.year):
        c.log(f'[Library] movie duplicate skip {title} ({year})')
        return False

    busy = False
    if not silent:
        busy = _busy_start()

    written = strm.write_movie(row)
    if written and not defer_scan:
        scan.trigger_video_library_update()

    if not silent:
        _busy_end(busy)
    return written


def add_from_params(params: dict) -> bool:
    p = params or {}
    return add_movie(
        name=p.get('name') or '',
        title=p.get('title') or p.get('name') or '',
        year=p.get('year') or '',
        imdb=p.get('imdb') or '',
        tmdb=p.get('tmdb') or '',
    )

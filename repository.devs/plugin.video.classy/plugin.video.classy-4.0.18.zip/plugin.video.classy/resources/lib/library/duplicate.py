# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file duplicate.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Duplicate detection  -  Kodi VideoLibrary + on-disk strm paths.'''

from __future__ import annotations

import os

from ..kodi import videolibrary
from ..modules.classy import c
from . import paths


def _setting_true(setting_id: str, *, default: bool = True) -> bool:
    value = c.get_setting(setting_id)
    if value is None or value == '':
        return default
    return str(value).lower() != 'false'


def dupe_check_enabled() -> bool:
    return _setting_true('library.check', default=True)


def movie_in_kodi(*, imdb: str = '', tmdb: str = '', title: str = '', year: str = '') -> bool:
    if not dupe_check_enabled():
        return False
    matches = videolibrary.find_movies(imdb=imdb, tmdb=tmdb, title=title, year=year)
    return bool(matches)


def tvshow_in_kodi(*, imdb: str = '', tmdb: str = '', title: str = '', year: str = '') -> bool:
    if not dupe_check_enabled():
        return False
    matches = videolibrary.find_tvshows(imdb=imdb, tmdb=tmdb, title=title, year=year)
    return bool(matches)


def episode_in_kodi(*, tvshowtitle: str, season: int, episode: int) -> bool:
    if not dupe_check_enabled():
        return False
    eps = videolibrary.get_episodes(tvshow_title=tvshowtitle, season=int(season))
    for row in eps:
        try:
            if int(row.get('season') or 0) == int(season) and int(row.get('episode') or 0) == int(episode):
                return True
        except (TypeError, ValueError):
            continue
    return False


def movie_strm_exists(title: str, year: str = '') -> bool:
    base = paths.movies_root()
    if not base:
        return False
    folder = paths.movie_folder(base, title, year)
    stem = paths.legal_filename(title)
    if year:
        stem = f'{stem}.{year}'
    return paths.file_exists(os.path.join(folder, f'{stem}.strm'))


def episode_strm_exists(tvshowtitle: str, year: str, season: int, episode: int) -> bool:
    base = paths.tv_root()
    if not base:
        return False
    show_path = paths.show_folder(base, tvshowtitle, year)
    season_path = paths.season_folder(show_path, season)
    safe_show = paths.sanitize_title(tvshowtitle)
    filename = paths.legal_filename(f'{safe_show} S{int(season):02d}E{int(episode):02d}.strm')
    return paths.file_exists(os.path.join(season_path, filename))

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file paths.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Library folder paths and safe filenames.'''

from __future__ import annotations

import os
import re

from ..modules import control
from ..modules.classy import c

_RESERVED = re.compile(r'(CON|PRN|AUX|NUL|COM\d|LPT\d)\.', re.I)


def transpath(path: str) -> str:
    text = c.to_str(path).strip()
    if not text:
        return ''
    return control.transPath(text)


def setting_path(setting_id: str, *, default: str = '') -> str:
    value = c.get_setting(setting_id) or default
    return c.to_str(value).strip()


def movies_root() -> str:
    root = setting_path(
        'library.movie',
        default='special://profile/addon_data/plugin.video.classy/Movies',
    )
    return transpath(root)


def tv_root() -> str:
    root = setting_path(
        'library.tv',
        default='special://profile/addon_data/plugin.video.classy/TVShows',
    )
    return transpath(root)


def sanitize_title(title: str) -> str:
    text = c.to_str(title).strip()
    try:
        text = text.translate(str.maketrans('', '', r'\/:*?"<>|'))
    except Exception:
        pass
    return re.sub(r'[^\w\-_\. ]', '_', text).strip() or 'Unknown'


def legal_filename(filename: str) -> str:
    text = c.to_str(filename).strip()
    text = re.sub(r'(?!\.)\W', '.', text)
    text = re.sub(r'\.+', '.', text).strip('.')
    text = _RESERVED.sub(r'\1_', text)
    return text or 'file'


def movie_folder(base: str, title: str, year: str = '') -> str:
    folder_name = sanitize_title(title)
    if year:
        folder_name = f'{folder_name} ({year})'
    return os.path.join(base, folder_name)


def show_folder(base: str, title: str, year: str = '') -> str:
    return movie_folder(base, title, year)


def season_folder(show_path: str, season: int) -> str:
    return os.path.join(show_path, f'Season {int(season)}')


def ensure_folder(path: str) -> bool:
    try:
        control.makeFile(path)
        return True
    except Exception as exc:
        c.log(f'[Library] mkdir failed {path}: {exc}', 1)
        return False


def write_text(path: str, content: str) -> bool:
    try:
        text = c.to_str(content)
        handle = control.openFile(path, 'w')
        try:
            handle.write(text)
        finally:
            handle.close()
        return True
    except Exception as exc:
        c.log(f'[Library] write failed {path}: {exc}', 1)
        return False


def file_exists(path: str) -> bool:
    try:
        local = transpath(path)
        if local and os.path.isfile(local):
            return True
    except Exception:
        pass
    try:
        return os.path.isfile(path)
    except Exception:
        return False

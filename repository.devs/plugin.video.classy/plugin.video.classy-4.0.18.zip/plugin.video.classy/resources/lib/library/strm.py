# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file strm.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Write .strm / .nfo files with Classy play URLs (imdb + tmdb).'''

from __future__ import annotations

import os

from ..metadata.video_row import VideoRow
from ..play.url import play_url
from ..modules.classy import c
from . import paths


def nfo_url(mediatype: str, *, imdb: str = '', tmdb: str = '') -> str:
    imdb = c.to_str(imdb).strip()
    tmdb = c.to_str(tmdb).strip()
    if imdb:
        return f'https://www.imdb.com/title/{imdb}'
    if tmdb:
        kind = 'tv' if mediatype in ('tv', 'tvshow', 'episode') else 'movie'
        return f'https://www.themoviedb.org/{kind}/{tmdb}'
    return ''


def write_movie(row: VideoRow) -> bool:
    base = paths.movies_root()
    if not base:
        c.log('[Library] library.movie path not set', 1)
        return False

    title = row.title or 'Unknown'
    year = c.to_str(row.year or '').strip()
    folder = paths.movie_folder(base, title, year)
    if not paths.ensure_folder(folder):
        return False

    stem = paths.legal_filename(title)
    if year:
        stem = f'{stem}.{year}'
    strm_path = os.path.join(folder, f'{stem}.strm')
    nfo_path = os.path.join(folder, f'{stem}.nfo')

    content = play_url(row)
    if not content:
        return False
    if not paths.write_text(strm_path, content):
        return False

    nfo = nfo_url('movie', imdb=row.imdb, tmdb=row.tmdb)
    if nfo:
        paths.write_text(nfo_path, nfo)
    c.log(f'[Library] movie strm {strm_path}')
    return True


def write_episode(row: VideoRow) -> bool:
    base = paths.tv_root()
    if not base:
        c.log('[Library] library.tv path not set', 1)
        return False

    show_title = row.tvshowtitle or row.title or 'Unknown'
    year = c.to_str(row.year or '').strip()
    season = int(row.season or 0)
    episode = int(row.episode or 0)
    if season <= 0 or episode <= 0:
        return False

    show_path = paths.show_folder(base, show_title, year)
    tvshow_nfo = os.path.join(show_path, 'tvshow.nfo')
    if not paths.file_exists(tvshow_nfo):
        paths.ensure_folder(show_path)
        nfo = nfo_url('tvshow', imdb=row.imdb, tmdb=row.tmdb)
        if nfo:
            paths.write_text(tvshow_nfo, nfo)

    season_path = paths.season_folder(show_path, season)
    paths.ensure_folder(season_path)

    safe_show = paths.sanitize_title(show_title)
    filename = paths.legal_filename(f'{safe_show} S{season:02d}E{episode:02d}.strm')
    strm_path = os.path.join(season_path, filename)

    content = play_url(row)
    if not content or not paths.write_text(strm_path, content):
        return False
    c.log(f'[Library] episode strm {strm_path}')
    return True

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file bulk.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Bulk Trakt  ->  library import (collection / watchlist).'''

from __future__ import annotations

from ..metadata.video_row import VideoRow
from ..modules.classy import c
from ..trakt import movie_lists, tv_lists
from . import movies as lib_movies
from . import scan
from . import tvshows as lib_tvshows

_BULK_MOVIE_PRESETS = frozenset({'traktcollection', 'traktwatchlist'})
_BULK_TV_PRESETS = frozenset({'traktcollection', 'traktwatchlist'})


def _confirm_bulk(label: str) -> bool:
    prompt = c.lang(33514) or 'Import all items to your library?'
    return c.yesnoDialog(f'{prompt}\n\n{label}')


def import_movies(preset: str) -> int:
    preset = (preset or '').strip()
    if preset not in _BULK_MOVIE_PRESETS:
        c.log(f'[Library] unsupported movie bulk preset {preset!r}', 1)
        return 0
    if not _confirm_bulk(preset):
        return 0

    page = movie_lists.fetch_page(preset)
    if not page:
        return 0
    items = page.get('results') or []
    added = 0
    for item in items:
        row = VideoRow.from_trakt_movie(item)
        if lib_movies.add_movie(
            title=row.title,
            year=row.year,
            imdb=row.imdb,
            tmdb=row.tmdb,
            silent=True,
            defer_scan=True,
        ):
            added += 1
    if added:
        scan.trigger_video_library_update()
    c.infoDialog(f'Added {added} of {len(items)} movies to library', time=4000)
    return added


def import_tvshows(preset: str) -> int:
    preset = (preset or '').strip()
    if preset not in _BULK_TV_PRESETS:
        c.log(f'[Library] unsupported tv bulk preset {preset!r}', 1)
        return 0
    if not _confirm_bulk(preset):
        return 0

    page = tv_lists.fetch_page(preset)
    if not page:
        return 0
    items = page.get('results') or []
    total_eps = 0
    for item in items:
        row = VideoRow.from_trakt_watched_show(item)
        total_eps += lib_tvshows.add_tvshow(
            tvshowtitle=row.tvshowtitle or row.title,
            year=row.year,
            imdb=row.imdb,
            tmdb=row.tmdb,
            silent=True,
            defer_scan=True,
        )
    if total_eps:
        scan.trigger_video_library_update()
    c.infoDialog(
        f'Processed {len(items)} shows  -  {total_eps} new episode strms',
        time=5000,
    )
    return total_eps

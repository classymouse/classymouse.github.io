# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

MDBList list provider  -  my / top / liked indexes + items pages.'''

from urllib.parse import parse_qsl, urlencode, urlparse

from ..apis.mdblist import BASE, has_credentials as api_has_key, mdblist
from ..modules.classy import c

_PAGE_LIMIT = 40


def has_credentials():
    return api_has_key()


def items_url(list_id, *, media='movie'):
    list_id = str(list_id or '').strip()
    if not list_id:
        return ''
    media = 'show' if str(media or '').lower() in ('show', 'tv', 'tvshow') else 'movie'
    return f'{BASE}/lists/{list_id}/items?{urlencode({"mediatype": media})}'


def is_list_items_url(url):
    text = (url or '').strip()
    if 'mdblist.com' not in text.lower():
        return False
    path = (urlparse(text).path or '').lower().rstrip('/')
    return '/lists/' in path and path.endswith('/items')


def _name_sort_key(entry):
    return str(entry.get('name') or '').casefold()


def _normalize_list(item, *, media='movie'):
    if not isinstance(item, dict):
        return None
    list_id = item.get('id')
    if list_id is None:
        list_id = (item.get('ids') or {}).get('mdblist') if isinstance(item.get('ids'), dict) else None
    name = (item.get('name') or '').strip()
    if list_id is None or not name:
        return None
    mediatype = (item.get('mediatype') or item.get('media_type') or '').strip().lower()
    # None/empty = mixed; keep. movie/show filter when set.
    want_show = str(media or '').lower() in ('show', 'tv', 'tvshow')
    if mediatype in ('movie', 'show'):
        if want_show and mediatype != 'show':
            return None
        if not want_show and mediatype != 'movie':
            return None
    return {
        'name': name,
        'id': list_id,
        'slug': (item.get('slug') or '').strip(),
        'items': item.get('items'),
        'items_url': items_url(list_id, media=media),
    }


def _fetch_list_collection(path, *, media='movie', log_label=''):
    if not has_credentials():
        return []
    data = mdblist.get(path)
    if not isinstance(data, list):
        c.log(f'[MDBList] {log_label or path}: empty/invalid response', 1)
        return []
    out = []
    for item in data:
        row = _normalize_list(item, media=media)
        if row:
            out.append(row)
    out.sort(key=_name_sort_key)
    c.log(f'[MDBList] {log_label or path}: {len(out)} list(s)')
    return out


def fetch_my_lists(*, media='movie'):
    return _fetch_list_collection('/lists/user', media=media, log_label='my')


def fetch_top_lists(*, media='movie'):
    return _fetch_list_collection('/lists/top', media=media, log_label='top')


def fetch_liked_lists(*, media='movie'):
    return _fetch_list_collection('/lists/liked', media=media, log_label='liked')


def _list_path_from_url(url):
    text = (url or '').strip()
    parsed = urlparse(text)
    path = parsed.path or ''
    extra_q = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if not path.startswith('/'):
        path = '/' + path
    return path, extra_q


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _ids_from_item(body):
    ids = {}
    imdb = _norm_imdb(body.get('imdb_id') or body.get('imdbid') or body.get('imdb'))
    if imdb:
        ids['imdb'] = imdb
    tmdb = body.get('tmdb') or body.get('tmdbid') or body.get('tmdb_id')
    if tmdb not in (None, '', 0, '0'):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    trakt = body.get('trakt') or body.get('traktid') or body.get('trakt_id')
    if trakt not in (None, '', 0, '0'):
        try:
            ids['trakt'] = int(trakt)
        except (TypeError, ValueError):
            pass
    tvdb = body.get('tvdb') or body.get('tvdbid') or body.get('tvdb_id')
    if tvdb not in (None, '', 0, '0'):
        try:
            ids['tvdb'] = int(tvdb)
        except (TypeError, ValueError):
            pass
    return ids


def _year_from_item(body):
    year = body.get('year') or body.get('release_year')
    if year not in (None, '', 0, '0'):
        try:
            return int(year)
        except (TypeError, ValueError):
            pass
    released = str(body.get('released') or body.get('release_date') or '')[:4]
    if released.isdigit():
        return int(released)
    return None


def _to_trakt_movie(item):
    body = item.get('movie') if isinstance(item.get('movie'), dict) else item
    if not isinstance(body, dict):
        return None
    title = (body.get('title') or body.get('name') or '').strip()
    if not title:
        return None
    out_ids = _ids_from_item(body)
    year = _year_from_item(body)
    return {
        'movie': {
            'title': title,
            'year': year,
            'ids': out_ids,
        }
    }


def _to_trakt_show(item):
    body = item.get('show') if isinstance(item.get('show'), dict) else item
    if not isinstance(body, dict):
        return None
    title = (body.get('title') or body.get('name') or '').strip()
    if not title:
        return None
    out_ids = _ids_from_item(body)
    year = _year_from_item(body)
    return {
        'show': {
            'title': title,
            'year': year,
            'ids': out_ids,
        }
    }


def _iter_raw_items(data):
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                yield item
        return
    if not isinstance(data, dict):
        return
    for key in ('movies', 'shows', 'items'):
        block = data.get(key)
        if isinstance(block, list):
            for item in block:
                if not isinstance(item, dict):
                    continue
                if key == 'movies' and 'movie' not in item and 'show' not in item:
                    yield dict(item, _mdb_force='movie')
                elif key == 'shows' and 'movie' not in item and 'show' not in item:
                    yield dict(item, _mdb_force='show')
                else:
                    yield item


def _item_media_kind(item):
    force = item.get('_mdb_force')
    if force:
        return force
    if isinstance(item.get('movie'), dict):
        return 'movie'
    if isinstance(item.get('show'), dict):
        return 'show'
    kind = (item.get('mediatype') or item.get('media_type') or item.get('type') or '').strip().lower()
    if kind in ('show', 'tv', 'tvshow', 'series'):
        return 'show'
    if kind in ('movie', 'movies'):
        return 'movie'
    return ''


def _convert_items(data, *, media='movie'):
    want_show = str(media or '').lower() in ('show', 'tv', 'tvshow')
    out = []
    for item in _iter_raw_items(data):
        kind = _item_media_kind(item)
        if want_show:
            if kind == 'movie':
                continue
            row = _to_trakt_show(item)
        else:
            if kind == 'show':
                continue
            row = _to_trakt_movie(item)
        if row:
            out.append(row)
    return out


def _paginate(items, page, limit=_PAGE_LIMIT):
    items = list(items or [])
    page = max(1, int(page or 1))
    limit = max(1, int(limit or _PAGE_LIMIT))
    total = len(items)
    total_pages = max(1, (total + limit - 1) // limit) if total else 1
    if page > total_pages:
        page = total_pages
    start = (page - 1) * limit
    return items[start:start + limit], page, total_pages


def fetch_items_page(url, *, page=1):
    '''Discover-shaped page for movie_discover / tv_discover.'''
    if not is_list_items_url(url):
        return None
    if not has_credentials():
        c.log('[MDBList] items require API key', 1)
        return None

    path, extra_q = _list_path_from_url(url)
    media = (extra_q.get('mediatype') or 'movie').strip().lower()
    params = {k: v for k, v in extra_q.items() if k != 'apikey'}
    # Prefer unified payloads when available; still handle movies/shows split.
    params.setdefault('unified', 'true')

    data = mdblist.get(path, params=params)
    if data is None:
        c.log(f'[MDBList] items failed path={path}', 1)
        return None

    items = _convert_items(data, media=media)
    page_items, page, total_pages = _paginate(items, page)
    c.log(
        f'[MDBList] items path={path} media={media} '
        f'page={page}/{total_pages} ({len(page_items)}/{len(items)})'
    )
    return {
        'results': page_items,
        'page': page,
        'total_pages': total_pages,
        '_source': 'trakt_list_items',
        '_preset': url,
        '_personal_list': True,
    }

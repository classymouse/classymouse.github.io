# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

MDBList package  -  list provider only.'''

from ..apis.mdblist import api_key, has_credentials, mdblist
from .lists import (
    fetch_items_page,
    fetch_liked_lists,
    fetch_my_lists,
    fetch_top_lists,
    is_list_items_url,
    items_url,
)

__all__ = [
    'api_key',
    'has_credentials',
    'mdblist',
    'fetch_items_page',
    'fetch_liked_lists',
    'fetch_my_lists',
    'fetch_top_lists',
    'is_list_items_url',
    'items_url',
]

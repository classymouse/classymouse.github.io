# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file freeomovie.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

FreeOMovie  -  flat latest list on freeomovie.info (no categories).'''

import html as html_lib
import json
import re

from ...modules import control
from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import fetch_text

# New SpeedPorn theme: article cards with hs__ poster + h2/h3 title.
_ARTICLE_RE = re.compile(r'<article[^>]*>(.*?)</article>', re.DOTALL | re.IGNORECASE)
_HREF_RE = re.compile(r'href="(https://freeomovie\.info/[^"#]+)"', re.IGNORECASE)
_IMG_RE = re.compile(r'<img[^>]+src="([^"]+)"', re.IGNORECASE)
_TITLE_RE = re.compile(r'<h[23][^>]*>(.*?)</h[23]>', re.DOTALL | re.IGNORECASE)

# Host-links-manager embeds on movie pages (HTML-escaped JSON in data-servers).
_SERVERS_RE = re.compile(r'data-servers="([^"]+)"', re.IGNORECASE)

# File-host links on movie pages  -  skip unless no stream embed exists.
_FILE_HOST_MARKERS = ('rapidgator.', 'nitroflare.', 'uploaded.', 'turbobit.')

# Prefer these before flaky Doodstream / myvidplay clones.
_HOST_FIRST = (
    'voe', 'mixdrop', 'mxdrop', 'streamtape', 'filemoon', 'streamwish',
    'vidhide', 'lulustream', 'vinovo', 'vidara',
)
_HOST_LAST = (
    'dood', 'myvidplay', 'ds2play', 'playmogo', 'dooood', 'doodstream',
)


class FreeOMovie(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='freeomovie',
            title='Porn Movies - [COLOR orchid]FOM[/COLOR]',
        )
        self.base_url = 'https://freeomovie.info/'

    def get_videos(self, url=None, page=1):
        page_num = int(page or 1)
        if page_num == 1:
            page_url = self.base_url
        else:
            page_url = f'{self.base_url}page/{page_num}/'

        c.log(f'[FreeOMovie] Fetching {page_url}')
        html = fetch_text(page_url, tag='FreeOMovie')
        if not html:
            return []

        results = []
        seen = set()
        for block in _ARTICLE_RE.findall(html):
            href_match = _HREF_RE.search(block)
            if not href_match:
                continue
            video_url = href_match.group(1).rstrip('/') + '/'
            if video_url in seen or video_url == self.base_url:
                continue
            seen.add(video_url)

            title_match = _TITLE_RE.search(block)
            raw_title = re.sub(r'<[^>]+>', '', title_match.group(1)) if title_match else ''
            title = self._cleanup_title(html_lib.unescape(raw_title))
            if not title:
                slug = video_url.rstrip('/').rsplit('/', 1)[-1]
                title = self._cleanup_title(slug.replace('-', ' ').title())

            img_match = _IMG_RE.search(block)
            thumb = img_match.group(1) if img_match else self.icon
            results.append((video_url, title, thumb))

        c.log(f'[FreeOMovie] Found {len(results)} videos on page {page_num}')
        if results:
            results.append(('NEXT_PAGE', f'[COLOR orchid]Next Page ({page_num + 1})[/COLOR]', ''))
        return results

    def resolve(self, url):
        c.log(f'[FreeOMovie] Resolving: {url}')
        html = fetch_text(url, tag='FreeOMovie')
        if not html:
            return None

        sources = self._extract_sources(html)
        if not sources:
            c.log('[FreeOMovie] No embed URLs found in page', 1)
            return None

        sources = self._rank_sources(sources)
        c.log(f'[FreeOMovie] {len(sources)} host(s): {[s[0] for s in sources]}')

        ordered = self._choose_source_order(sources)
        if not ordered:
            return None
        return self._resolve_with_fallback(ordered)

    def _host_rank(self, label, url):
        blob = f'{label} {url}'.lower()
        for idx, needle in enumerate(_HOST_LAST):
            if needle in blob:
                return 1000 + idx
        for idx, needle in enumerate(_HOST_FIRST):
            if needle in blob:
                return idx
        return 500

    def _rank_sources(self, sources):
        return sorted(sources, key=lambda item: self._host_rank(item[0], item[1]))

    def _choose_source_order(self, sources):
        '''Show picker when multiple hosts; Auto tries ranked list.'''
        if len(sources) == 1:
            return sources

        control.idle()
        labels = ['[COLOR orchid]Auto - try all[/COLOR]']
        labels.extend(f'[COLOR orchid]{label}[/COLOR]' for label, _ in sources)
        try:
            select = control.selectDialog(labels, heading='Select Source')
        except Exception as exc:
            c.log(f'[FreeOMovie] selectDialog failed ({exc}) - Auto', 1)
            select = 0

        if select == -1:
            c.log('[FreeOMovie] Source select cancelled')
            return []
        if select == 0:
            c.log('[FreeOMovie] Auto - try all hosts')
            return sources

        pick = sources[select - 1]
        c.log(f'[FreeOMovie] User picked {pick[0]} (fallback to others on fail)')
        return [pick] + [item for item in sources if item[1] != pick[1]]

    def _resolve_with_fallback(self, ordered):
        for idx, (label, embed) in enumerate(ordered):
            c.log(f'[FreeOMovie] Trying {label}: {embed}')
            resolved = self._try_resolveurl(embed)
            if resolved:
                if idx > 0:
                    try:
                        control.infoDialog(f'Playing via {label}', sound=False)
                    except Exception:
                        pass
                return resolved
            c.log(f'[FreeOMovie] {label} failed - next host')
        c.log('[FreeOMovie] All hosts failed', 1)
        return None

    def _extract_sources(self, html):
        sources = []
        seen = set()

        servers_match = _SERVERS_RE.search(html or '')
        if servers_match:
            try:
                payload = html_lib.unescape(servers_match.group(1))
                for entry in json.loads(payload):
                    if not isinstance(entry, dict):
                        continue
                    embed = (entry.get('u') or '').strip()
                    if not embed or embed in seen:
                        continue
                    if any(marker in embed.lower() for marker in _FILE_HOST_MARKERS):
                        continue
                    seen.add(embed)
                    label = (entry.get('l') or '').strip() or self._detect_service(embed)
                    sources.append((label, embed))
            except Exception as exc:
                c.log(f'[FreeOMovie] Failed to parse data-servers: {exc}', 1)

        if sources:
            return sources

        for _fl_url, fl_source in re.findall(
            r'data-fl-url="([^"]+)"[^>]*data-fl-source="([^"]+)"',
            html,
        ):
            embed = (fl_source or _fl_url).strip()
            if not embed or embed in seen:
                continue
            seen.add(embed)
            if any(marker in embed.lower() for marker in _FILE_HOST_MARKERS):
                continue
            sources.append((self._detect_service(embed), embed))

        if sources:
            return sources

        tabs_match = re.search(r'var\s+TABS\s*=\s*(\[.*?\]);', html, re.DOTALL)
        if tabs_match:
            try:
                tabs = json.loads(tabs_match.group(1))
                for tab in tabs:
                    embed = tab.get('url')
                    if embed and embed not in seen:
                        seen.add(embed)
                        sources.append((tab.get('label', 'Unknown'), embed))
            except Exception as exc:
                c.log(f'[FreeOMovie] Failed to parse TABS JSON: {exc}')

        if sources:
            return sources

        for embed in re.findall(r'href="([^"]+)"\s*target="myIframe"', html):
            if embed not in seen:
                seen.add(embed)
                sources.append((self._detect_service(embed), embed))

        return sources

    def _detect_service(self, url):
        url_lower = url.lower()
        hosts = (
            ('lulustream', 'LuluStream'),
            ('vidhidepre', 'Vidhide'),
            ('vidhide', 'Vidhide'),
            ('filemoon', 'Filemoon'),
            ('streamtape', 'Streamtape'),
            ('doodstream', 'Doodstream'),
            ('dood.', 'Doodstream'),
            ('playmogo', 'Doodstream'),
            ('earnvids', 'MixDrop'),
            ('mixdrop', 'MixDrop'),
            ('streamwish', 'StreamWish'),
            ('evoload', 'EvoLoad'),
            ('upstream', 'UpStream'),
            ('voe.', 'VOE'),
            ('vinovo', 'Vinovo'),
            ('streamvid', 'StreamVid'),
            ('vidoza', 'Vidoza'),
            ('turbovid', 'TurboVid'),
            ('vidcloud', 'VidCloud'),
            ('streamsb', 'StreamSB'),
            ('sbembed', 'StreamSB'),
            ('fembed', 'Fembed'),
            ('videovard', 'VideoVard'),
            ('streamhub', 'StreamHub'),
            ('gounlimited', 'GoUnlimited'),
        )
        for needle, label in hosts:
            if needle in url_lower:
                return label

        try:
            domain_match = re.search(r'https?://(?:www\.)?([^/]+)', url)
            if domain_match:
                return domain_match.group(1).split('.')[0].capitalize()
        except Exception:
            pass
        return 'Unknown'


site = FreeOMovie()

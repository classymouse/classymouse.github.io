# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file redtube.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

RedTube  -  search + direct resolve (Crew adult_sites port).'''

import re
from urllib.parse import quote_plus

from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import fetch_text


class RedTube(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='redtube',
            title='Search [COLOR firebrick][B]RedTube[/B][/COLOR]',
        )

    def search(self, keyword):
        if not keyword:
            return []

        c.log(f'[RedTube] Searching for: {keyword}')
        url = f'https://www.redtube.com/?search={quote_plus(keyword)}&page=1&hd=1'
        html = fetch_text(url, tag='RedTube')
        if not html:
            return []

        video_links = re.findall(r'<a[^>]+href="(/\d+)"', html)
        titles = re.findall(r'<img[^>]+alt="([^"]+)"[^>]*class="[^"]*thumb', html)

        results = []
        for i in range(min(len(video_links), len(titles))):
            video_url = 'https://www.redtube.com' + video_links[i]
            title = self._cleanup_title(titles[i])
            results.append((video_url, title, ''))

        c.log(f'[RedTube] Found {len(results)} results')
        return results

    def resolve(self, url):
        c.log(f'[RedTube] Resolving: {url}')
        html = fetch_text(url, tag='RedTube')
        if not html:
            return None

        match = re.search(r'"format":"mp4","videoUrl":"([^"]*)"', html)
        if not match:
            c.log('[RedTube] No manifest URL found', 1)
            return None

        manifest_url = 'https://www.redtube.com' + match.group(1).replace('\\/', '/')
        manifest = fetch_text(manifest_url, tag='RedTube')
        if not manifest:
            return None

        qualities = re.findall(r'ty"\:"(\d+)(?:[^\:]*)\:"([^"]*)', manifest)
        if not qualities:
            return None

        qualities.sort(reverse=True)
        video_url = qualities[0][1].replace('\\/', '/')
        c.log(f'[RedTube] Resolved to {qualities[0][0]}p')
        return video_url


site = RedTube()

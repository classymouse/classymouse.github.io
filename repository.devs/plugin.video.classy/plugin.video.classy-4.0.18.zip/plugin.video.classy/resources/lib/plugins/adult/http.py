# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file http.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

HTTP helpers for adult site plugins (Classy client.fetch wrapper).'''

from ...modules import client
from ...modules.classy import c

_DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

_BROWSER_HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}

CUMLOUDER_COOKIES = {
    'disclaimer-confirmed': '1',
    'parentDni': '0',
    'parentCountry': 'XX',
    'parentRegion': 'XX',
}


def fetch_text(url, timeout=30, headers=None, cookies=None, tag='Adult', retries=1):
    if not url:
        c.log(f'[{tag}] fetch skipped: empty url', 1)
        return ''

    headers = dict(_BROWSER_HEADERS)
    headers.update(headers or {})
    if 'User-Agent' not in headers:
        headers['User-Agent'] = _DEFAULT_UA
    if cookies:
        extra = '; '.join(f'{k}={v}' for k, v in cookies.items())
        existing = headers.get('Cookie', '')
        headers['Cookie'] = f'{existing}; {extra}'.strip('; ') if existing else extra

    last_error = ''
    for attempt in range(int(retries) + 1):
        resp = client.fetch(url, timeout=timeout, headers=headers)
        if resp.ok and resp.body:
            text = c.to_str(resp.body)
            c.log(f'[{tag}] GET {url} -> {resp.status} ({len(text)} bytes)')
            return text

        last_error = resp.error or f'HTTP {resp.status}' if resp.status else 'empty body'
        if attempt < retries:
            c.log(f'[{tag}] GET {url} failed ({last_error}), retry {attempt + 1}', 1)

    c.log(f'[{tag}] GET {url} failed: {last_error}', 1)
    return ''


def cumlouder_headers(referer='https://www.cumlouder.com/'):
    return {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': referer,
        'User-Agent': _DEFAULT_UA,
    }

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Adult content providers  -  plugin registry (Crew 3.x CrewAdult pattern).

Site modules register on import; the generic indexer lists them.'''

from .base import ClassyAdultProvider

from . import (  # noqa: F401  -  registers providers (menu order in base.MENU_ORDER)
    redtube,
    whoreshub,
    freeomovie,
    xxxfiles,
    homepornking,
    pornrewind,
    cumlouder,
)

__all__ = ['ClassyAdultProvider']

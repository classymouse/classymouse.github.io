# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file homepornking.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

HomePornKing  -  homemade listings + resolveurl (Crew adult_sites port).'''

import base64
import re
from urllib.parse import parse_qs, urlparse

from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import fetch_text


class HomePornKing(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='homepornking',
            title='Homemade Porn LQ - [COLOR orchid]HPK[/COLOR]',
        )
        self.base_url = 'https://www.homepornking.com/new/'

    def get_videos(self, url=None, page=1):
        page_num = int(page or 1)
        # Site pagination: /new/ (page 1), /new/2/, /new/3/  -  /new/1/ is 404.
        if page_num <= 1:
            page_url = self.base_url
        else:
            page_url = f'{self.base_url}{page_num}/'
        c.log(f'[HomePornKing] Fetching videos page {page_num} ({page_url})')
        html = fetch_text(page_url, tag='HomePornKing')
        if not html:
            return []

        pattern = r'(?s)pics_h(?:[^=]*)=\'([^\']*)\'><img src=\'([^\']*)\' alt=\'([^\']*)'
        matches = re.findall(pattern, html)

        results = []
        for path, thumb, title in matches:
            video_url = 'https://www.homepornking.com' + path
            results.append((video_url, self._cleanup_title(title), thumb))

        c.log(f'[HomePornKing] Found {len(results)} videos on page {page_num}')
        if results:
            results.append(('NEXT_PAGE', f'Next Page ({page_num + 1})...', ''))
        return results

    def resolve(self, url):
        c.log(f'[HomePornKing] Resolving: {url}')

        if '/go.php?u=' in url:
            try:
                parsed = urlparse(url)
                encoded = parse_qs(parsed.query).get('u', [''])[0]
                if encoded:
                    decoded = base64.b64decode(encoded).decode('utf-8')
                    c.log(f'[HomePornKing] Decoded go.php URL: {decoded}')
                    url = decoded
            except Exception as exc:
                c.log(f'[HomePornKing] Failed to decode go.php URL: {exc}')

        resolved = self._try_resolveurl(url)
        if resolved:
            return resolved

        c.log('[HomePornKing] Resolveurl failed, trying manual extraction')
        html = fetch_text(url, tag='HomePornKing')
        if html:
            video_url = self._extract_video_url(html, base_url=url)
            if video_url:
                return video_url

        c.log('[HomePornKing] All methods failed')
        return None


site = HomePornKing()

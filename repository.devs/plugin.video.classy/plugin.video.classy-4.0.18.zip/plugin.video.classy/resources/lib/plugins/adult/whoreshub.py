# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file whoreshub.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WhoresHub  -  categories + direct MP4 resolve (Crew adult_sites port).'''

import re

from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import fetch_text


class WhoresHub(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='whoreshub',
            title='HD & UHD Videos - [COLOR orchid]WH[/COLOR]',
        )
        self.base_url = 'https://www.whoreshub.com/'

    def get_categories(self):
        c.log('[WhoresHub] Fetching categories')
        results = [
            ('https://www.whoreshub.com/latest-updates/', '[COLOR orchid]Latest Updates[/COLOR]', self.icon),
            ('https://www.whoreshub.com/most-popular/', 'Most Viewed', self.icon),
            ('https://www.whoreshub.com/top-rated/', 'Top Rated', self.icon),
        ]

        try:
            all_categories = {}
            for page_num in range(1, 5):
                page_url = (
                    'https://www.whoreshub.com/categories/'
                    if page_num == 1
                    else f'https://www.whoreshub.com/categories/{page_num}/'
                )
                c.log(f'[WhoresHub] Fetching category page {page_num}')
                html = fetch_text(page_url, tag='WhoresHub')
                if not html:
                    continue

                cat_urls = re.findall(r'href="(https://www\.whoreshub\.com/categories/[^"]+)"', html)
                cat_urls = [u for u in cat_urls if not re.search(r'/categories/\d+/$|/categories/$', u)]

                for url in cat_urls:
                    if url in all_categories:
                        continue

                    cat_name = None
                    thumb_url = self.icon
                    count = None

                    match1 = re.search(
                        rf'href="{re.escape(url)}".*?data-src="([^"]+)".*?'
                        r'<span class="description">([^<]+)</span>.*?<span class="text">(\d+)</span>',
                        html,
                        re.DOTALL,
                    )
                    if match1:
                        thumb_url = (
                            'https:' + match1.group(1)
                            if not match1.group(1).startswith('http')
                            else match1.group(1)
                        )
                        cat_name = self._cleanup_title(match1.group(2))
                        count = match1.group(3)
                    else:
                        match2 = re.search(
                            rf'href="{re.escape(url)}"[^>]*>.*?data-src="([^"]+)"[^>]*alt="([^"]+)".*?'
                            r'<span class="text">(\d+)</span>',
                            html,
                            re.DOTALL,
                        )
                        if match2:
                            thumb_url = (
                                'https:' + match2.group(1)
                                if not match2.group(1).startswith('http')
                                else match2.group(1)
                            )
                            cat_name = self._cleanup_title(match2.group(2))
                            count = match2.group(3)

                    if not cat_name:
                        cat_name = url.rstrip('/').split('/')[-1].replace('-', ' ').title()

                    display_name = f'{cat_name} [{count}]' if count else cat_name
                    all_categories[url] = (display_name, thumb_url, cat_name)

            for url, (display_name, thumb, _) in sorted(all_categories.items(), key=lambda x: x[1][2]):
                results.append((url, display_name, thumb))

            c.log(f'[WhoresHub] Found {len(all_categories)} total categories')
        except Exception as exc:
            c.log(f'[WhoresHub] Failed to fetch categories: {exc}')

        c.log(f'[WhoresHub] Total sections: {len(results)}')
        return results

    def get_videos(self, url, page=1):
        c.log(f'[WhoresHub] Fetching videos from: {url}, page: {page}')
        page_num = int(page)
        if page_num == 1:
            page_url = url
        elif url.endswith('/'):
            page_url = f'{url}{page_num}/'
        else:
            page_url = f'{url}/{page_num}/'

        html = fetch_text(page_url, tag='WhoresHub')
        if not html:
            return []

        pattern = r'"item" href="([^"]*)" title="([^"]*).+?data-src="([^"]*)'
        matches = re.findall(pattern, html, re.DOTALL)

        results = []
        for video_url, title, thumb in matches:
            if title and video_url:
                title = self._cleanup_title(title)
                thumbnail = 'https:' + thumb if thumb and not thumb.startswith('http') else thumb
                results.append((video_url, title, thumbnail))

        c.log(f'[WhoresHub] Found {len(results)} videos')
        if results:
            results.append(('NEXT_PAGE', f'[COLOR orchid]Next Page ({page_num + 1})[/COLOR]', ''))
        return results

    def resolve(self, url):
        c.log(f'[WhoresHub] Resolving: {url}')
        try:
            html = fetch_text(url, tag='WhoresHub')
            if not html:
                return None

            pattern = r'_url(?:[^\']*)\'(h[^\']*).+?text\: \'([^\']*)'
            matches = re.findall(pattern, html, re.DOTALL)

            mp4_urls = []
            quality_labels = []
            for video_url, quality_label in matches:
                if 'mp4' in video_url:
                    mp4_urls.append(video_url + '|User-Agent=Mozilla/5.0&Referer=' + url)
                    quality_labels.append(quality_label)

            if not mp4_urls:
                return None

            def quality_rank(label):
                if '4k' in label.lower() or '2160' in label:
                    return 2160
                match = re.search(r'(\d+)', label)
                return int(match.group(1)) if match else 0

            pairs = sorted(zip(quality_labels, mp4_urls), key=lambda x: quality_rank(x[0]), reverse=True)
            best_label, selected_url = pairs[0]
            c.log(f'[WhoresHub] Resolved to: {best_label}')
            return selected_url
        except Exception as exc:
            c.log(f'[WhoresHub] Resolution failed: {exc}')
            return None


site = WhoresHub()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file base.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Base class for adult site provider plugins.'''

import re
import traceback
from urllib.parse import urljoin

from ...modules.classy import c


class ClassyAdultProvider:
    _providers = {}

    # Crew adult_sites/__init__.py import order (user-facing menu).
    MENU_ORDER = (
        'redtube',
        'whoreshub',
        'freeomovie',
        'xxxfiles',
        'homepornking',
        'pornrewind',
        'cumlouder',
    )

    def __init__(self, name, title, icon=None, fanart=None):
        self.name = name
        self.title = title
        self.icon = icon or c.addon_adult_icon()
        self.fanart = fanart or c.addon_fanart()
        ClassyAdultProvider._providers[name] = self

    @classmethod
    def get_provider(cls, name):
        return cls._providers.get(name)

    @classmethod
    def get_all_providers(cls):
        rank = {name: idx for idx, name in enumerate(cls.MENU_ORDER)}
        providers = list(cls._providers.values())
        providers.sort(key=lambda site: rank.get(site.name, len(rank)))
        return providers

    def get_categories(self):
        return []

    def get_videos(self, url=None, page=1):
        raise NotImplementedError

    def search(self, keyword):
        return []

    def resolve(self, url):
        raise NotImplementedError

    def _cleanup_title(self, title):
        if not title:
            return ''
        title = re.sub(r'&#(\d+);', '', title)
        for src, dst in (
            ('&amp;', '&'), ('&quot;', '"'), ('&apos;', "'"),
            ('&lt;', '<'), ('&gt;', '>'),
            ('\u2013', '-'), ('\u2014', '-'), ('\u2018', "'"), ('\u2019', "'"),
            ('\u201c', '"'), ('\u201d', '"'), ('\u2026', '...'),
        ):
            title = title.replace(src, dst)
        return title.strip()

    def _absolutize(self, url, base_url):
        text = (url or '').strip()
        if not text:
            return ''
        if text.startswith('//'):
            return 'https:' + text
        if text.startswith('http://') or text.startswith('https://'):
            return text
        return urljoin(base_url or '', text)

    def _try_resolveurl(self, url):
        try:
            import resolveurl
            import xbmcvfs

            xxx_plugins_path = 'special://home/addons/script.module.resolveurl.xxx/resources/plugins/'
            translated_path = xbmcvfs.translatePath(xxx_plugins_path)
            if xbmcvfs.exists(translated_path):
                resolveurl.add_plugin_dirs(translated_path)

            hmf = resolveurl.HostedMediaFile(url=url)
            if hmf.valid_url():
                resolved = hmf.resolve()
                if resolved:
                    return resolved
        except Exception as exc:
            c.log(f'[Adult.{self.name}] resolveurl failed: {exc}', 1)
            c.log(traceback.format_exc(), 2)
        return None

    def _extract_video_url(self, html, patterns=None, base_url=None):
        if patterns is None:
            patterns = [
                r'<meta[^>]+property=["\']og:video["\'][^>]+content=["\']([^"\']+)["\']',
                r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:video["\']',
                r'"contentUrl"\s*:\s*"([^"]+)"',
                r'<video[^>]*src=["\']([^"\']+)["\']',
                r'<source[^>]*src=["\']([^"\']+)["\']',
                r'video_url\s*=\s*["\']([^"\']+)["\']',
                r'https?://[^"\'\s<>]+\.mp4[^"\'\s<>]*',
            ]
        for pattern in patterns:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                found = match.group(1) if match.lastindex else match.group(0)
                return self._absolutize(found, base_url) if base_url else found
        return None

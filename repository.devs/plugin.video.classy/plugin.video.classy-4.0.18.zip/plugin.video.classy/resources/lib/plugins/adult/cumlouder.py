# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cumlouder.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Cumlouder  -  series categories + resolveurl (Crew adult_sites port).'''

import re

from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import CUMLOUDER_COOKIES, cumlouder_headers, fetch_text


class Cumlouder(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='cumlouder',
            title='[B][COLOR orange]CUM[/COLOR]LOUDER[/B]',
        )
        self.base_url = 'https://www.cumlouder.com/'

    def _fetch(self, url, timeout=15):
        return fetch_text(
            url,
            timeout=timeout,
            headers=cumlouder_headers(self.base_url),
            cookies=CUMLOUDER_COOKIES,
            tag='Cumlouder',
        )

    def get_categories(self):
        c.log('[Cumlouder] Fetching categories')
        html = self._fetch(self.base_url + 'series/')
        if not html:
            return []

        pattern = (
            r'(?s)href="(https://www\.cumlouder\.com/series/[^"]+)/"[^>]*>\s*<img[^>]+data-src="([^"]+)"'
            r'[^>]*alt="([^"]+)"[^>]*>\s*<h2[^>]*>([^<]+)</h2>'
        )
        matches = re.findall(pattern, html)

        results = []
        for cat_url, thumb_url, _alt_text, title in matches:
            results.append((cat_url, self._cleanup_title(title.strip()), thumb_url))

        c.log(f'[Cumlouder] Found {len(results)} categories')
        return results

    def get_videos(self, url, page=1):
        if not url:
            url = self.base_url
        c.log(f'[Cumlouder] Fetching videos from: {url}, page: {page}')

        base = url if url.endswith('/') else url + '/'
        html = self._fetch(base + str(page) + '/')
        if not html:
            return []

        pattern = r'(?s)<a class="muestra-escena" href="([^"]*).*?data-src="([^"]*).*?alt="([^"]*)'
        matches = re.findall(pattern, html)

        results = []
        for video_path, thumb, title in matches:
            video_url = 'https://www.cumlouder.com' + video_path
            results.append((video_url, self._cleanup_title(title), thumb))

        c.log(f'[Cumlouder] Found {len(results)} videos on page {page}')
        if results:
            results.append(('NEXT_PAGE', f'Next Page ({int(page) + 1})...', ''))
        return results

    def resolve(self, url):
        c.log(f'[Cumlouder] Resolving: {url}')

        resolved = self._try_resolveurl(url)
        if resolved:
            return resolved

        c.log('[Cumlouder] Resolveurl failed, trying manual extraction')
        html = self._fetch(url, timeout=10)
        if html:
            video_url = self._extract_video_url(html)
            if video_url:
                return video_url

        c.log('[Cumlouder] All methods failed')
        return None


site = Cumlouder()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file pornrewind.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Pornrewind  -  HD listings + resolveurl (Crew adult_sites port).'''

import re

from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import fetch_text


class Pornrewind(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='pornrewind',
            title='Pornrewind: [COLOR gold][B]HD[/B][/COLOR]',
        )
        self.base_url = 'https://www.pornrewind.com/categories/hd/'

    def get_videos(self, url=None, page=1):
        page_num = int(page or 1)
        c.log(f'[Pornrewind] Fetching videos page {page_num}')
        page_url = f'{self.base_url}{page_num}/'
        html = fetch_text(page_url, tag='Pornrewind')
        if not html:
            return []

        # Cards: <a class="thumb" href="..." title="..."><img src="/contents/.../preview.jpg">
        pattern = (
            r'<a class="thumb"[^>]*href="([^"]+)"[^>]*title="([^"]*)"[^>]*>'
            r'.*?src="([^"]+)"'
        )
        matches = re.findall(pattern, html, re.IGNORECASE | re.DOTALL)

        results = []
        for video_url, title, thumb in matches:
            thumb = self._absolutize(thumb, 'https://www.pornrewind.com/')
            results.append((video_url, self._cleanup_title(title), thumb))

        c.log(f'[Pornrewind] Found {len(results)} videos on page {page_num}')
        if results:
            results.append(('NEXT_PAGE', f'Next Page ({page_num + 1})...', ''))
        return results

    def resolve(self, url):
        c.log(f'[Pornrewind] Resolving: {url}')

        resolved = self._try_resolveurl(url)
        if resolved:
            return resolved

        c.log('[Pornrewind] Resolveurl failed, trying manual extraction')
        html = fetch_text(url, tag='Pornrewind')
        if html:
            # Player uses relative <source src="/contents/...mp4">; absolutize.
            video_url = self._extract_video_url(
                html,
                base_url='https://www.pornrewind.com/',
            )
            if video_url:
                c.log(f'[Pornrewind] Manual extract: {video_url}')
                return video_url

        c.log('[Pornrewind] All methods failed')
        return None


site = Pornrewind()

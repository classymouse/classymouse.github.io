# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file xxxfiles.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

XXXFiles  -  latest updates + direct source resolve (Crew adult_sites port).'''

import re

from ...modules.classy import c
from .base import ClassyAdultProvider
from .http import fetch_text


class XXXFiles(ClassyAdultProvider):
    def __init__(self):
        super().__init__(
            name='xxxfiles',
            title='New Videos - [COLOR orchid] XXF[/COLOR]',
        )

    def get_videos(self, url=None, page=1):
        c.log(f'[XXXFiles] Fetching videos, page: {page}')
        page_url = f'https://www.xxxfiles.com/latest-updates/{page}/'
        html = fetch_text(page_url, tag='XXXFiles')
        if not html:
            return []

        pattern = (
            r'(?s)thumb item(?:[^=]*)="([^"]*)(?:[^=]*)=(?:[^=]*)=(?:[^=]*)=(?:[^=]*)='
            r'"([^"]*)" alt="([^"]*)">(?:[^>]*)>([^<]*)'
        )
        matches = re.findall(pattern, html)

        results = []
        for match in matches:
            video_url = match[0]
            thumb = match[1] if len(match) > 1 else ''
            title = self._cleanup_title(match[2])
            if video_url and title:
                results.append((video_url, title, thumb))

        c.log(f'[XXXFiles] Found {len(results)} videos on page {page}')
        if results:
            results.append(('NEXT_PAGE', f'Next Page ({int(page) + 1})...', ''))
        return results

    def resolve(self, url):
        c.log(f'[XXXFiles] Resolving: {url}')
        html = fetch_text(url, tag='XXXFiles')
        if not html:
            return None

        sources = re.findall(r'(?s)source src=\'([^\']*)(?:[^=]*)=(?:[^=]*)="([^"]*)', html)
        if not sources:
            return None

        c.log('[XXXFiles] Resolved successfully')
        return sources[0][0]


site = XXXFiles()

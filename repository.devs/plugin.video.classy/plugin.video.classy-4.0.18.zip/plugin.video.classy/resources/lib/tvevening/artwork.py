# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file artwork.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Enrich evening episodes with TMDB title/plot/runtime/art/cast.'''

from ..modules import cache as caching
from ..modules.classy import c
from .filters import parse_episode_air_date


def _apply_cast_from_details(episode, details):
    """Copy countdown cast (3 leads + 3 guests) onto the episode dict."""
    if not details:
        return
    leads = details.get('cast_leads') or []
    guests = details.get('cast_guests') or []
    if leads:
        episode['cast_leads'] = leads
    if guests:
        episode['cast_guests'] = guests


def ensure_episode_cast(episode):
    """
    Fill cast_leads / cast_guests if missing (build-time or gap fallback).

    Safe no-op when TMDB id is absent or the episode already has cast.
    """
    if episode.get('cast_leads') or episode.get('cast_guests'):
        return
    show_tmdb = episode.get('showtmdb')
    season = episode.get('season')
    ep_num = episode.get('episode')
    if not show_tmdb or show_tmdb in ('0', 'None'):
        return
    try:
        details = caching.get_episode_details(show_tmdb, season, ep_num)
        _apply_cast_from_details(episode, details)
    except Exception as exc:
        title = episode.get('tvshowtitle', 'Unknown')
        c.log(f'[TV Evening] Cast fetch failed for {title}: {exc}')


def fetch_episode_air_date(episode):
    if parse_episode_air_date(episode.get('air_date') or episode.get('first_aired')):
        return

    show_tmdb = episode.get('showtmdb')
    season = episode.get('season')
    ep_num = episode.get('episode')
    if not show_tmdb or show_tmdb in ('0', 'None'):
        return

    try:
        details = caching.get_episode_details(show_tmdb, season, ep_num)
        if not details:
            return
        parsed = parse_episode_air_date(details.get('air_date'))
        if parsed:
            episode['air_date'] = parsed.isoformat()
        if details.get('duration'):
            episode['duration'] = details['duration']
        _apply_cast_from_details(episode, details)
    except Exception as exc:
        title = episode.get('tvshowtitle', 'Unknown')
        c.log(f'[TV Evening] Air date fetch failed for {title}: {exc}')


def fetch_episode_artwork(episode):
    show_tmdb = episode.get('showtmdb')
    season = episode.get('season')
    ep_num = episode.get('episode')
    show_title = episode.get('tvshowtitle', 'Unknown')
    if not show_tmdb or show_tmdb in ('0', 'None'):
        return

    try:
        details = caching.get_episode_details(show_tmdb, season, ep_num)
        if details:
            if details.get('title'):
                episode['title'] = details['title']
            if details.get('plot'):
                episode['plot'] = details['plot']
            if details.get('duration'):
                episode['duration'] = details['duration']
            if details.get('air_date'):
                episode['air_date'] = details['air_date']
            _apply_cast_from_details(episode, details)

        poster_url = caching.get_season_artwork(show_tmdb, season)
        if poster_url:
            episode['thumb'] = poster_url
            episode['poster'] = poster_url

        backdrop_url = caching.get_show_artwork(show_tmdb)
        if backdrop_url:
            episode['fanart'] = backdrop_url
    except Exception as exc:
        c.log(f'[TV Evening] Artwork fetch failed for {show_title}: {exc}')


def validate_episode_exists(episode):
    """
    Confirm episode exists on TMDB via cached details.
    If missing, try next season episode 1 once.
    """
    show_title = episode.get('tvshowtitle', 'Unknown')
    show_tmdb = str(episode.get('showtmdb') or '0')
    season = int(episode.get('season') or 0)
    ep_num = int(episode.get('episode') or 0)

    if show_tmdb in ('0', 'None', ''):
        c.log(f'[TV Evening] {show_title}  -  no TMDB id, keeping unverified')
        return episode

    try:
        details = caching.get_episode_details(show_tmdb, season, ep_num)
        if details:
            if details.get('title'):
                episode['title'] = details['title']
            if details.get('plot'):
                episode['plot'] = details['plot']
            if details.get('duration'):
                episode['duration'] = details['duration'] or episode.get('duration', 45)
            if details.get('air_date'):
                episode['air_date'] = details['air_date']
            _apply_cast_from_details(episode, details)
            return episode

        # Past season finale  -  try next season E01
        next_season = season + 1
        details = caching.get_episode_details(show_tmdb, next_season, 1)
        if details:
            c.log(
                f'[TV Evening] {show_title} S{season:02d}E{ep_num:02d} missing  -  '
                f'advanced to S{next_season:02d}E01'
            )
            episode['season'] = next_season
            episode['episode'] = 1
            if details.get('title'):
                episode['title'] = details['title']
            if details.get('plot'):
                episode['plot'] = details['plot']
            if details.get('duration'):
                episode['duration'] = details['duration'] or 45
            if details.get('air_date'):
                episode['air_date'] = details['air_date']
            _apply_cast_from_details(episode, details)
            return episode

        c.log(f'[TV Evening] {show_title} S{season:02d}E{ep_num:02d} not on TMDB  -  drop')
        return None
    except Exception as exc:
        c.log(f'[TV Evening] Validate failed for {show_title}: {exc}')
        return episode


def validate_episodes_parallel(episodes, progress_dialog=None, progress_start=40, progress_span=10):
    from concurrent.futures import ThreadPoolExecutor, as_completed

    total = len(episodes or [])
    if total == 0:
        return []

    validated = []
    workers = min(8, total)
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(validate_episode_exists, ep): ep for ep in episodes}
        for future in as_completed(futures):
            done += 1
            try:
                result = future.result()
                if result:
                    validated.append(result)
            except Exception as exc:
                c.log(f'[TV Evening] Validation worker error: {exc}')
            if progress_dialog and total:
                pct = progress_start + int((done / total) * progress_span)
                progress_dialog.update_progress(
                    f'Confirming your lineup...\n\n{done} of {total}',
                    min(progress_start + progress_span, pct),
                )
    return validated

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file recovery.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening recovery  -  Continue / Fresh / Delete after pause or Kodi restart.'''

from ..modules.classy import c
from . import recovery_dialog
from . import session


def has_stale_session():
    try:
        if session.is_resumable_and_monitor_inactive():
            info = session.load_full_session_from_db()
            c.log(
                '[TV Evening Recovery] Resumable session: {} episodes, state={}, position={}'.format(
                    info.get('playlist_size', 0),
                    info.get('session_state'),
                    info.get('current_position'),
                )
            )
            return True
        return False
    except Exception as exc:
        c.log(f'[TV Evening Recovery] check error: {exc}')
        return False


def get_session_info():
    try:
        return session.load_full_session_from_db()
    except Exception as exc:
        c.log(f'[TV Evening Recovery] session info error: {exc}')
        return None


def clear_stale_session():
    try:
        session.end_session()
        c.log('[TV Evening Recovery] Session cleared')
        return True
    except Exception as exc:
        c.log(f'[TV Evening Recovery] clear error: {exc}')
        return False


def _recovery_fanart(episodes):
    """Prefer a recognizable show backdrop from the saved evening playlist."""
    import random

    from . import pool

    candidates = []
    for ep in episodes or []:
        for key in ('fanart', 'poster', 'thumb'):
            url = (ep.get(key) or '').strip()
            if url and url not in ('0', 'None'):
                candidates.append(url)
                break
    if candidates:
        return random.choice(candidates)
    return pool.random_show_backdrop(episodes) or c.addon_fanart() or ''


def handle_recovery():
    """
    Returns 'continue', 'fresh', 'delete', or None
    (None = no resumable session, or user cancelled  -  do not start fresh silently).
    """
    try:
        if not has_stale_session():
            return None

        session_info = get_session_info()
        if not session_info or not session_info.get('episodes'):
            return None

        fanart = _recovery_fanart(session_info.get('episodes'))
        choice = recovery_dialog.show_recovery_dialog(
            session_info['playlist_size'],
            session_info['current_position'],
            session_info['episode_titles'],
            session_state=session_info.get('session_state'),
            fanart=fanart,
        )
        c.log(f'[TV Evening Recovery] User choice: {choice}')

        if choice == 'continue':
            return 'continue'
        if choice == 'fresh':
            clear_stale_session()
            return 'fresh'
        if choice == 'delete':
            clear_stale_session()
            return 'delete'
        return None
    except Exception as exc:
        c.log(f'[TV Evening Recovery] handle error: {exc}', 1)
        return None

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file filters.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Air-date eligibility for TV Evening candidates.'''

from datetime import date, datetime, timedelta

from ..modules.classy import c


def parse_episode_air_date(value):
    if value is None:
        return None
    s = str(value).strip()
    if not s or s in ('0', 'none', 'None'):
        return None
    head = s[:10]
    if len(head) == 10 and head[4] == '-' and head[7] == '-':
        try:
            return date(int(head[0:4]), int(head[5:7]), int(head[8:10]))
        except (ValueError, TypeError):
            pass
    try:
        return date.fromisoformat(head)
    except (ValueError, TypeError):
        return None


def episode_passes_air_date_filter(ep, min_age_hours, now=None):
    """
    When min_age_hours > 0:
    - reject missing/invalid air_date
    - reject future calendar dates
    - reject episodes newer than the min-age cutoff

    Returns (eligible, reason).
    """
    if min_age_hours <= 0:
        return True, 'filter_disabled'

    now = now or datetime.utcnow()
    cutoff_date = (now - timedelta(hours=min_age_hours)).date()
    today = now.date()

    raw = ep.get('air_date') or ep.get('first_aired')
    aired = parse_episode_air_date(raw)
    if not aired:
        if raw:
            c.log(f'[TV Evening] Unparseable air_date value: {raw!r}')
            return False, 'invalid_air_date'
        return False, 'no_air_date'

    if aired > today:
        return False, 'future_air_date'

    if aired > cutoff_date:
        return False, 'too_recent'

    return True, 'ok'


def log_air_date_decision(ep, eligible, reason, min_age_hours):
    title = ep.get('tvshowtitle', 'Unknown')
    season = ep.get('season', 0)
    episode = ep.get('episode', 0)
    air_date_str = ep.get('air_date') or ep.get('first_aired') or 'none'
    if eligible:
        c.log(
            f'[TV Evening] ACCEPTED {title} S{season:02d}E{episode:02d} '
            f'- air_date={air_date_str} ({reason})'
        )
    else:
        c.log(
            f'[TV Evening] SKIPPING {title} S{season:02d}E{episode:02d} '
            f'- air_date={air_date_str} ({reason}, min={min_age_hours}h)'
        )

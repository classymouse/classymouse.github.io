# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file pool.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Evening candidate pool  -  same source as Progress  ->  Next Episodes.

Always via tracker.next_episode_sessions (gate only). Never branch on
Simkl / Trakt / WeTrakr here. Cap to tvevening.source_count so the evening
lineup comes from the top of that Next Episodes list (recently watched).'''

from .. import tracker
from ..modules.classy import c
from ..modules import cache as caching
from . import settings


def fetch_next_episodes():
    """
    Return evening episode dicts from Progress  ->  Next Episodes.

    Same gate call as indexers.progress.next_episodes_* ; then keep the top
    ``tvevening.source_count`` slots (last-watched order).
    """
    try:
        # Match Progress browse/widget: same log_label so filters/cache align.
        result = tracker.next_episode_sessions(
            widget=True,
            limit=max(settings.source_count(), 50),
            log_label='next_episodes',
        )
        slots = result[0] if isinstance(result, (tuple, list)) else result
        slots = list(slots or [])
    except Exception as exc:
        c.log(f'[TV Evening] Next Episodes pool failed ({tracker.active_name()}): {exc}', 1)
        return []

    # top_slots already sorts by last_watched; keep that order, then cap.
    limit = max(1, int(settings.source_count() or 15))
    if len(slots) > limit:
        c.log(
            f'[TV Evening] Next Episodes pool: {len(slots)} slot(s)  ->  '
            f'top {limit} (tvevening.source_count)'
        )
        slots = slots[:limit]
    else:
        c.log(
            f'[TV Evening] Next Episodes pool via {tracker.active_name()}: '
            f'{len(slots)} slot(s)'
        )

    episodes = []
    for session in slots:
        try:
            ep = slot_to_episode(session)
            if ep:
                episodes.append(ep)
        except Exception as exc:
            c.log(f'[TV Evening] Bad Next Episodes slot: {exc}')
            continue

    # Preserve Next Episodes order (already last_watched desc from gate).
    return episodes


def slot_to_episode(session):
    show_data = session.get('show_data') or {}
    ids = show_data.get('ids') or {}
    show_title = (show_data.get('title') or 'Unknown').strip() or 'Unknown'
    show_imdb = ids.get('imdb') or '0'
    if show_imdb in (None, '', 'None'):
        show_imdb = '0'
    show_tmdb = str(ids.get('tmdb') or '0')
    show_year = str(show_data.get('year') or '')
    if not show_tmdb or show_tmdb in ('0', 'None'):
        return None

    next_season = int(session.get('season') or 0)
    next_episode = int(session.get('episode') or 0)
    if next_season <= 0 or next_episode <= 0:
        return None

    ep_title = (session.get('episode_title') or '').strip()
    if not ep_title:
        ep_title = f'Episode {next_episode}'

    return {
        'tvshowtitle': show_title,
        'title': ep_title,
        'season': next_season,
        'episode': next_episode,
        'showimdb': show_imdb,
        'showtmdb': show_tmdb,
        'year': show_year,
        'duration': 45,
        'plot': '',
        'thumb': '',
        'poster': '',
        'fanart': '',
        'last_watched_at': session.get('last_watched_at') or '1900-01-01T00:00:00.000Z',
    }


def random_show_backdrop(episodes=None):
    """Pick a fanart URL from pool shows (best-effort)."""
    try:
        pool = episodes
        if pool is None:
            pool = fetch_next_episodes()
        if not pool:
            return c.addon_fanart() or ''

        import random
        candidates = [ep for ep in pool if ep.get('showtmdb') and ep['showtmdb'] not in ('0', 'None')]
        if not candidates:
            return c.addon_fanart() or ''

        random.shuffle(candidates)
        for ep in candidates[:8]:
            url = caching.get_show_artwork(ep['showtmdb'])
            if url:
                return url
        return c.addon_fanart() or ''
    except Exception as exc:
        c.log(f'[TV Evening] Backdrop fetch failed: {exc}')
        return c.addon_fanart() or ''

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file playlist_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening playlist preview + episode info dialogs.'''

import traceback

import xbmcgui

from ..kodi.dialog_base import ClassyDialogBase
from ..modules.classy import c


class EpisodeInfoDialog(ClassyDialogBase):
    XML_FILE = 'EpisodeInfo.xml'

    def __init__(self, *args, **kwargs):
        self.show_title = kwargs.pop('show_title', 'Unknown Show')
        self.episode_badge = kwargs.pop('episode_badge', 'S01E01')
        self.episode_title = kwargs.pop('episode_title', 'Unknown Episode')
        self.runtime = kwargs.pop('runtime', '45')
        self.plot = kwargs.pop('plot', 'No plot available.')
        self.episode_poster = kwargs.pop('episode_poster', '')
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.set_properties({
            'episode_poster': self.episode_poster,
            'show_title': self.show_title,
            'episode_badge': self.episode_badge,
            'episode_title': self.episode_title,
            'runtime': self.runtime,
            'plot': self.plot,
        })

    def onClick(self, controlId):
        if controlId == 9000:
            self.close_with(9000)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.close_with(None)


class TVEveningPlaylistDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningPlaylist.xml'

    def __init__(self, *args, **kwargs):
        playlist = kwargs.pop('playlist', [])
        super().__init__(*args, **kwargs)
        self.playlist = playlist or []
        self.user_action = None

    def onInit(self):
        try:
            if self.playlist:
                first = self.playlist[0]
                fanart = first.get('fanart') or first.get('poster') or ''
                if fanart:
                    self.setProperty('fanart', fanart)

            total_runtime = sum(int(ep.get('duration') or 45) for ep in self.playlist)
            hours = total_runtime // 60
            minutes = total_runtime % 60
            self.setProperty(
                'runtime_text',
                f'{len(self.playlist)} episodes *  {total_runtime} minutes ({hours}h {minutes}m)',
            )

            list_control = self.getControl(9001)
            list_control.reset()
            for ep in self.playlist:
                show_title = ep.get('tvshowtitle', 'Unknown Show')
                season = int(ep.get('season') or 1)
                episode = int(ep.get('episode') or 1)
                episode_title = ep.get('title', 'Unknown Episode')
                runtime = int(ep.get('duration') or 45)
                thumb = ep.get('thumb') or ep.get('poster') or ''

                item = xbmcgui.ListItem(label=show_title)
                item.setArt({'icon': thumb, 'thumb': thumb})
                item.setProperty('episode_num', f'S{season:02d}E{episode:02d}')
                item.setProperty('episode_title', episode_title)
                item.setProperty('runtime', str(runtime))
                list_control.addItem(item)

            self.setFocusId(9010)
        except Exception as exc:
            c.log(f'[TV Evening Playlist] onInit error: {exc}', 1)
            c.log(traceback.format_exc(), 1)

    def onClick(self, controlId):
        if self.closing:
            return
        try:
            if controlId == 9001:
                list_control = self.getControl(9001)
                pos = list_control.getSelectedPosition()
                if 0 <= pos < len(self.playlist):
                    self._show_episode_info(self.playlist[pos])
            elif controlId == 9010:
                self.user_action = 'play'
                self.close_with(9010)
            elif controlId == 9011:
                self.user_action = 'first'
                self.close_with(9011)
            elif controlId == 9012:
                self.user_action = None
                self.close_with(9012)
        except Exception as exc:
            c.log(f'[TV Evening Playlist] onClick error: {exc}', 1)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.user_action = None
            self.close_with(None)

    def _show_episode_info(self, episode):
        try:
            season = int(episode.get('season') or 1)
            ep_num = int(episode.get('episode') or 1)
            info = EpisodeInfoDialog.run_modal(
                show_title=episode.get('tvshowtitle', 'Unknown Show'),
                episode_badge=f'S{season:02d}E{ep_num:02d}',
                episode_title=episode.get('title', 'Unknown Episode'),
                runtime=str(int(episode.get('duration') or 45)),
                plot=episode.get('plot') or 'No plot available.',
                episode_poster=episode.get('thumb') or episode.get('poster') or '',
            )
            del info
            try:
                self.setFocusId(9001)
            except Exception:
                pass
        except Exception as exc:
            c.log(f'[TV Evening Playlist] episode info error: {exc}', 1)


def show_playlist_preview(playlist):
    """Return 'play', 'first', or None (cancel)."""
    try:
        dialog = TVEveningPlaylistDialog.run_modal(playlist=playlist)
        try:
            return dialog.user_action
        finally:
            del dialog
    except Exception as exc:
        c.log(f'[TV Evening Playlist] preview error: {exc}', 1)
        c.log(traceback.format_exc(), 1)
        return 'play'

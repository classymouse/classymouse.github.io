# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file bridge_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Fullscreen fanart veil between episode end and countdown/complete.

Covers the home menu flash while the evening monitor waits for idle end and
the service thread queues the next skinned dialog.'''

from __future__ import annotations

from ..kodi.dialog_base import ClassyDialogBase
from ..modules import control
from ..modules.classy import c


BRIDGE_PENDING_PROP = 'thecrew.tvevening.bridge.pending'
BRIDGE_FANART_PROP = 'thecrew.tvevening.bridge.fanart'
BRIDGE_MESSAGE_PROP = 'thecrew.tvevening.bridge.message'
LAST_FANART_PROP = 'thecrew.tvevening.last_fanart'

_ACTIVE = {'dialog': None}


class TVEveningBridgeDialog(ClassyDialogBase):
    '''Non-modal  -  no buttons; countdown/complete sit on top and dismiss this.'''

    XML_FILE = 'TVEveningBridge.xml'

    def __init__(self, *args, **kwargs):
        fanart = kwargs.pop('fanart', '') or ''
        message = kwargs.pop('message', '') or 'One moment...'
        super().__init__(*args, **kwargs)
        self._fanart = fanart
        self._message = message

    def onInit(self):
        fanart = (self._fanart or '').strip()
        if not fanart or fanart in ('0', 'None'):
            fanart = (
                control.window.getProperty(BRIDGE_FANART_PROP)
                or control.window.getProperty(LAST_FANART_PROP)
                or c.addon_fanart()
                or ''
            )
        message = (self._message or '').strip() or 'One moment...'
        self.set_properties({
            'fanart': fanart,
            'message': message,
        })

    def onAction(self, action):
        # Absorb back/home during the veil  -  evening owns the session.
        pass


def remember_fanart(fanart):
    fanart = (fanart or '').strip()
    if fanart and fanart not in ('0', 'None'):
        control.window.setProperty(LAST_FANART_PROP, fanart)


def request_bridge(fanart='', message='One moment...'):
    '''Ask the service thread to raise (or refresh) the veil.'''
    art = (fanart or '').strip()
    if not art or art in ('0', 'None'):
        art = control.window.getProperty(LAST_FANART_PROP) or ''
    if art:
        control.window.setProperty(BRIDGE_FANART_PROP, art)
        remember_fanart(art)
    control.window.setProperty(BRIDGE_MESSAGE_PROP, (message or 'One moment...').strip())
    control.window.setProperty(BRIDGE_PENDING_PROP, 'true')


def dismiss_bridge():
    control.window.clearProperty(BRIDGE_PENDING_PROP)
    dialog = _ACTIVE.get('dialog')
    _ACTIVE['dialog'] = None
    if dialog is None:
        return
    try:
        dialog.close()
    except Exception:
        pass
    try:
        del dialog
    except Exception:
        pass


def dispatch_pending():
    '''Service tick  -  show non-modal veil if requested and not already up.'''
    if control.window.getProperty(BRIDGE_PENDING_PROP) != 'true':
        return False
    control.window.clearProperty(BRIDGE_PENDING_PROP)

    fanart = (
        control.window.getProperty(BRIDGE_FANART_PROP)
        or control.window.getProperty(LAST_FANART_PROP)
        or ''
    )
    message = control.window.getProperty(BRIDGE_MESSAGE_PROP) or 'One moment...'

    existing = _ACTIVE.get('dialog')
    if existing is not None:
        try:
            existing.set_properties({'fanart': fanart or c.addon_fanart() or '', 'message': message})
            return True
        except Exception:
            dismiss_bridge()

    try:
        dialog = TVEveningBridgeDialog.create(fanart=fanart, message=message)
        dialog.show()
        _ACTIVE['dialog'] = dialog
        c.log('[TV Evening Bridge] veil up')
        return True
    except Exception as exc:
        c.log(f'[TV Evening Bridge] show failed: {exc}', 1)
        _ACTIVE['dialog'] = None
        return False

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file play.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Start first (or next) TV Evening episode via plugin play URL + session DB.'''

from urllib.parse import quote_plus

import xbmc
import xbmcgui

from ..modules import control
from ..modules.classy import c
from . import playlist_db
from . import session
from . import monitor as evening_monitor


def build_episode_play_url(episode):
    """plugin:// play URL  -  select=2 = autoplay (no source picker)."""
    from ..play.url import meta_from_row

    url = 'plugin://plugin.video.classy/?action=play'
    url += f"&title={quote_plus(str(episode.get('title', '')))}"
    url += f"&year={quote_plus(str(episode.get('year', '')))}"
    url += f"&imdb={quote_plus(str(episode.get('showimdb', episode.get('imdb', '0'))))}"
    url += f"&tmdb={quote_plus(str(episode.get('showtmdb', episode.get('tmdb', '0'))))}"
    url += f"&season={quote_plus(str(episode.get('season', '')))}"
    url += f"&episode={quote_plus(str(episode.get('episode', '')))}"
    url += f"&tvshowtitle={quote_plus(str(episode.get('tvshowtitle', '')))}"
    premiered = episode.get('premiered') or episode.get('air_date') or ''
    if premiered:
        url += f"&premiered={quote_plus(str(premiered))}"
    # Embed art so ResolveStatus / scrape overlay has fanart before TMDB enrich.
    try:
        import json
        row = dict(episode or {})
        row.setdefault('mediatype', 'episode')
        if row.get('showtmdb') and not row.get('tmdb'):
            row['tmdb'] = row.get('showtmdb')
        if row.get('showimdb') and not row.get('imdb'):
            row['imdb'] = row.get('showimdb')
        meta = meta_from_row(row)
        if meta:
            url += f"&meta={quote_plus(json.dumps(meta, separators=(',', ':')))}"
    except Exception:
        pass
    url += '&select=2'
    return url


def play_episode_now(episode):
    """
    Start one evening episode.

    Classy resolves streams via Player.play(resolved_url), not setResolvedUrl.
    Kodi PlayList items that are plugin:// therefore fail with
    "one or more items failed to play". Use PlayMedia so the plugin runs as a
    normal play route and can Player.play() the resolved stream.
    """
    url = episode.get('url') or build_episode_play_url(episode)
    episode['url'] = url

    # Keep Kodi playlist empty  -  monitor drives each transition from the DB.
    try:
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception:
        pass

    import time as _time
    control.window.setProperty('thecrew.tvevening.last_play_started', str(_time.time()))
    control.window.setProperty('thecrew.tvevening.source_failure', 'none')
    try:
        from . import bridge_dialog
        bridge_dialog.remember_fanart(episode.get('fanart') or '')
        bridge_dialog.dismiss_bridge()
    except Exception:
        pass

    # Quote for PlayMedia builtin safety
    safe = url.replace('\\', '\\\\').replace('"', '\\"')
    xbmc.executebuiltin(f'PlayMedia("{safe}")')
    c.log(
        f"[TV Evening] PlayMedia {episode.get('tvshowtitle')} "
        f"S{int(episode.get('season') or 0):02d}E{int(episode.get('episode') or 0):02d}"
    )


def play_playlist(playlist, reserve_episodes=None):
    """
    Persist visible + reserve to DB, start monitor, play first episode.
    """
    if not playlist:
        return

    reserve_episodes = reserve_episodes or []
    c.log(
        f'[TV Evening] play_playlist: {len(playlist)} visible, '
        f'{len(reserve_episodes)} reserve'
    )

    session.clear_completing()
    control.window.clearProperty('thecrew.tvevening.transitioning')
    control.window.clearProperty(session.PROP_COMPLETE_PENDING)

    db = playlist_db.get_playlist_db()
    db.clear_playlist()

    for i, episode in enumerate(playlist):
        episode['url'] = build_episode_play_url(episode)
        db.add_episode(i, episode, is_reserve=False)

    reserve_base = len(playlist)
    for j, episode in enumerate(reserve_episodes):
        episode['url'] = build_episode_play_url(episode)
        db.add_episode(reserve_base + j, episode, is_reserve=True)

    db.set_metadata('playlist_started', xbmc.getInfoLabel('System.Date'))
    db.set_metadata('playlist_total', str(len(playlist)))
    db.set_metadata('visible_count', str(len(playlist)))
    db.set_metadata('reserve_count', str(len(reserve_episodes)))

    session.set_state(session.STATE_START, position=0)
    control.window.clearProperty('thecrew.tvevening.resume_mode')
    control.window.clearProperty('thecrew.tvevening.resume_prompt')

    # Monitor before first play so plugin play sees monitor.active
    evening_monitor.start_tv_evening_session(playlist, start_position=0)
    play_episode_now(playlist[0])


def resume_playlist(session_info):
    """Resume after recovery Continue."""
    episodes = session_info.get('episodes') or []
    current_position = int(session_info.get('current_position') or 0)
    initial_state = session_info.get('session_state') or session.STATE_PAUSED
    playlist_size = len(episodes)

    if current_position < 0 or current_position >= playlist_size:
        xbmcgui.Dialog().ok('TV Evening', 'Invalid resume position.')
        return

    c.log(
        f'[TV Evening] Resuming at {current_position}/{playlist_size} '
        f'(state={initial_state})'
    )

    for i in range(current_position):
        if session._episode_false_skip(episodes[i]):
            try:
                playlist_db.get_playlist_db().clear_episode_skipped(i)
            except Exception:
                pass

    ep = episodes[current_position]
    if not ep.get('url'):
        ep['url'] = build_episode_play_url(ep)

    session.clear_completing()
    control.window.clearProperty('thecrew.tvevening.transitioning')

    # Continue after dinner/crash: auto-seek bookmark. Between-episode gap: start 00:00.
    if initial_state in (session.STATE_PAUSED, session.STATE_PLAYING):
        control.window.setProperty('thecrew.tvevening.resume_mode', 'auto')
        bookmark = session.arm_playback_bookmark_props(current_position)
        if bookmark:
            c.log(
                f'[TV Evening] Armed local bookmark '
                f'{bookmark["resume_seconds"]:.0f}s ({bookmark["progress"]:.0f}%)'
            )
        else:
            c.log('[TV Evening] No local bookmark  -  will try tracker resume')
    else:
        control.window.clearProperty('thecrew.tvevening.resume_mode')
        session.clear_playback_bookmark()

    evening_monitor.start_tv_evening_session(
        episodes,
        start_position=current_position,
        initial_state=initial_state,
    )
    play_episode_now(ep)

    # User chose Continue Playing  -  start watching, do not re-pause.
    session.set_state(session.STATE_PLAYING, position=current_position)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file settings.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening setting helpers.'''

from ..modules.classy import c


def show_playlist():
    try:
        return c.get_setting('tvevening.show_playlist') == 'true'
    except Exception:
        return True


def gap_countdown():
    try:
        return int(c.get_setting('tvevening.gap_countdown') or 60)
    except Exception:
        return 60


def randomize():
    try:
        return c.get_setting('tvevening.randomize') == 'true'
    except Exception:
        return False


def source_count():
    try:
        return int(c.get_setting('tvevening.source_count') or 15)
    except Exception:
        return 15


def min_episode_age():
    try:
        return int(c.get_setting('tvevening.min_episode_age') or 48)
    except Exception:
        return 48

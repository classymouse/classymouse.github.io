# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening  -  next-episode playlist for a timed session (Classy / Crew 4.x).'''

from .start import start_tv_evening

__all__ = ('start_tv_evening',)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file build.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Build a timed TV Evening playlist from the tracker pool.'''

import random
import traceback
from datetime import datetime, timedelta

import xbmcgui

from .. import tracker
from ..modules.classy import c
from . import artwork
from . import filters
from . import pool
from . import settings


def _select_episodes_for_playlist(all_episodes, duration_minutes, min_age_hours, progress_dialog=None):
    # Over-select into a reserve buffer; trim later.
    target_runtime = duration_minutes + 45
    playlist = []
    skipped = []
    total_runtime = 0
    now = datetime.utcnow()
    total = len(all_episodes)
    idx = 0
    chunk_size = 12

    while total_runtime < target_runtime and idx < total:
        chunk = all_episodes[idx:idx + chunk_size]
        idx += len(chunk)
        if not chunk:
            break

        if min_age_hours > 0:
            for ep in chunk:
                artwork.fetch_episode_air_date(ep)
            if progress_dialog:
                pct = 25 + int((min(idx, total) / max(total, 1)) * 14)
                progress_dialog.update_progress(
                    f'Checking availability...\n\n{min(idx, total)} of {total}',
                    min(39, pct),
                )

        for ep in chunk:
            if total_runtime >= target_runtime:
                break
            if min_age_hours > 0:
                artwork.fetch_episode_air_date(ep)
            eligible, reason = filters.episode_passes_air_date_filter(ep, min_age_hours, now)
            filters.log_air_date_decision(ep, eligible, reason, min_age_hours)
            if not eligible:
                skipped.append(ep)
                continue
            playlist.append(ep)
            total_runtime += int(ep.get('duration') or 45)

    c.log(
        f'[TV Evening] Selected {len(playlist)} episode(s) after scanning '
        f'{min(idx, total)}/{total} candidates'
    )
    return playlist, skipped, total_runtime


def build_playlist(duration_minutes, progress_dialog=None):
    """
    Build playlist dict: visible, reserve, skipped, min_age_hours.
    Pool comes only from tracker.next_episode_sessions (via pool.fetch_next_episodes).
    """
    try:
        c.log(f'[TV Evening] Building playlist for {duration_minutes} minutes')
        if progress_dialog:
            progress_dialog.update_progress('Preparing your TV Evening...', 10)

        min_age_hours = settings.min_episode_age()
        c.log(f'[TV Evening] Minimum episode age: {min_age_hours} hours')
        c.log(f'[TV Evening] Fetching Next Episodes ({tracker.active_name()})')

        all_episodes = pool.fetch_next_episodes()
        if progress_dialog:
            progress_dialog.update_progress("Choosing tonight's lineup...", 25)

        if not all_episodes:
            xbmcgui.Dialog().ok(
                'No Episodes Found',
                'Could not find any next episodes from your watch progress.\n\n'
                f'Check Progress  ->  Next Episodes under {tracker.display_label()}.',
            )
            return None

        c.log(f'[TV Evening] Building from {len(all_episodes)} Next Episodes candidate(s)')

        if settings.randomize():
            c.log('[TV Evening] Randomizing episode order')
            random.shuffle(all_episodes)

        now = datetime.utcnow()
        if min_age_hours > 0:
            c.log(f"[TV Evening] Current UTC: {now.strftime('%Y-%m-%d %H:%M:%S')}")
            c.log(
                f"[TV Evening] Cutoff ({min_age_hours}h ago): "
                f"{(now - timedelta(hours=min_age_hours)).strftime('%Y-%m-%d %H:%M:%S')}"
            )
        elif progress_dialog:
            progress_dialog.update_progress("Choosing tonight's lineup...", 35)

        playlist, skipped, total_runtime = _select_episodes_for_playlist(
            all_episodes,
            duration_minutes,
            min_age_hours,
            progress_dialog=progress_dialog,
        )

        if progress_dialog:
            progress_dialog.update_progress('Confirming your lineup...', 40)

        validated_playlist = artwork.validate_episodes_parallel(
            playlist,
            progress_dialog=progress_dialog,
            progress_start=40,
            progress_span=10,
        )

        failed = set(
            (ep['showimdb'], ep['season'], ep['episode']) for ep in playlist
        ) - set(
            (ep['showimdb'], ep['season'], ep['episode']) for ep in validated_playlist
        )

        if len(validated_playlist) < len(playlist):
            shortage = len(playlist) - len(validated_playlist)
            used = set(
                (ep['showimdb'], ep['season'], ep['episode'])
                for ep in (validated_playlist + skipped)
            )
            used |= failed
            replacement_pool = [
                ep for ep in all_episodes
                if (ep['showimdb'], ep['season'], ep['episode']) not in used
            ]
            if replacement_pool and shortage > 0:
                candidates = replacement_pool[:shortage * 2]
                if min_age_hours > 0:
                    for candidate in candidates:
                        artwork.fetch_episode_air_date(candidate)
                eligible_candidates = []
                for candidate in candidates:
                    eligible, reason = filters.episode_passes_air_date_filter(
                        candidate, min_age_hours, now,
                    )
                    if eligible:
                        eligible_candidates.append(candidate)
                    else:
                        filters.log_air_date_decision(
                            candidate, False, f'validation_replacement_{reason}', min_age_hours,
                        )
                additional = artwork.validate_episodes_parallel(
                    eligible_candidates,
                    progress_dialog=progress_dialog,
                    progress_start=48,
                    progress_span=2,
                )
                validated_playlist.extend(additional)

        playlist = validated_playlist
        total_runtime = sum(int(ep.get('duration') or 45) for ep in playlist)

        TRIM_TOLERANCE = 15
        reserve_episodes = []
        if total_runtime > duration_minutes + TRIM_TOLERANCE:
            trim_runtime = 0
            trim_playlist = []
            for i, ep in enumerate(playlist):
                ep_dur = int(ep.get('duration') or 45)
                if trim_runtime + ep_dur > duration_minutes + TRIM_TOLERANCE and trim_playlist:
                    reserve_episodes = playlist[i:]
                    break
                trim_playlist.append(ep)
                trim_runtime += ep_dur
            c.log(
                f'[TV Evening] Trimmed {len(playlist)}  ->  {len(trim_playlist)} eps '
                f'({total_runtime} -> {trim_runtime}min, target={duration_minutes}); '
                f'{len(reserve_episodes)} reserve'
            )
            playlist = trim_playlist
            total_runtime = trim_runtime

        if len(reserve_episodes) > 1:
            reserve_episodes = reserve_episodes[:1]

        artwork_targets = playlist + reserve_episodes
        if progress_dialog:
            progress_dialog.update_progress('Getting things ready...', 50)
        for i, ep in enumerate(artwork_targets, 1):
            if progress_dialog and i % 2 == 0:
                pct = 50 + int((i / max(len(artwork_targets), 1)) * 50)
                progress_dialog.update_progress(
                    f'Getting things ready...\n\n{i} of {len(artwork_targets)}',
                    pct,
                )
            artwork.fetch_episode_artwork(ep)

        if progress_dialog:
            progress_dialog.update_progress('Your evening is ready.', 100)

        c.log(
            f'[TV Evening] Built {len(playlist)} visible, '
            f'{len(reserve_episodes)} reserve, {total_runtime} min'
        )
        return {
            'visible': playlist,
            'reserve': reserve_episodes,
            'skipped': skipped,
            'min_age_hours': min_age_hours,
        }
    except Exception as exc:
        c.log(f'[TV Evening] Error building playlist: {exc}', 1)
        c.log(f'[TV Evening] Traceback: {traceback.format_exc()}', 1)
        return None

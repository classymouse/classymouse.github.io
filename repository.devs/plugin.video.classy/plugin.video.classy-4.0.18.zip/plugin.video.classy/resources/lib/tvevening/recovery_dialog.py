# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file recovery_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening recovery dialog (Continue / Fresh / Delete).'''

from ..kodi.dialog_base import ClassyDialogBase
from ..modules.classy import c


class TVEveningRecoveryDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningRecovery.xml'
    BUTTON_CONTINUE = 9101
    BUTTON_START_FRESH = 9102
    BUTTON_DELETE = 9103

    def __init__(self, *args, **kwargs):
        message1 = kwargs.pop('message1', '')
        message2 = kwargs.pop('message2', '')
        fanart = kwargs.pop('fanart', '')
        super().__init__(*args, **kwargs)
        self.message1 = message1
        self.message2 = message2
        self.fanart = fanart
        self.user_choice = None

    def onInit(self):
        self.set_properties({
            'message1': self.message1,
            'message2': self.message2,
            'fanart': self.fanart or c.addon_fanart() or '',
        })
        try:
            self.setFocusId(self.BUTTON_CONTINUE)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId == self.BUTTON_CONTINUE:
            self.user_choice = 'continue'
            self.close_with(controlId)
        elif controlId == self.BUTTON_START_FRESH:
            self.user_choice = 'fresh'
            self.close_with(controlId)
        elif controlId == self.BUTTON_DELETE:
            self.user_choice = 'delete'
            self.close_with(controlId)

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.user_choice = 'delete'
            self.close_with(None)


def show_recovery_dialog(
    playlist_size,
    current_position,
    episode_titles=None,
    session_state=None,
    fanart='',
):
    remaining = playlist_size - current_position
    if remaining > 0:
        message1 = (
            f"You have an unfinished playlist with {remaining} "
            f"episode{'s' if remaining != 1 else ''} remaining."
        )
    else:
        message1 = (
            f"You have a completed playlist with {playlist_size} "
            f"episode{'s' if playlist_size != 1 else ''}."
        )

    state_hint = ''
    if session_state == 'paused':
        state_hint = ' (paused)'
    elif session_state == 'pausescreen':
        state_hint = ' (between episodes)'
    elif session_state == 'playing':
        state_hint = ' (in progress)'

    resume_label = ''
    if episode_titles and 0 <= current_position < len(episode_titles):
        resume_label = episode_titles[current_position]

    if resume_label and playlist_size > 0:
        message2 = f'Continue with: {resume_label}{state_hint}'
    elif current_position >= 0 and playlist_size > 0:
        message2 = f'Episode {current_position + 1} of {playlist_size}{state_hint}'
    else:
        message2 = (
            f"Playlist contains {playlist_size} "
            f"episode{'s' if playlist_size != 1 else ''}"
        )

    try:
        dialog = TVEveningRecoveryDialog.run_modal(
            message1=message1,
            message2=message2,
            fanart=fanart or '',
        )
        try:
            return dialog.user_choice
        finally:
            del dialog
    except Exception as exc:
        c.log(f'[TV Evening Recovery] dialog error: {exc}', 1)
        return None

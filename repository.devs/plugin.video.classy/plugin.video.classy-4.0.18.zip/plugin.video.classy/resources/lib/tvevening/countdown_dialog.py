# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file countdown_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening between-episode countdown  -  service-thread queued WindowXML dialog.'''

from __future__ import annotations

import json
import threading
import time

import xbmcgui

from ..kodi.dialog_base import ClassyDialogBase
from ..modules import control
from ..modules.classy import c


COUNTDOWN_PAYLOAD_PROP = 'thecrew.tvevening.countdown.params'
COUNTDOWN_PENDING_PROP = 'thecrew.tvevening.countdown.pending'
COUNTDOWN_RESULT_PROP = 'thecrew.tvevening.countdown.result'
COUNTDOWN_READY_PROP = 'thecrew.tvevening.countdown.ready'


class TVEveningCountdownDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningCountdown.xml'

    STATUS_LABEL = 9001
    COUNTDOWN_LABEL = 9003
    MESSAGES_TEXTBOX = 9004
    PLAY_NOW_BUTTON = 5
    CANCEL_BUTTON = 6

    def __init__(self, *args, **kwargs):
        next_episode = kwargs.pop('next_episode', None) or {}
        countdown = int(kwargs.pop('countdown', 60) or 60)
        super().__init__(*args, **kwargs)
        self.next_episode = next_episode
        self.countdown_seconds = max(5, countdown)
        self.user_choice = None
        self.stop_countdown = False
        self._stop_event = threading.Event()
        self.current_countdown = self.countdown_seconds
        self.messages = []

    def onInit(self):
        ep = self.next_episode or {}
        season = int(ep.get('season') or 0)
        episode = int(ep.get('episode') or 0)
        fanart = (ep.get('fanart') or '').strip()
        if not fanart or fanart in ('0', 'None'):
            fanart = c.addon_fanart() or ''

        self.set_properties({
            'show_title': ep.get('tvshowtitle') or 'Unknown',
            'episode_number': f'S{season:02d}E{episode:02d}',
            'episode_title': ep.get('title') or f'Episode {episode}',
            'episode_plot': ep.get('plot') or '',
            'episode_poster': ep.get('poster') or ep.get('thumb') or '',
            'fanart': fanart,
        })
        self._set_cast_props(ep)
        self._start_countdown()
        try:
            self.setFocusId(self.PLAY_NOW_BUTTON)
        except Exception:
            pass

    def _set_cast_props(self, ep):
        leads = ep.get('cast_leads') or []
        guests = ep.get('cast_guests') or []
        if not leads and not guests:
            raw = ep.get('cast_data')
            if isinstance(raw, str) and raw.strip():
                try:
                    data = json.loads(raw)
                    leads = data.get('leads') or data.get('cast_leads') or []
                    guests = data.get('guests') or data.get('cast_guests') or []
                except Exception:
                    pass
            elif isinstance(raw, dict):
                leads = raw.get('leads') or raw.get('cast_leads') or []
                guests = raw.get('guests') or raw.get('cast_guests') or []

        for i, lead in enumerate(list(leads)[:3], 1):
            if not isinstance(lead, dict):
                continue
            self.set_properties({
                f'lead{i}_name': lead.get('name') or '',
                f'lead{i}_character': lead.get('character') or '',
                f'lead{i}_thumb': lead.get('thumb') or '',
            })
        for i, guest in enumerate(list(guests)[:3], 1):
            if not isinstance(guest, dict):
                continue
            self.set_properties({
                f'guest{i}_name': guest.get('name') or '',
                f'guest{i}_character': guest.get('character') or '',
                f'guest{i}_thumb': guest.get('thumb') or '',
            })

    def _start_countdown(self):
        self.stop_countdown = False
        self._stop_event.clear()
        thread = threading.Thread(target=self._countdown_loop, name='tve-countdown', daemon=True)
        thread.start()

    def _countdown_loop(self):
        while not self.stop_countdown and self.current_countdown > 0:
            try:
                self.set_label(self.COUNTDOWN_LABEL, str(self.current_countdown))
            except Exception:
                pass
            self._stop_event.wait(1)
            self.current_countdown -= 1
        if not self.stop_countdown and self.current_countdown <= 0:
            self.user_choice = 'play'
            self.close_with(self.PLAY_NOW_BUTTON)

    def onClick(self, controlId):
        if self.closing:
            return
        if controlId == self.PLAY_NOW_BUTTON:
            self.user_choice = 'play'
            self.stop_countdown = True
            self._stop_event.set()
            self.close_with(controlId)
        elif controlId == self.CANCEL_BUTTON:
            if xbmcgui.Dialog().yesno('Stop TV Evening', 'Are you sure you want to stop the playlist?'):
                self.user_choice = 'cancel'
                self.stop_countdown = True
                self._stop_event.set()
                self.close_with(controlId)

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            if xbmcgui.Dialog().yesno('Stop TV Evening', 'Are you sure you want to stop the playlist?'):
                self.user_choice = 'cancel'
                self.stop_countdown = True
                self._stop_event.set()
                self.close_with(None)


def _run_countdown_modal(next_episode, countdown_seconds=60):
    try:
        dialog = TVEveningCountdownDialog.run_modal(
            next_episode=next_episode or {},
            countdown=countdown_seconds,
        )
        try:
            return dialog.user_choice or 'play'
        finally:
            del dialog
    except Exception as exc:
        c.log(f'[TV Evening Countdown] dialog error: {exc}', 1)
        return 'play'


def request_countdown(next_episode, countdown_seconds=60):
    """Queue countdown for ClassyMonitor service dispatch (not monitor thread)."""
    control.window.clearProperty(COUNTDOWN_RESULT_PROP)
    control.window.clearProperty(COUNTDOWN_READY_PROP)
    # Keep payload JSON-safe (episode rows may contain non-serializable leftovers).
    safe_ep = {}
    for key in (
        'tvshowtitle', 'title', 'plot', 'poster', 'thumb', 'fanart',
        'season', 'episode', 'cast_leads', 'cast_guests', 'cast_data',
        'position', 'showtmdb', 'showimdb',
    ):
        if next_episode and key in next_episode and next_episode[key] is not None:
            safe_ep[key] = next_episode[key]
    payload = json.dumps({
        'next_episode': safe_ep,
        'countdown_seconds': int(countdown_seconds or 60),
    })
    control.window.setProperty(COUNTDOWN_PAYLOAD_PROP, payload)
    control.window.setProperty(COUNTDOWN_PENDING_PROP, 'true')
    c.log('[TV Evening Countdown] Queued for service dispatch')


def wait_result(timeout_seconds=600):
    """Block until service thread finishes the queued countdown."""
    deadline = time.time() + max(30, float(timeout_seconds or 600))
    while time.time() < deadline:
        if control.window.getProperty(COUNTDOWN_READY_PROP) == 'true':
            result = control.window.getProperty(COUNTDOWN_RESULT_PROP) or 'play'
            control.window.clearProperty(COUNTDOWN_READY_PROP)
            control.window.clearProperty(COUNTDOWN_RESULT_PROP)
            return result
        time.sleep(0.25)
    c.log('[TV Evening Countdown] Timed out waiting for dialog  -  defaulting to play', 1)
    control.window.clearProperty(COUNTDOWN_PENDING_PROP)
    control.window.clearProperty(COUNTDOWN_PAYLOAD_PROP)
    return 'play'


def dispatch_pending():
    """Called from ClassyMonitor service loop."""
    if control.window.getProperty(COUNTDOWN_PENDING_PROP) != 'true':
        return False
    control.window.clearProperty(COUNTDOWN_PENDING_PROP)
    raw = control.window.getProperty(COUNTDOWN_PAYLOAD_PROP)
    control.window.clearProperty(COUNTDOWN_PAYLOAD_PROP)
    if not raw:
        c.log('[TV Evening Countdown] Dispatch: empty payload', 1)
        return False
    try:
        data = json.loads(raw)
    except Exception as exc:
        c.log(f'[TV Evening Countdown] Dispatch: bad payload: {exc}', 1)
        return False
    c.log('[TV Evening Countdown] Service dispatch  -  showing dialog')
    try:
        from . import bridge_dialog
        bridge_dialog.dismiss_bridge()
    except Exception:
        pass
    choice = _run_countdown_modal(
        data.get('next_episode') or {},
        int(data.get('countdown_seconds') or 60),
    )
    control.window.setProperty(COUNTDOWN_RESULT_PROP, choice or 'play')
    control.window.setProperty(COUNTDOWN_READY_PROP, 'true')
    return True

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file monitor.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening monitor  -  between-episode transitions and session end.

Gap uses skinned countdown (queued to ClassyMonitor service thread).
Uses thecrew.tvevening.* window props; Up Next stays suppressed via block_binge.'''

import threading
import time

import xbmc

from ..modules import control
from ..modules.classy import c
from . import playlist_db
from . import session
from . import settings


_av_started_event = threading.Event()
_AV_STARTED_PROP = 'thecrew.tvevening.av_started_ts'
_monitor_instance = None

# Don't declare "episode ended" on a single idle tick (audio switch / rebuffer).
_IDLE_END_SECONDS = 4.0
# Ignore end detection until playback has been confirmed this long.
_MIN_PLAY_BEFORE_END = 20.0


def _av_started_property_ts():
    try:
        val = control.window.getProperty(_AV_STARTED_PROP)
        return float(val) if val else 0.0
    except (TypeError, ValueError):
        return 0.0


def signal_av_started():
    """Called from ClassyPlayer.onAVStarted when evening monitor is active.

    Play runs in a separate plugin process  -  always write the window property.
    Monitor-process bookkeeping happens in TVEveningMonitor._on_av_confirmed.

    Ignore foreign streams (Greenhats, movies, other shows) so ~20s idle cannot
    advance the evening playlist.
    """
    try:
        if not session.playing_matches_evening_slot():
            c.log('[TV Evening Monitor] Ignoring AV from foreign content')
            return
    except Exception as exc:
        c.log(f'[TV Evening Monitor] AV identity check failed: {exc}', 1)
        return
    ts = str(time.time())
    control.window.setProperty(_AV_STARTED_PROP, ts)
    _av_started_event.set()
    global _monitor_instance
    if _monitor_instance and _monitor_instance.session_active:
        _monitor_instance._on_av_confirmed()


def clear_av_started():
    control.window.clearProperty(_AV_STARTED_PROP)
    _av_started_event.clear()


def wait_av_started(timeout, since=0.0, playing_check=None):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _av_started_event.is_set():
            return True
        if _av_started_property_ts() > since:
            return True
        if playing_check and playing_check():
            return True
        time.sleep(0.25)
    return False


def evening_is_live():
    return control.window.getProperty('thecrew.tvevening.monitor.active') == 'true'


def evening_blocks_upnext():
    if evening_is_live():
        return True
    return control.window.getProperty('thecrew.tvevening.block_binge') == 'true'


def ensure_recovery_eligible():
    """
    Return 'idle' | 'busy' | 'released'.

    The evening monitor thread starts in the plugin process. When that process
    exits, the thread can die while monitor.active stays set  -  recovery never
    shows and start aborts. If nothing is playing, soft-pause and clear the
    live flag so Continue / Fresh / Delete can run.
    """
    if not evening_is_live():
        return 'idle'
    playing = False
    try:
        playing = bool(xbmc.Player().isPlayingVideo())
    except Exception:
        playing = False
    if playing:
        return 'busy'

    c.log('[TV Evening] Releasing stale monitor.active (not playing)')
    global _monitor_instance
    try:
        if _monitor_instance is not None and _monitor_instance.session_active:
            _monitor_instance.stop(soft=True)
        else:
            session.soft_pause_session()
    except Exception as exc:
        c.log(f'[TV Evening] stale live release failed: {exc}', 1)
        try:
            session.deactivate_live_session()
            control.window.setProperty(session.PROP_RESUMABLE, 'true')
        except Exception:
            pass
    return 'released'


class TVEveningMonitor:
    def __init__(self, playlist_episodes, start_position=0, initial_state=session.STATE_START):
        self.playlist_episodes = list(playlist_episodes or [])
        self.current_position = max(0, int(start_position or 0))
        self.initial_state = initial_state or session.STATE_START
        self.session_active = False
        self.monitor_thread = None
        self.stop_monitoring = False
        self.transition_handled = False
        self._playback_confirmed_at = 0.0
        self._was_playing = False
        self._idle_since = 0.0

    def start(self):
        if self.session_active:
            return
        self.session_active = True
        self.stop_monitoring = False
        total = len(self.playlist_episodes)
        session.activate_live_session(self.current_position, total)
        session.set_state(self.initial_state, position=self.current_position)
        control.window.setProperty('thecrew.tvevening.total', str(total))
        self.monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name='TVEveningMonitor',
            daemon=True,
        )
        self.monitor_thread.start()
        c.log(
            f'[TV Evening Monitor] Started at pos={self.current_position}/{total}'
        )

    def stop(self, soft=False):
        self.stop_monitoring = True
        self.session_active = False
        try:
            from . import bridge_dialog
            bridge_dialog.dismiss_bridge()
        except Exception:
            pass
        if soft:
            session.soft_pause_session(position=self.current_position)
        else:
            session.deactivate_live_session()
        clear_av_started()
        c.log(f'[TV Evening Monitor] Stopped soft={soft}')

    def _on_av_confirmed(self):
        """Monitor-process side of AV start (property may arrive from play process)."""
        if not self.session_active:
            return
        if self._playback_confirmed_at > 0 and (time.time() - self._playback_confirmed_at) < 2:
            return
        self.transition_handled = False
        self._idle_since = 0.0
        self._playback_confirmed_at = time.time()
        session.set_state(session.STATE_PLAYING, position=self.current_position)
        try:
            playlist_db.get_playlist_db().mark_episode_started(self.current_position)
        except Exception:
            pass
        session.clear_scrape_failures(self.current_position)
        c.log('[TV Evening Monitor] AV confirmed  -  state=playing')

    def _playing(self):
        try:
            return xbmc.Player().isPlayingVideo()
        except Exception:
            return False

    def _playing_evening(self):
        """Video is up *and* it looks like the current evening slot (not Greenhats/movies)."""
        if not self._playing():
            return False
        try:
            return session.playing_matches_evening_slot()
        except Exception:
            return False

    def _monitor_loop(self):
        try:
            clear_av_started()
            since = time.time()
            ok = wait_av_started(90.0, since=since, playing_check=self._playing_evening)
            if ok or self._playing_evening():
                self._on_av_confirmed()
            elif not self._playing_evening():
                c.log('[TV Evening Monitor] Startup AV timeout')
                self._handle_startup_failure()
                return

            while not self.stop_monitoring and self.session_active:
                state = session.get_state()
                if state == session.STATE_PAUSESCREEN:
                    time.sleep(0.5)
                    continue

                # Dinner pause: keep session, but if the user left the player,
                # soft-pause so recovery can run (don't hold monitor.active forever).
                if state == session.STATE_PAUSED:
                    if self._playing():
                        self._idle_since = 0.0
                        time.sleep(0.5)
                        continue
                    if control.window.getProperty(session.PROP_USER_STOPPED) == 'true':
                        c.log('[TV Evening Monitor] Paused + user stop  -  soft pause')
                        self.stop(soft=True)
                        return
                    # Idle while paused (backed out of player without Stop callback)
                    now = time.time()
                    if self._idle_since <= 0:
                        self._idle_since = now
                    elif (now - self._idle_since) >= 3.0:
                        c.log('[TV Evening Monitor] Paused with no video  -  soft pause')
                        self.stop(soft=True)
                        return
                    time.sleep(0.5)
                    continue

                playing = self._playing()
                if playing:
                    # Foreign stream stole the player while we were live  -  soft-pause.
                    if (
                        self._playback_confirmed_at > 0
                        and not session.playing_matches_evening_slot()
                    ):
                        # Grace right after PlayMedia (tags lag)  -  don't soft-pause yet.
                        try:
                            last = float(
                                control.window.getProperty(
                                    'thecrew.tvevening.last_play_started'
                                )
                                or 0
                            )
                        except (TypeError, ValueError):
                            last = 0.0
                        if not last or (time.time() - last) >= 90.0:
                            c.log(
                                '[TV Evening Monitor] Foreign video while live  -  soft pause'
                            )
                            self.stop(soft=True)
                            return
                    self._was_playing = True
                    self._idle_since = 0.0
                    # Cross-process AV: confirm if property arrived after wait
                    if self._playback_confirmed_at <= 0:
                        self._on_av_confirmed()
                    self._poll_near_end()
                    time.sleep(1.0)
                    continue

                # Not playing  -  debounce before treating as episode end
                if self._was_playing and not self.transition_handled:
                    now = time.time()
                    if self._idle_since <= 0:
                        self._idle_since = now
                    idle_for = now - self._idle_since
                    play_for = (
                        (now - self._playback_confirmed_at)
                        if self._playback_confirmed_at > 0 else 0.0
                    )

                    if control.window.getProperty(session.PROP_USER_STOPPED) == 'true':
                        c.log('[TV Evening Monitor] User stop flag  -  soft pause')
                        self.stop(soft=True)
                        return

                    if play_for < _MIN_PLAY_BEFORE_END:
                        # Early idle: buffer / audio switch  -  wait, don't advance
                        if idle_for < 12:
                            time.sleep(0.5)
                            continue
                        c.log(
                            f'[TV Evening Monitor] Early idle {idle_for:.0f}s '
                            f'(played {play_for:.0f}s)  -  soft pause'
                        )
                        self.stop(soft=True)
                        return

                    if idle_for < _IDLE_END_SECONDS:
                        time.sleep(0.5)
                        continue

                    # Idle without user-stop flag: only treat as natural end if we
                    # armed near-end / transitioning. Otherwise soft-pause (Stop
                    # teardown can miss USER_STOPPED when getTime() collapses).
                    if control.window.getProperty('thecrew.tvevening.transitioning') != 'true':
                        c.log(
                            f'[TV Evening Monitor] Mid-watch idle {idle_for:.0f}s '
                            f'(played {play_for:.0f}s, not near end)  -  soft pause'
                        )
                        self.stop(soft=True)
                        return

                    self._was_playing = False
                    self._idle_since = 0.0
                    self._on_playback_ended()
                    continue

                time.sleep(0.5)
        except Exception as exc:
            c.log(f'[TV Evening Monitor] loop error: {exc}', 1)
            try:
                session.soft_pause_session(position=self.current_position)
            except Exception:
                pass
        finally:
            session.deactivate_live_session()
            self.session_active = False

    def _poll_near_end(self):
        """Mark transition approaching so Up Next stays suppressed."""
        try:
            if self._playback_confirmed_at <= 0:
                return
            if (time.time() - self._playback_confirmed_at) < _MIN_PLAY_BEFORE_END:
                return
            player = xbmc.Player()
            total = float(player.getTotalTime() or 0)
            current = float(player.getTime() or 0)
            if total <= 60:
                # Unreliable / short reported duration  -  don't arm early
                return
            remaining = total - current
            if remaining <= 20 or (current / total) >= 0.97:
                control.window.setProperty('thecrew.tvevening.transitioning', 'true')
        except Exception:
            pass

    def _handle_startup_failure(self):
        db = playlist_db.get_playlist_db()
        try:
            db.mark_episode_skipped(self.current_position)
        except Exception:
            pass
        session.record_scrape_failure()
        next_ep = db.get_next_episode(self.current_position)
        if next_ep:
            self.current_position = int(next_ep.get('position', self.current_position + 1))
            self._play_slot(next_ep)
            clear_av_started()
            since = time.time()
            if wait_av_started(90.0, since=since, playing_check=self._playing_evening) or self._playing_evening():
                self._on_av_confirmed()
            else:
                self.stop(soft=True)
        else:
            self._finish_session()

    def _on_playback_ended(self):
        self.transition_handled = True
        try:
            session.clear_playback_bookmark()
        except Exception:
            pass
        db = playlist_db.get_playlist_db()
        finished = None
        try:
            finished = db.get_episode_at_position(self.current_position)
        except Exception:
            finished = None
        try:
            db.mark_episode_watched(self.current_position)
        except Exception:
            pass

        # Local DB is not enough for the *next* evening pool  -  that comes from
        # Simkl/Trakt next_to_watch. Scrobble stop can under-report % on teardown;
        # force history so NYPD Blue / FROM don't reappear as "next".
        self._sync_tracker_watched(finished)

        next_ep = db.get_next_episode(self.current_position)
        if not next_ep:
            self._finish_session()
            return

        self._handle_episode_transition(next_ep)

    def _sync_tracker_watched(self, episode):
        '''Push finished episode into active tracker history (Simkl/Trakt).'''
        if not episode:
            return
        try:
            from .. import tracker
            imdb = (
                episode.get('showimdb')
                or episode.get('imdb')
                or ''
            )
            tmdb = (
                episode.get('showtmdb')
                or episode.get('tmdb')
                or ''
            )
            season = episode.get('season') or 0
            number = episode.get('episode') or 0
            if not (imdb or tmdb) or not season or not number:
                c.log(
                    f'[TV Evening] tracker watched skipped  -  '
                    f'ids/s/e missing imdb={imdb!r} tmdb={tmdb!r} '
                    f's={season} e={number}',
                    1,
                )
                return
            ok = tracker.mark_watched_episode(imdb, tmdb, season, number)
            c.log(
                f'[TV Evening] tracker watched '
                f'{episode.get("tvshowtitle") or "?"} '
                f'S{int(season):02d}E{int(number):02d} ok={ok}'
            )
        except Exception as exc:
            c.log(f'[TV Evening] tracker watched failed: {exc}', 1)

    def _gap_wait(self, next_episode):
        """Queue skinned countdown on the service thread; return True to play next."""
        from . import artwork
        from . import countdown_dialog

        # Resume / older playlists may lack cast_data  -  fill before the skin opens.
        try:
            artwork.ensure_episode_cast(next_episode)
        except Exception:
            pass

        seconds = max(5, int(settings.gap_countdown() or 60))
        control.window.setProperty('thecrew.tvevening.status', f'Next in {seconds}s...')
        countdown_dialog.request_countdown(next_episode, seconds)
        deadline = time.time() + seconds + 120
        while time.time() < deadline:
            if self.stop_monitoring:
                self._abort_queued_countdown()
                return False
            if session.get_state() == session.STATE_PAUSED:
                self._abort_queued_countdown()
                return False
            if control.window.getProperty(session.PROP_USER_STOPPED) == 'true':
                self._abort_queued_countdown()
                return False
            if control.window.getProperty(countdown_dialog.COUNTDOWN_READY_PROP) == 'true':
                result = control.window.getProperty(countdown_dialog.COUNTDOWN_RESULT_PROP) or 'play'
                control.window.clearProperty(countdown_dialog.COUNTDOWN_READY_PROP)
                control.window.clearProperty(countdown_dialog.COUNTDOWN_RESULT_PROP)
                c.log(f'[TV Evening Monitor] Countdown result={result}')
                return result == 'play'
            time.sleep(0.25)
        c.log('[TV Evening Monitor] Countdown wait timed out  -  continuing', 1)
        control.window.clearProperty(countdown_dialog.COUNTDOWN_PENDING_PROP)
        control.window.clearProperty(countdown_dialog.COUNTDOWN_PAYLOAD_PROP)
        return True

    @staticmethod
    def _abort_queued_countdown():
        from . import countdown_dialog

        control.window.clearProperty(countdown_dialog.COUNTDOWN_PENDING_PROP)
        control.window.clearProperty(countdown_dialog.COUNTDOWN_PAYLOAD_PROP)
        control.window.clearProperty(countdown_dialog.COUNTDOWN_READY_PROP)
        control.window.clearProperty(countdown_dialog.COUNTDOWN_RESULT_PROP)

    def _handle_episode_transition(self, next_episode):
        session.set_state(session.STATE_PAUSESCREEN, position=self.current_position)
        control.window.setProperty('thecrew.tvevening.transitioning', 'true')
        try:
            from . import bridge_dialog
            bridge_dialog.request_bridge(
                next_episode.get('fanart') or '',
                message='Next up...',
            )
        except Exception:
            pass
        session.clear_kodi_video_playlist()

        if not self._gap_wait(next_episode):
            c.log('[TV Evening Monitor] Gap cancelled  -  soft pause')
            try:
                from . import bridge_dialog
                bridge_dialog.dismiss_bridge()
            except Exception:
                pass
            self.stop(soft=True)
            return

        self.current_position = int(next_episode.get('position', self.current_position + 1))
        session.set_state(session.STATE_START, position=self.current_position)
        control.window.clearProperty('thecrew.tvevening.transitioning')
        control.window.clearProperty(session.PROP_USER_STOPPED)
        self.transition_handled = False
        self._was_playing = False
        self._playback_confirmed_at = 0.0
        self._idle_since = 0.0
        clear_av_started()
        self._play_slot(next_episode)

        since = time.time()
        if wait_av_started(90.0, since=since, playing_check=self._playing_evening) or self._playing_evening():
            self._on_av_confirmed()
        else:
            c.log('[TV Evening Monitor] Next episode AV timeout')
            self._handle_startup_failure()

    def _play_slot(self, episode):
        from .play import play_episode_now
        play_episode_now(episode)

    def _finish_session(self):
        """Last episode done  -  tear down playlist, queue completion dialog on service thread."""
        from . import complete_dialog

        c.log('[TV Evening Monitor] Last episode finished  -  queuing completion dialog')
        control.window.setProperty('thecrew.tvevening.transitioning', 'true')
        session.set_completing()

        # Count actually completed visible slots  -  not playlist length (can include
        # unplayed trim leftovers if something went sideways) and not reserves.
        episodes_watched = 0
        fanart = ''
        try:
            db = playlist_db.get_playlist_db()
            visible = db.get_visible_episodes() or []
            episodes_watched = sum(
                1 for ep in visible if ep.get('watched') or ep.get('completed')
            )
            for ep in reversed(visible):
                if ep.get('watched') or ep.get('completed'):
                    fanart = ep.get('fanart') or ''
                    break
            if not fanart and visible:
                fanart = visible[-1].get('fanart') or ''
        except Exception:
            pass
        if episodes_watched <= 0:
            episodes_watched = max(1, int(self.current_position) + 1)

        try:
            from . import bridge_dialog
            bridge_dialog.request_bridge(fanart, message='Wrapping up...')
        except Exception:
            pass
        session.clear_kodi_video_playlist()

        session.set_state(session.STATE_ENDED, position=self.current_position)
        # Keep block_binge / completing until the dialog closes (Crew parity).
        control.window.clearProperty('thecrew.tvevening.monitor.active')
        try:
            playlist_db.get_playlist_db().set_metadata('session_active', 'false')
        except Exception:
            pass
        try:
            playlist_db.get_playlist_db().clear_playlist()
        except Exception:
            pass

        complete_dialog.request_complete(episodes_watched, fanart)
        self.stop_monitoring = True
        self.session_active = False
        clear_av_started()
        c.log('[TV Evening Monitor] Session finished')


def start_tv_evening_session(playlist_episodes, start_position=0, initial_state=session.STATE_START):
    global _monitor_instance
    if _monitor_instance and _monitor_instance.session_active:
        try:
            _monitor_instance.stop(soft=True)
        except Exception:
            pass
    _monitor_instance = TVEveningMonitor(
        playlist_episodes,
        start_position=start_position,
        initial_state=initial_state,
    )
    _monitor_instance.start()
    return _monitor_instance

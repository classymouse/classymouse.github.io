# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file complete_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening completion screen  -  service-thread queued WindowXML dialog.'''

from __future__ import annotations

import datetime
import json
import threading

from ..kodi.dialog_base import ClassyDialogBase
from ..modules import control
from ..modules.classy import c


COMPLETE_PAYLOAD_PROP = 'thecrew.tvevening.complete.params'
COMPLETE_PENDING_PROP = 'thecrew.tvevening.complete.pending'


class TVEveningCompleteDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningComplete.xml'
    CLOSE_BUTTON = 5

    def __init__(self, *args, **kwargs):
        episodes_watched = int(kwargs.pop('episodes_watched', 0) or 0)
        fanart = kwargs.pop('fanart', '') or ''
        super().__init__(*args, **kwargs)
        self.episodes_watched = episodes_watched
        self.fanart = fanart
        self.countdown_seconds = 30
        self.countdown_active = True
        self.user_closed = False
        self._stop_event = threading.Event()

    def onInit(self):
        fanart = (self.fanart or '').strip()
        if not fanart or fanart in ('0', 'None'):
            fanart = c.addon_fanart() or ''
        stats = ''
        if self.episodes_watched > 0:
            plural = 's' if self.episodes_watched != 1 else ''
            stats = f'You watched {self.episodes_watched} episode{plural}'
        self.set_properties({
            'fanart': fanart,
            'greeting': self._greeting(),
            'stats': stats,
            'timer': f'Closing in {self.countdown_seconds} seconds...',
        })
        self._start_countdown()
        try:
            self.setFocusId(self.CLOSE_BUTTON)
        except Exception:
            pass

    def _greeting(self):
        hour = datetime.datetime.now().hour
        if 5 <= hour < 12:
            return 'Have a great day!'
        if 12 <= hour < 17:
            return 'Enjoy your day!'
        if 17 <= hour < 22:
            return 'Have a wonderful evening!'
        return 'Sleep well!'

    def _start_countdown(self):
        self._stop_event.clear()
        threading.Thread(target=self._countdown_loop, name='tve-complete', daemon=True).start()

    def _countdown_loop(self):
        for remaining in range(self.countdown_seconds, 0, -1):
            if not self.countdown_active or self.user_closed:
                break
            plural = 's' if remaining != 1 else ''
            self.setProperty('timer', f'Closing in {remaining} second{plural}...')
            self._stop_event.wait(1)
        if self.countdown_active and not self.user_closed:
            self.close_with(self.CLOSE_BUTTON)

    def onClick(self, controlId):
        if controlId == self.CLOSE_BUTTON:
            self.user_closed = True
            self.countdown_active = False
            self._stop_event.set()
            self.close_with(controlId)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.user_closed = True
            self.countdown_active = False
            self._stop_event.set()
            self.close_with(None)


def _run_complete_modal(episodes_watched=0, fanart=''):
    try:
        dialog = TVEveningCompleteDialog.run_modal(
            episodes_watched=episodes_watched,
            fanart=fanart or '',
        )
        del dialog
    except Exception as exc:
        c.log(f'[TV Evening Complete] dialog error: {exc}', 1)
    try:
        control.window.clearProperty('thecrew.tvevening.block_binge')
        control.window.clearProperty('thecrew.tvevening.transitioning')
        from . import session as evening_session
        evening_session.clear_completing()
    except Exception as exc:
        c.log(f'[TV Evening Complete] gate clear failed: {exc}', 1)
    c.log('[TV Evening Complete] Dialog closed')


def request_complete(episodes_watched=0, fanart=''):
    """Queue completion dialog for ClassyMonitor service dispatch."""
    payload = json.dumps({
        'episodes_watched': int(episodes_watched or 0),
        'fanart': fanart or '',
    })
    control.window.setProperty(COMPLETE_PAYLOAD_PROP, payload)
    control.window.setProperty(COMPLETE_PENDING_PROP, 'true')
    c.log(f'[TV Evening Complete] Queued for service dispatch ({episodes_watched} episodes)')


def dispatch_pending():
    """Called from ClassyMonitor service loop."""
    if control.window.getProperty(COMPLETE_PENDING_PROP) != 'true':
        return False
    control.window.clearProperty(COMPLETE_PENDING_PROP)
    raw = control.window.getProperty(COMPLETE_PAYLOAD_PROP)
    control.window.clearProperty(COMPLETE_PAYLOAD_PROP)
    if not raw:
        c.log('[TV Evening Complete] Dispatch: empty payload', 1)
        return False
    try:
        data = json.loads(raw)
    except Exception as exc:
        c.log(f'[TV Evening Complete] Dispatch: bad payload: {exc}', 1)
        return False
    c.log('[TV Evening Complete] Service dispatch  -  showing dialog')
    try:
        from . import bridge_dialog
        bridge_dialog.dismiss_bridge()
    except Exception:
        pass
    _run_complete_modal(
        episodes_watched=int(data.get('episodes_watched') or 0),
        fanart=data.get('fanart') or '',
    )
    return True

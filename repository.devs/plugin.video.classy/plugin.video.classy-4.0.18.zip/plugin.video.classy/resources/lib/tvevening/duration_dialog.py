# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file duration_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening duration + custom numeric dialogs (ClassyDialogBase).'''

import traceback

import xbmc

from ..kodi.dialog_base import ClassyDialogBase
from ..modules.classy import c


class TVEveningDurationDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningDuration.xml'

    def __init__(self, *args, **kwargs):
        fanart = kwargs.pop('fanart', '')
        super().__init__(*args, **kwargs)
        self.fanart = fanart
        self._building_mode = False

    def onInit(self):
        try:
            self.set_properties({
                'tvevening.fanart': self.fanart or c.addon_fanart() or '',
            })
            if self._building_mode or self.getProperty('tvevening.building') == 'true':
                self.show_building()
                return

            for cid in (8000, 8001, 8002, 8003):
                ctrl = self.control(cid)
                if ctrl is not None:
                    ctrl.setVisible(False)
            self.setFocusId(100)
        except Exception as exc:
            c.log(f'[TV Evening Duration] onInit error: {exc}', 1)

    def onClick(self, controlId):
        if self.closing:
            return
        self.close_with(controlId)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.close_with(None)

    def update_progress(self, message, percentage=None):
        try:
            center = self.control(8002)
            if center is not None:
                center.setText(message)
            if percentage is not None:
                self._update_progress_bar(percentage)
            xbmc.sleep(1)
        except Exception as exc:
            c.log(f'[TV Evening Duration] update_progress error: {exc}')

    def _update_progress_bar(self, percentage):
        try:
            percentage = max(0, min(100, int(percentage)))
            fill_width = int((percentage / 100.0) * 596)
            fill = self.control(8005)
            if fill is not None:
                fill.setWidth(fill_width)
            label = self.control(8006)
            if label is not None:
                label.setLabel(f'{percentage}%')
        except Exception as exc:
            c.log(f'[TV Evening Duration] progress bar error: {exc}')

    def _prepare_for_building_display(self):
        self._building_mode = True
        self.setProperty('tvevening.building', 'true')

    def show_building(self):
        try:
            self._prepare_for_building_display()
            for cid in (8000, 8001, 8002, 8003):
                ctrl = self.control(cid)
                if ctrl is not None:
                    ctrl.setVisible(True)

            for cid in (9001, 9002, 9000, 201, 200):
                ctrl = self.control(cid)
                if ctrl is not None:
                    ctrl.setVisible(False)

            for button_id in range(100, 107):
                ctrl = self.control(button_id)
                if ctrl is not None:
                    ctrl.setVisible(False)

            title = self.control(8001)
            if title is not None:
                title.setLabel('BUILDING YOUR PLAYLIST')
            text = self.control(8002)
            if text is not None:
                text.setText('Preparing your TV Evening...')
            self._update_progress_bar(0)
        except Exception as exc:
            c.log(f'[TV Evening Duration] show_building error: {exc}', 1)
            c.log(traceback.format_exc(), 1)


class TVEveningNumericDialog(ClassyDialogBase):
    XML_FILE = 'TVEveningNumericInput.xml'

    def __init__(self, *args, **kwargs):
        fanart = kwargs.pop('fanart', '')
        default = kwargs.pop('default', '60')
        super().__init__(*args, **kwargs)
        self.fanart = fanart
        self.value = str(default or '60')

    def onInit(self):
        try:
            self.set_properties({
                'tvevening.fanart': self.fanart or c.addon_fanart() or '',
            })
            try:
                self.getControl(201).setLabel('[COLOR orchid]CUSTOM DURATION[/COLOR]')
            except Exception:
                pass
            try:
                self.getControl(202).setLabel('Enter minutes for your TV Evening')
            except Exception:
                pass
            for cid, digit in (
                (101, '1'), (102, '2'), (103, '3'), (104, '4'), (105, '5'),
                (106, '6'), (107, '7'), (108, '8'), (109, '9'), (100, '0'),
            ):
                self.getControl(cid).setLabel(digit)
            self.getControl(110).setLabel('<')
            self.getControl(111).setLabel('C')
            self.getControl(112).setLabel('OK')
            self.getControl(113).setLabel('Cancel')
            self.update_display()
            self.setFocusId(105)
        except Exception as exc:
            c.log(f'[TV Evening Numeric] onInit error: {exc}', 1)

    def update_display(self):
        try:
            self.getControl(200).setLabel(self.value or '0')
        except Exception:
            pass

    def onClick(self, controlId):
        if self.closing:
            return
        if 100 <= controlId <= 109:
            digit = '0' if controlId == 100 else str(controlId - 100)
            if self.value == '0':
                self.value = digit
            elif len(self.value) < 4:
                self.value += digit
            self.update_display()
        elif controlId == 110:
            self.value = self.value[:-1] or '0'
            self.update_display()
        elif controlId == 111:
            self.value = '0'
            self.update_display()
        elif controlId == 112:
            self.close_with(112)
        elif controlId == 113:
            self.close_with(113)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.close_with(113)


_DURATION_MAP = {
    100: 30,
    101: 60,
    102: 120,
    103: 180,
    104: 240,
    105: -1,   # custom
    106: None,  # cancel
}


def show_numeric_input(fanart='', default='60'):
    try:
        dialog = TVEveningNumericDialog.run_modal(fanart=fanart, default=default)
        try:
            if dialog.button_id == 112:
                return dialog.value
            return None
        finally:
            del dialog
    except Exception as exc:
        c.log(f'[TV Evening Numeric] error: {exc}', 1)
        return None


def show_duration_with_progress(fanart=''):
    """
    Returns (duration_minutes, dialog) or (None, None).
    Dialog is kept open (non-modal re-show) for build progress.
    """
    try:
        while True:
            dialog = TVEveningDurationDialog.create(fanart=fanart)
            dialog.doModal()
            button_id = dialog.button_id

            if button_id not in _DURATION_MAP:
                del dialog
                return (None, None)

            duration = _DURATION_MAP[button_id]
            if duration == -1:
                custom = show_numeric_input(fanart=fanart)
                if custom:
                    dialog._prepare_for_building_display()
                    dialog.show()
                    return (int(custom), dialog)
                del dialog
                continue

            if duration is None:
                del dialog
                return (None, None)

            dialog._prepare_for_building_display()
            dialog.show()
            return (duration, dialog)
    except Exception as exc:
        c.log(f'[TV Evening Duration] error: {exc}', 1)
        c.log(traceback.format_exc(), 1)
        return (None, None)

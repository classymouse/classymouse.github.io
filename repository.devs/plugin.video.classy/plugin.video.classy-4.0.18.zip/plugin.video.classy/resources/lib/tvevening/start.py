# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file start.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening entry  -  duration  ->  gate pool  ->  build  ->  preview  ->  play.

Pool is always tracker.next_episode_sessions (gate only).'''

import sys
import traceback

import xbmcgui

from .. import tracker
from ..modules import control
from ..modules import kodi
from ..modules.classy import c
from . import build
from . import duration_dialog
from . import playlist_dialog
from . import settings


def _close_plugin_handle(succeeded=False):
    """Dismiss Kodi's plugin busy state for dialog-only routes."""
    try:
        handle = int(sys.argv[1])
    except (IndexError, ValueError, TypeError):
        return
    try:
        kodi.content(handle, 'videos')
        kodi.directory(handle, succeeded=succeeded, cacheToDisc=False)
    except Exception:
        pass
    try:
        control.idle()
    except Exception:
        pass


def _prompt_tracker_setup():
    """
    Provider-agnostic prompt using tracker.display_label().
    Auth dispatch uses the active XOR backend (gate helpers).
    """
    label = tracker.display_label()
    setup_now = c.yesnoDialog(
        f'TV Evening needs {label} to find next episodes from shows you\'re watching.\n\n'
        f'Would you like to set up {label} now?',
        heading=f'{label} Required',
        nolabel='Not Now',
        yeslabel=f'Set Up {label}',
    )
    if not setup_now:
        return False

    try:
        if tracker.is_simkl():
            from ..simkl import ui as simkl_ui
            simkl_ui.auth_simkl()
        elif tracker.is_wetrakr():
            from ..apis import wetrakr as wetrakr_api
            wetrakr_api.authenticate()
        else:
            from ..trakt import ui as trakt_ui
            trakt_ui.auth_trakt()
    except Exception as exc:
        c.log(f'[TV Evening] Tracker setup error: {exc}', 1)
    return tracker.live()


def _episode_short_label(ep, max_show_len=32):
    show = (ep.get('tvshowtitle') or 'Unknown').strip()
    if len(show) > max_show_len:
        show = show[:max_show_len - 1] + '...'
    season = int(ep.get('season') or 0)
    episode = int(ep.get('episode') or 0)
    return f'{show} S{season:02d}E{episode:02d}'


def _show_skipped_notification(skipped_episodes, min_age_hours):
    try:
        if not skipped_episodes:
            return
        if len(skipped_episodes) == 1:
            message = f'{_episode_short_label(skipped_episodes[0])} too recent  -  replaced'
        elif len(skipped_episodes) == 2:
            labels = ' and '.join(
                _episode_short_label(ep, max_show_len=22) for ep in skipped_episodes
            )
            message = f'{labels} too recent  -  replaced'
        else:
            message = f'{len(skipped_episodes)} too-recent episodes replaced (<{min_age_hours}h)'
        c.infoDialog(message, heading='TV Evening', time=8000, sound=False)
    except Exception as exc:
        c.log(f'[TV Evening] skipped notification error: {exc}')


def start_tv_evening():
    """Main entry: recovery or duration  ->  build  ->  preview  ->  play."""
    progress_dialog = None
    try:
        c.log('[TV Evening] Starting')

        if not tracker.live():
            if not _prompt_tracker_setup():
                return

        from . import monitor as evening_monitor
        from . import recovery

        gate = evening_monitor.ensure_recovery_eligible()
        if gate == 'busy':
            c.infoDialog(
                'TV Evening is already playing',
                heading='TV Evening',
                time=3000,
                sound=False,
            )
            c.log('[TV Evening] Already live and playing  -  aborting new start')
            return

        recovery_choice = recovery.handle_recovery()
        if recovery_choice == 'continue':
            session_info = recovery.get_session_info()
            if session_info:
                from .play import resume_playlist
                resume_playlist(session_info)
            return
        if recovery_choice == 'delete':
            return
        if recovery_choice == 'fresh':
            recovery.clear_stale_session()
        elif recovery_choice is None:
            from . import session as evening_session
            if evening_session.is_resumable_session():
                # Should be rare after ensure_recovery_eligible  -  surface recovery once more
                # rather than silently dead-ending the menu entry.
                c.log('[TV Evening] Resumable still present after cancel  -  not starting fresh')
                return

        # Random backdrop from the user's next-episode pool (Crew 3.x look).
        from . import pool as evening_pool
        fanart = evening_pool.random_show_backdrop() or c.addon_fanart() or ''
        duration, progress_dialog = duration_dialog.show_duration_with_progress(fanart)
        if duration is None:
            c.log('[TV Evening] Duration cancelled')
            return

        c.log(f'[TV Evening] Duration: {duration} minutes')
        if progress_dialog:
            progress_dialog.show_building()

        built = build.build_playlist(duration, progress_dialog)

        if progress_dialog:
            try:
                progress_dialog.close()
            except Exception:
                pass
            progress_dialog = None

        if not built or not built.get('visible'):
            skipped = (built or {}).get('skipped') or []
            if skipped:
                min_age = (built or {}).get('min_age_hours') or settings.min_episode_age()
                if min_age > 0:
                    xbmcgui.Dialog().ok(
                        'TV Evening',
                        'No episodes passed the minimum-air-age filter ({} hours).\n\n'
                        '{} candidate episode(s) were skipped.\n\n'
                        'Lower TV Evening  ->  Minimum episode age in settings, '
                        'or wait until recently aired episodes are old enough.'.format(
                            min_age, len(skipped),
                        ),
                    )
                else:
                    xbmcgui.Dialog().ok(
                        'TV Evening',
                        'Could not build a playlist from your watch progress.',
                    )
            return

        playlist = built['visible']
        choice = 'play'
        if settings.show_playlist():
            choice = playlist_dialog.show_playlist_preview(playlist)
            if choice is None:
                c.log('[TV Evening] Preview cancelled')
                return
            if choice == 'first':
                playlist = [playlist[0]]

        skipped = built.get('skipped') or []
        if skipped:
            _show_skipped_notification(skipped, built.get('min_age_hours') or 48)

        from .play import play_playlist
        play_playlist(playlist, reserve_episodes=built.get('reserve') or [])
    except Exception as exc:
        c.log(f'[TV Evening] start error: {exc}', 1)
        c.log(traceback.format_exc(), 1)
        try:
            if progress_dialog:
                progress_dialog.close()
        except Exception:
            pass
    finally:
        _close_plugin_handle(succeeded=False)

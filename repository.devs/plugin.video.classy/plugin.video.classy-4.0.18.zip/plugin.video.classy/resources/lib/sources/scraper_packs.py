# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scraper_packs.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Curated scraper-pack manifest (resources/data/scraper_packs.json).

Single source of truth for which external packs Classy / Crew 4.x wires.
Settings toggles and provider loaders still live per-pack; this file owns
the catalog, order, and defaults.'''

from __future__ import annotations

import json
import os

from ..modules.crewruntime import c
from .pack_settings import pack_enabled

_MANIFEST_NAME = 'scraper_packs.json'
_cache = None


def _manifest_path():
    # resources/lib/sources -> resources/data
    here = os.path.dirname(os.path.abspath(__file__))
    resources = os.path.dirname(os.path.dirname(here))
    return os.path.join(resources, 'data', _MANIFEST_NAME)


def load_manifest(force=False):
    '''Return parsed manifest dict (cached).'''
    global _cache
    if _cache is not None and not force:
        return _cache
    path = _manifest_path()
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or not isinstance(data.get('packs'), list):
            raise ValueError('invalid scraper_packs.json shape')
        _cache = data
        return _cache
    except Exception as exc:
        c.log(f'[ScraperPacks] Failed to load {_MANIFEST_NAME}: {exc}', 1)
        _cache = {'version': 0, 'packs': []}
        return _cache


def list_packs():
    '''Packs sorted by ``order`` then label.'''
    packs = list(load_manifest().get('packs') or [])
    packs.sort(key=lambda p: (int(p.get('order') or 100), str(p.get('label') or p.get('id') or '')))
    return packs


def get_pack(pack_id):
    pack_id = str(pack_id or '').strip()
    if not pack_id:
        return None
    for pack in list_packs():
        if pack.get('id') == pack_id:
            return pack
    return None


def _resolve_addons_dir(addons_dir=None):
    if addons_dir:
        return addons_dir
    try:
        import xbmcvfs
        path = xbmcvfs.translatePath('special://home/addons')
        if path and os.path.isdir(path):
            return path
    except Exception:
        pass
    # Fallback when called outside a full Kodi path resolve (loader / tests).
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(8):
        if os.path.basename(cur).lower() == 'addons':
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None


def is_installed(pack, addons_dir=None):
    '''True if Kodi reports the addon or its folder exists under addons/.

    Dialog callers often omit addons_dir; always fold in a folder check so a
    flaky/disabled HasAddon does not show "Not installed" for present packs.
    '''
    import xbmc

    addon_id = (pack or {}).get('addon') or ''
    if not addon_id:
        return False
    try:
        if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
            return True
    except Exception:
        pass
    root = _resolve_addons_dir(addons_dir)
    if root and os.path.isdir(os.path.join(root, addon_id)):
        return True
    return False


def is_enabled(pack):
    '''User toggle from settings (manifest ``enabled_default`` when unset).'''
    setting = (pack or {}).get('setting') or ''
    default = bool((pack or {}).get('enabled_default', True))
    if not setting:
        return default
    return pack_enabled(setting, default=default)


def set_enabled(pack, enabled):
    '''Persist pack enable flag.'''
    setting = (pack or {}).get('setting') or ''
    if not setting:
        return False
    try:
        from ..modules import control
        control.setSetting(setting, 'true' if enabled else 'false')
        return True
    except Exception as exc:
        c.log(f'[ScraperPacks] set_enabled failed for {setting}: {exc}', 1)
        return False


def loader_module_name(pack):
    '''Deprecated: packs load via pack_loader + JSON layout (kept for callers).'''
    return str((pack or {}).get('loader') or (pack or {}).get('id') or '').strip()


def pack_tag_prefixes():
    '''(prefix, tag) pairs for source-row labeling, from manifest ``tag`` + ``prefix``.'''
    pairs = []
    for pack in list_packs():
        prefix = str(pack.get('prefix') or '').strip().lower()
        if not prefix:
            continue
        if not prefix.endswith('.'):
            prefix = prefix + '.'
        tag = str(pack.get('tag') or '').strip()
        if not tag:
            label = str(pack.get('label') or pack.get('id') or '').strip()
            tag = f'[{label}]' if label else ''
        if tag:
            pairs.append((prefix, tag))
    return pairs

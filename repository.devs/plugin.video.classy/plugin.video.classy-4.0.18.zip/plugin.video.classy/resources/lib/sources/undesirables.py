# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file undesirables.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Undesirables blacklist  -  SQLite profile db, defaults from undesirables_defaults.'''

import os
import sqlite3

import xbmcaddon
import xbmcvfs

from ..modules.classy import c
from .undesirables_defaults import DEFAULT_UNDESIRABLES

_CREW_ADDON_ID = 'plugin.video.thecrew'


def _db_path():
    profile = xbmcaddon.Addon().getAddonInfo('profile')
    return os.path.join(xbmcvfs.translatePath(profile), 'undesirables.db')


def _crew_db_path():
    try:
        crew = xbmcaddon.Addon(_CREW_ADDON_ID)
        profile = xbmcvfs.translatePath(crew.getAddonInfo('profile'))
        return os.path.join(profile, 'undesirables.db')
    except Exception:
        return None


def _connect():
    path = _db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_schema(cur):
    cur.execute('''
        CREATE TABLE IF NOT EXISTS undesirables (
            keyword TEXT NOT NULL UNIQUE,
            user_defined INTEGER NOT NULL DEFAULT 0,
            enabled INTEGER NOT NULL DEFAULT 1,
            PRIMARY KEY (keyword)
        )
    ''')


def _import_crew_user_keywords(cur):
    '''Optional one-time pull of user-added keywords from Crew (not required for defaults).'''
    crew_path = _crew_db_path()
    if not crew_path or not os.path.isfile(crew_path):
        return 0
    try:
        cur.execute('ATTACH DATABASE ? AS crew', (crew_path,))
        count = cur.execute(
            'SELECT COUNT(*) FROM crew.undesirables WHERE user_defined = 1'
        ).fetchone()[0]
        if count:
            cur.execute('''
                INSERT OR IGNORE INTO undesirables (keyword, user_defined, enabled)
                SELECT keyword, user_defined, enabled FROM crew.undesirables
                WHERE user_defined = 1
            ''')
        cur.execute('DETACH DATABASE crew')
        if count:
            c.log(f'[Undesirables] migrated {count} user keywords from Crew')
        return int(count or 0)
    except Exception as exc:
        try:
            cur.execute('DETACH DATABASE crew')
        except Exception:
            pass
        c.log(f'[Undesirables] Crew user-keyword migration failed: {exc}', 1)
        return 0


def _seed_defaults(cur):
    count = cur.execute('SELECT COUNT(*) FROM undesirables').fetchone()[0]
    if count:
        return

    cur.executemany(
        'INSERT OR IGNORE INTO undesirables (keyword, user_defined, enabled) VALUES (?, 0, 1)',
        [(kw,) for kw in DEFAULT_UNDESIRABLES],
    )
    c.log(f'[Undesirables] seeded {len(DEFAULT_UNDESIRABLES)} defaults')
    _import_crew_user_keywords(cur)


def get_keywords():
    '''Enabled blacklist keywords, or empty when filtering is off.'''
    if c.get_setting('filter.undesirables') != 'true':
        return []
    try:
        conn = _connect()
        cur = conn.cursor()
        _ensure_schema(cur)
        _seed_defaults(cur)
        conn.commit()
        rows = cur.execute(
            'SELECT keyword FROM undesirables WHERE enabled = 1'
        ).fetchall()
        conn.close()
        keywords = [str(row['keyword']).lower() for row in rows]
        if c.devmode:
            c.log(f'[Undesirables] {len(keywords)} keywords active')
        return keywords
    except Exception as exc:
        c.log(f'[Undesirables] load failed, using defaults: {exc}', 1)
        return [kw.lower() for kw in DEFAULT_UNDESIRABLES]

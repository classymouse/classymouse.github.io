# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file rank.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Rank stream candidates for source picker default order.'''

_QUALITY_RANK = {
    '4k': 50, '2160p': 50, 'uhd': 48,
    '1080p': 40, '1080': 38, 'fhd': 36,
    '720p': 30, '720': 28, 'hd': 26,
    'sd': 10, 'cam': 2, 'scr': 4,
}


def _quality_score(quality):
    q = str(quality or '').lower()
    for token, score in _QUALITY_RANK.items():
        if token in q:
            return score
    return 15


def rank_candidates(candidates):
    def sort_key(cand):
        source = str(cand.source or (cand.raw or {}).get('source') or '').lower()
        cached_bonus = 1000 if source == 'cached torrent' else 0
        return (
            cached_bonus,
            _quality_score(cand.quality),
            int(cand.seeders or 0),
            float(cand.size or 0),
        )

    return sorted(candidates or [], key=sort_key, reverse=True)

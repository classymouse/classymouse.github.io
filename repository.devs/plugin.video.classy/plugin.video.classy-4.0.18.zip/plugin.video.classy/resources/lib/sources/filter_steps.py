# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file filter_steps.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Individual stream filters  -  register here; gated by user settings.'''

import re
from urllib.parse import parse_qs, unquote, urlparse

from ..modules.classy import c
from .filter_pipeline import register_filter
from .quality_tiers import is_cam_quality, quality_tier
from .undesirables import get_keywords

_HEVC_MARKERS = (
    'hevc', 'h265', 'h.265', 'x265', 'x.265',
)

_TORRENT_SOURCES = frozenset({
    'torrent', 'cached torrent', 'uncached torrent', 'unknown torrent', 'magnet',
})

_DANGEROUS_EXTENSIONS = (
    '.exe', '.bat', '.cmd', '.com', '.msi', '.scr', '.vbs', '.apk',
)

_DANGEROUS_TOKENS = frozenset({
    'exe', 'bat', 'cmd', 'com', 'msi', 'scr', 'vbs', 'apk',
})

_EXTRAS_KEYWORDS = (
    'sample', 'extra', 'extras', 'deleted', 'deleted.scene', 'deleted.scenes',
    'blooper', 'bloopers', 'making.of', 'makingof', 'behind.the.scenes',
    'featurette', 'featurettes', 'commentary', 'gag.reel', 'outtake', 'outtakes',
    'interview', 'interviews', 'trailer', 'teaser', 'promo', 'bonus',
    'documentary', 'doc', '.extras.', '-extras-', '_extras_',
)


def _candidate_blob(candidate):
    parts = (candidate.url, candidate.name, candidate.info, candidate.quality)
    return ' '.join(str(p) for p in parts if p).lower()


def _release_text(candidate):
    url = (candidate.url or '').strip()
    name = (candidate.name or '').strip()
    if url.startswith('magnet:'):
        try:
            params = parse_qs(urlparse(url).query)
            dn = (params.get('dn') or [''])[0]
            if dn:
                return unquote(dn).replace('+', ' ').strip().lower()
        except Exception:
            pass
    if name:
        return name.lower()
    return url.lower()


def _contains_marker(blob, markers):
    return any(marker in blob for marker in markers)


def _is_dangerous_release(candidate):
    '''Drop executables / installers masquerading as video releases.'''
    release = _release_text(candidate)
    if not release:
        return False
    for ext in _DANGEROUS_EXTENSIONS:
        if release.endswith(ext):
            return True
    tokens = re.split(r'[\s\.\-\_\[\]\(\)\+]+', release)
    if tokens and tokens[-1] in _DANGEROUS_TOKENS:
        return True
    return False


def filter_dangerous_releases(candidates, request=None):
    return [cand for cand in candidates if not _is_dangerous_release(cand)]


def _is_extra(candidate):
    release_info = _release_text(candidate)
    if not release_info:
        return False
    tokens = re.split(r'[\s\.\-\_\[\]\(\)\+]+', release_info)
    for keyword in _EXTRAS_KEYWORDS:
        if keyword in tokens:
            return True
        if any(
            token.startswith(keyword + '.') or token.endswith('.' + keyword)
            for token in tokens
        ):
            return True
    return False


def _is_undesirable(candidate, keywords):
    if not keywords:
        return False
    blob = f'{(candidate.url or "")} {(candidate.name or "")}'.lower()
    return any(keyword in blob for keyword in keywords)


def _quality_ceiling_index():
    try:
        return int(c.get_setting('hosts.quality') or 0)
    except (TypeError, ValueError):
        return 0


def is_debrid_source(candidate):
    '''Torrent / magnet / debrid-tagged rows (quality floor applies to these).'''
    if candidate.raw.get('debrid'):
        return True
    url = (candidate.url or '').lower()
    if url.startswith('magnet:'):
        return True
    source = (candidate.source or '').lower()
    if source in _TORRENT_SOURCES or 'torrent' in source:
        return True
    return bool(candidate.debridonly)


def filter_hevc_out(candidates, request=None):
    '''Drop HEVC/x265 rows when the user disabled HEVC in settings.'''
    return [
        cand for cand in candidates
        if not _contains_marker(_candidate_blob(cand), _HEVC_MARKERS)
    ]


def filter_debrid_only(candidates, request=None):
    '''Keep only debrid-eligible rows when debrid is configured.'''
    return [cand for cand in candidates if is_debrid_source(cand)]


def filter_quality_floor(candidates, request=None):
    '''Quality ceiling on debrid sources  -  setting is max tier, lower tiers pass too.'''
    ceiling = _quality_ceiling_index()
    allow_cams = c.get_setting('hosts.screener') == 'true'
    kept = []

    for cand in candidates:
        if is_cam_quality(cand.quality):
            if allow_cams:
                kept.append(cand)
            continue

        if not is_debrid_source(cand):
            kept.append(cand)
            continue

        tier = quality_tier(cand.quality)
        if tier is not None and tier >= ceiling:
            kept.append(cand)

    return kept


def filter_extras_out(candidates, request=None):
    return [cand for cand in candidates if not _is_extra(cand)]


def filter_undesirables_out(candidates, request=None):
    keywords = get_keywords()
    if not keywords:
        return list(candidates or [])
    return [cand for cand in candidates if not _is_undesirable(cand, keywords)]


def filter_title_match(candidates, request=None):
    '''Drop releases whose title prefix is not the requested show/movie.'''
    if request is None:
        return list(candidates or [])
    from .title_match import match_play_request, release_name_from_candidate

    kept = []
    for cand in candidates or []:
        release = release_name_from_candidate(cand)
        # No usable release name (bare magnet / hoster URL)  -  keep, don't fail-closed.
        if not release or release.startswith(('magnet:', 'http://', 'https://', 'ftp://')):
            kept.append(cand)
            continue
        if match_play_request(request, release):
            kept.append(cand)
    return kept


def _hevc_filter_active():
    return c.get_setting('HEVC') != 'true'


def _debrid_only_active():
    from ..modules import debrid as debrid_mod
    return c.get_setting('debrid.only') == 'true' and debrid_mod.status()


register_filter('dangerous', lambda: True, filter_dangerous_releases)
# Opt-in like Crew (default off)  -  always-on wiped scrapes with strict fail-closed match.
register_filter(
    'title_match',
    lambda: c.get_setting('filter.title') == 'true',
    filter_title_match,
)
register_filter('extras', lambda: c.get_setting('filter.extras') == 'true', filter_extras_out)
register_filter('undesirables', lambda: c.get_setting('filter.undesirables') == 'true', filter_undesirables_out)
register_filter('hevc', _hevc_filter_active, filter_hevc_out)
register_filter('debrid_only', _debrid_only_active, filter_debrid_only)
register_filter('quality', lambda: True, filter_quality_floor)

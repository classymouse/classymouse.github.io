# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file undesirables_defaults.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Canonical default undesirables  -  single source of truth for new installs.'''

# Domain / watermark keywords (same set as Crew 3.x DEFAULT_UNDESIRABLES).
DEFAULT_UNDESIRABLES = (
    # Tamil torrent sites
    'tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws',
    'www.tamilrockers.pl', 'www.tamilblasters.news', 'www.1tamilmv.hair',
    'www.1tamilmv.mov', '1tamilmv.press', 'www.1tamilmv.world',
    'www.tamilmv.bid', 'www.tamilmv.work',
    # MovieRulz variants
    'www.movierulz.com', 'movierulz.vpn', 'www.3movierulz.com',
    'www.3movierulz.watch', 'www.3movierulz.ws', 'www.movierulzhd.website',
    # Other foreign / spam sites
    'www.mkvcinemas.com', 'www.katmoviehd.se', 'www.torrenting.com',
    'movcr.cc', 'movcr.to', 'psarips.com',
    # Watermarks / spam
    'www.1xbet.com', 'crazy4tv.com', 'crazy4tv-com',
    'kickass.global', 'www.xbay.me',
    # Quality indicators to filter
    '(es)', '(imax)', '13+', '18+',
)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file orchestrator.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Parallel provider scrape session.'''

import threading
import time
import traceback

import xbmc

from ..modules.classy import c
from ..modules.scraper_threads import Thread
from ..modules import scraper_client
from ..play.models import PlayRequest, StreamCandidate
from .filter_pipeline import apply_stream_filters
from .filters import (
    DedupeAccumulator,
    apply_per_quality_limits,
    limit_returned_sources,
    normalize_raw_results,
)
from ..modules.debridcheck import annotate_debrid_cache, expand_debrid_sources
from .provider_filter import filter_providers
from .rank import rank_candidates
from .labels import provider_display, provider_label
from .registry import load_providers
from .scrape_dialog import ScrapeCounters, create_scrape_dialog, format_counter_line
from .source_cache import get_cached_candidates, put_cached_candidates
from . import upnext_cache

# Proceed once we have results and no new rows land (dead scrapers must not hold the dialog).
STRAGGLER_IDLE_S = 3.0
STRAGGLER_IDLE_BUSY_S = 2.0
STRAGGLER_BUSY_THRESHOLD = 25
PREEMPTIVE_LIMIT_DEFAULT = 10

# Magnets to expand / TorBox-check after rank  -  avoids 1000+ API calls pre-list.
_DEBRID_PREP_MAGNET_CAP = 200


def _quality_floor_index():
    try:
        return max(0, min(4, int(c.get_setting('hosts.quality') or 0)))
    except (TypeError, ValueError):
        return 0


def _tier_count_at_floor(snapshot, floor):
    '''Sources at or above the user quality floor.'''
    q4k, q1080, q720, qsd, total, _dups = snapshot
    if floor <= 0:
        return q4k
    if floor <= 2:
        return q4k + q1080
    if floor == 3:
        return q4k + q1080 + q720
    return total


class ScrapeSession:
    def __init__(self, request, timeout=30, show_dialog=True):
        self.request = request
        self.timeout = max(5, int(timeout or 30))
        self.show_dialog = bool(show_dialog)
        self.host_dict = {}
        self.host_pr_dict = {}
        self._dedupe = DedupeAccumulator()
        self._lock = threading.Lock()
        self._errors = []
        self._counters = None
        self._provider_labels = {}
        self._cancelled = False
        self._monitor = xbmc.Monitor()
        self._last_result_at = 0.0

    @property
    def cancelled(self):
        return self._cancelled

    def _result_count(self):
        with self._lock:
            return len(self._dedupe.items())

    def _straggler_idle_limit(self, count):
        if count >= STRAGGLER_BUSY_THRESHOLD:
            return STRAGGLER_IDLE_BUSY_S
        return STRAGGLER_IDLE_S

    def _should_exit_early(self, alive):
        if not alive:
            return False, ''
        count = self._result_count()
        if count <= 0:
            return False, ''
        idle = time.time() - self._last_result_at
        limit = self._straggler_idle_limit(count)
        if idle >= limit:
            names = [
                self._provider_labels.get(t.name, provider_display(t.name))
                for t in alive[:6]
                if getattr(t, 'name', None)
            ]
            tail = f' still running: {", ".join(names)}' if names else ''
            return True, (
                f'straggler cutoff ({count} sources, idle {idle:.1f}s >= {limit:.0f}s,{tail})'
            )
        if self._counters and self._preemptive_ready():
            return True, 'preemptive cutoff (enough sources at quality floor)'
        return False, ''

    def _preemptive_ready(self):
        enabled = str(c.get_setting('preemptive.termination') or 'true').lower()
        if enabled in ('false', '0', 'no', 'off'):
            return False
        try:
            limit = int(c.get_setting('preemptive.limit') or PREEMPTIVE_LIMIT_DEFAULT)
        except (TypeError, ValueError):
            limit = PREEMPTIVE_LIMIT_DEFAULT
        limit = max(1, limit)
        floor = _quality_floor_index()
        at_floor = _tier_count_at_floor(self._counters.snapshot(), floor)
        return at_floor >= limit

    def run(self):
        # Up Next prescrape (single-use) beats TTL source cache  -  identity is next S/E.
        upnext_hit = upnext_cache.get_candidates(self.request)
        if upnext_hit:
            c.log(
                f'[Play] Up Next cache hit -> {len(upnext_hit)} streams '
                f'(skip scrape overlay)',
            )
            return upnext_hit

        cached = get_cached_candidates(self.request)
        if cached:
            return self._finalize(cached, from_cache=True)

        providers = load_providers()
        active = filter_providers(providers, self.request)
        if not active:
            c.log('[Play] no providers matched request')
            return []

        data = self.request.to_scrape_data()
        threads = []
        started = time.time()
        scraper_client.reset_scrape_host_failures()
        c.log(
            f'[Play] scrape start {self.request.display_title!r} '
            f'providers={len(active)}/{len(providers)} timeout={self.timeout}s'
        )

        dialog = None
        self._counters = ScrapeCounters()
        self._last_result_at = started
        if self.show_dialog:
            dialog = create_scrape_dialog(
                self.request,
                self.request.display_title,
                len(active),
                self.timeout,
            )
            dialog.open()

        for name, provider in active:
            self._provider_labels[name] = provider_label(name, provider)
            thread = Thread(self._scrape_one, name, provider, data)
            thread.name = name
            thread.start()
            threads.append(thread)

        deadline = started + self.timeout
        handoff_dialog = None
        try:
            while time.time() < deadline:
                if self._monitor.abortRequested():
                    self._cancelled = True
                    c.log('[Play] scrape cancelled (Kodi abort)')
                    break
                alive = [t for t in threads if t.is_alive()]
                if not alive:
                    break
                if dialog:
                    alive_labels = [
                        self._provider_labels.get(t.name, provider_display(t.name))
                        for t in alive
                        if getattr(t, 'name', None)
                    ]
                    dialog.tick(self._counters, alive_labels)
                    if dialog.cancelled:
                        self._cancelled = True
                        c.log('[Play] scrape cancelled by user')
                        break
                should_exit, reason = self._should_exit_early(alive)
                if should_exit:
                    c.log(f'[Play] {reason}')
                    break
                time.sleep(0.2)
        finally:
            if dialog:
                if self._counters:
                    try:
                        dialog.tick(self._counters, [])
                    except Exception:
                        pass
                if self._cancelled:
                    if getattr(dialog, 'persistent', False):
                        try:
                            dialog.close_overlay()
                        except Exception:
                            dialog.close()
                    else:
                        dialog.close()
                else:
                    handoff_dialog = dialog

        scraper_client.scrape_host_failure_summary()

        if not self._cancelled:
            for thread in threads:
                thread.join(timeout=0.5)

        if self._cancelled:
            elapsed = time.time() - started
            c.log(f'[Play] scrape aborted after {elapsed:.1f}s (discarding partial results)')
            return []

        elapsed = time.time() - started
        deduped = self._dedupe.items()
        if deduped:
            put_cached_candidates(self.request, deduped)
        return self._finalize(
            deduped,
            from_cache=False,
            elapsed=elapsed,
            provider_count=len(active),
            dialog=handoff_dialog,
        )

    def _status_dialog(self, dialog, percent, status_line, *, counters=True):
        if not dialog:
            return
        if counters and self._counters:
            line1 = format_counter_line(self._counters.snapshot())
            dialog._update(percent, line1, status_line)
        else:
            dialog._update(percent, status_line)

    def _finalize(self, deduped, from_cache=False, elapsed=0.0, provider_count=0, dialog=None):
        prep_dialog = dialog
        try:
            if self.show_dialog and not from_cache:
                if prep_dialog is None:
                    prep_dialog = create_scrape_dialog(
                        self.request,
                        self.request.display_title,
                        1,
                        30,
                    )
                    prep_dialog.open()
                self._status_dialog(
                    prep_dialog,
                    55,
                    '[COLOR orchid]Preparing sources...[/COLOR]',
                )

            ranked = rank_candidates(apply_stream_filters(deduped, self.request))
            # Cap per quality band on magnets first (before debrid expand / top-N
            # prep). Post-expand the same limit would collapse 800 4K clones to 3.
            ranked = apply_per_quality_limits(ranked)
            trimmed = _cap_magnets_for_debrid(ranked, _DEBRID_PREP_MAGNET_CAP)
            self._status_dialog(
                prep_dialog,
                75,
                '[COLOR orchid]Checking debrid cache...[/COLOR]',
            )
            expanded = expand_debrid_sources(trimmed)
            labeled = annotate_debrid_cache(expanded)
            ranked = limit_returned_sources(rank_candidates(labeled))
        finally:
            if prep_dialog:
                prep_dialog.close()

        if from_cache:
            c.log(f'[Play] cache hit -> {len(ranked)} streams ({len(deduped)} raw)')
        else:
            err_n = len(self._errors)
            c.log(
                f'[Play] scrape done {len(ranked)} streams from '
                f'{provider_count} providers in {elapsed:.1f}s errors={err_n}'
            )
            if err_n and not ranked:
                sample = ', '.join(
                    f'{name}:{(msg or "")[:40]}' for name, msg in self._errors[:5]
                )
                c.log(
                    f'[Play] 0 streams with {err_n} provider failure(s)  -  {sample}',
                    1,
                )
            elif err_n:
                c.log(
                    f'[Play] {err_n} provider failure(s) while returning '
                    f'{len(ranked)} stream(s)',
                    2,
                )
        return ranked

    def _scrape_one(self, name, provider, data):
        started = time.time()
        try:
            if self._cancelled:
                return
            raw = _call_sources(provider, data, self.host_dict, self.host_pr_dict)
            if self._cancelled:
                return
            items = normalize_raw_results(raw, provider_name=name)
            if items:
                with self._lock:
                    if self._cancelled:
                        return
                    new_rows, batch_dups = self._dedupe.extend(items)
                    self._last_result_at = time.time()
                if self._counters:
                    if new_rows:
                        self._counters.add(new_rows)
                    if batch_dups:
                        self._counters.add_duplicates(batch_dups)
                c.log(
                    f'[Play] {name} -> {len(items)} '
                    f'(+{len(new_rows)} unique, -{batch_dups} dup) '
                    f'({time.time() - started:.1f}s)'
                )
            else:
                c.log(f'[Play] {name} -> 0 ({time.time() - started:.1f}s)', 2)
        except Exception as exc:
            with self._lock:
                self._errors.append((name, str(exc)))
            c.log(f'[Play] {name} failed: {exc}', 1)
            if c.devmode:
                c.log(traceback.format_exc(), 1)


def _call_sources(provider, data, host_dict, host_pr_dict):
    '''Invoke provider.sources with arity fallbacks.

    TypeError retries with fewer args. Other exceptions propagate so the
    scrape session can record a provider failure (distinct from 0 results).
    '''
    attempts = (
        (data, host_dict, host_pr_dict),
        (data, host_dict),
        (data,),
    )
    last_type_error = None
    for args in attempts:
        try:
            result = provider.sources(*args)
            if result is None:
                return []
            return result
        except TypeError as exc:
            last_type_error = exc
            continue
    if last_type_error is not None:
        raise last_type_error
    return []


def _is_magnet_candidate(cand):
    url = (getattr(cand, 'url', '') or '').strip()
    return url.startswith('magnet:') or bool(getattr(cand, 'debridonly', False))


def _cap_magnets_for_debrid(candidates, max_magnets):
    '''Keep top-ranked rows; cap unique magnets before debrid expand/API checks.'''
    if not candidates or max_magnets <= 0:
        return list(candidates or [])

    kept = []
    magnet_hashes = set()
    magnets_kept = 0
    for cand in candidates:
        if not _is_magnet_candidate(cand):
            kept.append(cand)
            continue
        info_hash = ''
        try:
            from .filters import _magnet_hash
            info_hash = _magnet_hash(cand)
        except Exception:
            pass
        if info_hash and info_hash in magnet_hashes:
            kept.append(cand)
            continue
        if magnets_kept >= max_magnets:
            continue
        if info_hash:
            magnet_hashes.add(info_hash)
        magnets_kept += 1
        kept.append(cand)

    dropped = len(candidates) - len(kept)
    if dropped:
        c.log(
            f'[Play] debrid prep: kept {magnets_kept} magnets '
            f'({len(kept)} rows, dropped {dropped} lower-ranked)'
        )
    return kept


def scrape_streams(request, timeout=30, show_dialog=True):
    if not isinstance(request, PlayRequest):
        raise TypeError('request must be PlayRequest')
    session = ScrapeSession(request, timeout=timeout, show_dialog=show_dialog)
    candidates = session.run()
    return candidates, session.cancelled

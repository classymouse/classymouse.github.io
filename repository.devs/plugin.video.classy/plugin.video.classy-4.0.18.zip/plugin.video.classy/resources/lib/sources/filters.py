# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file filters.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Post-scrape normalization and deduplication.'''

import json
import re

from ..play.models import StreamCandidate

_BTIH_RE = re.compile(r'btih:([0-9a-fA-F]{40})', re.I)


def normalize_raw_results(raw_list, provider_name=''):
    out = []
    for item in raw_list or []:
        if isinstance(item, (bytes, str)):
            try:
                item = json.loads(item)
            except Exception:
                continue
        if not isinstance(item, dict):
            continue
        # Prefer registry key so pack tags ([Classy]/[Gears], ...) survive labeling.
        # Keep the scraper's own provider leaf (e.g. Diamond's "Torrentio" / "AioStreams")
        # as scraper_name for display.
        if provider_name:
            item = dict(item)
            orig = str(item.get('provider') or '').strip()
            item['provider'] = provider_name
            if orig and orig.lower() not in provider_name.lower():
                item['scraper_name'] = orig
        candidate = StreamCandidate.from_raw(item, provider=provider_name)
        if candidate:
            out.append(candidate)
    return out


def _magnet_hash(candidate):
    h = (candidate.hash or '').strip().lower()
    if len(h) == 40:
        return h
    url = candidate.url or ''
    if url.startswith('magnet:'):
        match = _BTIH_RE.search(url)
        if match:
            return match.group(1).lower()
    return ''


def _remove_dups_enabled():
    from ..modules.classy import c

    val = str(c.get_setting('remove.dups') or 'true').lower()
    return val not in ('false', '0', 'no', 'off')


class DedupeAccumulator:
    '''Incremental magnet/host dedupe  -  same rules as dedupe_candidates().'''

    def __init__(self):
        self.enabled = _remove_dups_enabled()
        self._best_by_hash = {}
        self._hash_order = []
        self._seen_keys = set()
        self._unique = []
        self._passthrough = []
        self.duplicates_removed = 0

    def extend(self, items):
        '''Add candidates; return (new_unique_rows, batch_duplicates_removed).'''
        batch = list(items or [])
        if not batch:
            return [], 0
        if not self.enabled:
            self._passthrough.extend(batch)
            return batch, 0

        new_rows = []
        batch_dups = 0
        for cand in batch:
            status = self._add_one(cand)
            if status == 'new':
                new_rows.append(cand)
            else:
                batch_dups += 1
        self.duplicates_removed += batch_dups
        return new_rows, batch_dups

    def items(self):
        if not self.enabled:
            return list(self._passthrough)
        return [self._best_by_hash[h] for h in self._hash_order] + list(self._unique)

    @property
    def unique_magnet_count(self):
        return len(self._hash_order)

    def _add_one(self, cand):
        info_hash = _magnet_hash(cand)
        if info_hash:
            prev = self._best_by_hash.get(info_hash)
            if prev is None:
                self._best_by_hash[info_hash] = cand
                self._hash_order.append(info_hash)
                return 'new'
            if (cand.seeders or 0) > (prev.seeders or 0):
                self._best_by_hash[info_hash] = cand
            return 'dup'

        url = cand.url or ''
        key_url = url[:60] if url.startswith('magnet:') else url
        key = f'{cand.provider}|{cand.name}|{key_url}'
        if key in self._seen_keys:
            return 'dup'
        self._seen_keys.add(key)
        self._unique.append(cand)
        return 'new'


def dedupe_candidates(candidates, notify=False):
    '''Drop duplicate magnets (same btih across packs) and duplicate host links.'''
    from ..modules.classy import c

    items = list(candidates or [])
    if not items:
        return []

    acc = DedupeAccumulator()
    acc.extend(items)
    out = acc.items()
    removed = acc.duplicates_removed
    if acc.enabled:
        c.log(
            f'[Sources] dedupe: {len(items)} -> {len(out)} '
            f'(-{removed}, {acc.unique_magnet_count} unique magnets)'
        )
    elif c.devmode:
        c.log(f'[Sources] dedupe: skipped ({len(items)} rows, remove.dups off)')
    if notify and removed:
        try:
            c.infoDialog(c.lang(32089).format(removed), time=4000)
        except Exception:
            pass
    return out


def _quality_band(quality):
    '''Bucket label for per-quality caps (4K / 1440p / 1080p / 720p / SD / CAM).'''
    from .quality_tiers import CAM_QUALITIES, QUALITY_FLOOR_LABELS, quality_tier

    q = str(quality or '').strip().lower()
    if q in CAM_QUALITIES:
        return 'CAM'
    tier = quality_tier(quality)
    if tier is None:
        return 'CAM'
    if 0 <= tier < len(QUALITY_FLOOR_LABELS):
        return QUALITY_FLOOR_LABELS[tier]
    return 'SD'


def apply_per_quality_limits(candidates, limit_per_quality=None):
    '''Keep at most N rows per quality band (0 / unset = unlimited).

    Run on pre-expand magnet rows so a limit of 3 means 3x4K + 3x1080p + ...
    Applying after debrid expand collapses the whole list to N (every clone
    shares the same band).
    '''
    from ..modules.classy import c

    if limit_per_quality is None:
        try:
            limit_per_quality = int(c.get_setting('results.per_quality_limit') or 0)
        except (TypeError, ValueError):
            limit_per_quality = 0
    if not limit_per_quality or limit_per_quality <= 0:
        return list(candidates or [])

    counts = {}
    out = []
    for cand in candidates or []:
        band = _quality_band(getattr(cand, 'quality', None))
        used = counts.get(band, 0)
        if used < limit_per_quality:
            out.append(cand)
            counts[band] = used + 1
        else:
            counts[band] = used + 1
    removed = len(candidates or []) - len(out)
    if removed > 0:
        kept_summary = ', '.join(
            f'{band}:{min(total, limit_per_quality)}/{total}'
            for band, total in sorted(counts.items())
        )
        c.log(
            f'[Sources] per-quality limit {limit_per_quality}: '
            f'{len(candidates)} -> {len(out)} (-{removed}) [{kept_summary}]'
        )
    return out


def limit_returned_sources(candidates):
    '''Cap list length after rank  -  ``returned.sources`` setting (default 100).'''
    from ..modules.classy import c

    try:
        limit = int(c.get_setting('returned.sources') or 100)
    except (TypeError, ValueError):
        limit = 100
    limit = max(1, min(1000, limit))
    out = list(candidates or [])[:limit]
    if len(candidates or []) > len(out):
        c.log(f'[Sources] returned limit {limit} ({len(candidates)} -> {len(out)})')
    return out

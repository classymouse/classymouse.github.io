# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file provider_filter.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Select providers that can handle the current PlayRequest.'''

from ..modules.classy import c
from ..play.models import PlayRequest


def filter_providers(provider_list, request):
    if not provider_list:
        return []
    if not isinstance(request, PlayRequest):
        return list(provider_list)

    content = 'episode' if request.is_episode else 'movie'
    filtered = []
    rejected = []

    for name, obj in provider_list:
        try:
            if getattr(obj, 'defunct', False):
                rejected.append((name, 'defunct'))
                continue
            if _supports_content(name, obj, content):
                filtered.append((name, obj))
            else:
                rejected.append((name, f'no {content} support'))
        except Exception as exc:
            c.log(f'[Sources] provider inspect failed {name}: {exc}', 1)

    if c.devmode and rejected:
        c.log(f'[Sources] providers rejected ({len(rejected)}): {rejected[:12]}')
    c.log(f'[Sources] providers for {content}: {len(filtered)}/{len(provider_list)}')
    return filtered


def _supports_content(name, obj, content):
    prefix = name.split('.')[0] if isinstance(name, str) else ''

    # External packs declare hasMovies/hasEpisodes; internal scrapers use movie/tvshow.
    if content == 'movie':
        if prefix in ('classyscrapers', 'cocoscrapers', 'gearsscrapers', 'magneto', 'viperscrapers'):
            return bool(getattr(obj, 'hasMovies', False) or getattr(obj, 'sources', None))
        return bool(getattr(obj, 'movie', None) or getattr(obj, 'sources', None))

    if prefix in ('classyscrapers', 'cocoscrapers', 'gearsscrapers', 'magneto', 'viperscrapers'):
        return bool(getattr(obj, 'hasEpisodes', False) or getattr(obj, 'sources', None))
    return bool(getattr(obj, 'tvshow', None) or getattr(obj, 'sources', None))

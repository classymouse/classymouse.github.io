# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file labels.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Classy source row labels - scan line + optional release name.'''

import re
from urllib.parse import parse_qs, unquote, urlparse

from ..modules import debrid_names
from ..modules.classy import c

_DOT = '  |  '

_QUALITY_COLOR = (
    ('4k', 'gold'), ('2160', 'gold'), ('uhd', 'gold'),
    ('1440', 'yellow'),
    ('1080', 'lime'),
    ('720', 'deepskyblue'), ('hd', 'deepskyblue'),
    ('480', 'gray'), ('sd', 'gray'),
    ('cam', 'orange'), ('scr', 'orange'), ('tele', 'orange'),
)

# Order for info chips on line 1 (after quality / provider / debrid).
_TAG_RANK = {
    'Remux': 10, 'Web': 11, 'Blu-ray': 12, 'HDTV': 13,
    'HEVC': 20, 'H.264': 21, 'AV1': 22,
    'DV': 30, 'HDR': 31,
    'Atmos': 40, 'TrueHD': 41, 'DTS-HD MA': 42, 'DD+': 43, 'DD': 44, 'DTS': 45, 'AAC': 46, '5.1': 47,
}

_SIZE_RE = re.compile(r'^[\d.,]+\s*(?:GB|GiB|MB|MiB)$', re.I)


def _compact_on():
    return c.get_setting('sources.compact') == 'true'


def _extrainfo_on():
    # Default on when unset (Crew parity).
    raw = c.get_setting('sources.extrainfo')
    if raw in (None, ''):
        return True
    return str(raw).lower() == 'true'


def build_list_label(candidate, index=0):
    '''Directory label for one stream row (supports \\n when multiline setting is on).'''
    compact = _compact_on()
    multiline = (not compact) and c.get_setting('sourcelist.multiline') == 'true'
    filename_on_line2 = (not compact) and c.get_setting('sources.pack.name') == 'true'
    head = _line1(candidate, index)
    name = _release_name(candidate) if filename_on_line2 else ''

    if multiline:
        if name:
            return f'{head}\n[COLOR grey][I]{name}[/I][/COLOR]'
        return head

    if name:
        return f'{head} - {name}'
    return head


def build_select_rows(candidate, index=0):
    '''
    Kodi Dialog.select row - (title, detail) tuple for useDetails mode.

    Built-in select dialogs use a fixed row height; \\n in labels gets clipped.
    useDetails=True gives a proper second line with taller rows.
    '''
    head = _line1(candidate, index)
    show_name = (not _compact_on()) and c.get_setting('sources.pack.name') == 'true'
    detail = _release_name(candidate) if show_name else ''
    return head, detail


def _line1(candidate, index):
    '''Scan row: index  |  debrid  |  quality  |  provider  |  size  |  cache  |  tags...'''
    idx = f'{int(index) + 1:02d}'
    quality = _quality_coloured(candidate.quality)
    head = [idx]

    debrid = _debrid_short(candidate)
    if debrid:
        head.append(f'[COLOR orchid]{debrid}[/COLOR]')
    head.append(quality)

    # Pick signals first: who found it, how big, then cache  -  codecs after.
    tail = []
    raw = candidate.raw or {}
    short = raw.get('scraper_name') or raw.get('diamond_source')
    provider = provider_display(candidate.provider, short_name=short)
    if provider:
        tail.append(provider)

    size = _size_text(candidate)
    if size:
        tail.append(size)

    source_chip = _source_type_chip(candidate)
    if source_chip:
        tail.append(source_chip)

    if _extrainfo_on():
        chip_limit = 3 if _compact_on() else 6
        tail.extend(_info_chips(candidate, limit=chip_limit, include_size=False))
    if not tail:
        return _DOT.join(head)
    return f'{_DOT.join(head)}{_DOT}[COLOR blue]{"  |  ".join(tail)}[/COLOR]'


def _info_chips(candidate, limit=6, include_size=True):
    '''Valuable parsed tokens for line 1 - size (optional), codec, HDR, audio.'''
    ranked = []
    seen = set()

    def add(label, rank=60):
        key = str(label or '').lower()
        if not label or key in seen:
            return
        seen.add(key)
        ranked.append((rank, label))

    size = _size_text(candidate)
    if include_size and size:
        add(size, rank=5)

    name = _release_name(candidate)
    for tag in _parse_release_tags(name):
        add(tag, rank=_TAG_RANK.get(tag, 60))

    for token in _info_tokens(candidate):
        if size and token.lower() == size.lower():
            continue
        add(token, rank=55)

    ranked.sort(key=lambda item: item[0])
    return [label for _, label in ranked[:limit]]


def _quality_coloured(quality):
    q = str(quality or 'SD').strip()
    q_lower = q.lower()
    for token, color in _QUALITY_COLOR:
        if token in q_lower:
            return f'[COLOR {color}]{q.upper()}[/COLOR]'
    return q.upper()


# Internal scrapers only  -  external packs use scraper_packs.json ``tag``.
_INTERNAL_PREFIXES = (
    ('resources.lib.scrapers.orion', '[Orion]'),
    ('resources.lib.scrapers.', '[Crew]'),
)


def _pack_prefixes():
    try:
        from . import scraper_packs
        return tuple(scraper_packs.pack_tag_prefixes()) + _INTERNAL_PREFIXES
    except Exception:
        return _INTERNAL_PREFIXES


def _short_scraper_name(provider, short_name=None):
    '''Human scraper leaf - optional scraper's ``.name``, else last path segment.'''
    if short_name:
        text = str(short_name).strip()
        if text:
            return text
    name = str(provider or '').replace('\\', '/').split('/')[-1]
    if name.lower().endswith('.py'):
        name = name[:-3]
    # cocoscrapers.torrents_mediafusion  ->  mediafusion
    if '_' in name and '.' in str(provider or ''):
        leaf = name.split('_', 1)[-1]
    else:
        leaf = name.split('.')[-1]
    leaf = leaf.replace('_', ' ').strip()
    if not leaf:
        return ''
    return leaf[0].upper() + leaf[1:]


def provider_display(provider, short_name=None):
    '''Display name with pack tag when registry key is pack-qualified.'''
    if not provider and not short_name:
        return ''
    key = str(provider or '').strip()
    key_lower = key.lower()
    scraper = _short_scraper_name(key, short_name=short_name)
    if not scraper and not key:
        return ''

    for prefix, tag in _pack_prefixes():
        if key_lower.startswith(prefix):
            return f'{tag} {scraper}' if scraper else tag

    return scraper or key


def provider_label(registry_key, provider=None):
    '''Progress-dialog label - pack prefix from registry key + scraper name.'''
    short = getattr(provider, 'name', None) if provider is not None else None
    return provider_display(registry_key, short_name=short)


def _debrid_short(candidate):
    raw = candidate.raw or {}
    debrid = raw.get('debrid') or ''
    if not debrid:
        return ''
    return debrid_names.short_code(debrid)


def _source_type_chip(candidate):
    source = str(candidate.source or (candidate.raw or {}).get('source') or '').strip().lower()
    if source == 'cached torrent':
        return '[COLOR lime]CACHED[/COLOR]'
    if source == 'uncached torrent':
        return '[COLOR orange]UNCACHED[/COLOR]'
    if source == 'unknown torrent':
        return '[COLOR skyblue]UNKNOWN[/COLOR]'
    if source == 'torrent':
        # Cache check off (or hoster path): plain TORRENT. When check is on,
        # unlabeled magnets are stamped unknown torrent in debridcheck.
        return 'TORRENT'
    if source == 'magnet':
        return 'MAGNET'
    if source == 'pack':
        return 'PACK'
    return ''


def _release_name(candidate):
    name = (candidate.name or '').strip()
    if name:
        return name
    url = candidate.url or ''
    if url.startswith('magnet:'):
        try:
            params = parse_qs(urlparse(url).query)
            dn = (params.get('dn') or [''])[0]
            if dn:
                return unquote(dn).replace('+', ' ').strip()
        except Exception:
            pass
    return ''


def _size_text(candidate):
    try:
        gb = float(candidate.size or 0)
    except (TypeError, ValueError):
        gb = 0.0
    if gb > 0:
        return f'{gb:.2f} GB'
    for token in _info_tokens(candidate):
        if _SIZE_RE.match(token):
            return token
    return ''


def _info_tokens(candidate):
    raw = candidate.info or ''
    if isinstance(raw, list):
        parts = [str(x).strip() for x in raw if str(x).strip()]
    else:
        parts = [p.strip() for p in str(raw).split('|') if p.strip()]
    if parts and _SIZE_RE.match(parts[0]):
        parts = parts[1:]
    return parts


def _parse_release_tags(name):
    '''Container / codec / HDR / audio from release name.'''
    if not name:
        return []
    blob = re.sub(r'[^a-z0-9]+', ' ', str(name).lower())
    blob = f' {blob} '
    tags = []
    seen = set()

    def _add(label):
        key = label.lower()
        if key not in seen:
            tags.append(label)
            seen.add(key)

    rules = (
        ((' remux ',), 'Remux'),
        ((' webdl ', ' web dl ', ' webrip ', ' web rip '), 'Web'),
        ((' bluray ', ' blu ray ', ' bdrip ', ' brrip '), 'Blu-ray'),
        ((' hdtv ',), 'HDTV'),
        ((' x265 ', ' h265 ', ' hevc '), 'HEVC'),
        ((' x264 ', ' h264 ', ' avc '), 'H.264'),
        ((' av1 ',), 'AV1'),
        ((' dolby vision ',), 'DV'),
        ((' hdr10plus ', ' hdr10 ', ' hdr '), 'HDR'),
        ((' atmos ',), 'Atmos'),
        ((' truehd ',), 'TrueHD'),
        ((' dts hd ma ', ' hd ma '), 'DTS-HD MA'),
        ((' eac3 ', ' ddplus ', ' dd+ '), 'DD+'),
        ((' dts ',), 'DTS'),
        ((' ac3 ',), 'DD'),
        ((' aac ',), 'AAC'),
        ((' 5 1 ',), '5.1'),
    )
    for needles, label in rules:
        if any(n in blob for n in needles):
            _add(label)
    return tags

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scrape_timeout.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Scraper timeout from settings or play URL params.'''

from ..modules.classy import c


def resolve_timeout(params=None, fallback=30):
    if params:
        raw = (params or {}).get('timeout')
        if raw not in (None, ''):
            try:
                return max(5, int(raw))
            except (TypeError, ValueError):
                pass
    try:
        return max(5, int(c.get_setting('scrapers.timeout.1') or fallback))
    except (TypeError, ValueError):
        return max(5, int(fallback or 30))

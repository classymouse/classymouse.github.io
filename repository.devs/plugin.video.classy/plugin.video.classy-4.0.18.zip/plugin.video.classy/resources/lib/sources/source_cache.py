# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file source_cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Scrape result cache  -  skip re-scraping the same title within TTL.'''

import json
import os
import sqlite3
import time

import xbmcaddon
import xbmcvfs

from ..modules.classy import c
from ..play.models import PlayRequest, StreamCandidate


def cache_enabled():
    setting = c.get_setting('sources.cache.enabled')
    if setting is None or setting == '':
        return True
    return setting == 'true'


def _duration_seconds():
    try:
        minutes = int(c.get_setting('sources.cache.duration') or 15)
    except (TypeError, ValueError):
        minutes = 15
    return max(1, minutes) * 60


def _db_path():
    profile = xbmcaddon.Addon().getAddonInfo('profile')
    return os.path.join(xbmcvfs.translatePath(profile), 'source_cache.db')


def _connect():
    path = _db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0)
    return conn


def _ensure_schema(cur):
    cur.execute('''
        CREATE TABLE IF NOT EXISTS source_cache (
            cache_key TEXT PRIMARY KEY,
            imdb_id TEXT,
            tmdb_id TEXT,
            season TEXT,
            episode TEXT,
            sources_json TEXT,
            cached_at INTEGER
        )
    ''')


def cache_key(request):
    imdb = str(request.imdb or '').strip()
    tmdb = str(request.tmdb or '').strip()
    if request.is_episode and request.season and request.episode:
        return f'sources_{imdb}_{tmdb}_s{request.season}e{request.episode}'
    return f'sources_{imdb}_{tmdb}_movie'


def get_cached_candidates(request):
    '''Return deduped cached candidates, or None on miss/expiry.'''
    if not cache_enabled() or not isinstance(request, PlayRequest):
        return None

    key = cache_key(request)
    now = int(time.time())
    ttl = _duration_seconds()

    try:
        conn = _connect()
        cur = conn.cursor()
        _ensure_schema(cur)
        row = cur.execute(
            'SELECT sources_json, cached_at FROM source_cache WHERE cache_key = ?',
            (key,),
        ).fetchone()
        conn.close()
        if not row:
            c.log(f'[SourceCache] MISS {key}')
            return None

        sources_json, cached_at = row
        age = now - int(cached_at or 0)
        if age >= ttl:
            c.log(f'[SourceCache] EXPIRED {key} age={age}s ttl={ttl}s')
            return None

        payload = json.loads(sources_json or '[]')
        if not isinstance(payload, list):
            return None

        out = []
        for item in payload:
            cand = StreamCandidate.from_dict(item)
            if cand:
                out.append(cand)
        c.log(f'[SourceCache] HIT {key} {len(out)} rows age={age}s')
        return out or None
    except Exception as exc:
        c.log(f'[SourceCache] read failed: {exc}', 1)
        return None


def put_cached_candidates(request, candidates):
    '''Store deduped pre-filter candidates.'''
    if not cache_enabled() or not candidates:
        return

    key = cache_key(request)
    payload = [cand.to_dict() for cand in candidates]
    try:
        body = json.dumps(payload, default=str)
    except Exception as exc:
        c.log(f'[SourceCache] serialize failed: {exc}', 1)
        return

    try:
        conn = _connect()
        cur = conn.cursor()
        _ensure_schema(cur)
        cur.execute(
            '''INSERT OR REPLACE INTO source_cache
               (cache_key, imdb_id, tmdb_id, season, episode, sources_json, cached_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (
                key,
                str(request.imdb or ''),
                str(request.tmdb or ''),
                str(request.season or '') if request.is_episode else '',
                str(request.episode or '') if request.is_episode else '',
                body,
                int(time.time()),
            ),
        )
        conn.commit()
        conn.close()
        c.log(f'[SourceCache] stored {key} ({len(payload)} rows)')
    except Exception as exc:
        c.log(f'[SourceCache] write failed: {exc}', 1)


def clear_all():
    '''Drop all scrape-result rows (source_cache.db).'''
    path = _db_path()
    if not path or not xbmcvfs.exists(path):
        return True
    try:
        conn = _connect()
        cur = conn.cursor()
        cur.execute('DELETE FROM source_cache')
        conn.commit()
        conn.close()
        c.log('[SourceCache] cleared all scrape results')
        try:
            from . import upnext_cache
            upnext_cache.clear_all()
        except Exception:
            pass
        return True
    except Exception as exc:
        c.log(f'[SourceCache] clear_all failed: {exc}', 1)
        return False

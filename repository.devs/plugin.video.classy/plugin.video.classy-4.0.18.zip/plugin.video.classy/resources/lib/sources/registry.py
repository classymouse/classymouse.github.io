# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file registry.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Provider registry  -  load scraper modules from dirs and external packs.'''

import importlib.util
import os
import sys
import traceback

from ..modules.crewruntime import c
from ..modules.pack_client import install_pack_client_shims
from ..modules.pack_cfscrape import get_cfscrape


def find_addons_dir(start_path=None):
    cur = start_path or os.path.dirname(__file__)
    for _ in range(8):
        if os.path.basename(cur).lower() == 'addons':
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None


def _load_sources_from_dir(src_dir, prefix=None):
    results = []
    if not os.path.isdir(src_dir):
        return results

    parent_dir = os.path.dirname(src_dir)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)

    for fname in os.listdir(src_dir):
        if not fname.endswith('.py') or fname == '__init__.py':
            continue

        module_basename = os.path.splitext(fname)[0]
        if module_basename == 'orion':
            continue
        load_name = f'{prefix}.{module_basename}' if prefix else module_basename
        path = os.path.join(src_dir, fname)

        try:
            spec = importlib.util.spec_from_file_location(load_name, path)
            if spec is None or spec.loader is None:
                c.log(f'Could not load spec for "{path}": spec or loader is None', 1)
                continue
            module = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(module)
            except AttributeError:
                if hasattr(spec.loader, 'load_module'):
                    try:
                        module = spec.loader.load_module(load_name)
                    except Exception as exc:
                        c.log(f'Could not load module "{path}" via load_module: {exc}', 1)
                        continue
                else:
                    c.log(f'Loader for "{path}" does not support exec_module or load_module', 1)
                    continue

            source_name = f'{prefix}.{module_basename}' if prefix else module_basename
            try:
                cfscrape_mod = get_cfscrape()
                if cfscrape_mod is not None and not hasattr(module, 'cfscrape'):
                    setattr(module, 'cfscrape', cfscrape_mod)
            except Exception:
                pass

            if hasattr(module, 'source') and callable(getattr(module, 'source')):
                try:
                    results.append((source_name, module.source()))
                except Exception as exc:
                    c.log(f'[Sources] Failed to instantiate source "{source_name}": {exc}', 1)
            else:
                c.log(f'[Sources] Skipping non-source module: {source_name}', 2)
        except Exception as exc:
            c.log(f'[Sources] Failed to load module "{path}": {exc}', 1)
            c.log(f'[Sources] Traceback: {traceback.format_exc()}', 1)
    return results


def load_providers():
    '''Load internal scrapers plus curated external packs from scraper_packs.json.'''
    from . import pack_loader
    from . import scraper_packs
    from .providers import internal
    from .providers import orion as orion_provider

    providers = []

    try:
        install_pack_client_shims()
    except Exception as exc:
        c.log(f'[Sources] Pack client shim install failed: {exc}', 1)

    providers.extend(internal.load(_load_sources_from_dir))
    providers.extend(orion_provider.load(_load_sources_from_dir))

    addons_dir = find_addons_dir()
    for pack in scraper_packs.list_packs():
        try:
            providers.extend(pack_loader.load_pack(pack, _load_sources_from_dir, addons_dir))
        except Exception as exc:
            pid = pack.get('id') or pack.get('label') or '?'
            c.log(f'[Sources] Pack load failed ({pid}): {exc}', 1)
            c.log(f'[Sources] Traceback: {traceback.format_exc()}', 1)

    _log_provider_breakdown(providers)
    return providers


def _log_provider_breakdown(providers):
    from . import scraper_packs

    buckets = {'internal': 0, 'other': 0}
    for pack in scraper_packs.list_packs():
        buckets[pack.get('id') or 'other'] = 0

    for name, _ in providers:
        if name.startswith('resources.lib.scrapers'):
            buckets['internal'] += 1
            continue
        matched = False
        for pack in scraper_packs.list_packs():
            prefix = pack.get('prefix') or ''
            pid = pack.get('id') or ''
            if prefix and name.startswith(prefix):
                buckets[pid] = buckets.get(pid, 0) + 1
                matched = True
                break
        if not matched:
            buckets['other'] += 1

    try:
        parts = [f'internal={buckets.get("internal", 0)}']
        for pack in scraper_packs.list_packs():
            pid = pack.get('id') or ''
            parts.append(f'{pid}={buckets.get(pid, 0)}')
        if buckets.get('other'):
            parts.append(f'other={buckets["other"]}')
        c.log(f'[Sources] Final total scrapers loaded: {len(providers)} ({", ".join(parts)})')
    except Exception:
        c.log(f'[Sources] Final total scrapers loaded: {len(providers)}', 1)

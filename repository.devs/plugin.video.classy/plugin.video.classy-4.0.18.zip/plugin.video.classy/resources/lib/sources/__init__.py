# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Provider registry entry point.

load_providers()  -  canonical API for the play path.
sources()  -  backward-compatible alias (Crew 3.x name).'''

from .registry import load_providers

__all__ = ['load_providers', 'sources']


def sources():
    return load_providers()

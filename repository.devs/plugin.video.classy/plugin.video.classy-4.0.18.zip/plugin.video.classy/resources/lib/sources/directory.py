# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file directory.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Directory source list  -  stash scrape results and open addon listing.'''

import json
import sys
from urllib.parse import quote_plus

import xbmc
import xbmcgui

from ..modules import kodi
from ..modules.classy import c
from ..play.models import PlayRequest, StreamCandidate
from .labels import build_list_label

PROP_CANDIDATES = 'classy.sources.candidates'
PROP_REQUEST = 'classy.sources.request'
# Pre-sourceList folder (season/episodes)  -  A1c/A1d origin collapse.
PROP_ORIGIN_FOLDER = 'thecrew.sources.origin_folder'


def _window():
    return xbmcgui.Window(10000)


def stash_origin_folder(path=None):
    '''Remember the Videos folder that opened sourceList.'''
    try:
        folder = (path or xbmc.getInfoLabel('Container.FolderPath') or '').strip()
    except Exception:
        folder = ''
    if not folder:
        return
    addon_id = (c.addon_id or '').strip().lower()
    folder_l = folder.lower()
    if addon_id and f'plugin://{addon_id}' not in folder_l:
        return
    if 'action=sourcelist' in folder_l:
        return
    try:
        _window().setProperty(PROP_ORIGIN_FOLDER, folder)
    except Exception:
        pass


def load_origin_folder():
    try:
        return _window().getProperty(PROP_ORIGIN_FOLDER) or ''
    except Exception:
        return ''


def clear_origin_folder():
    try:
        _window().clearProperty(PROP_ORIGIN_FOLDER)
    except Exception:
        pass


def collapse_to_origin(*, reason='', only_if_sourcelist=True):
    '''Replace current Videos folder with stashed origin (A1c/A1d).

    Safe under fullscreen playback  -  only the plugin container path changes.
    Returns True when an Update was issued.
    '''
    origin = (load_origin_folder() or '').strip()
    if not origin:
        return False
    try:
        folder = (xbmc.getInfoLabel('Container.FolderPath') or '').strip().lower()
    except Exception:
        folder = ''
    if only_if_sourcelist and 'action=sourcelist' not in folder:
        return False
    try:
        xbmc.executebuiltin(f'Container.Update({origin},replace)')
        c.log(f'[Sources] origin collapse ({reason or "?"})')
        return True
    except Exception as exc:
        c.log(f'[Sources] origin collapse failed: {exc}', 1)
        return False




def stash_session(candidates, request):
    payload = [cand.to_dict() for cand in (candidates or [])]
    req = {
        'mediatype': request.mediatype,
        'title': request.title,
        'year': request.year,
        'imdb': request.imdb,
        'tmdb': request.tmdb,
        'tvdb': request.tvdb,
        'trakt': request.trakt,
        'season': request.season,
        'episode': request.episode,
        'tvshowtitle': request.tvshowtitle,
        'localtvshowtitle': request.localtvshowtitle,
        'premiered': request.premiered,
        'meta': request.meta or {},
    }
    win = _window()
    win.setProperty(PROP_CANDIDATES, json.dumps(payload))
    win.setProperty(PROP_REQUEST, json.dumps(req))


def load_session():
    win = _window()
    raw_candidates = win.getProperty(PROP_CANDIDATES)
    raw_request = win.getProperty(PROP_REQUEST)
    if not raw_candidates:
        return [], None
    try:
        items = json.loads(raw_candidates)
    except Exception:
        return [], None
    candidates = []
    for item in items or []:
        cand = StreamCandidate.from_dict(item)
        if cand:
            candidates.append(cand)
    request = None
    if raw_request:
        try:
            request = PlayRequest(**json.loads(raw_request))
        except Exception:
            request = None
    return candidates, request


def open_source_directory(candidates, request):
    if not candidates:
        kodi.notification(c.addon_id, 'No streams found')
        return False
    stash_origin_folder()
    stash_session(candidates, request)
    title = quote_plus(request.display_title or 'Sources')
    base = sys.argv[0]
    xbmc.executebuiltin(f'Container.Update({base}?action=sourceList&title={title})')
    c.log(f'[Sources] directory mode: {len(candidates)} streams')
    return True


def show_source_directory(params):
    '''Build Kodi directory rows for stashed candidates.'''
    import xbmcplugin

    handle = int(sys.argv[1])
    candidates, request = load_session()
    if not candidates:
        kodi.notification(c.addon_id, 'No sources in session')
        kodi.directory(handle, succeeded=False)
        return

    meta = (request.meta if request else None) or {}
    heading = (params or {}).get('title') or (request.display_title if request else 'Sources')
    xbmcplugin.setPluginCategory(handle, heading)

    art = _art_from_meta(meta)
    if art.get('fanart'):
        try:
            xbmcplugin.setPluginFanart(art['fanart'])
        except Exception:
            pass

    from ..modules.downloader import downloads_ready

    can_download = downloads_ready()
    download_label = c.lang(30893)

    for index, cand in enumerate(candidates):
        label = build_list_label(cand, index)
        li = kodi.item(label=label, path=cand.url or '')
        li.setProperty('IsPlayable', 'false')
        if art:
            li.setArt(art)
            if art.get('fanart'):
                li.setProperty('Fanart_Image', art['fanart'])
        # Cheap InfoTag only  -  fields already on request/meta (no HTTP, no cast).
        _apply_source_infotag(li, request, meta)
        if can_download:
            try:
                li.addContextMenuItems([(
                    download_label,
                    f'RunPlugin({sys.argv[0]}?action=download&index={index})',
                )])
            except Exception:
                pass
        url = (
            f'{sys.argv[0]}?action=playItem'
            f'&index={index}'
        )
        kodi.addItem(handle=handle, url=url, listitem=li, isFolder=False)

    kodi.directory(handle, succeeded=True)


def _art_from_meta(meta):
    if not isinstance(meta, dict):
        return {}
    poster = meta.get('poster') or meta.get('thumb') or ''
    fanart = meta.get('fanart') or ''
    thumb = meta.get('thumb') or poster
    art = {}
    if poster:
        art['poster'] = poster
        art['icon'] = poster
    if thumb:
        art['thumb'] = thumb
    if fanart:
        art['fanart'] = fanart
    return art


def _source_info_title(request, meta):
    '''Movie/episode title for InfoTag  -  never the colored scrape label.'''
    meta = meta if isinstance(meta, dict) else {}
    if request is not None and getattr(request, 'is_episode', False):
        show = (
            (request.tvshowtitle or meta.get('tvshowtitle') or request.title or '')
            .strip()
        )
        try:
            season = int(request.season or meta.get('season') or 0)
            episode = int(request.episode or meta.get('episode') or 0)
        except (TypeError, ValueError):
            season = episode = 0
        if show and season > 0 and episode > 0:
            return '%s S%02dE%02d' % (show, season, episode)
        return show or (request.display_title or '').strip() or 'Episode'
    title = ''
    if request is not None:
        title = (request.title or request.display_title or '').strip()
    if not title:
        title = (meta.get('title') or meta.get('tvshowtitle') or '').strip()
    return title or 'Video'


def _apply_source_infotag(li, request, meta):
    '''Stamp Estuary-facing fields already in hand (Crew 3.2.24 + plot).

    Have: title, mediatype, year, plot, premiered, S/E, ids, trailer,
    duration/rating/votes when present.
    Have-not: cast, director/writer objects, genre/studio piles, HTTP enrich.
    '''
    meta = meta if isinstance(meta, dict) else {}
    try:
        info = li.getVideoInfoTag()
    except Exception:
        return

    info_title = _source_info_title(request, meta)
    is_episode = bool(request is not None and getattr(request, 'is_episode', False))
    mediatype = 'episode' if is_episode else 'movie'
    try:
        meta_mt = (meta.get('mediatype') or '').strip().lower()
        if meta_mt in ('movie', 'episode'):
            mediatype = meta_mt
    except Exception:
        pass

    try:
        info.setMediaType(mediatype)
        info.setTitle(info_title)
    except Exception:
        pass

    if is_episode and request is not None:
        show = (request.tvshowtitle or meta.get('tvshowtitle') or '').strip()
        if show:
            try:
                info.setTvShowTitle(show)
            except Exception:
                pass
        try:
            season = int(request.season or meta.get('season') or 0)
            episode = int(request.episode or meta.get('episode') or 0)
        except (TypeError, ValueError):
            season = episode = 0
        if season > 0:
            try:
                info.setSeason(season)
            except Exception:
                pass
        if episode > 0:
            try:
                info.setEpisode(episode)
            except Exception:
                pass

    year = ''
    if request is not None and request.year:
        year = str(request.year).strip()
    if not year:
        year = str(meta.get('year') or '').strip()
    if year.isdigit():
        try:
            info.setYear(int(year))
        except Exception:
            pass

    plot = (meta.get('plot') or meta.get('overview') or '').strip()
    if plot:
        try:
            info.setPlot(plot)
        except Exception:
            pass

    premiered = ''
    if request is not None:
        premiered = (request.premiered or '').strip()
    if not premiered:
        premiered = (meta.get('premiered') or meta.get('aired') or '').strip()
    if premiered:
        try:
            info.setPremiered(premiered)
        except Exception:
            pass

    try:
        duration = int(meta.get('duration') or 0)
    except (TypeError, ValueError):
        duration = 0
    if duration > 0:
        try:
            info.setDuration(duration)
        except Exception:
            pass

    try:
        rating = float(meta.get('rating') or 0)
    except (TypeError, ValueError):
        rating = 0.0
    try:
        votes = int(meta.get('votes') or 0)
    except (TypeError, ValueError):
        votes = 0
    if rating > 0:
        try:
            info.setRating(rating, votes=votes)
        except TypeError:
            try:
                info.setRating(rating)
            except Exception:
                pass

    unique = {}
    imdb = ''
    tmdb = ''
    tvdb = ''
    if request is not None:
        try:
            imdb = request.imdb_for_scrape() if hasattr(request, 'imdb_for_scrape') else (
                ('tt' + request.imdb) if request.imdb and not str(request.imdb).startswith('tt')
                else (request.imdb or '')
            )
        except Exception:
            imdb = (request.imdb or '')
        tmdb = str(request.tmdb or '').strip()
        tvdb = str(request.tvdb or '').strip()
    if not imdb:
        imdb = str(meta.get('imdb') or meta.get('imdbnumber') or '').strip()
    if not tmdb:
        tmdb = str(meta.get('tmdb') or '').strip()
    if not tvdb:
        tvdb = str(meta.get('tvdb') or '').strip()
    if imdb:
        unique['imdb'] = imdb if str(imdb).startswith('tt') else ('tt' + str(imdb))
    if tmdb:
        unique['tmdb'] = tmdb
    if tvdb:
        unique['tvdb'] = tvdb
    if unique:
        try:
            info.setUniqueIDs(unique)
        except Exception:
            pass

    # Trailer: prefer meta URL; else Classy trailer action (Crew 3.2.24).
    trailer = (meta.get('trailer') or '').strip()
    if trailer in ('0', 'None'):
        trailer = ''
    if not trailer or not trailer.startswith('plugin://'):
        try:
            from ..play.trailer import trailer_plugin_url
            trailer = trailer_plugin_url(
                name=(
                    (request.tvshowtitle if is_episode and request else '')
                    or info_title
                ),
                imdb=unique.get('imdb', ''),
                tmdb_id=unique.get('tmdb', ''),
                mediatype='tvshow' if is_episode else mediatype,
                url=trailer if trailer.startswith('http') else '',
            )
        except Exception:
            trailer = ''
    if trailer:
        try:
            info.setTrailer(trailer)
        except Exception:
            pass

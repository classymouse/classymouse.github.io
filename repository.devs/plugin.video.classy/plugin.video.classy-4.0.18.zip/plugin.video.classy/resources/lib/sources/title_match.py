# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file title_match.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Strict release-title matching for scrape results.

Episode rule: text before SxxExx must clean-equal the show title (or an alias).
Rejects Bosch.Legacy / Rotten.Legacy when the target is Legacy.
Fail-closed on errors.'''

from __future__ import annotations

import re
from urllib.parse import parse_qs, unquote, urlparse

from ..modules import cleantitle

_RANGE_PATTERNS = (
    r's\d{1,3}e\d{1,3}[-.]e\d{1,3}',
    r's\d{1,3}e\d{1,3}[-.]\d{1,3}(?!p|bit|gb)(?!\d{1,3})',
    r's\d{1,3}[-.]e\d{1,3}[-.]e\d{1,3}',
    r'season[.-]?\d{1,3}[.-]?ep[.-]?\d{1,3}[.-]ep[.-]?\d{1,3}',
    r'season[.-]?\d{1,3}[.-]?episode[.-]?\d{1,3}[-.]episode[.-]?\d{1,3}',
)

_QUALITY_SPLIT = re.compile(
    r'2160p|216op|4k|1080p|1o8op|108op|1o80p|720p|72op|480p|48op',
    re.I,
)


def episode_hdlr(season, episode):
    try:
        return f'S{int(season):02d}E{int(episode):02d}'
    except (TypeError, ValueError):
        return ''


def normalize_alias_titles(aliases):
    out = []
    for alias in aliases or []:
        if isinstance(alias, dict):
            alias = alias.get('title') or alias.get('name') or ''
        text = str(alias or '').strip()
        if text and text not in out:
            out.append(text)
    return out


def release_name_from_candidate(candidate):
    '''Prefer magnet dn=, then candidate.name, then URL.'''
    url = (getattr(candidate, 'url', None) or '').strip()
    name = (getattr(candidate, 'name', None) or '').strip()
    if url.startswith('magnet:'):
        try:
            params = parse_qs(urlparse(url).query)
            dn = (params.get('dn') or [''])[0]
            if dn:
                return unquote(dn).replace('+', ' ').strip()
        except Exception:
            pass
    if name:
        return name
    return url


def match_release(
    title,
    release_name,
    *,
    aliases=None,
    year='',
    hdlr='',
    is_movie=True,
    imdb='',
):
    '''True when release_name belongs to title (strict prefix / year match).'''
    try:
        title = str(title or '').strip()
        release_name = str(release_name or '').strip()
        if not title or not release_name:
            return False

        imdb = str(imdb or '').strip().lower()
        if imdb and imdb.startswith('tt') and imdb in release_name.lower():
            return True

        year = str(year or '').strip()
        hdlr = str(hdlr or '').strip()
        years = []
        if is_movie and year:
            try:
                y = int(year)
                years = [str(y - 1), str(y), str(y + 1)]
            except (TypeError, ValueError):
                years = [year]
            if years and not any(y in release_name for y in years):
                return False
        else:
            if not hdlr:
                return False
            if not re.search(re.escape(hdlr), release_name, re.I):
                return False
            for pattern in _RANGE_PATTERNS:
                if re.search(pattern, release_name, re.I):
                    return False

        title_list = []
        for alias in normalize_alias_titles(aliases):
            alias_clean = alias.replace('&', 'and')
            if year:
                alias_clean = alias_clean.replace(year, '')
            if is_movie:
                for y in years:
                    alias_clean = alias_clean.replace(y, '')
            alias_clean = alias_clean.strip()
            if alias_clean and alias_clean not in title_list:
                title_list.append(alias_clean)

        title_clean = title.replace('&', 'and')
        if year:
            title_clean = title_clean.replace(year, '')
        title_clean = title_clean.strip()
        if title_clean and title_clean not in title_list:
            title_list.append(title_clean)

        release_title = re.sub(
            r'([(])(?=((19|20)[0-9]{2})).*?([)])',
            r'\2',
            release_name,
        )
        if is_movie and year:
            t = release_title.replace(year, '').replace('&', 'and')
            for y in years:
                t = t.split(y)[0]
        else:
            t = re.split(re.escape(hdlr), release_title, 1, re.I)[0]
            t = t.replace('&', 'and')
            if year:
                t = t.replace(year, '')
            # Strip year tokens in the title prefix (Legacy.2025.S01E01).
            t = re.sub(r'(?:19|20)\d{2}', '', t)

        t = _QUALITY_SPLIT.split(t, 1)[0]
        release_clean = cleantitle.get(t)
        if not release_clean:
            return False

        return any(cleantitle.get(valid) == release_clean for valid in title_list)
    except Exception:
        return False


def match_play_request(request, release_name):
    '''Match a PlayRequest against a release filename / magnet dn.'''
    if request is None:
        return True
    is_episode = bool(getattr(request, 'is_episode', False))
    if is_episode:
        title = getattr(request, 'tvshowtitle', None) or getattr(request, 'title', None)
        hdlr = episode_hdlr(
            getattr(request, 'season', None),
            getattr(request, 'episode', None),
        )
        return match_release(
            title,
            release_name,
            aliases=getattr(request, 'aliases', None),
            year=getattr(request, 'year', '') or '',
            hdlr=hdlr,
            is_movie=False,
            imdb=getattr(request, 'imdb', '') or '',
        )

    title = getattr(request, 'title', None) or getattr(request, 'tvshowtitle', None)
    return match_release(
        title,
        release_name,
        aliases=getattr(request, 'aliases', None),
        year=getattr(request, 'year', '') or '',
        hdlr=str(getattr(request, 'year', '') or ''),
        is_movie=True,
        imdb=getattr(request, 'imdb', '') or '',
    )

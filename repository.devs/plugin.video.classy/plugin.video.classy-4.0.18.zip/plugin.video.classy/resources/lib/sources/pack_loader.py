# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file pack_loader.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Generic external scraper-pack loader driven by scraper_packs.json.

Layouts:
  group_dirs        -  walk sources_root/<group>/*.py  (Classy / Coco / Viper)
  providers_nested  -  walk sources_root/providers/<group>/*.py (+ other top dirs)
                     (Gears / Diamond)
  pack_api          -  import pack module and call its sources() API (Magneto)'''

from __future__ import annotations

import os
import sys

from ..modules.crewruntime import c
from .pack_settings import pack_enabled
from . import scraper_packs


def load_pack(pack, file_loader, addons_dir):
    '''Load one manifest pack. ``file_loader`` is registry._load_sources_from_dir.'''
    sources = []
    label = pack.get('label') or pack.get('id') or 'pack'
    try:
        if not _gate(pack, addons_dir, label):
            return sources

        _apply_sys_path(pack, addons_dir)
        _run_hooks(pack)

        layout = str(pack.get('layout') or 'group_dirs').strip()
        if layout == 'pack_api':
            sources.extend(_load_pack_api(pack, label))
        elif layout == 'providers_nested':
            sources.extend(_load_providers_nested(pack, file_loader, addons_dir, label))
        else:
            sources.extend(_load_group_dirs(pack, file_loader, addons_dir, label))
    except Exception as exc:
        c.log(f'[Sources] Error during {label} detection: {exc}', 1)
    return sources


def _gate(pack, addons_dir, label):
    addon_id = pack.get('addon') or ''
    setting = pack.get('setting') or ''
    default = bool(pack.get('enabled_default', True))

    if not scraper_packs.is_installed(pack, addons_dir):
        c.log(f'[Sources] {label} not installed, skipping')
        return False
    if setting and not pack_enabled(setting, default=default):
        c.log(f'[Sources] {label} installed but disabled in settings')
        return False
    if not addons_dir:
        c.log(f'[Sources] {label}: addons dir not found', 1)
        return False

    if pack.get('ensure_enabled'):
        _ensure_kodi_enabled(addon_id, label)

    c.log(f'[Sources] {label} detected and enabled, attempting to load scrapers')
    return True


def _ensure_kodi_enabled(addon_id, label):
    import xbmc

    if not addon_id:
        return
    try:
        if xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})'):
            return
    except Exception:
        return
    c.log(f'[Sources] {label} is installed but disabled in Kodi - enabling it')
    try:
        xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
            f'"params":{{"addonid":"{addon_id}","enabled":true}},"id":1}}'
        )
        xbmc.sleep(750)
    except Exception as exc:
        c.log(f'[Sources] Failed to enable {label} in Kodi: {exc}', 1)


def _apply_sys_path(pack, addons_dir):
    addon_id = pack.get('addon') or ''
    for rel in pack.get('sys_path') or ['lib']:
        path = os.path.join(addons_dir, addon_id, *str(rel).replace('\\', '/').split('/'))
        if os.path.isdir(path) and path not in sys.path:
            sys.path.insert(0, path)


def _run_hooks(pack):
    for hook in pack.get('hooks') or []:
        if hook == 'pack_client_shims':
            try:
                from ..modules.pack_client import install_pack_client_shims
                install_pack_client_shims()
            except Exception as exc:
                c.log(f'[Sources] pack_client_shims failed: {exc}', 1)


def _prefix_root(pack):
    return str(pack.get('prefix') or pack.get('id') or '').rstrip('.')


def _sources_root(pack, addons_dir):
    addon_id = pack.get('addon') or ''
    rel = str(pack.get('sources_root') or '').replace('\\', '/').strip('/')
    if not rel:
        return None
    return os.path.join(addons_dir, addon_id, *rel.split('/'))


def _load_group_dirs(pack, file_loader, addons_dir, label):
    sources = []
    base_dir = _sources_root(pack, addons_dir)
    root = _prefix_root(pack)
    if not base_dir or not os.path.isdir(base_dir):
        c.log(f'[Sources] {label} sources directory not found', 1)
        return sources

    for subdir in os.listdir(base_dir):
        full = os.path.join(base_dir, subdir)
        if not os.path.isdir(full) or subdir.startswith('_'):
            continue
        try:
            loaded = file_loader(full, prefix=f'{root}.{subdir}')
            sources.extend(loaded)
            c.log(f'[Sources] Loaded {len(loaded)} scrapers from {root}/{subdir}')
        except Exception as exc:
            c.log(f'[Sources] Failed to load {root}/{subdir}: {exc}', 1)
    return sources


def _load_providers_nested(pack, file_loader, addons_dir, label):
    '''Gears/Diamond style: sources_root may contain providers/<group>/ and other dirs.'''
    sources = []
    base_dir = _sources_root(pack, addons_dir)
    root = _prefix_root(pack)
    if not base_dir or not os.path.isdir(base_dir):
        c.log(f'[Sources] {label} sources directory not found', 1)
        return sources

    for subdir in os.listdir(base_dir):
        full = os.path.join(base_dir, subdir)
        if not os.path.isdir(full) or subdir.startswith('_'):
            continue
        try:
            if subdir == 'providers':
                for group in os.listdir(full):
                    group_path = os.path.join(full, group)
                    if not os.path.isdir(group_path) or group.startswith('_'):
                        continue
                    loaded = file_loader(
                        group_path,
                        prefix=f'{root}.providers.{group}',
                    )
                    sources.extend(loaded)
                    c.log(
                        f'[Sources] Loaded {len(loaded)} scrapers from '
                        f'{root}/providers/{group}'
                    )
            else:
                loaded = file_loader(full, prefix=f'{root}.{subdir}')
                sources.extend(loaded)
                c.log(f'[Sources] Loaded {len(loaded)} scrapers from {root}/{subdir}')
        except Exception as exc:
            c.log(f'[Sources] Failed to load {root}/{subdir}: {exc}', 1)
    return sources


def _load_pack_api(pack, label):
    '''Magneto-style: pack exposes sources(specified_folders=..., ret_all=True).'''
    sources = []
    api = pack.get('api') or {}
    module_name = api.get('module') or _prefix_root(pack)
    folders = api.get('folders') or ['torrents']
    prefix = _prefix_root(pack)

    import importlib
    mod = importlib.import_module(module_name)
    raw = mod.sources(specified_folders=list(folders), ret_all=True)
    for name, source_factory in raw:
        try:
            folder = folders[0] if len(folders) == 1 else 'api'
            sources.append((f'{prefix}.{folder}.{name}', source_factory()))
        except Exception as exc:
            c.log(f'[Sources] {label} failed to instantiate {name}: {exc}', 1)

    c.log(f'[Sources] Loaded {len(sources)} providers from {prefix}/api')
    return sources

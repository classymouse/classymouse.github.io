# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scrape_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Scrape progress dialog  -  incremental quality counters, no list rescan.'''

import threading
import time

import xbmc
import xbmcgui

from ..modules.classy import c
from .quality_tiers import quality_tier

UPDATE_INTERVAL = 0.4
_COUNTER_FMT = '[COLOR %s][B]%s[/B][/COLOR]'


def _colored_count(value):
    color = 'red' if value == 0 else 'lime'
    return _COUNTER_FMT % (color, value)


def _quality_bucket(quality):
    '''Map quality to one of 4K / 1080p / 720p / SD counter buckets.'''
    tier = quality_tier(quality)
    if tier is None:
        return 'sd'
    if tier == 0:
        return '4k'
    if tier in (1, 2):
        return '1080'
    if tier == 3:
        return '720'
    return 'sd'


class ScrapeCounters:
    def __init__(self):
        self._lock = threading.Lock()
        self.q4k = 0
        self.q1080 = 0
        self.q720 = 0
        self.qsd = 0
        self.total = 0
        self.dups = 0

    def add(self, candidates):
        if not candidates:
            return
        with self._lock:
            for cand in candidates:
                bucket = _quality_bucket(getattr(cand, 'quality', ''))
                if bucket == '4k':
                    self.q4k += 1
                elif bucket == '1080':
                    self.q1080 += 1
                elif bucket == '720':
                    self.q720 += 1
                else:
                    self.qsd += 1
                self.total += 1

    def add_duplicates(self, count):
        if not count:
            return
        with self._lock:
            self.dups += int(count)

    def snapshot(self):
        with self._lock:
            return self.q4k, self.q1080, self.q720, self.qsd, self.total, self.dups


def format_counter_line(snapshot):
    q4k, q1080, q720, qsd, total, dups = snapshot
    parts = [
        f'4K: {_colored_count(q4k)}',
        f'1080p: {_colored_count(q1080)}',
        f'720p: {_colored_count(q720)}',
        f'SD: {_colored_count(qsd)}',
        f'Total: {_colored_count(total)}',
    ]
    if dups:
        parts.append(f'Dups: {_colored_count(dups)}')
    return ' | '.join(parts)


def _format_active_line(alive_labels, completed, total_providers):
    if not alive_labels:
        return '[COLOR orchid]Finishing up...[/COLOR]'
    if len(alive_labels) > 6:
        active = f'{len(alive_labels)} scrapers'
    else:
        active = ', '.join(alive_labels)
    return (
        f'[COLOR orchid]Scraping: {active} | '
        f'{completed}/{total_providers} complete[/COLOR]'
    )


class ScrapeProgressDialog:
    def __init__(self, title, total_providers, timeout):
        self._title = title
        self._total_providers = max(1, int(total_providers or 1))
        self._timeout = max(5, int(timeout or 30))
        self._dlg = xbmcgui.DialogProgress()
        self._monitor = xbmc.Monitor()
        self._opened = False
        self._cancelled = False
        self._last_paint = 0.0
        self._start = 0.0
        self.persistent = False

    @property
    def cancelled(self):
        return self._cancelled

    def open(self):
        self._start = time.time()
        self._dlg.create(c.addon_id, self._title)
        self._dlg.update(0, '[COLOR orchid]Searching sources...[/COLOR]')
        self._opened = True
        self._last_paint = 0.0

    def _update(self, percent, *lines):
        '''DialogProgress.update accepts at most percent + one message string.'''
        message = '\n'.join(line for line in lines if line)
        self._dlg.update(percent, message)

    def tick(self, counters, alive_labels):
        if not self._opened:
            return
        if self._monitor.abortRequested() or self._dlg.iscanceled():
            self._cancelled = True
            return

        now = time.time()
        if now - self._last_paint < UPDATE_INTERVAL:
            return
        self._last_paint = now

        elapsed = now - self._start
        percent = int(100 * min(elapsed / self._timeout, 0.99))
        completed = self._total_providers - len(alive_labels)
        line1 = format_counter_line(counters.snapshot())
        line2 = _format_active_line(alive_labels, completed, self._total_providers)
        if c.devmode:
            line2 += f'\n[COLOR lawngreen]Devmode: {elapsed:.1f}s[/COLOR]'
        self._update(percent, line1, line2)

    def close(self):
        if not self._opened:
            return
        try:
            self._dlg.close()
        except Exception:
            pass
        self._opened = False

    def close_overlay(self):
        '''No WindowXML for stock DialogProgress.'''
        self.close()


class OverlayScrapeProgressDialog:
    '''Paint scrape progress onto ResolveStatus  -  same surface as smart resolve.'''

    def __init__(self, request, title, total_providers, timeout, persistent=True):
        self._request = request
        self._title = title
        self._total_providers = max(1, int(total_providers or 1))
        self._timeout = max(5, int(timeout or 30))
        self._monitor = xbmc.Monitor()
        self._opened = False
        self._cancelled = False
        self._last_paint = 0.0
        self._start = 0.0
        self._overlay = None
        self.persistent = bool(persistent)
        self.quiet = True  # TV Evening: fixed header, whisper status only

    @property
    def cancelled(self):
        return self._cancelled

    def open(self):
        from ..kodi.resolve_status import open_resolve_status, get_active_overlay

        self._start = time.time()
        self._overlay = get_active_overlay() or open_resolve_status(
            self._request, title=self._title, reuse=True,
        )
        try:
            # Keep show / SxxExx / episode title visible for the whole scrape -> resolve.
            self._overlay.update_status('Finding sources...', '', '')
        except Exception:
            pass
        self._opened = True
        self._last_paint = 0.0

    def _update(self, percent, *lines):
        if not self._overlay:
            return
        if self.quiet:
            # One calm line  -  ignore quality/scraper dashboards.
            try:
                pct = int(percent)
            except (TypeError, ValueError):
                pct = -1
            main = 'Finding sources...'
            if pct >= 90:
                main = 'Almost ready...'
            elif pct >= 40:
                main = 'Still looking...'
            try:
                self._overlay.update_status(main, '', '')
            except Exception:
                pass
            return

        main = 'Searching sources...'
        sub = ''
        attempt = ''
        usable = [line for line in lines if line]
        if usable:
            main = usable[0]
            if len(usable) > 1:
                sub = usable[1]
            if len(usable) > 2:
                attempt = usable[2]
        try:
            pct = int(percent)
        except (TypeError, ValueError):
            pct = -1
        if pct > 0 and not attempt:
            attempt = f'{pct}%'
        try:
            self._overlay.update_status(main, sub, attempt)
        except Exception:
            pass

    def tick(self, counters, alive_labels):
        if not self._opened:
            return
        if self._monitor.abortRequested():
            self._cancelled = True
            return
        try:
            if self._overlay and self._overlay.is_cancelled():
                self._cancelled = True
                return
        except Exception:
            pass

        now = time.time()
        if now - self._last_paint < UPDATE_INTERVAL:
            return
        self._last_paint = now

        elapsed = now - self._start
        percent = int(100 * min(elapsed / self._timeout, 0.99))
        if self.quiet:
            self._update(percent)
            return
        completed = self._total_providers - len(alive_labels)
        line1 = format_counter_line(counters.snapshot())
        line2 = _format_active_line(alive_labels, completed, self._total_providers)
        if c.devmode:
            line2 += f'  |  {elapsed:.1f}s'
        self._update(percent, line1, line2)

    def close(self):
        '''End scrape paints; keep WindowXML open when persistent (resolve continues).'''
        if not self._opened:
            return
        self._opened = False
        if self.persistent and not self._cancelled:
            try:
                if self._overlay:
                    self._overlay.update_status('Preparing stream...', '', '')
            except Exception:
                pass
            return
        self.close_overlay()

    def close_overlay(self):
        if self._overlay is None:
            return
        try:
            self._overlay.close()
        except Exception:
            pass
        try:
            from ..kodi.resolve_status import clear_active_overlay
            clear_active_overlay()
        except Exception:
            pass
        self._overlay = None


def create_scrape_dialog(request, title, total_providers, timeout):
    '''Stock DialogProgress, or ResolveStatus when TV Evening owns the session.'''
    try:
        from ..kodi.resolve_status import experience_overlay_wanted
        if experience_overlay_wanted():
            return OverlayScrapeProgressDialog(
                request, title, total_providers, timeout, persistent=True,
            )
    except Exception as exc:
        c.log(f'[Scrape] experience overlay unavailable: {exc}', 1)
    return ScrapeProgressDialog(title, total_providers, timeout)

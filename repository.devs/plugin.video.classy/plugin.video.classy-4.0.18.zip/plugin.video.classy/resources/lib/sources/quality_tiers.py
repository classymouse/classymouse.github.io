# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file quality_tiers.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Quality tier indices  -  match Crew ``hosts.quality`` enum (0 = 4K ... 4 = SD).'''

# Setting index = highest quality tier allowed; lower tiers pass too.
# 0=4K  ->  all tiers  |  2=1080p  ->  1080p+720p+SD  |  4=SD  ->  SD only.
QUALITY_FLOOR_LABELS = ('4K', '1440p', '1080p', '720p', 'SD')

# (quality token, tier index)  -  first match wins.
_TIER_TOKENS = (
    ('4k', 0), ('2160p', 0), ('uhd', 0),
    ('1440p', 1),
    ('1080p', 2), ('1080', 2), ('fhd', 2),
    ('720p', 3), ('720', 3), ('hd', 3),
    ('sd', 4), ('480p', 4), ('480', 4),
)

CAM_QUALITIES = frozenset({
    'cam', 'scr', 'screener', 'tele', 'telesync', 'tc', 'ts',
})


def normalize_quality(quality):
    q = str(quality or '').strip()
    if q.lower() in ('hd',):
        return '720p'
    return q


def quality_tier(quality):
    '''Return tier 0 (4K) ... 4 (SD), or ``None`` for cam/screener rows.'''
    q = normalize_quality(quality).lower()
    if q in CAM_QUALITIES:
        return None
    for token, tier in _TIER_TOKENS:
        if q == token or token in q:
            return tier
    return 4


def is_cam_quality(quality):
    return str(quality or '').lower().strip() in CAM_QUALITIES

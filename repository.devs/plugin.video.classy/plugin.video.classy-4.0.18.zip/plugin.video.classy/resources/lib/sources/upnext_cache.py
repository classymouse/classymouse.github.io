# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file upnext_cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Up Next prescrape cache  -  single-use scrape results for the next episode.

Keyed by imdb/tmdb + S/E. Stored in profile SQLite (shared plugin/service).
Consumed on read so a miss falls through to a normal scrape.'''

from __future__ import annotations

import json
import os
import sqlite3
import time

import xbmcaddon
import xbmcvfs

from ..modules.classy import c
from ..play.models import PlayRequest, StreamCandidate


def _db_path():
    profile = xbmcaddon.Addon().getAddonInfo('profile')
    return os.path.join(xbmcvfs.translatePath(profile), 'source_cache.db')


def _connect():
    path = _db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return sqlite3.connect(path, timeout=30.0)


def _ensure_schema(cur):
    cur.execute(
        '''
        CREATE TABLE IF NOT EXISTS upnext_cache (
            cache_key TEXT PRIMARY KEY,
            sources_json TEXT,
            cached_at INTEGER
        )
        '''
    )


def _norm_imdb(value):
    text = str(value or '').strip()
    if text.startswith('tt'):
        text = text[2:]
    return text


def cache_key(imdb, tmdb, season, episode):
    imdb_n = _norm_imdb(imdb)
    tmdb_n = str(tmdb or '').strip()
    try:
        season_n = int(season or 0)
        episode_n = int(episode or 0)
    except (TypeError, ValueError):
        return ''
    if season_n <= 0 or episode_n <= 0:
        return ''
    if not imdb_n and not tmdb_n:
        return ''
    return f'upnext_{imdb_n}_{tmdb_n}_s{season_n}e{episode_n}'


def cache_key_for_request(request):
    if not isinstance(request, PlayRequest) or not request.is_episode:
        return ''
    return cache_key(request.imdb, request.tmdb, request.season, request.episode)


def put_candidates(imdb, tmdb, season, episode, candidates):
    '''Store finalized StreamCandidate list for next-episode play.'''
    key = cache_key(imdb, tmdb, season, episode)
    if not key or not candidates:
        return False
    payload = []
    for cand in candidates:
        if isinstance(cand, StreamCandidate):
            payload.append(cand.to_dict())
        elif isinstance(cand, dict):
            payload.append(cand)
    if not payload:
        return False
    try:
        body = json.dumps(payload, default=str)
    except Exception as exc:
        c.log(f'[UpNextCache] serialize failed: {exc}', 1)
        return False
    try:
        conn = _connect()
        cur = conn.cursor()
        _ensure_schema(cur)
        cur.execute(
            '''INSERT OR REPLACE INTO upnext_cache
               (cache_key, sources_json, cached_at) VALUES (?, ?, ?)''',
            (key, body, int(time.time())),
        )
        conn.commit()
        conn.close()
        c.log(f'[UpNextCache] stored {key} ({len(payload)} streams)')
        return True
    except Exception as exc:
        c.log(f'[UpNextCache] write failed: {exc}', 1)
        return False


def get_candidates(request):
    '''Single-use read for PlayRequest. None on miss.'''
    key = cache_key_for_request(request)
    if not key:
        return None
    try:
        conn = _connect()
        cur = conn.cursor()
        _ensure_schema(cur)
        row = cur.execute(
            'SELECT sources_json FROM upnext_cache WHERE cache_key = ?',
            (key,),
        ).fetchone()
        if not row:
            conn.close()
            c.log(f'[UpNextCache] MISS {key}')
            return None
        cur.execute('DELETE FROM upnext_cache WHERE cache_key = ?', (key,))
        conn.commit()
        conn.close()
        payload = json.loads(row[0] or '[]')
        if not isinstance(payload, list):
            return None
        out = []
        for item in payload:
            cand = StreamCandidate.from_dict(item)
            if cand and (cand.url or '').strip():
                out.append(cand)
        if not out:
            c.log(f'[UpNextCache] empty payload {key}')
            return None
        c.log(f'[UpNextCache] HIT {key} ({len(out)} streams, consumed)')
        return out
    except Exception as exc:
        c.log(f'[UpNextCache] read failed: {exc}', 1)
        return None


def clear_all():
    '''Drop all Up Next prescrape rows (Tools clear / maintenance).'''
    try:
        conn = _connect()
        cur = conn.cursor()
        _ensure_schema(cur)
        cur.execute('DELETE FROM upnext_cache')
        conn.commit()
        conn.close()
        c.log('[UpNextCache] cleared')
        return True
    except Exception as exc:
        c.log(f'[UpNextCache] clear failed: {exc}', 1)
        return False

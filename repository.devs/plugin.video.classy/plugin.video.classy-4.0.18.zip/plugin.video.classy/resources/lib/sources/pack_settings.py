# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file pack_settings.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Scraper pack enable helpers  -  default on when setting is absent.'''

from ..modules.classy import c


def pack_enabled(setting_id, default=True):
    '''Return whether a pack is enabled (missing setting uses ``default``).'''
    value = c.get_setting(setting_id)
    if value is None or value == '':
        return default
    return value == 'true'

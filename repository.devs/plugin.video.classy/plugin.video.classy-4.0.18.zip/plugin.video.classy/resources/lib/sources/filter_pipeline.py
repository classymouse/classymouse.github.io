# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file filter_pipeline.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Settings-driven post-scrape filter pipeline.

Register steps with ``register_filter(name, when, fn)``. Each step runs only
when ``when()`` is true. Steps are applied in registration order.

Example (in filter_steps.py)::

    register_filter(
        'hevc',
        lambda: c.get_setting('HEVC') != 'true',
        filter_hevc_out,
    )'''

from ..modules.classy import c

_STEPS = []
_LOADED = False


def register_filter(name, when, fn):
    '''Register a filter step.

    Args:
        name: Log label (e.g. ``'hevc'``).
        when: Callable returning True when this step should run.
        fn: ``(candidates, request) -> list[StreamCandidate]``.
    '''
    _STEPS.append((str(name), when, fn))


def apply_stream_filters(candidates, request=None):
    '''Run all registered filters whose ``when()`` predicate is true.'''
    _ensure_loaded()
    if not candidates:
        return []

    out = list(candidates)
    for name, when, fn in _STEPS:
        try:
            active = bool(when())
        except Exception as exc:
            c.log(f'[Filter] {name}: when() failed: {exc}', 1)
            continue
        if not active:
            continue

        before = len(out)
        try:
            filtered = fn(out, request)
        except Exception as exc:
            c.log(f'[Filter] {name}: error: {exc}', 1)
            continue
        if filtered is None:
            continue
        out = filtered
        removed = before - len(out)
        if removed:
            c.log(f'[Filter] {name}: {before} -> {len(out)} (-{removed})')
        elif c.devmode:
            c.log(f'[Filter] {name}: {before} unchanged')

    return out


def _ensure_loaded():
    global _LOADED
    if _LOADED:
        return
    from . import filter_steps  # noqa: F401  -  registers steps

    _LOADED = True

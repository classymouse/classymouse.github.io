# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file orion.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Orion provider  -  separate from built-in scrapers toggle.'''

import importlib.util
import os

from ...modules.crewruntime import c
from ...orion.api import api


def is_enabled():
    value = c.get_setting('orion.enabled')
    if value is None or value == '':
        return True
    return str(value).lower() not in ('false', '0', 'no', 'off')


def load(_loader):
    sources = []
    if not is_enabled():
        c.log('[Sources] Orion disabled in settings  -  skipping')
        return sources

    path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        'scrapers',
        'orion.py',
    )
    if not os.path.isfile(path):
        c.log('[Sources] Orion scraper file missing', 1)
        return sources

    try:
        spec = importlib.util.spec_from_file_location('resources.lib.scrapers.orion', path)
        if spec is None or spec.loader is None:
            c.log('[Sources] Could not load Orion scraper spec', 1)
            return sources
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if hasattr(module, 'source') and callable(module.source):
            sources.append(('resources.lib.scrapers.orion', module.source()))
            c.log('[Sources] Orion provider loaded')
        else:
            c.log('[Sources] Orion scraper has no source() factory', 1)
    except Exception as exc:
        c.log(f'[Sources] Orion load failed: {exc}', 1)

    if not api.is_orion_installed():
        c.log('[Sources] script.module.orion not installed  -  Orion scrape inactive until setup', 2)
    elif not api.get_credentials_info():
        c.log('[Sources] Orion not authorized  -  use Tools  ->  Orion  ->  Authorize', 2)

    return sources

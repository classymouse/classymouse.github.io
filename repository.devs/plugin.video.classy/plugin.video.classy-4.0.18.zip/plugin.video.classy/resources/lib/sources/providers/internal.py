# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file internal.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Internal Crew scrapers (resources/lib/scrapers).'''

import os

from ...modules.crewruntime import c


def is_enabled():
    '''Master toggle  -  Settings  ->  External Scrapers  ->  Enable built-in scrapers.'''
    value = c.get_setting('crewscrapers.enabled')
    if value is None or value == '':
        return True
    return str(value).lower() != 'false'


def load(loader):
    sources = []
    if not is_enabled():
        c.log('[Sources] Built-in scrapers disabled in settings  -  skipping scrapers/')
        return sources
    try:
        lib_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        scrapers_dir = os.path.join(lib_dir, 'scrapers')
        if os.path.isdir(scrapers_dir):
            loaded = loader(scrapers_dir, prefix='resources.lib.scrapers')
            loaded = [
                item for item in (loaded or [])
                if not (isinstance(item[0], str) and item[0].endswith('.orion'))
            ]
            if loaded:
                sources.extend(loaded)
                try:
                    short_names = [
                        n.split('.')[-1].replace('_', ' ').title() if isinstance(n, str) else str(n)
                        for n, _ in loaded[:8]
                    ]
                    c.log(f'[Sources] Loaded {len(loaded)} scrapers from scrapers/: {short_names}')
                except Exception:
                    c.log(f'[Sources] Loaded {len(loaded)} scrapers from scrapers/')
            else:
                c.log('[Sources] No scrapers found in scrapers/', 2)
    except Exception as exc:
        c.log(f'[Sources] Failed loading scrapers: {exc}', 1)
    c.log(f'[Sources] Crew scrapers loaded: {len(sources)}')
    return sources

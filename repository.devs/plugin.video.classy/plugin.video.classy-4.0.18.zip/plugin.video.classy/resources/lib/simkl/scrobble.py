# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scrobble.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl scrobble + playback delete.'''

from __future__ import annotations

from ..apis.simkl import SimklApi
from ..modules.classy import c
from ..progress import filters as slot_filters
from . import auth
from . import progress as simkl_progress
from . import sync

WATCHED_PCT_DEFAULT = slot_filters.RESUME_PROGRESS_MAX_DEFAULT


def watched_percent():
    return slot_filters.resume_progress_max()


MIN_POSITION_SEC = 60


def _valid_id(value):
    return str(value or '').strip() not in ('', '0', 'None', 'null')


def _scrobble_ids(imdb='', tmdb=''):
    ids = {}
    if _valid_id(imdb):
        imdb_val = str(imdb)
        ids['imdb'] = imdb_val if imdb_val.startswith('tt') else f'tt{imdb_val}'
    if _valid_id(tmdb):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    return ids


def delete_playback(playback_id):
    if not playback_id:
        return False
    if not auth.has_credentials():
        return False
    ok = SimklApi().delete_playback(playback_id)
    if ok:
        c.log(f'[Simkl Scrobble] deleted playback id={playback_id}')
        sync.invalidate()
    return ok


def find_playback_id(mediatype, imdb='', tmdb='', season=0, episode=0):
    items = sync.fetch_playback(
        'movies' if mediatype == 'movie' else 'episodes'
    )
    want_imdb = str(imdb or '').strip()
    want_tmdb = str(tmdb or '').strip()
    for item in items:
        if not isinstance(item, dict):
            continue
        if mediatype == 'movie':
            movie = item.get('movie') if isinstance(item.get('movie'), dict) else {}
            ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
            if want_tmdb and str(ids.get('tmdb') or '') == want_tmdb:
                return item.get('id')
            if want_imdb and str(ids.get('imdb') or '') == want_imdb:
                return item.get('id')
        else:
            show = item.get('show') if isinstance(item.get('show'), dict) else {}
            ep = item.get('episode') if isinstance(item.get('episode'), dict) else {}
            ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
            try:
                s = int(ep.get('season') or 0)
                e = int(ep.get('number') or 0)
            except (TypeError, ValueError):
                continue
            if s != int(season or 0) or e != int(episode or 0):
                continue
            if want_tmdb and str(ids.get('tmdb') or '') == want_tmdb:
                return item.get('id')
            if want_imdb and str(ids.get('imdb') or '') == want_imdb:
                return item.get('id')
    return None


def clear_playback_session(mediatype, imdb='', tmdb='', season=0, episode=0):
    playback_id = find_playback_id(mediatype, imdb, tmdb, season, episode)
    return delete_playback(playback_id) if playback_id else False


def scrobble_session(session, current_sec, total_sec, action):
    if not auth.scrobble_enabled() or not auth.has_credentials():
        return False

    try:
        total = float(total_sec or 0)
        current = float(current_sec or 0)
    except (TypeError, ValueError):
        return False
    if total <= 0:
        return False
    percent = max(0.0, min(100.0, (current / total) * 100.0))
    if action in ('start', 'pause') and current < MIN_POSITION_SEC and percent < 1:
        return False

    mediatype = (session.get('mediatype') or 'movie').lower()
    imdb = session.get('imdb') or ''
    tmdb = session.get('tmdb') or ''
    title = session.get('title') or session.get('tvshowtitle') or ''
    year = session.get('year') or 0
    try:
        year = int(year) if year else 0
    except (TypeError, ValueError):
        year = 0

    api = SimklApi()
    if mediatype == 'episode':
        show = api.build_show_obj(title=session.get('tvshowtitle') or title, imdb=imdb, tmdb=tmdb)
        try:
            season = int(session.get('season') or 0)
            number = int(session.get('episode') or 0)
        except (TypeError, ValueError):
            return False
        media_obj = {
            'show': show,
            'episode': {'season': season, 'number': number},
        }
    else:
        media_obj = {'movie': api.build_movie_obj(title=title, year=year, imdb=imdb, tmdb=tmdb)}

    try:
        if action == 'start':
            result = api.scrobble_start(media_obj, percent)
        elif action == 'pause':
            result = api.scrobble_pause(media_obj, percent)
        else:
            result = api.scrobble_stop(media_obj, percent)
            should_clear = bool(session.get('_outcome_clear_resume'))
            if not should_clear:
                should_clear = percent >= watched_percent()
            if should_clear:
                clear_playback_session(
                    mediatype,
                    imdb=imdb,
                    tmdb=tmdb,
                    season=session.get('season') or 0,
                    episode=session.get('episode') or 0,
                )
        ok = result is not None
        if ok:
            sync.invalidate()
            simkl_progress.invalidate_next_episodes()
            if action in ('pause', 'stop'):
                try:
                    from ..progress.widget_signals import notify_progress_changed
                    notify_progress_changed(f'simkl_scrobble_{action}')
                except Exception:
                    pass
            c.log(f'[Simkl Scrobble] {action} {mediatype} {percent:.0f}%')
        return ok
    except Exception as exc:
        c.log(f'[Simkl Scrobble] {action} failed: {exc}', 1)
        return False

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl list converters  -  Trakt-shaped rows for VideoRow.from_trakt_*.'''

from __future__ import annotations

import re

from . import sync


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _norm_id(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    return text


def _poster_url(poster):
    if not poster:
        return ''
    text = str(poster)
    if text.startswith('http'):
        return text
    return f'https://simkl.in/posters/{text}_m.jpg'


def _to_trakt_movie_item(entry):
    movie = entry.get('movie') if isinstance(entry, dict) else None
    if not isinstance(movie, dict):
        movie = entry if isinstance(entry, dict) else {}
    ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
    title = (movie.get('title') or '').strip()
    if not title:
        return None
    year = re.sub(r'[^0-9]', '', str(movie.get('year') or '')) or None
    imdb = _norm_imdb(ids.get('imdb'))
    tmdb = _norm_id(ids.get('tmdb'))
    out_ids = {}
    if imdb:
        out_ids['imdb'] = imdb
    if tmdb:
        try:
            out_ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    body = {
        'title': title,
        'year': int(year) if year else None,
        'overview': movie.get('overview') or '',
        'runtime': movie.get('runtime') or 0,
        'ids': out_ids,
    }
    poster = _poster_url(movie.get('poster'))
    if poster:
        body['images'] = {'poster': {'thumb': poster}}
    return {'movie': body}


def _to_trakt_show_item(entry):
    show = entry.get('show') if isinstance(entry, dict) else None
    if not isinstance(show, dict):
        show = entry if isinstance(entry, dict) else {}
    ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
    title = (show.get('title') or '').strip()
    if not title:
        return None
    year = re.sub(r'[^0-9]', '', str(show.get('year') or '')) or None
    imdb = _norm_imdb(ids.get('imdb'))
    tmdb = _norm_id(ids.get('tmdb'))
    tvdb = _norm_id(ids.get('tvdb'))
    out_ids = {}
    if imdb:
        out_ids['imdb'] = imdb
    if tmdb:
        try:
            out_ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    if tvdb:
        try:
            out_ids['tvdb'] = int(tvdb)
        except (TypeError, ValueError):
            pass
    body = {
        'title': title,
        'year': int(year) if year else None,
        'overview': show.get('overview') or '',
        'ids': out_ids,
    }
    return {'show': body}


def movie_items(status='plantowatch'):
    out = []
    for entry in sync.fetch_status_items('movies', status):
        item = _to_trakt_movie_item(entry)
        if item:
            out.append(item)
    return out


def show_items(status='plantowatch'):
    out = []
    for entry in sync.fetch_status_items('shows', status):
        item = _to_trakt_show_item(entry)
        if item:
            out.append(item)
    return out


def rated_movies():
    from ..apis.simkl import SimklApi
    from . import auth

    if not auth.has_credentials():
        return []
    data = SimklApi().get_ratings(media_type='movies')
    rows = data if isinstance(data, list) else []
    out = []
    for entry in rows:
        if not isinstance(entry, dict):
            continue
        item = _to_trakt_movie_item(entry)
        if item:
            out.append(item)
    return out


def rated_shows():
    from ..apis.simkl import SimklApi
    from . import auth

    if not auth.has_credentials():
        return []
    data = SimklApi().get_ratings(media_type='shows')
    rows = data if isinstance(data, list) else []
    out = []
    for entry in rows:
        if not isinstance(entry, dict):
            continue
        item = _to_trakt_show_item(entry)
        if item:
            out.append(item)
    return out

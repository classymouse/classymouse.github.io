# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file sync.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl library sync  -  activities-gated status buckets.'''

from __future__ import annotations

from ..apis.simkl import SimklApi
from ..modules.classy import c
from . import auth

_STATUS_CACHE = {}
_ACTIVITIES_CACHE = {'ts': 0.0, 'data': {}}
_ACTIVITIES_TTL = 20 * 60  # seconds


def _api():
    return SimklApi()


def _extract_entries(data, media_type):
    if isinstance(data, list):
        return data
    if not isinstance(data, dict):
        return []
    for key in (media_type, 'movies', 'shows', 'tv', 'items'):
        block = data.get(key)
        if isinstance(block, list):
            return block
    return []


def get_last_activities(force=False):
    import time

    now = time.time()
    if (
        not force
        and _ACTIVITIES_CACHE['data']
        and (now - _ACTIVITIES_CACHE['ts']) < _ACTIVITIES_TTL
    ):
        return _ACTIVITIES_CACHE['data']
    data = _api().get_last_activities() if auth.has_credentials() else {}
    if not isinstance(data, dict):
        data = {}
    _ACTIVITIES_CACHE['data'] = data
    _ACTIVITIES_CACHE['ts'] = now
    return data


def activity_stamp(media_type):
    acts = get_last_activities()
    if media_type == 'movies':
        block = acts.get('movies') if isinstance(acts.get('movies'), dict) else {}
        stamp = block.get('all') or acts.get('all') or ''
    else:
        block = acts.get('tv_shows') if isinstance(acts.get('tv_shows'), dict) else {}
        stamp = block.get('all') or acts.get('all') or ''
    return str(stamp or '')


def invalidate():
    _STATUS_CACHE.clear()
    _ACTIVITIES_CACHE['data'] = {}
    _ACTIVITIES_CACHE['ts'] = 0.0
    try:
        from . import watch_sync
        watch_sync.invalidate()
    except Exception:
        pass


def fetch_status_items(media_type, status):
    '''GET /sync/all-items/{movies|shows}/{status} (phase-1, summary).'''
    if not auth.has_credentials():
        return []
    stamp = activity_stamp(media_type) or 'unknown'
    cache_key = (media_type, status, stamp)
    cached = _STATUS_CACHE.get(cache_key)
    if cached is not None:
        return list(cached)
    try:
        data = _api().get_items_by_status(
            media_type=media_type,
            status=status,
            extended=None,
            phase1_initial=True,
        )
        entries = _extract_entries(data, media_type)
        _STATUS_CACHE[cache_key] = entries
        c.log(
            f'[Simkl] fetch_status_items {media_type}/{status}: '
            f'{len(entries)} item(s) (act={stamp[:19]})'
        )
        return list(entries)
    except Exception as exc:
        c.log(f'[Simkl] fetch_status_items error ({media_type}/{status}): {exc}', 1)
        return []


def fetch_playback(media_type=''):
    if not auth.has_credentials():
        return []
    try:
        data = _api().get_playback(media_type)
        if isinstance(data, list):
            return data
        return []
    except Exception as exc:
        c.log(f'[Simkl] fetch_playback error: {exc}', 1)
        return []

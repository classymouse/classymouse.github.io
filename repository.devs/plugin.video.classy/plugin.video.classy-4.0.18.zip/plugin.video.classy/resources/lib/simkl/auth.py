# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file auth.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl credentials  -  token never expires; no refresh.'''

from ..modules.classy import c


def has_credentials() -> bool:
    return bool((c.get_setting('simkl.token') or '').strip())


def get_username() -> str:
    return (c.get_setting('simkl.user') or '').strip()


def set_credentials(token: str = '', username: str = ''):
    c.set_setting('simkl.token', token or '')
    c.set_setting('simkl.user', username or '')


def clear_credentials():
    set_credentials('', '')


def scrobble_enabled() -> bool:
    '''Respect simkl.scrobble; default on when unset.'''
    value = c.get_setting('simkl.scrobble')
    if value is None or value == '':
        return True
    return str(value).lower() == 'true'

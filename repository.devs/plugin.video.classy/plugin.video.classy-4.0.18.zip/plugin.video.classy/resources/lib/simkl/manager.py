# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file manager.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl Manager dialog  -  status buckets + rate (no collection).'''

from __future__ import annotations

import xbmcgui

from ..apis.simkl import SimklApi
from ..modules.classy import c
from . import auth
from . import sync


def manager(name, imdb, tmdb, content):
    if not auth.has_credentials():
        c.infoDialog(
            'Simkl not connected  -  authorize in Settings',
            heading=name or 'Simkl',
            sound=True,
        )
        return

    imdb_s = str(imdb or '').strip()
    if imdb_s in ('0', 'None'):
        imdb_s = ''
    try:
        tmdb_i = int(tmdb) if tmdb and str(tmdb) not in ('0', 'None', '') else 0
    except (TypeError, ValueError):
        tmdb_i = 0
    if not imdb_s and not tmdb_i:
        c.infoDialog('No valid ID for this item', heading=name or 'Simkl', sound=True)
        return

    is_movie = (content or '').lower() == 'movie'
    title = (name or '').strip()
    dropped = c.lang(30791) or 'Dropped'
    watching = c.lang(30789) or 'Watching'
    on_hold = c.lang(30790) or 'On Hold'
    actions = [
        ('Rate this', 'rate'),
        ('Remove Rating', 'remove_rating'),
    ]
    if is_movie:
        actions += [
            ('Plan to Watch', 'plantowatch'),
            ('Completed', 'completed'),
            (dropped, 'dropped'),
            ('Remove from list', 'remove'),
        ]
    else:
        actions += [
            ('Plan to Watch', 'plantowatch'),
            (watching, 'watching'),
            (on_hold, 'hold'),
            (dropped, 'dropped'),
            ('Completed', 'completed'),
            ('Remove from list', 'remove'),
        ]

    select = xbmcgui.Dialog().select('Simkl Manager', [a[0] for a in actions])
    if select < 0:
        return

    action_key = actions[select][1]
    success_label = actions[select][0]
    api = SimklApi()
    media = (
        api.build_movie_obj(title=title, imdb=imdb_s, tmdb=tmdb_i)
        if is_movie
        else api.build_show_obj(title=title, imdb=imdb_s, tmdb=tmdb_i)
    )

    result = None
    if action_key == 'rate':
        labels = [str(i) for i in range(1, 11)]
        rating_select = xbmcgui.Dialog().select('Rate', labels)
        if rating_select < 0:
            return
        rated = dict(media)
        rated['rating'] = rating_select + 1
        result = api.add_rating(movies=[rated]) if is_movie else api.add_rating(shows=[rated])
        success_label = f'Rated {rated["rating"]}/10'
    elif action_key == 'remove_rating':
        result = api.remove_rating(movies=[media]) if is_movie else api.remove_rating(shows=[media])
    elif action_key == 'remove':
        result = api.remove_from_list(movies=[media]) if is_movie else api.remove_from_list(shows=[media])
    else:
        result = (
            api.add_to_watchlist(movies=[media], status=action_key)
            if is_movie
            else api.add_to_watchlist(shows=[media], status=action_key)
        )

    if result is None:
        c.infoDialog('Simkl request failed', heading=title or 'Simkl', sound=True)
        return

    sync.invalidate()
    c.log(f'[Simkl Manager] {action_key} ok for {title!r}')
    c.infoDialog(success_label, heading=title or 'Simkl', sound=False)

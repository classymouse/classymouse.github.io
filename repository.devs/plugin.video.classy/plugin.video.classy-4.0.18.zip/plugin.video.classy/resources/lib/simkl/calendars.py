# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file calendars.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl calendars  -  CDN v2 TV feeds + optional my-library filter.'''

from __future__ import annotations

from datetime import date, datetime, timedelta

from ..apis.simkl import SimklApi
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from . import auth
from . import lists as simkl_lists

# Presets used by calendars_menu / tracker.calendar_episodes.
_MY_PRESETS = frozenset({
    'mycalendar',
    'calendar_today',
    'calendar_thisweek',
    'calendar_nextweek',
})

_TV_CALENDAR_PATH = '/calendar/v2/tv.json'


def _norm_id(raw):
    text = str(raw or '').strip()
    if not text or text.lower() in ('none', 'null', '0'):
        return '0'
    return text


def _norm_imdb(raw):
    text = str(raw or '').strip()
    if not text or text.lower() in ('none', 'null', '0'):
        return '0'
    if text.isdigit():
        return f'tt{text}'
    return text


def fetch_tv_calendar():
    '''CDN v2 payload: {calendar: [...], metadata: {simkl_id: show}}.'''
    api = SimklApi()
    data = api.get(_TV_CALENDAR_PATH, base=api.CDN, with_auth=False, timeout=20)
    if not isinstance(data, dict):
        c.log('[Simkl] calendar CDN: empty/invalid response', 1)
        return {'calendar': [], 'metadata': {}}
    return {
        'calendar': data.get('calendar') if isinstance(data.get('calendar'), list) else [],
        'metadata': data.get('metadata') if isinstance(data.get('metadata'), dict) else {},
    }


def _window_predicate(window):
    '''Return (label, predicate(air_local_date) -> bool). Crew-aligned windows.'''
    today = date.today()
    w = (window or 'week').lower()

    if w in ('today', 'calendar_today', 'calendar_all_today'):
        return 'today', lambda d: d == today
    if w in ('week', 'calendar_thisweek', 'thisweek', 'calendar_all_thisweek'):
        end = today + timedelta(days=6)
        return 'week', lambda d: today <= d <= end
    if w in ('nextweek', 'calendar_nextweek'):
        day_7 = today + timedelta(days=7)
        day_14 = today + timedelta(days=14)
        return 'nextweek', lambda d: day_7 < d <= day_14
    if w in ('thismonth', 'calendar_all_thismonth'):
        end = today + timedelta(days=29)
        return 'month', lambda d: today <= d <= end
    if w in ('my', 'mycalendar'):
        # CDN rolling window  -  filter by library only.
        return 'my', lambda _d: True
    end = today + timedelta(days=6)
    return 'week', lambda d: today <= d <= end


def _library_keys():
    '''TMDB/IMDB keys for watching + plantowatch (my calendar filter).'''
    keys = set()
    for status in ('watching', 'plantowatch'):
        for item in simkl_lists.show_items(status):
            show = item.get('show') if isinstance(item, dict) else {}
            ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
            tmdb = _norm_id(ids.get('tmdb'))
            imdb = _norm_imdb(ids.get('imdb'))
            if tmdb != '0':
                keys.add(('tmdb', tmdb))
            if imdb != '0':
                keys.add(('imdb', imdb))
    return keys


def _air_local_date(raw_date):
    try:
        air_dt = datetime.fromisoformat(str(raw_date).replace('Z', '+00:00'))
        return air_dt.astimezone().date() if air_dt.tzinfo else air_dt.date()
    except Exception:
        try:
            return date.fromisoformat(str(raw_date)[:10])
        except Exception:
            return None


def _raw_calendar_items(window):
    '''Trakt-shaped episode dicts for VideoRow.from_trakt_episode.'''
    _label, in_window = _window_predicate(window)
    mine = (window or '') in _MY_PRESETS

    data = fetch_tv_calendar()
    calendar = data.get('calendar') or []
    metadata = data.get('metadata') or {}

    library = _library_keys() if mine else None
    if mine and not library:
        c.log('[Simkl] calendar: no watching/plantowatch shows  -  empty', 1)
        return []

    out = []
    for entry in calendar:
        if not isinstance(entry, dict):
            continue
        ep = entry.get('episode') if isinstance(entry.get('episode'), dict) else {}
        if not ep:
            continue
        sid = entry.get('simkl_id')
        show = metadata.get(str(sid)) if sid is not None else None
        if not isinstance(show, dict):
            continue
        ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
        tmdb = _norm_id(ids.get('tmdb'))
        imdb = _norm_imdb(ids.get('imdb'))
        if library is not None:
            if (('tmdb', tmdb) not in library) and (('imdb', imdb) not in library):
                continue

        air_local = _air_local_date(entry.get('date') or '')
        if air_local is None or not in_window(air_local):
            continue

        try:
            season = int(ep.get('season') or 0)
            number = int(ep.get('episode') or ep.get('number') or 0)
        except (TypeError, ValueError):
            continue
        if season < 0 or number < 1:
            continue

        title = (show.get('title') or '').strip()
        if not title:
            continue
        year = None
        rel = show.get('release_date') or ''
        if isinstance(rel, str) and len(rel) >= 4 and rel[:4].isdigit():
            year = int(rel[:4])

        out.append({
            'show': {
                'title': title,
                'year': year,
                'ids': {
                    'tmdb': None if tmdb == '0' else tmdb,
                    'imdb': None if imdb == '0' else imdb,
                    'tvdb': None if _norm_id(ids.get('tvdb')) == '0' else _norm_id(ids.get('tvdb')),
                    'simkl': sid,
                },
            },
            'episode': {
                'season': season,
                'number': number,
                'title': (ep.get('title') or '').strip(),
            },
            'first_aired': air_local.strftime('%Y-%m-%d'),
        })

    out.sort(key=lambda item: item.get('first_aired') or '')
    c.log(f'[Simkl] calendar window={window}: {len(out)} episode(s)', 1)
    return out


def calendar_episodes(window='week'):
    '''Raw Trakt-shaped episode dicts for a window id.'''
    try:
        return _raw_calendar_items(window)
    except Exception as exc:
        c.log(f'[Simkl] calendar_episodes error: {exc}', 1)
        return []


def fetch_page(preset, *, page=1, page_size=50, widget_limit=None, **_kwargs):
    '''Return (VideoRow list, total) matching trakt calendar_lists.fetch_page.'''
    preset = (preset or '').strip()
    mine = preset in _MY_PRESETS
    if mine and not auth.has_credentials():
        return [], 0

    items = calendar_episodes(preset)
    rows = []
    for item in items:
        try:
            row = VideoRow.from_trakt_episode(item)
        except Exception:
            continue
        rows.append(row)

    total = len(rows)
    if widget_limit:
        try:
            limit = max(1, int(widget_limit))
        except (TypeError, ValueError):
            limit = 20
        return rows[:limit], total

    try:
        page = max(1, int(page))
        page_size = max(1, int(page_size))
    except (TypeError, ValueError):
        page, page_size = 1, 50
    start = (page - 1) * page_size
    return rows[start:start + page_size], total

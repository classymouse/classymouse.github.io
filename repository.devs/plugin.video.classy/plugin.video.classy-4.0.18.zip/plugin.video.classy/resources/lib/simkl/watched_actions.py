# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file watched_actions.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl mark watched / playcount actions.'''

from __future__ import annotations

from ..apis.simkl import SimklApi
from ..modules import control
from ..modules.classy import c
from . import auth
from . import progress as simkl_progress
from . import scrobble as simkl_scrobble
from . import sync


def _ids(imdb='', tmdb=''):
    ids = {}
    imdb = str(imdb or '').strip()
    if imdb and imdb not in ('0', 'None'):
        ids['imdb'] = imdb if imdb.startswith('tt') else f'tt{imdb}'
    tmdb = str(tmdb or '').strip()
    if tmdb and tmdb not in ('0', 'None'):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    return ids


def _parse_watched(query, watched_param=None):
    '''CM sends query=6 (unwatched) or 7 (watched)  -  same as Trakt playcount routes.'''
    if query is not None and str(query).strip() != '':
        try:
            value = int(query)
        except (TypeError, ValueError):
            return None
        if value == 7:
            return True
        if value == 6:
            return False
        return None
    if watched_param is not None:
        text = str(watched_param).lower()
        if text in ('false', '0', 'no'):
            return False
        if text in ('true', '1', 'yes'):
            return True
    return None


def _after_success():
    try:
        from ..progress.widget_signals import notify_progress_changed
        notify_progress_changed('simkl_playcount')
    except Exception:
        pass
    try:
        control.execute('Container.Refresh')
    except Exception:
        pass


def mark_movie(imdb, tmdb='', watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False
    api = SimklApi()
    payload = [{'ids': ids}]
    try:
        if watched:
            result = api.add_to_history(movies=payload)
        else:
            result = api.remove_from_history(movies=payload)
        sync.invalidate()
        simkl_scrobble.clear_playback_session('movie', imdb=imdb, tmdb=tmdb)
        if result is not None:
            c.log(f'[Simkl] mark_movie watched={watched} imdb={imdb} tmdb={tmdb}')
            _after_success()
        return result is not None
    except Exception as exc:
        c.log(f'[Simkl] mark_movie failed: {exc}', 1)
        return False


def mark_episode(imdb, tmdb, season, episode, watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False, 'missing ids'
    try:
        season = int(season)
        episode = int(episode)
    except (TypeError, ValueError):
        return False, 'bad season/episode'
    api = SimklApi()
    show = {
        'ids': ids,
        'seasons': [{'number': season, 'episodes': [{'number': episode}]}],
    }
    try:
        if watched:
            result = api.add_to_history(shows=[show])
        else:
            result = api.remove_from_history(shows=[show])
        sync.invalidate()
        simkl_progress.invalidate_next_episodes()
        simkl_scrobble.clear_playback_session(
            'episode', imdb=imdb, tmdb=tmdb, season=season, episode=episode,
        )
        if result is not None:
            c.log(
                f'[Simkl] mark_episode watched={watched} '
                f'S{season:02d}E{episode:02d} imdb={imdb} tmdb={tmdb}',
            )
            _after_success()
        return (result is not None), ''
    except Exception as exc:
        c.log(f'[Simkl] mark_episode failed: {exc}', 1)
        return False, str(exc)


def mark_season(imdb, tmdb, season, watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False
    try:
        season = int(season)
    except (TypeError, ValueError):
        return False
    if season < 0:
        return False
    api = SimklApi()
    show = {
        'ids': ids,
        'seasons': [{'number': season}],
    }
    try:
        if watched:
            result = api.add_to_history(shows=[show])
        else:
            result = api.remove_from_history(shows=[show])
        sync.invalidate()
        simkl_progress.invalidate_next_episodes()
        if result is not None:
            c.log(
                f'[Simkl] mark_season watched={watched} '
                f'S{season:02d} imdb={imdb} tmdb={tmdb}',
            )
            _after_success()
        return result is not None
    except Exception as exc:
        c.log(f'[Simkl] mark_season failed: {exc}', 1)
        return False


def mark_show(imdb, tmdb='', watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False
    api = SimklApi()
    try:
        if watched:
            result = api.add_to_history(shows=[{'ids': ids}])
        else:
            result = api.remove_from_history(shows=[{'ids': ids}])
        sync.invalidate()
        simkl_progress.invalidate_next_episodes()
        if result is not None:
            c.log(f'[Simkl] mark_show watched={watched} imdb={imdb} tmdb={tmdb}')
            _after_success()
        return result is not None
    except Exception as exc:
        c.log(f'[Simkl] mark_show failed: {exc}', 1)
        return False


def apply_playcount(params, *, mediatype):
    if not auth.has_credentials():
        return False, 'Connect Simkl to mark watched'

    params = params or {}
    watched = _parse_watched(params.get('query'), params.get('watched'))
    if watched is None:
        return False, 'Invalid playcount action'

    imdb = params.get('imdb') or ''
    tmdb = params.get('tmdb') or ''
    mediatype = (mediatype or params.get('mediatype') or 'movie').lower()

    if mediatype == 'movie':
        ok = mark_movie(imdb, tmdb, watched=watched)
    elif mediatype in ('tvshow', 'show'):
        ok = mark_show(imdb, tmdb, watched=watched)
    elif mediatype == 'episode':
        ok, _detail = mark_episode(
            imdb, tmdb, params.get('season'), params.get('episode'), watched=watched,
        )
    elif mediatype == 'season':
        ok = mark_season(imdb, tmdb, params.get('season'), watched=watched)
    else:
        return False, 'Unsupported media type'

    if ok:
        return True, 'Marked as watched' if watched else 'Marked as unwatched'
    return False, 'Simkl request failed  -  see classy.log'

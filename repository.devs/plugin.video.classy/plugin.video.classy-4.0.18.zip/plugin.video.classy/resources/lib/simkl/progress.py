# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file progress.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl progress  -  next episodes + playback sessions (slot-shaped).'''

from __future__ import annotations

from ..apis.simkl import SimklApi
from ..modules.classy import c
from ..progress import filters as slot_filters
from . import auth
from . import sync

_NEXT_CACHE = {'stamp': '', 'slots': None}


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _norm_id(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    return text


def _parse_ep_marker(info):
    if not isinstance(info, dict):
        return 0, 0, ''
    try:
        season = int(info.get('season') or info.get('s') or 0)
        episode = int(
            info.get('episode')
            if info.get('episode') is not None
            else info.get('number')
            if info.get('number') is not None
            else info.get('e')
            or 0
        )
    except (TypeError, ValueError):
        return 0, 0, ''
    title = (info.get('title') or info.get('name') or '').strip()
    return season, episode, title


def invalidate_next_episodes():
    _NEXT_CACHE['stamp'] = ''
    _NEXT_CACHE['slots'] = None


def next_episode_sessions():
    '''Slots: show_data, season, episode, last_watched_at, episode_title.'''
    if not auth.has_credentials():
        return []
    stamp = sync.activity_stamp('shows') or 'unknown'
    if _NEXT_CACHE['slots'] is not None and _NEXT_CACHE['stamp'] == stamp:
        return list(_NEXT_CACHE['slots'])

    out = []
    try:
        data = SimklApi().get_items_by_status(
            media_type='shows',
            status='watching',
            extended=None,
            phase1_initial=True,
            next_watch_info=True,
        )
        entries = data if isinstance(data, list) else []
        if isinstance(data, dict):
            for key in ('shows', 'items'):
                if isinstance(data.get(key), list):
                    entries = data[key]
                    break
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            show = entry.get('show') if isinstance(entry.get('show'), dict) else {}
            ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
            title = (show.get('title') or '').strip()
            if not title:
                continue
            tmdb = _norm_id(ids.get('tmdb'))
            if not tmdb:
                continue
            imdb = _norm_imdb(ids.get('imdb'))
            tvdb = _norm_id(ids.get('tvdb'))
            info = entry.get('next_to_watch_info')
            if not isinstance(info, dict):
                info = entry.get('next_to_watch')
            season, episode, ep_title = _parse_ep_marker(info)
            if season <= 0 or episode <= 0:
                last = entry.get('last_watched')
                ls, le, _ = _parse_ep_marker(last)
                if ls > 0 and le > 0:
                    season, episode = ls, le + 1
                    ep_title = ''
            if season <= 0 or episode <= 0:
                continue
            last_watched_at = (
                entry.get('last_watched_at')
                or (info.get('date') if isinstance(info, dict) else None)
                or ''
            )
            show_data = {
                'title': title,
                'year': show.get('year'),
                'ids': {
                    'imdb': imdb or None,
                    'tmdb': int(tmdb),
                    'tvdb': int(tvdb) if tvdb.isdigit() else None,
                },
            }
            out.append({
                'show_data': show_data,
                'season': season,
                'episode': episode,
                'last_watched_at': last_watched_at or '',
                'episode_title': ep_title,
            })
        out.sort(key=lambda k: k.get('last_watched_at') or '', reverse=True)
        _NEXT_CACHE['stamp'] = stamp
        _NEXT_CACHE['slots'] = out
        c.log(f'[Simkl] next_episode_sessions: {len(out)} slot(s)')
    except Exception as exc:
        c.log(f'[Simkl] next_episode_sessions error: {exc}', 1)
        return []
    return list(out)


def movie_playback_items():
    '''Trakt-shaped playback rows for scan_in_progress_movie_slots.'''
    out = []
    for item in sync.fetch_playback('movies'):
        if not isinstance(item, dict):
            continue
        try:
            progress = float(item.get('progress') or 0)
        except (TypeError, ValueError):
            continue
        if progress <= 0 or progress >= slot_filters.resume_progress_max():
            continue
        movie = item.get('movie') if isinstance(item.get('movie'), dict) else {}
        if not (movie.get('title') or '').strip():
            continue
        out.append(item)
    out.sort(key=lambda k: k.get('paused_at') or '', reverse=True)
    return out


def episode_playback_items():
    '''Trakt-shaped playback rows for scan_in_progress_episode_slots.'''
    out = []
    for item in sync.fetch_playback('episodes'):
        if not isinstance(item, dict):
            continue
        try:
            progress = float(item.get('progress') or 0)
        except (TypeError, ValueError):
            continue
        if progress <= 0 or progress >= slot_filters.resume_progress_max():
            continue
        if not isinstance(item.get('show'), dict) or not isinstance(item.get('episode'), dict):
            continue
        out.append(item)
    out.sort(key=lambda k: k.get('paused_at') or '', reverse=True)
    return out


def watching_show_items():
    '''Trakt-shaped show rows for watching bucket / in-progress shows.'''
    from . import lists as simkl_lists
    return simkl_lists.show_items('watching')

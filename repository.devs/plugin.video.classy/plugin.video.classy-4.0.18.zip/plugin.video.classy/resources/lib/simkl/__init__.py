# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl product package.'''

from . import auth
from . import calendars
from . import lists
from . import manager
from . import movie_lists
from . import progress
from . import scrobble
from . import sync
from . import tv_lists
from . import ui
from . import watched_actions

__all__ = [
    'auth',
    'calendars',
    'lists',
    'manager',
    'movie_lists',
    'progress',
    'scrobble',
    'sync',
    'tv_lists',
    'ui',
    'watched_actions',
]

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl My TV presets  -  tvshows&url=simkl* keys.'''

from ..modules.classy import c
from . import auth
from . import lists as simkl_lists

MY_TV_PRESETS = frozenset({
    'simklwatchlist',
    'simklwatching',
    'simklhold',
    'simklhistory',
    'simkldropped',
    'simklratings',
})

_STATUS_MAP = {
    'simklwatchlist': 'plantowatch',
    'simklwatching': 'watching',
    'simklhold': 'hold',
    'simklhistory': 'completed',
    'simkldropped': 'dropped',
}


def is_my_tv_preset(preset):
    return (preset or '').strip() in MY_TV_PRESETS


def fetch_page(preset, *, page=1):
    preset = (preset or '').strip()
    if preset not in MY_TV_PRESETS:
        return None
    if not auth.has_credentials():
        c.log(f'[SimklTvLists] {preset} requires auth', 1)
        return None

    if preset == 'simklratings':
        items = simkl_lists.rated_shows()
    else:
        items = simkl_lists.show_items(_STATUS_MAP[preset])

    # tv_discover expects show-shaped rows via from_trakt_watched_show when source set
    return {
        'results': items,
        'page': 1,
        'total_pages': 1,
        '_source': 'trakt_list_items',
        '_preset': preset,
    }

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file watch_sync.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl  ->  Trakt-shaped watched payloads for WatchIndex / MovieWatchIndex.'''

from __future__ import annotations

from ..apis.simkl import SimklApi
from ..modules.classy import c
from . import auth
from . import sync

_WATCHED_CACHE = {
    'movies_stamp': '',
    'movies': None,
    'shows_stamp': '',
    'shows': None,
}


def invalidate():
    _WATCHED_CACHE['movies_stamp'] = ''
    _WATCHED_CACHE['movies'] = None
    _WATCHED_CACHE['shows_stamp'] = ''
    _WATCHED_CACHE['shows'] = None


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _norm_id(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    return text


def _extract_entries(data, media_type):
    if isinstance(data, list):
        return data
    if not isinstance(data, dict):
        return []
    for key in (media_type, 'movies', 'shows', 'tv', 'items'):
        block = data.get(key)
        if isinstance(block, list):
            return block
    return []


def watched_movies():
    '''Trakt-shaped /sync/watched/movies rows from Simkl completed.'''
    if not auth.has_credentials():
        return []
    stamp = sync.activity_stamp('movies') or 'unknown'
    if _WATCHED_CACHE['movies'] is not None and _WATCHED_CACHE['movies_stamp'] == stamp:
        return list(_WATCHED_CACHE['movies'])

    out = []
    try:
        for entry in sync.fetch_status_items('movies', 'completed'):
            if not isinstance(entry, dict):
                continue
            movie = entry.get('movie') if isinstance(entry.get('movie'), dict) else entry
            if not isinstance(movie, dict):
                continue
            ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
            title = (movie.get('title') or '').strip()
            if not title:
                continue
            out_ids = {}
            imdb = _norm_imdb(ids.get('imdb'))
            tmdb = _norm_id(ids.get('tmdb'))
            if imdb:
                out_ids['imdb'] = imdb
            if tmdb:
                try:
                    out_ids['tmdb'] = int(tmdb)
                except (TypeError, ValueError):
                    pass
            if not out_ids:
                continue
            out.append({
                'movie': {
                    'title': title,
                    'year': movie.get('year'),
                    'ids': out_ids,
                },
                'plays': 1,
                'last_watched_at': entry.get('last_watched_at') or '',
            })
        _WATCHED_CACHE['movies'] = out
        _WATCHED_CACHE['movies_stamp'] = stamp
        c.log(f'[Simkl] watched_movies: {len(out)} item(s)')
    except Exception as exc:
        c.log(f'[Simkl] watched_movies error: {exc}', 1)
        return []
    return list(out)


def watched_shows():
    '''Trakt-shaped /sync/watched/shows rows (seasons/episodes) from Simkl.'''
    if not auth.has_credentials():
        return []
    stamp = sync.activity_stamp('shows') or 'unknown'
    if _WATCHED_CACHE['shows'] is not None and _WATCHED_CACHE['shows_stamp'] == stamp:
        return list(_WATCHED_CACHE['shows'])

    out = []
    seen = set()
    try:
        api = SimklApi()
        for status in ('watching', 'completed'):
            data = api.get_items_by_status(
                media_type='shows',
                status=status,
                extended='full',
                phase1_initial=True,
                episode_watched_at=True,
                include_all_episodes=(status == 'completed'),
            )
            for entry in _extract_entries(data, 'shows'):
                if not isinstance(entry, dict):
                    continue
                show = entry.get('show') if isinstance(entry.get('show'), dict) else {}
                ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
                tmdb = _norm_id(ids.get('tmdb'))
                if not tmdb or tmdb in seen:
                    continue
                seen.add(tmdb)
                imdb = _norm_imdb(ids.get('imdb'))
                tvdb = _norm_id(ids.get('tvdb'))
                out_ids = {'tmdb': int(tmdb)}
                if imdb:
                    out_ids['imdb'] = imdb
                if tvdb and tvdb.isdigit():
                    out_ids['tvdb'] = int(tvdb)

                seasons_out = []
                for season in entry.get('seasons') or []:
                    if not isinstance(season, dict):
                        continue
                    try:
                        sn = int(season.get('number') or 0)
                    except (TypeError, ValueError):
                        continue
                    if sn <= 0:
                        continue
                    eps_out = []
                    for ep in season.get('episodes') or []:
                        if not isinstance(ep, dict):
                            continue
                        try:
                            en = int(ep.get('number') or 0)
                        except (TypeError, ValueError):
                            continue
                        if en <= 0:
                            continue
                        if status == 'watching' or ep.get('watched_at'):
                            eps_out.append({
                                'number': en,
                                'plays': 1,
                                'last_watched_at': ep.get('watched_at') or '',
                            })
                    if eps_out:
                        seasons_out.append({'number': sn, 'episodes': eps_out})

                aired = int(entry.get('total_episodes_count') or 0)
                if aired <= 0:
                    aired = sum(len(s.get('episodes') or []) for s in seasons_out)

                out.append({
                    'show': {
                        'title': (show.get('title') or '').strip(),
                        'year': show.get('year'),
                        'aired_episodes': aired,
                        'ids': out_ids,
                    },
                    'seasons': seasons_out,
                    'last_watched_at': entry.get('last_watched_at') or '',
                })
        _WATCHED_CACHE['shows'] = out
        _WATCHED_CACHE['shows_stamp'] = stamp
        c.log(f'[Simkl] watched_shows: {len(out)} show(s)')
    except Exception as exc:
        c.log(f'[Simkl] watched_shows error: {exc}', 1)
        return []
    return list(out)

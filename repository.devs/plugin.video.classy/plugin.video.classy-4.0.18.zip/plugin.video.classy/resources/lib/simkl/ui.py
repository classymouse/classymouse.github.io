# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file ui.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl UI  -  PIN device auth (QR + poll), mirror Trakt QR dialog pattern.'''

from __future__ import annotations

import threading
import time
import traceback
from urllib.parse import quote

import xbmcgui

from ..apis.simkl import PIN_PAGE, SimklApi, get_client_id
from ..modules.classy import c
from . import auth


def _qr_image_url(data, size=280):
    return (
        f'https://api.qrserver.com/v1/create-qr-code/?data={quote(data)}&size={size}x{size}'
    )


def _show_simkl_pin_dialog(verification_url, user_code, qr_path, interval, expires_in):
    try:
        class SimklPINViewer(xbmcgui.WindowXMLDialog):
            def __init__(self, *args, **kwargs):
                self.header = kwargs.get('header', 'Simkl Authorization')
                self.message = kwargs.get('message', '')
                self.qr_path = kwargs.get('qr_path', '') or ''
                self.user_code = kwargs.get('user_code', '')
                self.interval = max(1, int(kwargs.get('interval', 5)))
                self.expires_in = int(kwargs.get('expires_in', 600))
                self.authenticated = False
                self.access_token = ''
                self.polling = True
                self.poll_thread = None

            def onInit(self):
                try:
                    self.getControl(101).setLabel(self.header)
                    self.getControl(502).setText(self.message)
                    if self.qr_path:
                        self.getControl(501).setImage(self.qr_path)
                    self.setFocusId(503)
                    self.poll_thread = threading.Thread(target=self._poll_for_token)
                    self.poll_thread.daemon = True
                    self.poll_thread.start()
                except Exception as exc:
                    c.log(f'[Simkl PIN] onInit error: {exc}', 1)

            def _poll_for_token(self):
                try:
                    api = SimklApi()
                    start = time.time()
                    while self.polling and (time.time() - start) < self.expires_in:
                        time.sleep(self.interval)
                        try:
                            data = api.poll_pin(self.user_code)
                            if not isinstance(data, dict):
                                continue
                            result = (data.get('result') or '').upper()
                            if result == 'OK':
                                token = (data.get('access_token') or '').strip()
                                if token:
                                    self.authenticated = True
                                    self.access_token = token
                                    self.close()
                                    return
                            elif result == 'EXPIRED':
                                c.log('[Simkl PIN] PIN expired', 1)
                                self.close()
                                return
                        except Exception as poll_exc:
                            c.log(f'[Simkl PIN] poll error: {poll_exc}', 1)
                    if self.polling:
                        c.log('[Simkl PIN] polling timed out', 1)
                        self.close()
                except Exception as exc:
                    c.log(f'[Simkl PIN] polling thread error: {exc}', 1)

            def onAction(self, action):
                if action.getId() in (10, 92):
                    self.polling = False
                    self.close()

            def onClick(self, control_id):
                if control_id == 503:
                    self.polling = False
                    self.close()

        message = (
            f'Scan QR code with your mobile device\n\n'
            f'OR visit:\n{verification_url}\n\n'
            f'Enter code: {user_code}\n\n'
            f'Waiting for authorization... (expires in {expires_in}s)'
        )
        addon_path, skin = c.resolve_dialog_skin('LogViewer_QR.xml')
        dialog = SimklPINViewer(
            'LogViewer_QR.xml',
            addon_path,
            skin,
            '1080i',
            header='Simkl Authorization',
            message=message,
            qr_path=qr_path or '',
            user_code=user_code,
            interval=interval,
            expires_in=expires_in,
        )
        dialog.doModal()
        authenticated = dialog.authenticated
        access_token = dialog.access_token
        dialog.polling = False
        del dialog
        return authenticated, access_token
    except Exception:
        c.log(f'[Simkl] QR dialog failed:\n{traceback.format_exc()}', 1)
        return False, ''


def auth_simkl():
    '''Settings / My lists  -  PIN flow with QR dialog.'''
    try:
        if auth.has_credentials():
            username = auth.get_username()
            prompt = (
                f'Simkl account [{username}] already authorized.[CR][CR]Re-authorize?'
                if username
                else 'Simkl already authorized.[CR][CR]Re-authorize?'
            )
            if not c.yesnoDialog(prompt, heading='Simkl'):
                return
            auth.clear_credentials()

        client_id = get_client_id()
        if not client_id:
            c.infoDialog(
                'No Simkl Client ID configured.\n\n'
                'Add your Client ID in Settings > Watch Tracking.\n'
                'Register free at simkl.com/settings/developer/new',
                heading='Simkl',
                sound=True,
            )
            return

        c.log('[Simkl Auth] Requesting PIN...', 1)
        api = SimklApi()
        pin_data = api.request_pin()
        if not isinstance(pin_data, dict):
            c.infoDialog(
                'Failed to connect to Simkl. Check your internet connection.',
                heading='Simkl',
                sound=True,
            )
            return

        user_code = (pin_data.get('user_code') or '').strip()
        if not user_code:
            c.infoDialog('Simkl returned an invalid response.', heading='Simkl', sound=True)
            return

        expires_in = int(pin_data.get('expires_in', 600))
        interval = int(pin_data.get('interval', 5))
        pin_url = f'{PIN_PAGE}{user_code}'
        c.log(f'[Simkl Auth] user_code={user_code}', 1)

        qr_path = _qr_image_url(pin_url, size=280)
        authenticated, access_token = _show_simkl_pin_dialog(
            pin_url, user_code, qr_path, interval, expires_in,
        )

        if not authenticated or not access_token:
            c.log('[Simkl Auth] authorization failed or timed out', 1)
            c.infoDialog('Simkl authorization failed or timed out.', heading='Simkl', sound=True)
            return

        username = api.fetch_username(access_token)
        auth.set_credentials(access_token, username)
        c.log(f'[Simkl Auth] Authorized as: {username or "(unknown)"}', 1)
        c.infoDialog(
            f'Simkl authorized{": " + username if username else ""}',
            heading='Simkl',
            sound=True,
        )
    except Exception as exc:
        c.log(f'[Simkl Auth] error: {exc}', 1)
        c.log(traceback.format_exc(), 1)
        c.infoDialog(f'Simkl authorization error:\n{exc}', heading='Simkl', sound=True)


def revoke_simkl():
    '''Clear local Simkl token (no remote revoke endpoint).'''
    try:
        if not auth.has_credentials():
            c.infoDialog('No Simkl account is authorized.', heading='Simkl', sound=False)
            return
        username = auth.get_username()
        prompt = (
            f'Remove Simkl authorization for {username}?'
            if username
            else 'Remove Simkl authorization?'
        )
        if c.yesnoDialog(prompt, heading='Simkl'):
            auth.clear_credentials()
            c.log('[Simkl Auth] Authorization revoked', 1)
            c.infoDialog('Simkl authorization removed.', heading='Simkl', sound=False)
    except Exception as exc:
        c.log(f'[Simkl Auth] revoke error: {exc}', 1)

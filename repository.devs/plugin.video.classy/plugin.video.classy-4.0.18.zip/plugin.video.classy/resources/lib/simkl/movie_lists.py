# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl My Movies presets  -  movies&url=simkl* keys.'''

from ..modules.classy import c
from . import auth
from . import lists as simkl_lists

# Match Trakt movie_lists / calendar history page size.
_PAGE_LIMIT = 40

MY_MOVIE_PRESETS = frozenset({
    'simklwatchlist',
    'simklhistory',
    'simkldropped',
    'simklratings',
})

_STATUS_MAP = {
    'simklwatchlist': 'plantowatch',
    'simklhistory': 'completed',
    'simkldropped': 'dropped',
}


def is_my_movie_preset(preset):
    return (preset or '').strip() in MY_MOVIE_PRESETS


def _paginate(items, page, limit=_PAGE_LIMIT):
    items = list(items or [])
    page = max(1, int(page or 1))
    limit = max(1, int(limit or _PAGE_LIMIT))
    total = len(items)
    total_pages = max(1, (total + limit - 1) // limit) if total else 1
    if page > total_pages:
        page = total_pages
    start = (page - 1) * limit
    return items[start:start + limit], page, total_pages


def fetch_page(preset, *, page=1):
    preset = (preset or '').strip()
    if preset not in MY_MOVIE_PRESETS:
        return None
    if not auth.has_credentials():
        c.log(f'[SimklMovieLists] {preset} requires auth', 1)
        return None

    if preset == 'simklratings':
        items = simkl_lists.rated_movies()
    else:
        items = simkl_lists.movie_items(_STATUS_MAP[preset])

    page_items, page, total_pages = _paginate(items, page)
    c.log(
        f'[SimklMovieLists] {preset} page={page}/{total_pages} '
        f'({len(page_items)}/{len(items)} items)'
    )

    return {
        'results': page_items,
        'page': page,
        'total_pages': total_pages,
        '_source': 'trakt_movies',
        '_preset': preset,
    }

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file orion.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Orion scraper  -  runs in parallel with other providers when module is installed.'''

from .base import BaseScraper
from ..modules.crewruntime import c
from ..orion.api import api


class source(BaseScraper):
    priority = 0

    def __init__(self):
        super().__init__(name='orion')
        self.movie = True
        self.tvshow = True

    def _scrape_sources(self, data, hostDict):
        if not api.scrape_allowed():
            return []

        limit = api.get_smart_limit()
        season = data.get('season')
        episode = data.get('episode')

        if season not in (None, '', 0, '0') and episode not in (None, '', 0, '0'):
            imdb = data.get('imdb') or 0
            tmdb = data.get('tmdb') or 0
            title = data.get('tvshowtitle') or data.get('title') or ''
            try:
                season_no = int(season)
                episode_no = int(episode)
            except (TypeError, ValueError):
                c.log('[orion] invalid season/episode  -  skipping', 1)
                return []
            raw = api.get_episode(
                imdb=imdb,
                tmdb=tmdb,
                title=title,
                season=season_no,
                episode=episode_no,
                limit=limit,
            )
            return api.do_orion_scrape(raw, 'episode')

        imdb = data.get('imdb') or ''
        if not imdb:
            c.log('[orion] movie scrape missing imdb  -  skipping', 2)
            return []
        raw = api.get_movie(imdb, limit=limit)
        return api.do_orion_scrape(raw, 'movie')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Upstream API clients (TMDB, Fanart, TVDB, Simkl, MDBList). Trakt lives in trakt/.'''

from .tmdb import TmdbApi, tmdb
from .fanart import FanartApi, fanart
from .tvdb import TvdbApi, tvdb
from .simkl import SimklApi, simkl
from .mdblist import MdblistApi, mdblist

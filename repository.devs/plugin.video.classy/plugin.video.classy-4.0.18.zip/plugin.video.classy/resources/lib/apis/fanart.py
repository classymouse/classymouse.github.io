# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file fanart.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Fanart.tv v3  -  artwork JSON (HTTP base URL matches 3.x).'''

from .. import cache
from ..metadata import cache_ttl
from ..modules import keys
from ..modules import msg_handler
from ..modules.classy import c
from .base import request_json

NS_FANART = 'fanart'


class FanartApi:
    BASE = 'http://webservice.fanart.tv/v3'

    def __init__(self, api_key=None, client_key=None):
        self.api_key = api_key or keys.fanart_key
        self.client_key = client_key or (c.get_setting('fanart.tv.user') or '').strip()

    def _headers(self):
        headers = {'api-key': self.api_key}
        if self.client_key:
            headers['client-key'] = self.client_key
        return headers

    def _cached_get(self, cache_key, url):
        cached = cache.get_json(NS_FANART, cache_key, ttl_ok=True)
        if cached is not None:
            return cached
        data = request_json(msg_handler.API_FANART, url, headers=self._headers())
        if isinstance(data, dict) and data.get('status') == 'error':
            return None
        if data is not None:
            cache.put_json(NS_FANART, cache_key, data, ttl_seconds=cache_ttl.FANART_TTL)
        return data

    def get_tv(self, tvdb_id):
        tvdb_id = str(tvdb_id or '').strip()
        if not tvdb_id or tvdb_id in ('0', 'None'):
            return None
        cache_key = f'tv/tvdb/{tvdb_id}'
        url = f'{self.BASE}/tv/{tvdb_id}'
        return self._cached_get(cache_key, url)

    def get_movie(self, tmdb_id):
        tmdb_id = str(tmdb_id or '').strip()
        if not tmdb_id or tmdb_id in ('0', 'None'):
            return None
        cache_key = f'movie/tmdb/{tmdb_id}'
        url = f'{self.BASE}/movies/{tmdb_id}'
        return self._cached_get(cache_key, url)


fanart = FanartApi()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file podnapisi.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Podnapisi.net subtitle search + download (OpenSubtitles fallback).'''

from __future__ import annotations

import json
import zipfile
from io import BytesIO
from urllib.parse import urlencode

from ..modules import client
from ..modules.classy import c

BASE_URL = 'https://www.podnapisi.net'
SEARCH_URL = '%s/subtitles/search/advanced' % BASE_URL
USER_AGENT = 'TheCrew-Podnapisi/%s' % c.version
TIMEOUT = 28

# ISO 639-1 for Podnapisi (from Classy LANG_DICT / OpenSubtitles codes).
_LANG_TO_POD = {
    'eng': 'en', 'en': 'en',
    'dut': 'nl', 'nld': 'nl', 'nl': 'nl',
    'ger': 'de', 'deu': 'de', 'de': 'de',
    'fre': 'fr', 'fra': 'fr', 'fr': 'fr',
    'spa': 'es', 'es': 'es',
    'ita': 'it', 'it': 'it',
    'por': 'pt', 'pt': 'pt',
    'pb': 'pt-br', 'pob': 'pt-br',
    'rus': 'ru', 'ru': 'ru',
    'pol': 'pl', 'pl': 'pl',
    'ara': 'ar', 'ar': 'ar',
    'chi': 'zh', 'zho': 'zh', 'zh': 'zh',
    'jpn': 'ja', 'ja': 'ja',
    'kor': 'ko', 'ko': 'ko',
    'tur': 'tr', 'tr': 'tr',
}


def fallback_enabled():
    return str(c.get_setting('subtitles.fallback_podnapisi') or 'true').lower() in ('true', '1')


def _pod_lang_codes(languages):
    codes = []
    for lang in languages or []:
        key = str(lang or '').lower().strip()
        if not key:
            continue
        code = _LANG_TO_POD.get(key)
        if not code and len(key) == 2:
            code = key
        if not code and len(key) >= 3:
            code = _LANG_TO_POD.get(key[:3])
        if code and code not in codes:
            codes.append(code)
    return codes


def _build_url(params):
    return '%s?%s' % (SEARCH_URL, urlencode(params, doseq=True))


def _search(params):
    url = _build_url(params)
    try:
        resp = client.api_request(
            'podnapisi',
            url,
            method='GET',
            headers={'Accept': 'application/json', 'User-Agent': USER_AGENT},
            timeout=TIMEOUT,
        )
        if not resp.ok or not resp.body:
            c.log(f'[Podnapisi] search HTTP {getattr(resp, "status", "?")}', 1)
            return []
        body = resp.body
        if isinstance(body, bytes):
            body = body.decode('utf-8', errors='replace')
        data = json.loads(body)
        if not isinstance(data, dict):
            return []
        rows = data.get('data') or []
        return rows if isinstance(rows, list) else []
    except Exception as exc:
        c.log(f'[Podnapisi] search failed: {exc}', 1)
        return []


def _row_id(row):
    return row.get('id') or row.get('publish_id')


def _pick_best(rows, preferred_langs):
    preferred = _pod_lang_codes(preferred_langs)
    if not preferred:
        preferred = ['en']

    def score(row):
        lang = (row.get('language') or '').lower()
        flags = row.get('flags') or []
        hi = 1 if 'hearing_impaired' in flags else 0
        try:
            lang_rank = preferred.index(lang)
        except ValueError:
            lang_rank = len(preferred) + 1
        downloads = int(row.get('download_count') or row.get('downloads') or 0)
        return (lang_rank, hi, -downloads)

    candidates = [r for r in rows if _row_id(r)]
    if not candidates:
        return None
    candidates.sort(key=score)
    return candidates[0]


def _extract_zip(content):
    if not content or not isinstance(content, (bytes, bytearray)):
        return content
    if content[:2] != b'PK':
        return content
    try:
        with zipfile.ZipFile(BytesIO(content)) as archive:
            names = archive.namelist()
            if not names:
                return None
            return archive.read(names[0])
    except Exception as exc:
        c.log(f'[Podnapisi] zip extract failed: {exc}', 1)
        return None


def _download(publish_id):
    if not publish_id:
        return None
    url = '%s/subtitles/%s/download?%s' % (
        BASE_URL,
        publish_id,
        urlencode({'container': 'zip'}),
    )
    try:
        resp = client.api_request(
            'podnapisi',
            url,
            method='GET',
            headers={'User-Agent': USER_AGENT},
            timeout=TIMEOUT,
        )
        if not resp.ok:
            c.log(f'[Podnapisi] download HTTP {getattr(resp, "status", "?")}', 1)
            return None
        body = resp.body
        if isinstance(body, str):
            body = body.encode('utf-8')
        return _extract_zip(body)
    except Exception as exc:
        c.log(f'[Podnapisi] download failed: {exc}', 1)
        return None


def fetch_best(
    languages,
    *,
    mediatype='episode',
    title='',
    tvshowtitle='',
    year='',
    season=None,
    episode=None,
):
    '''
    Search Podnapisi and return (content_bytes, lang_code) or None.
    languages: Classy/OS style codes (eng, dut, ...) in priority order.
    '''
    if not fallback_enabled():
        return None

    pod_langs = _pod_lang_codes(languages)
    if not pod_langs:
        return None

    mt = (mediatype or 'movie').lower()
    year_int = str(year or '').strip()

    if mt == 'episode':
        keywords = (tvshowtitle or title or '').strip()
        if not keywords:
            return None
        try:
            s = int(season or 0)
            e = int(episode or 0)
        except (TypeError, ValueError):
            return None
        if s <= 0 or e <= 0:
            return None
        label = '%s S%02dE%02d' % (keywords, s, e)
        base_params = {
            'keywords': keywords,
            'seasons': str(s),
            'episodes': str(e),
            'movie_type': ['tv-series', 'mini-series'],
        }
        if year_int.isdigit() and int(year_int) > 1900:
            base_params['year'] = year_int
    else:
        keywords = (title or '').strip()
        if not keywords:
            return None
        label = keywords
        base_params = {
            'keywords': keywords,
            'movie_type': 'movie',
        }
        if year_int.isdigit() and int(year_int) > 1900:
            base_params['year'] = year_int

    c.log(f'[Podnapisi] search {label} langs={",".join(pod_langs)}')

    # Podnapisi returns empty when multiple languages are comma-combined; try in order.
    for lang in pod_langs:
        params = dict(base_params)
        params['language'] = lang
        rows = _search(params)
        if not rows:
            continue

        best = _pick_best(rows, [lang])
        if not best:
            continue

        publish_id = _row_id(best)
        picked_lang = (best.get('language') or lang).lower()
        c.log(f'[Podnapisi] picked id={publish_id} lang={picked_lang}')
        content = _download(publish_id)
        if content:
            return content, picked_lang

    c.log('[Podnapisi] no results')
    return None

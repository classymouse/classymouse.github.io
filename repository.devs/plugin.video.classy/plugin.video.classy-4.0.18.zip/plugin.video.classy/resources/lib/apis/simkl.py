# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file simkl.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl API  -  PIN auth + authenticated requests for Classy tracker.

Tokens never expire (unlike Trakt). Expand sync/scrobble in later phases.'''

from __future__ import annotations

import threading
import time

from ..modules import keys
from ..modules import msg_handler
from ..modules.classy import c
from .base import build_url, request_json

APP_NAME = 'The Crew'
PIN_PAGE = 'https://simkl.com/pin/'


def _app_version():
    try:
        return str(c.version or '4.0.2')
    except Exception:
        return '4.0.2'


def user_agent():
    return f'{APP_NAME}/{_app_version()} Kodi'


def get_client_id():
    try:
        override = (c.get_setting('simkl.client_id') or '').strip()
        if override:
            return override
    except Exception:
        pass
    return keys.simkl_id


def required_params(extra=None):
    params = {
        'client_id': get_client_id(),
        'app-name': APP_NAME,
        'app-version': _app_version(),
    }
    if extra:
        params.update(extra)
    return params


class SimklApi:
    BASE = 'https://api.simkl.com'
    CDN = 'https://data.simkl.in'

    _post_lock = threading.Lock()
    _last_post_time = 0.0
    _POST_MIN_INTERVAL = 1.05

    def __init__(self):
        self.client_id = get_client_id()

    def _headers(self, *, with_auth=True, token=None):
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': user_agent(),
            'simkl-api-key': get_client_id(),
        }
        if with_auth:
            tok = (token if token is not None else (c.get_setting('simkl.token') or '')).strip()
            if tok:
                headers['Authorization'] = f'Bearer {tok}'
        return headers

    def _throttle_post(self):
        with self._post_lock:
            now = time.time()
            wait = self._POST_MIN_INTERVAL - (now - self._last_post_time)
            if wait > 0:
                time.sleep(wait)
            self._last_post_time = time.time()

    def get(self, path, params=None, base=None, *, with_auth=True, token=None, timeout=30):
        url = build_url(base or self.BASE, path, required_params(params))
        return request_json(
            msg_handler.API_SIMKL,
            url,
            headers=self._headers(with_auth=with_auth, token=token),
            timeout=timeout,
        )

    def post(self, path, params=None, json_body=None, base=None, *, with_auth=True, token=None, timeout=30, pin_only=False):
        self._throttle_post()
        if pin_only:
            url = build_url(base or self.BASE, path, {'client_id': get_client_id()})
        else:
            url = build_url(base or self.BASE, path, required_params(params))
        return request_json(
            msg_handler.API_SIMKL,
            url,
            method='POST',
            headers=self._headers(with_auth=with_auth, token=token),
            json_body=json_body if json_body is not None else {},
            timeout=timeout,
        )

    def request_pin(self):
        '''POST /oauth/pin  -  returns user_code, expires_in, interval.'''
        from ..modules import client

        url = build_url(self.BASE, '/oauth/pin', {'client_id': get_client_id()})
        resp = client.api_request(
            msg_handler.API_SIMKL,
            url,
            method='POST',
            headers={'User-Agent': user_agent(), 'Content-Type': 'application/json'},
            json_body={},
            timeout=30,
        )
        if not resp.ok or not resp.body:
            c.log(f'[Simkl API] PIN request failed status={getattr(resp, "status", "?")}', 1)
            return None
        try:
            import json
            return json.loads(resp.body)
        except Exception as exc:
            c.log(f'[Simkl API] PIN JSON parse failed: {exc}', 1)
            return None

    def poll_pin(self, user_code):
        '''GET /oauth/pin/{code}  -  returns parsed dict or None (pending/error).'''
        from ..modules import client
        import json

        url = build_url(self.BASE, f'/oauth/pin/{user_code}', {'client_id': get_client_id()})
        resp = client.api_request(
            msg_handler.API_SIMKL,
            url,
            method='GET',
            headers={'User-Agent': user_agent()},
            timeout=10,
        )
        if not resp.ok or not resp.body:
            return None
        try:
            return json.loads(resp.body)
        except Exception:
            return None

    def fetch_username(self, token):
        data = self.get('/users/settings', with_auth=True, token=token, timeout=15)
        if not isinstance(data, dict):
            return ''
        user = data.get('user') if isinstance(data.get('user'), dict) else data
        if not isinstance(user, dict):
            return ''
        return (user.get('name') or user.get('username') or '').strip()

    def ping(self):
        '''Lightweight CDN trending call  -  no user token.'''
        return self.get(
            '/discover/trending/movies/today_100.json',
            base=self.CDN,
            with_auth=False,
        )

    # --- Sync / library -----------------------------------------------------

    def get_last_activities(self):
        return self.post('/sync/activities', json_body={})

    def get_all_items(
        self,
        media_type='',
        status='',
        extended=None,
        date_from=None,
        phase1_initial=False,
        episode_watched_at=False,
        include_all_episodes=False,
        next_watch_info=False,
    ):
        if not phase1_initial and not date_from:
            c.log(
                '[Simkl API] get_all_items refused  -  need date_from or phase1_initial=True',
                1,
            )
            return None
        endpoint = '/sync/all-items'
        if media_type:
            endpoint = f'{endpoint}/{media_type}'
            if status:
                endpoint = f'{endpoint}/{status}'
        params = {}
        if extended:
            params['extended'] = extended
        if date_from:
            params['date_from'] = date_from
        if episode_watched_at:
            params['episode_watched_at'] = 'yes'
        if include_all_episodes:
            params['include_all_episodes'] = 'yes'
        if next_watch_info:
            params['next_watch_info'] = 'yes'
        return self.get(endpoint, params=params or None)

    def get_items_by_status(self, media_type, status, **kwargs):
        return self.get_all_items(media_type=media_type, status=status, **kwargs)

    def add_to_watchlist(self, movies=None, shows=None, status='plantowatch'):
        data = {}
        if movies:
            data['movies'] = [dict(m, to=status) for m in movies]
        if shows:
            data['shows'] = [dict(s, to=status) for s in shows]
        return self.post('/sync/add-to-list', json_body=data) if data else None

    def add_to_history(self, movies=None, shows=None, episodes=None):
        data = {}
        if movies:
            data['movies'] = movies
        if shows:
            data['shows'] = shows
        if episodes:
            data['episodes'] = episodes
        return self.post('/sync/history', json_body=data) if data else None

    def remove_from_history(self, movies=None, shows=None, episodes=None):
        data = {}
        if movies:
            data['movies'] = movies
        if shows:
            data['shows'] = shows
        if episodes:
            data['episodes'] = episodes
        return self.post('/sync/history/remove', json_body=data) if data else None

    def remove_from_list(self, movies=None, shows=None):
        return self.remove_from_history(movies=movies, shows=shows)

    def get_ratings(self, media_type='movies', date_from=None):
        params = {'type': media_type}
        if date_from:
            params['date_from'] = date_from
        return self.get('/sync/ratings', params=params)

    def add_rating(self, movies=None, shows=None):
        data = {}
        if movies:
            data['movies'] = movies
        if shows:
            data['shows'] = shows
        return self.post('/sync/ratings', json_body=data) if data else None

    def remove_rating(self, movies=None, shows=None):
        data = {}
        if movies:
            data['movies'] = movies
        if shows:
            data['shows'] = shows
        return self.post('/sync/ratings/remove', json_body=data) if data else None

    def get_playback(self, media_type=''):
        endpoint = '/sync/playback'
        mt = str(media_type or '').strip().lower()
        if mt in ('movie', 'movies'):
            endpoint = f'{endpoint}/movies'
        elif mt in ('episode', 'episodes'):
            endpoint = f'{endpoint}/episodes'
        return self.get(endpoint)

    def delete_playback(self, playback_id):
        from ..modules import client

        if not playback_id:
            return False
        url = build_url(self.BASE, f'/sync/playback/{playback_id}', required_params())
        resp = client.api_request(
            msg_handler.API_SIMKL,
            url,
            method='DELETE',
            headers=self._headers(with_auth=True),
            timeout=30,
        )
        return bool(resp.ok or getattr(resp, 'status', 0) in (204, 404))

    def scrobble_start(self, media_obj, progress):
        return self.post('/scrobble/start', json_body=dict(media_obj, progress=progress))

    def scrobble_pause(self, media_obj, progress):
        return self.post('/scrobble/pause', json_body=dict(media_obj, progress=progress))

    def scrobble_stop(self, media_obj, progress):
        return self.post('/scrobble/stop', json_body=dict(media_obj, progress=progress))

    @staticmethod
    def build_movie_obj(title='', year=0, imdb='', tmdb=0):
        ids = {}
        if imdb:
            ids['imdb'] = imdb
        if tmdb:
            try:
                ids['tmdb'] = int(tmdb)
            except (TypeError, ValueError):
                pass
        obj = {'ids': ids}
        if title:
            obj['title'] = title
        if year:
            try:
                obj['year'] = int(year)
            except (TypeError, ValueError):
                pass
        return obj

    @staticmethod
    def build_show_obj(title='', year=0, imdb='', tmdb=0, tvdb=0):
        ids = {}
        if imdb:
            ids['imdb'] = imdb
        if tmdb:
            try:
                ids['tmdb'] = int(tmdb)
            except (TypeError, ValueError):
                pass
        if tvdb:
            try:
                ids['tvdb'] = int(tvdb)
            except (TypeError, ValueError):
                pass
        obj = {'ids': ids}
        if title:
            obj['title'] = title
        if year:
            try:
                obj['year'] = int(year)
            except (TypeError, ValueError):
                pass
        return obj


simkl = SimklApi()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file wetrakr.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr API client (device OAuth, sync, discover, calendars, scrobble).

XOR watch-tracker home when Tracking service = WeTrakr. Also used as
scrobble sidecar when home is Trakt/Simkl. Defers scrobble when
script.wetrakr is installed, enabled, and authorised.

Last audited changelog tip: API_DOC_VERSION (see api.wetrakr.com/#/changelog).
'''

from __future__ import annotations

import json
import os
import threading
import time
import traceback
from urllib.parse import quote

import xbmc
import xbmcaddon
import xbmcgui

from ..modules.classy import c
from ..modules import client, control, kodi, keys

BASE_URL = 'https://api.wetrakr.com'
# Tip of https://api.wetrakr.com/#/changelog last coded against.
API_DOC_VERSION = '1.0.10'
APP_UA = 'TheCrew-WeTrakr/%s' % c.version
CLIENT_ID = (keys.wetrakr_id or '').strip()

ABOUT_TEXT = (
    '[B]About WeTrakr[/B][CR][CR]'
    'Tracking and scrobble data in The Crew can come from the '
    '[B]WeTrakr[/B] service and API (wetrakr.com).[CR][CR]'
    '[B]Credit[/B][CR]'
    'WeTrakr is developed by Alberto and the WeTrakr team.[CR]'
    'This add-on uses the WeTrakr API under their Terms of Use.[CR][CR]'
    '[B]Attribution[/B][CR]'
    'Kodi list screens cannot show a live link on every row. '
    'Credit for WeTrakr data is given here, in Settings  ->  Accounts  ->  '
    'About WeTrakr, and via the WeTrakr logo where shown.[CR][CR]'
    'Website: [B]https://wetrakr.com[/B][CR]'
    'API docs: [B]https://api.wetrakr.com[/B][CR][CR]'
    '[B]In The Crew[/B][CR]'
    'Set [B]Watch home[/B] to WeTrakr for ticks, resume, Next Episodes, and '
    'watchlist. Or keep Trakt/Simkl as home and use WeTrakr under '
    '[B]Also send watches[/B] for scrobble-only.[CR][CR]'
    'If the official [B]script.wetrakr[/B] add-on is enabled and authorised, '
    'disable it when The Crew should own WeTrakr scrobbling.'
)

_OFFICIAL_ID = 'script.wetrakr'
_scrobbled_session = False
_skip_logged = False
_last_seek_point = None
_REFRESH_LOCK = threading.Lock()


def _icon():
    try:
        art = c.get_art_path()
        path = os.path.join(art, 'wetrakr.png')
        if os.path.isfile(path):
            return path
    except Exception:
        pass
    return c.addon_icon()


def _client_id():
    return CLIENT_ID


def _token():
    token = (c.get_setting('wetrakr.token') or '').strip()
    if token in ('', '0', 'empty_setting'):
        return ''
    return token


def _refresh_token():
    token = (c.get_setting('wetrakr.refresh') or '').strip()
    if token in ('', '0', 'empty_setting'):
        return ''
    return token


def _expires_at():
    try:
        return float(c.get_setting('wetrakr.expires') or 0)
    except (TypeError, ValueError):
        return 0.0


def has_credentials():
    return bool(_token())


def scrobble_enabled():
    return c.get_setting('wetrakr.scrobble') == 'true'


def _min_progress():
    '''min_progress query for /scrobble/* (1.0.10).

    % at/above which a play counts as finished. Sourced from the global
    playback.watched_percent (resume_progress_max) and clamped 50-100.'''
    try:
        from ..progress import filters as slot_filters
        value = int(round(slot_filters.resume_progress_max()))
    except Exception:
        value = 90
    return max(50, min(100, value))


def scrobble_threshold():
    '''Deprecated 1.0.10: alias of resume_progress_max() (min_progress source).

    The standalone 'wetrakr.scrobble_threshold' slider is retired; the global
    playback.watched_percent now feeds min_progress on scrobble events.'''
    return _min_progress()


def _addon_enabled(addon_id):
    try:
        if not xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
            return False
        return bool(xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon_id))
    except Exception:
        return False


def official_addon_owns_scrobble():
    try:
        if not _addon_enabled(_OFFICIAL_ID):
            return False
        try:
            inst = xbmcaddon.Addon(_OFFICIAL_ID)
            ext_token = str(inst.getSetting('api_token') or '').strip()
        except Exception:
            ext_token = ''
        if not ext_token:
            return False
        try:
            track_watched = str(inst.getSetting('track_watched') or 'true').lower()
            track_playing = str(inst.getSetting('track_playing') or 'true').lower()
            if track_watched in ('false', '0') and track_playing in ('false', '0'):
                return False
        except Exception:
            pass
        return True
    except Exception as exc:
        c.log(f'[WeTrakr] official addon check failed: {exc}', 1)
        return False


def active_home_is_wetrakr():
    '''True when the XOR watch tracker is WeTrakr  -  backend owns scrobble then.'''
    try:
        from .. import tracker
        return tracker.active_service() == tracker.TRACKER_WETRAKR
    except Exception:
        return False


def should_scrobble():
    global _skip_logged
    if not has_credentials() or not scrobble_enabled():
        return False
    # When WeTrakr is the home tracker, the tracker backend sends /scrobble/*.
    # Suppress the sidecar path so events are not sent twice.
    if active_home_is_wetrakr():
        return False
    if official_addon_owns_scrobble():
        if not _skip_logged:
            c.log('[WeTrakr] scrobble skipped  -  script.wetrakr enabled & authorised')
            _skip_logged = True
        return False
    _skip_logged = False
    return True


def _parse_int(value):
    if value in (None, '', 'None', 'empty_setting', 0, '0'):
        return None
    try:
        result = int(value)
        return result if result > 0 else None
    except Exception:
        return None


def _oauth_headers():
    return {
        'Content-Type': 'application/json',
        'User-Agent': APP_UA,
        'wetrakr-api-version': '1',
    }


def _api_headers(token=None):
    headers = _oauth_headers()
    client_id = _client_id()
    if client_id:
        headers['wetrakr-api-key'] = client_id
    access = token if token is not None else _token()
    if access:
        headers['Authorization'] = 'Bearer %s' % access
    return headers


def _save_grant(data, username=None):
    access = (data.get('access_token') or '').strip()
    if not access:
        return False
    refresh = (data.get('new_refresh_token') or data.get('refresh_token') or '').strip()
    try:
        expires_in = int(data.get('expires_in') or 604800)
    except (TypeError, ValueError):
        expires_in = 604800
    c.set_setting('wetrakr.token', access)
    if refresh:
        c.set_setting('wetrakr.refresh', refresh)
    c.set_setting('wetrakr.expires', str(int(time.time()) + max(120, expires_in) - 120))
    if username:
        c.set_setting('wetrakr.user', str(username))
    elif data.get('username'):
        c.set_setting('wetrakr.user', str(data.get('username')))
    return True


def _clear_grant():
    c.set_setting('wetrakr.user', '')
    c.set_setting('wetrakr.token', '')
    c.set_setting('wetrakr.refresh', '')
    c.set_setting('wetrakr.expires', '0')


def _grant_expiring():
    expires = _expires_at()
    if expires <= 0:
        return False
    return time.time() >= expires


def _response_error_code(resp):
    '''Parse WeTrakr JSON error.code / error string from an HttpResponse.'''
    if resp is None:
        return ''
    body = getattr(resp, 'body', None)
    if not body:
        return ''
    try:
        data = json.loads(body) if isinstance(body, (str, bytes)) else body
    except Exception:
        return ''
    if not isinstance(data, dict):
        return ''
    err = data.get('error')
    if isinstance(err, dict):
        return str(err.get('code') or err.get('error') or '').strip().upper()
    if isinstance(err, str):
        return err.strip().upper()
    return str(data.get('code') or '').strip().upper()


def try_refresh_access_token(force=False):
    '''Trade refresh token for a new access token (rotated refresh).

    1.0.6+: dead refresh answers 401 INVALID_REFRESH_TOKEN (was 400). Clear the
    grant so we stop retry loops and the user re-authorises.
    '''
    refresh = _refresh_token()
    if not refresh:
        return False
    with _REFRESH_LOCK:
        if not force and _token() and not _grant_expiring():
            return True
        try:
            resp = client.api_request(
                'wetrakr',
                '%s/oauth/token/refresh' % BASE_URL.rstrip('/'),
                method='POST',
                headers=_oauth_headers(),
                json_body={'refresh_token': refresh},
                timeout=15,
            )
            if not resp.ok or not resp.body:
                status = getattr(resp, 'status', None)
                code = _response_error_code(resp)
                c.log(
                    f'[WeTrakr] refresh failed HTTP {status or "?"} code={code or "-"}',
                    1,
                )
                if status in (401, 403) or code in (
                    'INVALID_REFRESH_TOKEN',
                    'TOKEN_REVOKED',
                    'INVALID_TOKEN',
                ):
                    _clear_grant()
                    c.log('[WeTrakr] cleared grant  -  refresh token unusable', 1)
                return False
            data = json.loads(resp.body) if isinstance(resp.body, (str, bytes)) else resp.body
            if not isinstance(data, dict) or not data.get('access_token'):
                c.log('[WeTrakr] refresh failed: no access token', 1)
                return False
            return _save_grant(data)
        except Exception as exc:
            c.log(f'[WeTrakr] refresh error: {exc}', 1)
            return False


def _ensure_access_token():
    if _token() and not _grant_expiring():
        return True
    return try_refresh_access_token(force=False)


def _scrobble_body(media_type, tmdb_id, percent, season=None, episode=None, title='', year=None):
    try:
        progress = float(percent or 0)
    except Exception:
        progress = 0.0
    tid = _parse_int(tmdb_id)
    if not tid:
        return None
    year_int = _parse_int(year)
    if year_int in (0, 2050):
        year_int = None
    if media_type == 'movie':
        movie = {'ids': {'tmdb': tid}}
        if title:
            movie['title'] = title
        if year_int:
            movie['year'] = year_int
        body = {'movie': movie}
    else:
        show = {'ids': {'tmdb': tid}}
        if title:
            show['title'] = title
        if year_int:
            show['year'] = year_int
        body = {
            'show': show,
            'episode': {
                'season': int(season or 0),
                'number': int(episode or 0),
            },
        }
    body['progress'] = round(progress, 1)
    body['app_version'] = c.version
    return body


def interpret_scrobble_response(resp, action='scrobble'):
    '''Classify a /scrobble/* response.

    Returns (ok, ignored, reason). 404 / ignored:true are soft no-ops (not hard fail).
    '''
    if resp is None:
        return False, False, 'no response'
    status = getattr(resp, 'status', None)
    body = getattr(resp, 'body', None)
    data = None
    if body:
        try:
            data = json.loads(body) if isinstance(body, (str, bytes)) else body
        except Exception:
            data = None
    if not isinstance(data, dict):
        data = {}
    if status == 404:
        c.log(f'[WeTrakr Scrobble] {action} 404  -  title unresolved', 1)
        return False, True, 'not_found'
    if resp.ok:
        if data.get('ignored') is True:
            reason = str(data.get('reason') or 'ignored').strip() or 'ignored'
            c.log(f'[WeTrakr Scrobble] {action} ignored ({reason})')
            return True, True, reason
        return True, False, ''
    code = _response_error_code(resp)
    c.log(f'[WeTrakr Scrobble] {action} HTTP {status or "?"} code={code or "-"}', 1)
    return False, False, code or str(status or 'error')


def _cancel_playing_identity(media_type, tmdb_id, season=None, episode=None, title='', year=None):
    '''Scrobble identity body for DELETE /scrobble/playing (no progress / app_version).'''
    body = _scrobble_body(media_type, tmdb_id, 0, season, episode, title, year)
    if not body:
        return None
    body.pop('progress', None)
    body.pop('app_version', None)
    return body


def _cancel_playing_response_ok(resp, *, labeled=''):
    '''True when cancel succeeded or the playing row is already gone.'''
    if resp is None:
        return False
    status = getattr(resp, 'status', None)
    if resp.ok:
        return True
    # Already cleared / unresolved title  -  treat as success for CM clear-resume.
    if status == 404:
        return True
    body = getattr(resp, 'body', None)
    data = None
    if body:
        try:
            data = json.loads(body) if isinstance(body, (str, bytes)) else body
        except Exception:
            data = None
    if isinstance(data, dict) and (
        data.get('_missing') is True or data.get('ignored') is True
    ):
        return True
    if labeled:
        c.log(f'[WeTrakr Scrobble] cancel HTTP {status or "?"} ({labeled})', 1)
    else:
        c.log(f'[WeTrakr Scrobble] cancel HTTP {status or "?"}', 1)
    return False


def cancel_playing(media_type=None, tmdb_id=None, season=None, episode=None,
                   title='', year=None):
    '''DELETE /scrobble/playing  -  abandon without logging a play (1.0.2+).

    With tmdb_id: cancel that title's playing / resume row (CM Clear Resume).
    Without ids: cancel whatever session the token currently has.
    '''
    if not _client_id() or not _ensure_access_token():
        return False
    body = None
    label = ''
    if tmdb_id:
        kind = (media_type or '').lower()
        if kind not in ('movie', 'episode'):
            kind = 'episode' if season not in (None, '', 0, '0') else 'movie'
        body = _cancel_playing_identity(
            kind, tmdb_id, season=season, episode=episode, title=title, year=year,
        )
        if not body:
            c.log('[WeTrakr Scrobble] cancel skipped  -  no tmdb identity', 1)
            return False
        if kind == 'episode':
            label = f'{kind} S{int(season or 0):02d}E{int(episode or 0):02d} tmdb={tmdb_id}'
        else:
            label = f'{kind} tmdb={tmdb_id}'
    url = '%s/scrobble/playing' % BASE_URL.rstrip('/')
    try:
        resp = client.api_request(
            'wetrakr',
            url,
            method='DELETE',
            headers=_api_headers(),
            json_body=body,
            timeout=12,
        )
        if _cancel_playing_response_ok(resp, labeled=label):
            c.log(
                f'[WeTrakr Scrobble] cancel playing'
                + (f' {label}' if label else ''),
            )
            return True
        if getattr(resp, 'status', None) in (401, 403) and try_refresh_access_token(force=True):
            resp = client.api_request(
                'wetrakr',
                url,
                method='DELETE',
                headers=_api_headers(),
                json_body=body,
                timeout=12,
            )
            if _cancel_playing_response_ok(resp, labeled=label):
                c.log(
                    f'[WeTrakr Scrobble] cancel playing'
                    + (f' {label}' if label else ''),
                )
                return True
        return False
    except Exception as exc:
        c.log(f'[WeTrakr Scrobble] cancel error: {exc}', 1)
    return False


def _post_scrobble(action, media_type, progress=0, title='', year=None, tmdb_id=None,
                   season=None, episode=None, show_title=None):
    if not should_scrobble():
        return False
    if not _client_id():
        c.log('[WeTrakr] missing app client_id')
        return False
    if not _ensure_access_token():
        c.log('[WeTrakr] no usable access token  -  re-authorise')
        return False
    if action == 'cancel':
        return cancel_playing()
    path = {
        'start': '/scrobble/start',
        'pause': '/scrobble/pause',
        'stop': '/scrobble/stop',
        'progress': '/scrobble/start',
    }.get(action)
    if not path:
        return False
    # Episodes: Red Light uses show title on the show object.
    label = show_title if media_type == 'episode' and show_title else title
    body = _scrobble_body(media_type, tmdb_id, progress, season, episode, label, year)
    if not body:
        c.log(f'[WeTrakr] Skip {action}: no tmdb for {title or media_type}')
        return False
    # 1.0.10: pass min_progress (finished threshold) on scrobble events.
    from .base import build_url
    url = build_url(BASE_URL, path, {'min_progress': _min_progress()})
    try:
        resp = client.api_request(
            'wetrakr',
            url,
            method='POST',
            headers=_api_headers(),
            json_body=body,
            timeout=12,
        )
        ok, _ignored, _reason = interpret_scrobble_response(resp, action)
        if ok and not _ignored:
            c.log(f'[WeTrakr Scrobble] {action} {media_type} {body.get("progress", 0):.0f}%')
            return True
        if ok:
            return True
        if getattr(resp, 'status', None) in (401, 403) and try_refresh_access_token(force=True):
            resp = client.api_request(
                'wetrakr',
                url,
                method='POST',
                headers=_api_headers(),
                json_body=body,
                timeout=12,
            )
            ok, _ignored, _reason = interpret_scrobble_response(resp, action)
            if ok and not _ignored:
                c.log(f'[WeTrakr Scrobble] {action} {media_type} {body.get("progress", 0):.0f}%')
            return ok
        return False
    except Exception as exc:
        c.log(f'[WeTrakr] {action} error: {exc}')
    return False


def send_event_async(action, media_type, **kwargs):
    threading.Thread(
        target=_post_scrobble,
        args=(action, media_type),
        kwargs=kwargs,
        daemon=True,
    ).start()


# ---------------------------------------------------------------------------
# Authenticated sync helpers  -  shared by the tracker backend (resources.lib.wetrakr).
# msg_handler auto-refreshes on 401/403 (REFRESH_AUTH) then retries once.
# ---------------------------------------------------------------------------

# Home widgets each run in their own LanguageInvoker process  -  threading
# locks do not span them. Cooldown lives on Window(10000) + disk so it
# survives Kodi restart (Window props die on exit; probing while server-banned
# just extends the ban  -  see 17:54 storm -> 18:20 immediate 429).
_RATE_LOCK = threading.Lock()
_RATE_LIMIT_UNTIL = 0.0
_RATE_LIMIT_PROP = 'thecrew.wetrakr.rate_limit_until'
_RATE_DISK_NS = 'wetrakr'
_RATE_DISK_KEY = 'rate_limit_v1'
# Live log 2026-11-13: Retry-After: 23716 (~6.6h). Capping client wait to
# 30-60s made ProgressCacheWorker probe early and re-arm the ban.
_RATE_MAX_WAIT = 24 * 60 * 60  # honor long Retry-After (max 24h)
_RATE_MIN_WAIT = 60  # floor when header missing


def _retry_seconds(resp):
    '''Seconds suggested by Retry-After / RateLimit-Reset.

    Retry-After is delay-seconds (seen live at 30, 60, then 23716).
    RateLimit-Reset may be delay-seconds or a unix timestamp.
    '''
    try:
        headers = getattr(resp, 'headers', None) or {}
        retry_after = None
        rate_reset = None
        for key, value in headers.items():
            lk = str(key).lower()
            if lk == 'retry-after':
                retry_after = value
            elif lk == 'ratelimit-reset':
                rate_reset = value
        reset = retry_after if retry_after not in (None, '') else rate_reset
        if reset in (None, ''):
            return _RATE_MIN_WAIT
        val = float(str(reset).strip())
        # Unix epoch (RateLimit-Reset) vs delay-seconds.
        if val > 1e9:
            wait = int(val - time.time())
        else:
            wait = int(val)
        return max(1, min(wait, _RATE_MAX_WAIT))
    except Exception:
        return _RATE_MIN_WAIT


def _home_window():
    return xbmcgui.Window(10000)


def _disk_rate_payload():
    try:
        from .. import cache as disk_cache
        data = disk_cache.get_json(_RATE_DISK_NS, _RATE_DISK_KEY, ttl_ok=False)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_disk_rate(until, strikes):
    try:
        from .. import cache as disk_cache
        disk_cache.put_json(
            _RATE_DISK_NS,
            _RATE_DISK_KEY,
            {
                'until': float(until),
                'strikes': int(strikes),
                'updated_at': time.time(),
            },
            # Keep the row around longer than the cooldown itself.
            ttl_seconds=max(_RATE_MAX_WAIT * 2, float(until) - time.time() + 60),
        )
    except Exception:
        pass


def _rate_limit_remaining():
    '''Seconds left on cooldown (local + Window + disk).'''
    now = time.time()
    local = 0.0
    with _RATE_LOCK:
        local = max(0.0, _RATE_LIMIT_UNTIL - now)
    shared = 0.0
    try:
        raw = _home_window().getProperty(_RATE_LIMIT_PROP)
        if raw:
            shared = max(0.0, float(raw) - now)
    except Exception:
        shared = 0.0
    disk = 0.0
    try:
        payload = _disk_rate_payload()
        disk = max(0.0, float(payload.get('until') or 0) - now)
    except Exception:
        disk = 0.0
    return max(local, shared, disk)


def _mark_rate_limited(seconds):
    '''Stamp cooldown for every LanguageInvoker and across Kodi restarts.

    Honor the server Retry-After as-is (including multi-hour bans). Do not
    invent exponential floors  -  probing early is what climbs the ban.
    '''
    global _RATE_LIMIT_UNTIL
    try:
        wait = max(float(_RATE_MIN_WAIT), float(seconds))
    except (TypeError, ValueError):
        wait = float(_RATE_MIN_WAIT)
    wait = min(wait, float(_RATE_MAX_WAIT))
    until = time.time() + wait

    payload = _disk_rate_payload()
    strikes = int(payload.get('strikes') or 0) + 1

    with _RATE_LOCK:
        _RATE_LIMIT_UNTIL = max(_RATE_LIMIT_UNTIL, until)
    try:
        win = _home_window()
        cur = float(win.getProperty(_RATE_LIMIT_PROP) or 0)
        if until > cur:
            win.setProperty(_RATE_LIMIT_PROP, '%.3f' % until)
    except Exception:
        pass
    _write_disk_rate(until, strikes)
    return wait, strikes


def _clear_rate_limit():
    '''Successful authed call  -  drop strike counter and cooldown stamps.'''
    global _RATE_LIMIT_UNTIL
    with _RATE_LOCK:
        _RATE_LIMIT_UNTIL = 0.0
    try:
        _home_window().clearProperty(_RATE_LIMIT_PROP)
    except Exception:
        pass
    try:
        from .. import cache as disk_cache
        disk_cache.delete(_RATE_DISK_NS, _RATE_DISK_KEY)
    except Exception:
        pass


def is_rate_limited():
    '''True while a prior 429 cooldown is still active (cross-process + disk).'''
    return _rate_limit_remaining() > 0.05


def _notify_locked():
    try:
        from ..modules import kodi
        kodi.notification('WeTrakr', 'This WeTrakr list is over the plan limit', time=4000)
    except Exception:
        pass


def api_raw(method, path, params=None, body=None, user=True, timeout=20, _retried=False):
    '''Low-level request. user=False is app-key only (public calendars / catalog).

    429: stamp Window + disk cooldown (exponential) and soft-fail immediately.
    Do not sleep on GetDirectory  -  Home widgets each own a LanguageInvoker
    and a sleep-retry stampede is what empties the shelves.
    420: returned as a normal HttpResponse (caller / api_json marks _locked).
    '''
    if not _client_id():
        c.log('[WeTrakr] missing app client_id', 1)
        return None

    cool = _rate_limit_remaining()
    if cool > 0.05:
        c.log(
            f'[WeTrakr] rate-limit cooldown ({cool:.0f}s); skip {path}',
            1,
        )
        return None

    token = None
    if user:
        if not _ensure_access_token():
            c.log('[WeTrakr] no usable access token  -  re-authorise', 1)
            return None
        token = _token()
    from .base import build_url
    url = build_url(BASE_URL, path, params)
    try:
        resp = client.api_request(
            'wetrakr',
            url,
            method=(method or 'GET').upper(),
            headers=_api_headers(token=token if user else ''),
            json_body=body,
            timeout=timeout,
        )
    except Exception as exc:
        c.log(f'[WeTrakr] {method} {path} error: {exc}', 1)
        return None

    status = getattr(resp, 'status', None)
    if status == 429:
        header_wait = _retry_seconds(resp)
        wait, strikes = _mark_rate_limited(header_wait)
        # Log raw headers once so we can see what the API actually sent.
        try:
            hdrs = getattr(resp, 'headers', None) or {}
            interesting = {
                str(k): str(v)
                for k, v in hdrs.items()
                if str(k).lower() in (
                    'retry-after', 'ratelimit-reset', 'ratelimit-remaining',
                    'x-ratelimit-reset', 'x-ratelimit-remaining',
                )
            }
        except Exception:
            interesting = {}
        c.log(
            f'[WeTrakr] 429 on {path}; header_wait={header_wait}s '
            f'cooldown={wait:.0f}s strikes={strikes} hdrs={interesting}',
            1,
        )
        return None
    if status and 200 <= int(status) < 300 and user:
        # Only clear after a real success  -  do not clear on 404/420.
        if _disk_rate_payload().get('strikes'):
            _clear_rate_limit()
    if status == 420:
        c.log(f'[WeTrakr] 420 plan lock on {path}', 1)
    try:
        headers = getattr(resp, 'headers', None) or {}
        for hkey, hval in headers.items():
            if str(hkey).lower() == 'wetrakr-deprecation' and hval:
                c.log(
                    f'[WeTrakr] deprecation on {method} {path}: {hval} '
                    f'(API_DOC_VERSION={API_DOC_VERSION})',
                    1,
                )
                break
    except Exception:
        pass
    return resp


def _parse_body(resp):
    if resp is None or not getattr(resp, 'body', None):
        return None
    try:
        if isinstance(resp.body, (str, bytes)):
            return json.loads(resp.body)
        return resp.body
    except Exception as exc:
        c.log(f'[WeTrakr] JSON parse failed: {exc}', 1)
        return None


def api_json(method, path, params=None, body=None, user=True, timeout=20, notify_locked=False):
    '''Request returning parsed JSON (dict/list) or None.

    HTTP 420 -> {'_locked': True} (and optional toast when notify_locked).
    '''
    resp = api_raw(method, path, params=params, body=body, user=user, timeout=timeout)
    if resp is None:
        return None
    status = getattr(resp, 'status', None)
    if status == 420:
        if notify_locked:
            _notify_locked()
        return {'_locked': True}
    if status == 404:
        return {'_missing': True}
    if not resp.ok:
        return None
    return _parse_body(resp)


def api_json_headers(method, path, params=None, body=None, user=True, timeout=20,
                     notify_locked=True):
    '''Like api_json but also returns response headers (for X-Pagination-*).

    Returns (payload, headers). payload may be {'_locked': True} / None.
    '''
    resp = api_raw(method, path, params=params, body=body, user=user, timeout=timeout)
    if resp is None:
        return None, {}
    headers = dict(getattr(resp, 'headers', None) or {})
    status = getattr(resp, 'status', None)
    if status == 420:
        if notify_locked:
            _notify_locked()
        return {'_locked': True}, headers
    if status == 404:
        return {'_missing': True}, headers
    if not resp.ok:
        return None, headers
    return _parse_body(resp), headers


def authed_raw(method, path, params=None, body=None, timeout=20):
    '''Authenticated request  -  returns the HttpResponse (or None).'''
    return api_raw(method, path, params=params, body=body, user=True, timeout=timeout)


def authed_json(method, path, params=None, body=None, timeout=20):
    '''Authenticated request returning parsed JSON (dict/list) or None.'''
    return api_json(method, path, params=params, body=body, user=True, timeout=timeout)


def scrobble_body_for_session(session, percent):
    '''Build a /scrobble/* body from a Classy playback session snapshot.'''
    mediatype, kwargs = _session_kwargs(session, percent)
    label = (
        kwargs.get('show_title')
        if mediatype == 'episode' and kwargs.get('show_title')
        else kwargs.get('title')
    )
    body = _scrobble_body(
        mediatype,
        kwargs.get('tmdb_id'),
        percent,
        kwargs.get('season'),
        kwargs.get('episode'),
        label,
        kwargs.get('year'),
    )
    return mediatype, body


def request_device_code():
    client_id = _client_id()
    if not client_id:
        c.log('[WeTrakr] device/code missing app key', 1)
        return None
    try:
        resp = client.api_request(
            'wetrakr',
            '%s/oauth/device/code' % BASE_URL.rstrip('/'),
            method='POST',
            headers=_oauth_headers(),
            json_body={'client_id': client_id},
            timeout=15,
        )
        if resp.ok and resp.body:
            data = json.loads(resp.body) if isinstance(resp.body, (str, bytes)) else resp.body
            if isinstance(data, dict) and data.get('device_code'):
                return data
        c.log(f'[WeTrakr] device/code HTTP {getattr(resp, "status", "?")}', 1)
    except Exception as exc:
        c.log(f'[WeTrakr] device/code error: {exc}', 1)
    return None


def _poll_device_token(device_code):
    try:
        resp = client.api_request(
            'wetrakr',
            '%s/oauth/device/token' % BASE_URL.rstrip('/'),
            method='POST',
            headers=_oauth_headers(),
            json_body={'code': device_code, 'client_id': _client_id()},
            timeout=12,
        )
        raw = getattr(resp, 'body', None)
        if not raw:
            return {'error': 'http_%s' % getattr(resp, 'status', '?')}
        try:
            data = json.loads(raw) if isinstance(raw, (str, bytes)) else raw
            return data if isinstance(data, dict) else {'error': 'bad_json'}
        except Exception:
            return {'error': 'http_%s' % getattr(resp, 'status', '?')}
    except Exception as exc:
        c.log(f'[WeTrakr] poll error: {exc}', 1)
        return None


def _account_username(token):
    try:
        resp = client.api_request(
            'wetrakr',
            '%s/account/settings' % BASE_URL.rstrip('/'),
            method='GET',
            headers=_api_headers(token=token),
            timeout=20,
        )
        if resp.status in (401, 403):
            return None
        if not resp.ok or not resp.body:
            return ''
        payload = json.loads(resp.body) if isinstance(resp.body, (str, bytes)) else resp.body
        info = payload.get('info') if isinstance(payload, dict) else None
        if not isinstance(info, dict):
            info = {}
        name = info.get('username') or info.get('display_name')
        return str(name) if name else ''
    except Exception as exc:
        c.log(f'[WeTrakr] account read failed: {exc}', 1)
        return ''


def _qr_image_url(data, size=280):
    return (
        f'https://api.qrserver.com/v1/create-qr-code/?data={quote(data)}&size={size}x{size}'
    )


def _auth_url(verification_url, user_code):
    verification_url = (verification_url or 'https://wetrakr.com/activate').rstrip('/')
    if 'code=' in verification_url:
        return verification_url
    if user_code:
        return '%s?code=%s' % (verification_url, user_code)
    return verification_url


def _show_wetrakr_qr_dialog(auth_url, user_code, qr_path, device_code, interval, expires_in):
    try:
        class WeTrakrQRViewer(xbmcgui.WindowXMLDialog):
            def __init__(self, *args, **kwargs):
                self.header = kwargs.get('header', 'WeTrakr Authorisation')
                self.message = kwargs.get('message', '')
                self.qr_path = kwargs.get('qr_path', '') or ''
                self.device_code = kwargs.get('device_code', '')
                self.interval = max(1, int(kwargs.get('interval', 5)))
                self.expires_in = int(kwargs.get('expires_in', 600))
                self.authenticated = False
                self.access_token = ''
                self.refresh_token = ''
                self.expires_in_token = 604800
                self.username = ''
                self.grant = None
                self.polling = True
                self.poll_thread = None

            def onInit(self):
                try:
                    self.getControl(101).setLabel(self.header)
                    self.getControl(502).setText(self.message)
                    if self.qr_path:
                        self.getControl(501).setImage(self.qr_path)
                    self.setFocusId(503)
                    self.poll_thread = threading.Thread(target=self._poll_for_token)
                    self.poll_thread.daemon = True
                    self.poll_thread.start()
                except Exception as exc:
                    c.log(f'[WeTrakr QR] onInit error: {exc}', 1)

            def _request_close(self):
                '''Prefer GUI-thread close  -  worker-thread close() is flaky on V22/noVNC.'''
                try:
                    xbmc.executebuiltin('Action(Close)')
                except Exception:
                    pass
                try:
                    self.close()
                except Exception:
                    pass

            def _poll_for_token(self):
                try:
                    start = time.time()
                    while self.polling and (time.time() - start) < self.expires_in:
                        time.sleep(self.interval)
                        try:
                            data = _poll_device_token(self.device_code)
                            if not isinstance(data, dict):
                                continue
                            token = (data.get('access_token') or '').strip()
                            if token:
                                self.authenticated = True
                                self.access_token = token
                                self.refresh_token = (
                                    data.get('new_refresh_token')
                                    or data.get('refresh_token')
                                    or ''
                                )
                                try:
                                    self.expires_in_token = int(data.get('expires_in') or 604800)
                                except (TypeError, ValueError):
                                    self.expires_in_token = 604800
                                self.grant = data
                                # Username fetch is network  -  do it after modal,
                                # not on the poll thread (kept dialog on Waiting...).
                                self.username = (
                                    data.get('username') or 'WeTrakr User'
                                )
                                try:
                                    self.getControl(502).setText(
                                        'Authorised  -  closing...'
                                    )
                                except Exception:
                                    pass
                                self.polling = False
                                self._request_close()
                                return
                            error = data.get('error') or ''
                            if error == 'expired_token':
                                c.log('[WeTrakr QR] device code expired', 1)
                                self.polling = False
                                self._request_close()
                                return
                            # authorization_pending / slow_down are normal  -  quiet.
                            if error and error not in (
                                'authorization_pending',
                                'slow_down',
                                'http_400',
                            ):
                                c.log(f'[WeTrakr QR] poll: {error}', 1)
                        except Exception as poll_exc:
                            c.log(f'[WeTrakr QR] poll error: {poll_exc}', 1)
                    if self.polling:
                        c.log('[WeTrakr QR] polling timed out', 1)
                        self.polling = False
                        self._request_close()
                except Exception as exc:
                    c.log(f'[WeTrakr QR] polling thread error: {exc}', 1)

            def onAction(self, action):
                if action.getId() in (10, 92):
                    self.polling = False
                    self.close()

            def onClick(self, control_id):
                if control_id == 503:
                    self.polling = False
                    self.close()

        message = (
            f'Scan QR code with your mobile device\n\n'
            f'OR visit:\n{auth_url}\n\n'
            f'Enter code: {user_code}\n\n'
            f'Waiting for authorisation... (expires in {expires_in}s)'
        )
        addon_path, skin = c.resolve_dialog_skin('LogViewer_QR.xml')
        dialog = WeTrakrQRViewer(
            'LogViewer_QR.xml',
            addon_path,
            skin,
            '1080i',
            header='WeTrakr Authorisation',
            message=message,
            qr_path=qr_path or '',
            device_code=device_code,
            interval=interval,
            expires_in=expires_in,
        )
        dialog.doModal()
        authenticated = dialog.authenticated
        grant = dialog.grant or {
            'access_token': dialog.access_token,
            'refresh_token': dialog.refresh_token,
            'expires_in': dialog.expires_in_token,
        }
        username = dialog.username
        dialog.polling = False
        del dialog
        return authenticated, grant, username
    except Exception:
        c.log(f'[WeTrakr] QR dialog failed:\n{traceback.format_exc()}', 1)
        return False, {}, ''


def authenticate(_dummy=''):
    if official_addon_owns_scrobble():
        control.okDialog(
            'The official [B]WeTrakr[/B] Kodi add-on is enabled and authorised.[CR][CR]'
            'The Crew will leave scrobbling to that add-on so events are not sent twice.[CR][CR]'
            'Disable [B]script.wetrakr[/B] if you want The Crew to scrobble instead.',
            heading='WeTrakr',
        )
        return False

    icon = _icon()
    if not _client_id():
        kodi.notification('WeTrakr', 'Missing app key', icon=icon)
        return False

    code_data = request_device_code()
    if not code_data or not code_data.get('device_code'):
        kodi.notification('WeTrakr', 'Authorisation failed', icon=icon)
        return False

    user_code = str(code_data.get('user_code') or '')
    device_code = code_data.get('device_code')
    verification_url = (code_data.get('verification_url') or 'https://wetrakr.com/activate').rstrip('/')
    expires_in = int(code_data.get('expires_in') or 600)
    interval = max(int(code_data.get('interval') or 5), 1)
    auth_url = _auth_url(verification_url, user_code)
    qr_path = _qr_image_url(auth_url, size=280)

    authenticated, grant, username = _show_wetrakr_qr_dialog(
        auth_url, user_code, qr_path, device_code, interval, expires_in,
    )

    if not authenticated or not (grant or {}).get('access_token'):
        kodi.notification('WeTrakr', 'Authorisation failed', icon=icon)
        return False

    token = (grant.get('access_token') or '').strip()
    resolved = _account_username(token) if token else ''
    if resolved:
        username = resolved
    _save_grant(grant, username=username or 'WeTrakr User')
    if c.get_setting('wetrakr.scrobble') not in ('true', 'false'):
        c.set_setting('wetrakr.scrobble', 'true')
    kodi.notification('WeTrakr', 'Account authorised', icon=icon)
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return True


def revoke(_dummy=''):
    token = _token()
    refresh = _refresh_token()
    if token:
        try:
            client.api_request(
                'wetrakr',
                '%s/oauth/logout' % BASE_URL.rstrip('/'),
                method='POST',
                headers=_api_headers(),
                json_body={'refresh_token': refresh} if refresh else {},
                timeout=12,
            )
        except Exception as exc:
            c.log(f'[WeTrakr] logout error: {exc}', 1)
    _clear_grant()
    try:
        from ..wetrakr import store as wt_store
        from ..wetrakr import sync as wt_sync
        wt_sync.invalidate()
        wt_store.clear_watched()
    except Exception:
        pass
    kodi.notification('WeTrakr', 'Authorisation reset', icon=_icon())
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return True


def about(_dummy=''):
    '''Attribution + credits for WeTrakr API Terms (Settings  ->  About WeTrakr).'''
    icon = _icon()
    try:
        from ..wetrakr.about_dialog import show_about_dialog
        if show_about_dialog(logo_path=icon if icon and os.path.isfile(icon) else ''):
            return True
    except Exception as exc:
        c.log(f'[WeTrakr] about dialog failed: {exc}', 1)
    # Fallback: plain okDialog (ASCII credits).
    control.okDialog(ABOUT_TEXT, heading='About WeTrakr')
    return True


def reset_playback_flags():
    global _scrobbled_session, _last_seek_point
    _scrobbled_session = False
    _last_seek_point = None


def _session_kwargs(session, progress):
    mediatype = (session.get('mediatype') or 'movie').lower()
    if mediatype not in ('movie', 'episode'):
        mediatype = 'episode' if session.get('season') else 'movie'
    return mediatype, dict(
        title=session.get('title') or '',
        year=session.get('year') or None,
        tmdb_id=session.get('tmdb') or None,
        season=session.get('season') or None,
        episode=session.get('episode') or None,
        show_title=session.get('tvshowtitle') or None,
        progress=max(0.0, min(100.0, float(progress or 0))),
    )


def tick_progress(_player):
    '''No-op: WeTrakr wants playback events, not a progress timer (Red Light).'''
    return


def handle_playback_scrobble(state, session, current_sec, total_sec):
    '''Map Classy player states -> official /scrobble/* (async, event-only).'''
    global _scrobbled_session, _last_seek_point

    if not should_scrobble():
        if not scrobble_enabled():
            return
        if not has_credentials():
            c.log('[WeTrakr] scrobble skipped  -  not authorised')
        return

    try:
        progress = (float(current_sec) / float(total_sec) * 100.0) if total_sec and total_sec > 0 else 0.0
    except Exception:
        progress = 0.0

    mediatype, kwargs = _session_kwargs(session, progress)

    if state == 'start':
        _scrobbled_session = False
        _last_seek_point = progress
        c.log(f'[WeTrakr] queue start {mediatype} {progress:.0f}%')
        send_event_async('start', mediatype, **kwargs)
        return

    if state == 'pause':
        c.log(f'[WeTrakr] queue pause {mediatype} {progress:.0f}%')
        send_event_async('pause', mediatype, **kwargs)
        return

    if state == 'resume':
        c.log(f'[WeTrakr] queue resume(start) {mediatype} {progress:.0f}%')
        send_event_async('start', mediatype, **kwargs)
        return

    if state == 'seek':
        prev = _last_seek_point
        _last_seek_point = progress
        if prev is not None and abs(progress - float(prev)) < 8:
            return
        c.log(f'[WeTrakr] queue seek(start) {mediatype} {progress:.0f}%')
        send_event_async('start', mediatype, **kwargs)
        return

    # stop / end
    if _scrobbled_session:
        return
    _scrobbled_session = True
    c.log(f'[WeTrakr] queue stop {mediatype} {progress:.0f}%')
    send_event_async('stop', mediatype, **kwargs)

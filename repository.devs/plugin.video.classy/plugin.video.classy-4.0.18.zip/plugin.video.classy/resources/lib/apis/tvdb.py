# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tvdb.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TVDb v3 login + minimal GET (v4 keys use legacy v3 login flow).'''

from ..modules import keys
from ..modules import msg_handler
from ..modules.classy import c
from .base import build_url, request_json


class TvdbApi:
    BASE = 'https://api.thetvdb.com'

    def __init__(self, api_key=None):
        self.api_key = api_key or keys.tvdb_key
        self.token = None

    def login(self):
        url = build_url(self.BASE, '/login')
        headers = {'Content-Type': 'application/json'}
        data = request_json(
            msg_handler.API_TVDB,
            url,
            method='POST',
            headers=headers,
            json_body={'apikey': self.api_key},
        )
        if data and data.get('token'):
            self.token = data['token']
            return True
        c.log('[TvdbApi] login failed', 1)
        return False

    def _auth_headers(self):
        if not self.token and not self.login():
            return None
        return {
            'Authorization': f'Bearer {self.token}',
            'Accept': 'application/json',
        }

    def get_series(self, tvdb_id):
        headers = self._auth_headers()
        if not headers:
            return None
        url = build_url(self.BASE, f'/series/{tvdb_id}')
        return request_json(msg_handler.API_TVDB, url, headers=headers)


tvdb = TvdbApi()

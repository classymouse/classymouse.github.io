# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file base.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Shared helpers for apis/  -  JSON over client.api_request + msg_handler.
'''

import json
from urllib.parse import urlencode

from ..modules.classy import c
from ..modules import client


def build_url(base, path, params=None):
    base = (base or '').rstrip('/')
    path = path or ''
    if path and not path.startswith('/'):
        path = '/' + path
    url = base + path
    if params:
        clean = {k: v for k, v in params.items() if v is not None and v != ''}
        if clean:
            sep = '&' if '?' in url else '?'
            url = url + sep + urlencode(clean)
    return url


def request_json(api, url, method='GET', headers=None, json_body=None, timeout=30):
    resp = client.api_request(
        api,
        url,
        method=method,
        headers=headers,
        json_body=json_body,
        timeout=timeout,
    )
    if not resp.ok:
        if c.is_devmode():
            c.log(f'[Api] {api} HTTP {resp.status} {url} err={resp.error}', 1)
        return None
    if not resp.body:
        return None
    try:
        return json.loads(resp.body)
    except Exception as exc:
        c.log(f'[Api] JSON parse failed {url}: {exc}', 1)
        return None

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tmdb.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB v3  -  thin client (no UI).'''

from ..modules import keys
from ..modules import msg_handler
from ..modules.classy import c
from ..metadata import tmdb_cache
from . import tmdb_paths
from .base import build_url, request_json


class TmdbApi:
    BASE = 'https://api.themoviedb.org/3'
    IMAGE_BASE = 'https://image.tmdb.org/t/p'

    def __init__(self, api_key=None, language=None):
        self.api_key = api_key or keys.tmdb_key
        self.language = language or self._default_language()

    def _default_language(self):
        lang = (c.get_setting('tmdb.lang') or c.get_setting('api.language') or '').strip()
        return lang or 'en-US'

    def _params(self, extra=None):
        params = {'api_key': self.api_key, 'language': self.language}
        if extra:
            params.update(extra)
        return params

    def get(self, path, params=None):
        extra = dict(params or {})
        key = tmdb_cache.cache_key(path, self.language, extra)
        cached = tmdb_cache.get(key)
        if cached is not None:
            return cached
        url = build_url(self.BASE, path, self._params(params))
        data = request_json(msg_handler.API_TMDB, url)
        if data is not None:
            tmdb_cache.set(key, data)
        return data

    def get_tv(self, tmdb_id, append=None):
        params = {}
        if append:
            params['append_to_response'] = append
        return self.get(tmdb_paths.path('detail', 'tv', tmdb_id=tmdb_id), params)

    def get_tv_season(self, tmdb_id, season, append=None):
        params = {}
        if append:
            params['append_to_response'] = append
        return self.get(
            tmdb_paths.path('season', tmdb_id=tmdb_id, season=season),
            params,
        )

    def get_tv_episode(self, tmdb_id, season, episode, append=None):
        params = {}
        if append:
            params['append_to_response'] = append
        return self.get(
            tmdb_paths.path(
                'episode', tmdb_id=tmdb_id, season=season, episode=episode,
            ),
            params or None,
        )

    def find_external(self, external_id, source='imdb_id'):
        return self.get(
            tmdb_paths.path('find', external_id=external_id),
            {'external_source': source},
        )

    def configuration(self):
        '''Public smoke-test endpoint (no user data).'''
        return self.get(tmdb_paths.path('configuration'))

    def discover_tv(self, params=None):
        return self.get(tmdb_paths.path('discover', 'tv'), params)

    def discover_movie(self, params=None):
        return self.get(tmdb_paths.path('discover', 'movie'), params)

    def trending_tv(self, window='day', params=None):
        return self.get(
            tmdb_paths.path('trending', 'tv', window=window),
            params,
        )

    def list_tv(self, list_name, params=None):
        return self.get(tmdb_paths.path('lists', 'tv', list_name), params)

    def trending_movie(self, window='day', params=None):
        return self.get(
            tmdb_paths.path('trending', 'movie', window=window),
            params,
        )

    def list_movie(self, list_name, params=None):
        return self.get(tmdb_paths.path('lists', 'movie', list_name), params)

    def curated_list(self, list_id, params=None):
        return self.get(tmdb_paths.path('curated_list', list_id=list_id), params)

    def search(self, mediatype, query, page=1):
        mt = (mediatype or 'movie').strip().lower()
        if mt in ('person', 'people'):
            return self.search_person(query, page=page)
        key = 'tv' if mt in ('tv', 'tvshow', 'show', 'tvshows') else 'movie'
        return self.get(
            tmdb_paths.path('search', key),
            {'query': query, 'page': max(1, int(page or 1))},
        )

    def search_person(self, query, page=1):
        return self.get(
            tmdb_paths.path('search', 'person'),
            {'query': query, 'page': max(1, int(page or 1))},
        )

    def trending_person(self, window='day'):
        return self.get(tmdb_paths.path('trending', 'person', window=window))

    def person_movie_credits(self, person_id):
        return self.get(
            tmdb_paths.path('person', 'movie_credits', person_id=int(person_id)),
        )

    def person_tv_credits(self, person_id):
        return self.get(
            tmdb_paths.path('person', 'tv_credits', person_id=int(person_id)),
        )

    def get_movie(self, tmdb_id, append=None):
        params = {}
        if append:
            params['append_to_response'] = append
        return self.get(tmdb_paths.path('detail', 'movie', tmdb_id=tmdb_id), params)

    def similar_movie(self, tmdb_id, params=None):
        extra = dict(params or {})
        return self.get(
            tmdb_paths.path('similar', 'movie', tmdb_id=int(tmdb_id)),
            extra,
        )

    def similar_tv(self, tmdb_id, params=None):
        extra = dict(params or {})
        return self.get(
            tmdb_paths.path('similar', 'tv', tmdb_id=int(tmdb_id)),
            extra,
        )


tmdb = TmdbApi()

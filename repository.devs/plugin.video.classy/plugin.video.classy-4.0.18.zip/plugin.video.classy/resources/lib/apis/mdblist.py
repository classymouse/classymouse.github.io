# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file mdblist.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

MDBList API  -  list provider client (API key). Not a tracker backend.'''

from __future__ import annotations

from ..modules import msg_handler
from ..modules.classy import c
from .base import build_url, request_json

BASE = 'https://api.mdblist.com'


def api_key():
    return (c.get_setting('mdblist.api_key') or '').strip()


def has_credentials():
    return bool(api_key())


class MdblistApi:
    BASE = BASE

    def _params(self, extra=None):
        params = {'apikey': api_key()}
        if extra:
            params.update(extra)
        return params

    def _headers(self):
        # Docs: authenticate via ?apikey= only. Bearer breaks some keys (HTTP 401).
        return {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }

    def get(self, path, params=None, *, timeout=30):
        if not has_credentials():
            return None
        url = build_url(self.BASE, path, self._params(params))
        return request_json(
            msg_handler.API_MDBLIST,
            url,
            headers=self._headers(),
            timeout=timeout,
        )


mdblist = MdblistApi()

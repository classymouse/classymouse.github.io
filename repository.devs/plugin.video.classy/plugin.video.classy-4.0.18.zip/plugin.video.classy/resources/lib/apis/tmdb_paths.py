# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tmdb_paths.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB API v3 path registry  -  templates only, no HTTP.

Use path('detail', 'tv', tmdb_id=123) or path('discover', 'movie').
Query params belong on TmdbApi.get(..., params={...}).

Discover-first policy
---------------------
TMDB has deprecated many "list by X id" sub-routes in favour of discover filters.
Do **not** add paths like /keyword/{id}/movies  -  use discover + params instead.

| Deprecated (do not register)              | Use instead                          |
|-------------------------------------------|--------------------------------------|
| /keyword/{id}/movies                      | discover/movie?with_keywords={id}    |
| /genre/{id}/movies or /genre/{id}/tv      | discover/*?with_genres={id}          |
| /network/{id}/tv                          | discover/tv?with_networks={id}       |
| /company/{id}/movies                      | discover/*?with_companies={id}       |

Still valid (and in this registry):
- /discover/movie, /discover/tv  -  primary browse/filter API
- /list/{list_id}  -  curated TMDB lists (Oscars, Christmas, etc.)
- /genre/*/list  -  genre ID lookup only (not browse)
- /search/keyword  -  resolve keyword text  ->  id, then with_keywords on discover
- Curated shortcuts: /movie/popular, /tv/on_the_air, trending, detail, credits

Crew 3.x tvshows/movies indexers already built discover URLs with with_genres,
with_networks, air_date.*, etc. Port those as discover params, not legacy paths.

Ref: https://developer.themoviedb.org/reference/keyword-movies (deprecated  ->  discover)'''

from ..path_resolve import resolve_path

# Nested keys  ->  path template (leading slash, no host).
TMDB_PATHS = {
    'configuration': '/configuration',
    'find': '/find/{external_id}',
    'search': {
        'movie': '/search/movie',
        'tv': '/search/tv',
        'person': '/search/person',
        'multi': '/search/multi',
        'keyword': '/search/keyword',
    },
    'discover': {
        'movie': '/discover/movie',
        'tv': '/discover/tv',
    },
    'trending': {
        'movie': '/trending/movie/{window}',
        'tv': '/trending/tv/{window}',
        'person': '/trending/person/{window}',
    },
    'detail': {
        'movie': '/movie/{tmdb_id}',
        'tv': '/tv/{tmdb_id}',
        'person': '/person/{person_id}',
    },
    'similar': {
        'movie': '/movie/{tmdb_id}/similar',
        'tv': '/tv/{tmdb_id}/similar',
    },
    'recommendations': {
        'movie': '/movie/{tmdb_id}/recommendations',
        'tv': '/tv/{tmdb_id}/recommendations',
    },
    'lists': {
        'movie': {
            'popular': '/movie/popular',
            'top_rated': '/movie/top_rated',
            'now_playing': '/movie/now_playing',
            'upcoming': '/movie/upcoming',
        },
        'tv': {
            'popular': '/tv/popular',
            'top_rated': '/tv/top_rated',
            'on_the_air': '/tv/on_the_air',
            'airing_today': '/tv/airing_today',
        },
    },
    'season': '/tv/{tmdb_id}/season/{season}',
    'episode': '/tv/{tmdb_id}/season/{season}/episode/{episode}',
    'person': {
        'movie_credits': '/person/{person_id}/movie_credits',
        'tv_credits': '/person/{person_id}/tv_credits',
        'combined_credits': '/person/{person_id}/combined_credits',
    },
    'genre': {
        'movie': '/genre/movie/list',
        'tv': '/genre/tv/list',
    },
    'curated_list': '/list/{list_id}',
}


def path(*keys, **fmt):
    '''Resolve a TMDB path template from TMDB_PATHS.'''
    return resolve_path(TMDB_PATHS, keys, fmt or None, label='TMDB path')

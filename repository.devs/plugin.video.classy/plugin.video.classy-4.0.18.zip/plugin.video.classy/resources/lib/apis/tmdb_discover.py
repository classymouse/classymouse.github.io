# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tmdb_discover.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB TV + movie discover presets  -  Crew query strings as param dicts.'''

from datetime import datetime, timedelta

from .tmdb import tmdb as api
from ..trakt import movie_lists as trakt_movie_lists
from ..simkl import movie_lists as simkl_movie_lists
from ..simkl import tv_lists as simkl_tv_lists
from ..mdblist import lists as mdblist_lists
from ..trakt import tv_lists as trakt_tv_lists
from ..trakt import paths as trakt_paths
from ..trakt import transport as trakt_transport
from ..trakt import user_lists as trakt_user_lists
from ..wetrakr import movie_lists as wetrakr_movie_lists
from ..wetrakr import tv_lists as wetrakr_tv_lists
from ..wetrakr import user_lists as wetrakr_user_lists
from ..wetrakr import discover as wetrakr_discover

# Crew default region/language filters for English-language discovery rows.
_EN_DISCOVER = {
    'include_adult': 'false',
    'include_null_first_air_dates': 'false',
    'with_origin_country': 'US|GB|AU',
    'with_original_language': 'en',
}


def _today():
    return datetime.now().strftime('%Y-%m-%d')


def _days_ago(days):
    return (datetime.now() - timedelta(days=int(days))).strftime('%Y-%m-%d')


def _days_ahead(days):
    return (datetime.now() + timedelta(days=int(days))).strftime('%Y-%m-%d')


def _years_ago(years):
    '''Approx calendar floor (365.25 days/year) for discover date filters.'''
    return _days_ago(int(float(years) * 365.25))


def _discover_tid(*, network_id=None, tid=None):
    token = str(tid or network_id or '').strip()
    return token or None


def discover_params(preset, *, network_id=None, tid=None):
    '''
    Resolve a Crew-style url key to TMDB discover query params.
    Returns None when the preset uses a non-discover fetch path.
    '''
    today = _today()
    preset = (preset or '').strip()
    token = _discover_tid(network_id=network_id, tid=tid)

    if preset == 'premiere':
        # New TV Shows: recently premiered EN/US/GB/AU series people actually track.
        # Pure first_air_date.desc floods the list with TMDB junk (no vote floor).
        return {
            **_EN_DISCOVER,
            'region': 'US',
            'first_air_date.gte': _days_ago(60),
            'first_air_date.lte': today,
            'sort_by': 'popularity.desc',
            'vote_count.gte': '2',
        }

    if preset == 'airing':
        return {
            **_EN_DISCOVER,
            'sort_by': 'popularity.desc',
            'air_date.lte': today,
            'air_date.gte': _days_ago(1),
        }

    if preset == 'popular':
        return {
            **_EN_DISCOVER,
            'sort_by': 'popularity.desc',
            'vote_count.gte': '1000',
            'air_date.gte': _days_ago(1),
        }

    if preset == 'rating':
        return {
            **_EN_DISCOVER,
            'sort_by': 'vote_average.desc',
            'vote_count.gte': '200',
        }

    if preset == 'views':
        return {
            **_EN_DISCOVER,
            'sort_by': 'vote_count.desc',
            'vote_count.gte': '1500',
            'first_air_date.lte': today,
        }

    if preset == 'active':
        return {
            **_EN_DISCOVER,
            'sort_by': 'popularity.desc',
            'with_status': '0|2',
        }

    if preset == 'upcoming':
        return {
            'include_adult': 'false',
            'include_null_first_air_dates': 'false',
            'first_air_date.gte': today,
            'sort_by': 'first_air_date.asc',
            'region': 'US',
        }

    if preset in ('tmdb_networks', 'network') and token:
        return {
            'sort_by': 'first_air_date.desc',
            'with_networks': str(token),
        }

    if preset in ('tmdb_certification', 'certification') and token:
        return {
            'certification': str(token),
            'certification_country': 'US',
            'sort_by': 'first_air_date.desc',
        }

    if preset in ('tmdb_language', 'language', 'languages') and token:
        return {
            'include_adult': 'false',
            'sort_by': 'popularity.desc',
            'with_original_language': str(token),
        }

    if preset in ('tmdb_genre', 'genre') and token:
        # Anime is not a TMDB genre  -  Animation from Japan (Crew custom_link).
        if token.lower() == 'anime':
            return {
                'include_adult': 'false',
                'include_null_first_air_dates': 'false',
                'language': 'en-US',
                'sort_by': 'popularity.desc',
                'with_origin_country': 'JP',
                'with_genres': '16',
            }
        # Documentary (99): plain popularity floods 1950s - 90s catalogue noise.
        if str(token) == '99':
            return {
                **_EN_DISCOVER,
                'sort_by': 'popularity.desc',
                'with_genres': '99',
                'first_air_date.gte': _years_ago(15),
                'vote_count.gte': '5',
            }
        return {
            **_EN_DISCOVER,
            'sort_by': 'popularity.desc',
            'with_genres': str(token),
        }

    if preset == 'tmdb_networks_no_unaired' and token:
        return {
            'first_air_date.lte': today,
            'sort_by': 'first_air_date.desc',
            'with_networks': str(token),
        }

    # Kids hub (Crew kids_tv_*  -  Animation 16 / Family 10751 / Kids 10762).
    if preset == 'kids_tv_animation':
        return {
            'include_adult': 'false',
            'include_null_first_air_dates': 'false',
            'sort_by': 'popularity.desc',
            'with_genres': '16',
            'vote_count.gte': '20',
        }
    if preset == 'kids_tv_family':
        return {
            'include_adult': 'false',
            'include_null_first_air_dates': 'false',
            'sort_by': 'popularity.desc',
            'with_genres': '10751',
            'vote_count.gte': '20',
        }
    if preset == 'kids_tv_kids':
        return {
            'include_adult': 'false',
            'include_null_first_air_dates': 'false',
            'sort_by': 'popularity.desc',
            'with_genres': '10762',
            'vote_count.gte': '20',
        }
    if preset == 'kids_tv_all':
        return {
            'include_adult': 'false',
            'include_null_first_air_dates': 'false',
            'sort_by': 'popularity.desc',
            'with_genres': '16,10751,10762',
            'vote_count.gte': '20',
        }

    return None


def fetch_tv_page(preset, *, page=1, network_id=None, tid=None, query=None):
    '''
    Fetch one page for a Crew url key. Returns TMDB/Trakt JSON dict or None.

    Response shape is normalized to {results, page, total_pages} where possible.
    '''
    preset = (preset or '').strip()
    page = max(1, int(page or 1))

    if preset == 'tmdb_similar':
        token = _discover_tid(tid=tid)
        if not token:
            return None
        data = api.similar_tv(token, {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'similar'
        return data

    if mdblist_lists.is_list_items_url(preset):
        return mdblist_lists.fetch_items_page(preset, page=page)
    if wetrakr_user_lists.is_list_items_url(preset):
        return wetrakr_user_lists.fetch_items_page(preset, page=page)
    if wetrakr_discover.is_public_list_url(preset):
        list_id, media = wetrakr_discover.parse_public_list_url(preset)
        return wetrakr_discover.fetch_public_list_items_page(
            list_id, media=media or 'show', page=page,
        )
    if simkl_tv_lists.is_my_tv_preset(preset):
        return simkl_tv_lists.fetch_page(preset, page=page)
    if wetrakr_tv_lists.is_my_tv_preset(preset):
        return wetrakr_tv_lists.fetch_page(preset, page=page)
    if wetrakr_discover.is_tv_preset(preset):
        return wetrakr_discover.fetch_page(
            preset, media='show', page=page, query=query,
        )
    if trakt_tv_lists.is_my_tv_preset(preset):
        return trakt_tv_lists.fetch_page(preset, page=page)

    if preset == 'trending':
        items = trakt_transport.get_json(
            trakt_paths.path('shows', 'trending'),
            params={'page': page, 'limit': 40, 'extended': 'full'},
            with_auth=False,
        )
        if not isinstance(items, list):
            return None
        return {
            'results': items,
            'page': page,
            'total_pages': page + 1 if len(items) >= 40 else page,
            '_source': 'trakt_trending',
        }

    params = discover_params(preset, network_id=network_id, tid=tid)
    if params is not None:
        params = dict(params)
        params['page'] = page
        data = api.discover_tv(params)
        if isinstance(data, dict):
            data['_source'] = 'discover'
        return data

    list_key = {
        'tmdb_tv_on_the_air': 'on_the_air',
        'on_the_air': 'on_the_air',
        'tmdb_tv_airing_today': 'airing_today',
        'airing_today': 'airing_today',
        'tmdb_tv_popular_tv': 'popular',
        'tmdb_tv_top_rated': 'top_rated',
    }.get(preset)
    if list_key:
        data = api.list_tv(list_key, {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'list'
        return data

    if preset in ('tmdb_tv_trending_day', 'tmdb_trending_day'):
        data = api.trending_tv('day', {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'trending'
        return data

    if preset in ('tmdb_tv_trending_week', 'tmdb_trending_week'):
        data = api.trending_tv('week', {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'trending'
        return data

    if preset == 'tmdb_tv_upcoming':
        params = discover_params('upcoming')
        params['page'] = page
        data = api.discover_tv(params)
        if isinstance(data, dict):
            data['_source'] = 'discover'
        return data

    return None


# --- Movie presets (Crew movies.py) ----------------------------------------

_EN_MOVIE_DISCOVER = {
    'include_adult': 'false',
    'include_video': 'false',
    'with_original_language': 'en',
    'with_origin_country': 'US|GB|CA|AU|NZ',
}

# Crew movies.py curated TMDB list IDs (not discover).
_TMDB_CURATED_LISTS = {
    'oscars': '28',
    'xristmas': '8280352',
}


def _flatten_trakt_boxoffice(raw):
    '''Trakt /movies/boxoffice  ->  [{movie: {...}, rank?, revenue?}, ...].

    Trakt may return either a flat ranked list or legacy weekend blocks:
      [{revenue, movie}, ...]
      [{weekend, movies: [{rank, revenue, movie}, ...]}]
    '''
    items = []
    if not isinstance(raw, list):
        return items
    for block in raw:
        if not isinstance(block, dict):
            continue
        if isinstance(block.get('movie'), dict):
            items.append(block)
            continue
        for entry in block.get('movies') or []:
            if isinstance(entry, dict) and isinstance(entry.get('movie'), dict):
                items.append(entry)
    return items


def _tmdb_list_page(data, *, page=1):
    '''Normalize TMDB /list/{id} JSON to discover-shaped page dict.'''
    if not isinstance(data, dict):
        return None
    items = data.get('items') or data.get('results') or []
    movies = [item for item in items if isinstance(item, dict) and item.get('title')]
    total_pages = max(1, int(data.get('total_pages') or 1))
    return {
        'results': movies,
        'page': int(data.get('page') or page),
        'total_pages': total_pages,
        '_source': 'tmdb_list',
    }


def discover_movie_params(preset, *, network_id=None, tid=None):
    '''Crew movies url key  ->  TMDB discover params. None if not discover.'''
    today = _today()
    preset = (preset or '').strip()
    token = _discover_tid(network_id=network_id, tid=tid)

    if preset == 'popular':
        return {
            **_EN_MOVIE_DISCOVER,
            'sort_by': 'popularity.desc',
            'with_release_type': '1|2|3',
            'release_date.gte': _days_ago(60),
            'release_date.lte': today,
        }

    if preset == 'rating':
        return {
            **_EN_MOVIE_DISCOVER,
            'sort_by': 'vote_average.desc',
            'vote_count.gte': '200',
            'release_date.lte': today,
        }

    if preset == 'views':
        return {
            **_EN_MOVIE_DISCOVER,
            'sort_by': 'popularity.desc',
            'vote_average.gte': '8',
            'vote_average.lte': '10',
            'release_date.lte': today,
        }

    # Seasonal Halloween hub  -  popular Horror (genre 27); no Trakt dependency.
    if preset == 'halloween':
        return {
            **_EN_MOVIE_DISCOVER,
            'sort_by': 'popularity.desc',
            'with_genres': '27',
            'vote_count.gte': '50',
            'release_date.lte': today,
        }

    if preset in ('tmdb_networks', 'network') and token:
        return {
            'with_networks': str(token),
            'release_date.lte': today,
            'sort_by': 'primary_release_date.desc',
        }

    if preset in ('tmdb_certification', 'certification') and token:
        return {
            **_EN_MOVIE_DISCOVER,
            'certification': str(token),
            'certification_country': 'US',
            'sort_by': 'primary_release_date.desc',
        }

    if preset in ('tmdb_language', 'language', 'languages') and token:
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'sort_by': 'popularity.desc',
            'with_original_language': str(token),
        }

    if preset in ('tmdb_genre', 'genre') and token:
        # Documentary (99): keep recent features, not the entire film archive.
        if str(token) == '99':
            return {
                **_EN_MOVIE_DISCOVER,
                'sort_by': 'popularity.desc',
                'with_genres': '99',
                'primary_release_date.gte': _years_ago(15),
                'vote_count.gte': '20',
            }
        return {
            **_EN_MOVIE_DISCOVER,
            'sort_by': 'popularity.desc',
            'with_genres': str(token),
        }

    if preset == 'tmdb_movie_discover_year' and token:
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'sort_by': 'popularity.desc',
            'primary_release_year': str(token),
            'with_original_language': 'en',
        }

    if preset == 'tmdb_networks_no_unaired' and token:
        return {
            'release_date.lte': today,
            'sort_by': 'primary_release_date.desc',
            'with_watch_providers': str(token),
            'watch_region': 'US',
        }

    # Kids hub (Crew kids_movies_*  -  G/PG + Animation 16 / Family 10751).
    if preset == 'kids_movies_animation':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'certification_country': 'US',
            'certification': 'G|PG',
            'sort_by': 'popularity.desc',
            'with_genres': '16',
            'vote_count.gte': '50',
        }
    if preset == 'kids_movies_family':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'certification_country': 'US',
            'certification': 'G|PG',
            'sort_by': 'popularity.desc',
            'with_genres': '10751',
            'vote_count.gte': '50',
        }
    if preset == 'kids_movies_all':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'certification_country': 'US',
            'certification': 'G|PG',
            'sort_by': 'popularity.desc',
            'with_genres': '16,10751',
            'vote_count.gte': '50',
        }
    # Disney animation (replace dead White disney_years XML).
    # Companies: Walt Disney Pictures 2 | WDAS 6125 | Pixar 3; genre Animation.
    if preset == 'kids_movies_disney':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'certification_country': 'US',
            'certification': 'G|PG',
            'sort_by': 'popularity.desc',
            'with_genres': '16',
            'with_companies': '2|6125|3',
            'vote_count.gte': '20',
        }

    # New Movies (movieWidget)  -  popular theatrical releases, past 60 days.
    if preset in ('tmdb_movie_featured', 'featured'):
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'region': 'US',
            'sort_by': 'popularity.desc',
            'with_release_type': '1|2|3',
            'release_date.gte': _days_ago(60),
            'release_date.lte': today,
        }

    # JustWatch-style  -  past 31 days, streaming/digital/physical/TV release types.
    if preset in ('tmdb_movie_latest_releases', 'latest_releases'):
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'region': 'US',
            'vote_count.gte': '10',
            'sort_by': 'release_date.desc',
            'release_date.gte': _days_ago(31),
            'release_date.lte': today,
            'with_release_type': '4|5|6',
        }

    # JustWatch-style  -  past 31 days, premiere + theatrical release types.
    if preset == 'tmdb_movie_premieres':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'region': 'US',
            'vote_count.gte': '10',
            'sort_by': 'release_date.desc',
            'release_date.gte': _days_ago(31),
            'release_date.lte': today,
            'with_release_type': '1|3|2',
        }

    # Movie release calendars  -  upcoming theatrical (2|3) or DVD/physical (5).
    if preset == 'calendar_thisweek':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'with_original_language': 'en',
            'with_release_type': '2|3',
            'release_date.gte': today,
            'release_date.lte': _days_ahead(7),
            'sort_by': 'release_date.asc',
        }

    if preset == 'calendar_thismonth':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'with_original_language': 'en',
            'with_release_type': '2|3',
            'release_date.gte': today,
            'release_date.lte': _days_ahead(30),
            'sort_by': 'release_date.asc',
        }

    if preset == 'calendar_dvd_thisweek':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'with_original_language': 'en',
            'with_release_type': '5',
            'release_date.gte': today,
            'release_date.lte': _days_ahead(7),
            'sort_by': 'release_date.asc',
        }

    if preset == 'calendar_dvd_thismonth':
        return {
            'include_adult': 'false',
            'include_video': 'false',
            'with_original_language': 'en',
            'with_release_type': '5',
            'release_date.gte': today,
            'release_date.lte': _days_ahead(30),
            'sort_by': 'release_date.asc',
        }

    return None


def fetch_movie_page(preset, *, page=1, network_id=None, tid=None, query=None):
    '''Fetch one page for a Crew movies url key.'''
    preset = (preset or '').strip()
    page = max(1, int(page or 1))

    if preset == 'tmdb_similar':
        token = _discover_tid(tid=tid)
        if not token:
            return None
        data = api.similar_movie(token, {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'similar'
        return data

    if trakt_user_lists.is_list_items_url(preset):
        return trakt_user_lists.fetch_items_page(preset, page=page)
    if mdblist_lists.is_list_items_url(preset):
        return mdblist_lists.fetch_items_page(preset, page=page)
    if wetrakr_user_lists.is_list_items_url(preset):
        return wetrakr_user_lists.fetch_items_page(preset, page=page)
    if wetrakr_discover.is_public_list_url(preset):
        list_id, media = wetrakr_discover.parse_public_list_url(preset)
        return wetrakr_discover.fetch_public_list_items_page(
            list_id, media=media or 'movie', page=page,
        )

    if simkl_movie_lists.is_my_movie_preset(preset):
        return simkl_movie_lists.fetch_page(preset, page=page)
    if wetrakr_movie_lists.is_my_movie_preset(preset):
        return wetrakr_movie_lists.fetch_page(preset, page=page)
    try:
        from ..wetrakr import calendars as wetrakr_calendars
        if wetrakr_calendars.is_movie_calendar_preset(preset):
            return wetrakr_calendars.fetch_movie_page(preset, page=page)
    except Exception:
        pass
    if wetrakr_discover.is_movie_preset(preset):
        return wetrakr_discover.fetch_page(
            preset, media='movie', page=page, query=query,
        )
    if trakt_movie_lists.is_my_movie_preset(preset):
        return trakt_movie_lists.fetch_page(preset, page=page)

    if preset == 'trending':
        items = trakt_transport.get_json(
            trakt_paths.path('movies', 'trending'),
            params={'page': page, 'limit': 40, 'extended': 'full'},
            with_auth=False,
        )
        if not isinstance(items, list):
            return None
        return {
            'results': items,
            'page': page,
            'total_pages': page + 1 if len(items) >= 40 else page,
            '_source': 'trakt_trending',
        }

    if preset == 'boxoffice':
        raw = trakt_transport.get_json(
            trakt_paths.path('movies', 'boxoffice'),
            with_auth=False,
        )
        if raw is None:
            return None
        items = _flatten_trakt_boxoffice(raw)
        if not items:
            return None
        return {
            'results': items,
            'page': 1,
            'total_pages': 1,
            '_source': 'trakt_boxoffice',
        }

    list_id = _TMDB_CURATED_LISTS.get(preset)
    if list_id:
        data = api.curated_list(list_id, {'page': page})
        return _tmdb_list_page(data, page=page)

    params = discover_movie_params(preset, network_id=network_id, tid=tid)
    if params is not None:
        params = dict(params)
        params['page'] = page
        data = api.discover_movie(params)
        if isinstance(data, dict):
            data['_source'] = 'discover'
        return data

    list_key = {
        'theaters': 'now_playing',
        'now_playing': 'now_playing',
        'tmdb_movie_now_playing': 'now_playing',
        'upcoming': 'upcoming',
        'tmdb_movie_upcoming': 'upcoming',
        'tmdb_movie_popular': 'popular',
        'tmdb_movie_top_rated': 'top_rated',
    }.get(preset)
    if list_key:
        extra = {'page': page}
        if list_key in ('now_playing', 'upcoming'):
            extra['region'] = 'US'
        data = api.list_movie(list_key, extra)
        if isinstance(data, dict):
            data['_source'] = 'list'
        return data

    if preset in ('tmdb_movie_trending_day', 'tmdb_trending_day'):
        data = api.trending_movie('day', {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'trending'
        return data

    if preset in ('tmdb_movie_trending_week', 'tmdb_trending_week'):
        data = api.trending_movie('week', {'page': page})
        if isinstance(data, dict):
            data['_source'] = 'trending'
        return data

    return None

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file introdb.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TheIntroDB v3 client - intro / recap / credits segments (read-only).
'''

import json
import os
import time

from ..apis.base import build_url, request_json
from ..modules import control
from ..modules.classy import c

BASE_URL = 'https://api.theintrodb.org/v3'
CACHE_TTL_SEC = 7 * 24 * 3600
_CACHE_FILE = 'introdb.cache.json'


def _cache_path():
    return os.path.join(control.dataPath, _CACHE_FILE)


def _load_cache():
    path = _cache_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle) or {}
    except Exception:
        return {}


def _save_cache(data):
    path = _cache_path()
    try:
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except Exception as exc:
        c.log(f'[IntroDB] cache write failed: {exc}', 1)


def _cache_key(tmdb_id, imdb_id, season, episode, duration_ms):
    return '|'.join([
        str(tmdb_id or ''),
        str(imdb_id or ''),
        str(season or ''),
        str(episode or ''),
        str(duration_ms or ''),
    ])


def _ms_to_sec(value):
    if value is None:
        return None
    try:
        return float(value) / 1000.0
    except (TypeError, ValueError):
        return None


def _pick_segment(entries):
    if not entries:
        return None
    if not isinstance(entries, list):
        entries = [entries]
    best = entries[0]
    for item in entries:
        try:
            weight = int(item.get('weight') or 0)
            best_weight = int(best.get('weight') or 0)
            if weight > best_weight:
                best = item
        except (TypeError, ValueError):
            continue
    start_ms = best.get('start_ms')
    end_ms = best.get('end_ms')
    start_sec = _ms_to_sec(start_ms)
    end_sec = _ms_to_sec(end_ms)
    if start_ms is None:
        start_sec = 0.0
    if start_sec is None and end_sec is None:
        return None
    return {
        'start_sec': float(start_sec or 0.0),
        'end_sec': end_sec,
        'source': 'introdb',
    }


def _parse_media_response(data):
    if not data:
        return {}
    intro = _pick_segment(data.get('intro'))
    recap = _pick_segment(data.get('recap'))
    credits = _pick_segment(data.get('credits'))
    # Playback builds an ordered queue from recap + intro; never merge (recap+intro
    # spans minutes and caused bad seeks from t=0).
    skip = intro or recap
    return {
        'skip': skip,
        'intro': intro,
        'recap': recap,
        'credits': credits,
        'raw': data,
    }


def _finalize_parsed(parsed):
    if not parsed:
        return {}
    return dict(parsed)


def get_media(tmdb_id=None, imdb_id=None, tvdb_id=None, season=None, episode=None, duration_ms=None):
    '''
    Fetch segment timings. Episodes require season/episode.
    Returns dict with skip, intro, recap, credits keys (values may be None).
    '''
    params = {}
    if tmdb_id:
        params['tmdb_id'] = int(tmdb_id)
    elif imdb_id:
        imdb_str = str(imdb_id).strip()
        if not imdb_str.startswith('tt'):
            digits = ''.join(ch for ch in imdb_str if ch.isdigit())
            imdb_str = f'tt{digits}' if digits else imdb_str
        params['imdb_id'] = imdb_str
    elif tvdb_id:
        params['tvdb_id'] = int(tvdb_id)
    else:
        return {}

    if season is not None and episode is not None:
        params['season'] = int(season)
        params['episode'] = int(episode)
    if duration_ms:
        params['duration_ms'] = int(duration_ms)

    key = _cache_key(tmdb_id, imdb_id, season, episode, duration_ms)
    cache = _load_cache()
    entry = cache.get(key)
    now = time.time()
    if entry and (now - float(entry.get('ts') or 0)) < CACHE_TTL_SEC:
        return _finalize_parsed(entry.get('data') or {})

    url = build_url(BASE_URL, '/media', params)
    raw = request_json('introdb', url, timeout=20)
    parsed = _finalize_parsed(_parse_media_response(raw))
    cache[key] = {'ts': now, 'data': parsed}
    _save_cache(cache)
    if parsed.get('intro') or parsed.get('recap'):
        intro = parsed.get('intro') or {}
        recap = parsed.get('recap') or {}
        c.log(
            f'[IntroDB] S{season}E{episode} '
            f'recap={recap.get("start_sec", "-")}-{recap.get("end_sec", "-")}s '
            f'intro={intro.get("start_sec", "-")}-{intro.get("end_sec", "-")}s',
        )
    return parsed


def credits_start_sec(tmdb_id=None, imdb_id=None, season=None, episode=None, duration_sec=None):
    duration_ms = int(float(duration_sec) * 1000) if duration_sec else None
    data = get_media(
        tmdb_id=tmdb_id,
        imdb_id=imdb_id,
        season=season,
        episode=episode,
        duration_ms=duration_ms,
    )
    credits = data.get('credits')
    if not credits:
        return None
    return credits.get('start_sec')

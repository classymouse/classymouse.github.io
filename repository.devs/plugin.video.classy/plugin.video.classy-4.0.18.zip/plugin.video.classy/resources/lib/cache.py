# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

SQLite disk cache  -  activity-fingerprint invalidation + optional TTL (later).

Progress / Trakt bulk: pass invalidation=probe.fingerprint('episodes', 'shows').
Browse lists (later): pass ttl_seconds instead of relying on activity stamps.'''

import json
import os
import sqlite3
import threading
import time

from .modules.classy import c

_DB_FILENAME = 'classy_cache.db'
_SCHEMA_VERSION = 1

_lock = threading.Lock()
_conn = None


def _profile_dir():
    override = os.environ.get('CLASSY_CACHE_DIR')
    if override:
        if not os.path.isdir(override):
            os.makedirs(override, exist_ok=True)
        return override
    try:
        import xbmcaddon
        import xbmcvfs

        profile = xbmcaddon.Addon().getAddonInfo('profile')
        if not profile:
            return ''
        path = xbmcvfs.translatePath(profile)
        if path and not os.path.isdir(path):
            os.makedirs(path, exist_ok=True)
        return path
    except Exception:
        return ''


def db_path():
    profile = _profile_dir()
    if not profile:
        return ''
    return os.path.join(profile, _DB_FILENAME)


def _connect():
    global _conn
    path = db_path()
    if not path:
        return None
    if _conn is None:
        _conn = sqlite3.connect(path, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
    return _conn


def _init_schema(conn):
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
        '''
    )
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS cache (
            namespace TEXT NOT NULL,
            cache_key TEXT NOT NULL,
            invalidation TEXT NOT NULL DEFAULT '',
            payload TEXT NOT NULL,
            updated_at REAL NOT NULL,
            expires_at REAL,
            PRIMARY KEY (namespace, cache_key)
        )
        '''
    )
    row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    version = int(row['value']) if row else 0
    if version < _SCHEMA_VERSION:
        conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES ('schema_version', ?)",
            (str(_SCHEMA_VERSION),),
        )
    conn.commit()


def _get_conn():
    with _lock:
        conn = _connect()
        if conn is None:
            return None
        _init_schema(conn)
        return conn


def get(namespace, cache_key, invalidation=None, *, ttl_ok=True):
    '''
    Return cached payload text on hit, else None.

    Hit when row exists AND (invalidation matches if given) AND not TTL-expired.
    '''
    conn = _get_conn()
    if conn is None:
        return None
    ns = str(namespace or '')
    key = str(cache_key or '')
    try:
        row = conn.execute(
            'SELECT invalidation, payload, expires_at FROM cache '
            'WHERE namespace=? AND cache_key=?',
            (ns, key),
        ).fetchone()
    except sqlite3.Error as exc:
        c.log(f'[Cache] get {ns}/{key} failed: {exc}', 1)
        return None
    if not row:
        return None
    if invalidation is not None and str(row['invalidation'] or '') != str(invalidation):
        return None
    expires_at = row['expires_at']
    if ttl_ok and expires_at is not None and time.time() > float(expires_at):
        return None
    return row['payload']


def get_json(namespace, cache_key, invalidation=None, *, ttl_ok=True):
    raw = get(namespace, cache_key, invalidation=invalidation, ttl_ok=ttl_ok)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception as exc:
        c.log(f'[Cache] JSON decode {namespace}/{cache_key}: {exc}', 1)
        return None


def put(namespace, cache_key, payload_text, invalidation='', ttl_seconds=None):
    conn = _get_conn()
    if conn is None:
        return False
    ns = str(namespace or '')
    key = str(cache_key or '')
    now = time.time()
    expires_at = (now + float(ttl_seconds)) if ttl_seconds else None
    try:
        conn.execute(
            '''
            INSERT INTO cache(namespace, cache_key, invalidation, payload, updated_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(namespace, cache_key) DO UPDATE SET
                invalidation=excluded.invalidation,
                payload=excluded.payload,
                updated_at=excluded.updated_at,
                expires_at=excluded.expires_at
            ''',
            (ns, key, str(invalidation or ''), payload_text, now, expires_at),
        )
        conn.commit()
        return True
    except sqlite3.Error as exc:
        c.log(f'[Cache] put {ns}/{key} failed: {exc}', 1)
        return False


def put_json(namespace, cache_key, data, invalidation='', ttl_seconds=None):
    try:
        text = json.dumps(data, separators=(',', ':'))
    except Exception as exc:
        c.log(f'[Cache] JSON encode {namespace}/{cache_key}: {exc}', 1)
        return False
    return put(namespace, cache_key, text, invalidation=invalidation, ttl_seconds=ttl_seconds)


def delete(namespace, cache_key):
    conn = _get_conn()
    if conn is None:
        return False
    try:
        conn.execute(
            'DELETE FROM cache WHERE namespace=? AND cache_key=?',
            (str(namespace or ''), str(cache_key or '')),
        )
        conn.commit()
        return True
    except sqlite3.Error as exc:
        c.log(f'[Cache] delete failed: {exc}', 1)
        return False


def clear_namespace(namespace):
    conn = _get_conn()
    if conn is None:
        return False
    try:
        conn.execute('DELETE FROM cache WHERE namespace=?', (str(namespace or ''),))
        conn.commit()
        return True
    except sqlite3.Error as exc:
        c.log(f'[Cache] clear_namespace failed: {exc}', 1)
        return False


def clear_all():
    '''Wipe all rows in classy_cache.db (progress slots, TMDB disk cache, etc.).'''
    conn = _get_conn()
    if conn is None:
        return False
    try:
        conn.execute('DELETE FROM cache')
        conn.commit()
        c.log('[Cache] cleared all classy_cache.db rows')
        return True
    except sqlite3.Error as exc:
        c.log(f'[Cache] clear_all failed: {exc}', 1)
        return False

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file browse.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Search history menu + TMDB result directories (movie / tvshow).'''

from __future__ import annotations

import sys
from urllib.parse import quote_plus, urlencode

import xbmc

from ..apis.tmdb import tmdb
from ..indexers.navigator import n
from ..kodi import listing
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..metadata.video_row import VideoRow
from ..modules import kodi
from ..modules.classy import c
from ..play.url import play_url
from . import history

# String ids  -  32070/32078/32079 match Crew; 32763+ are Classy-only.
L_NEW_SEARCH = 32763
L_CLEAR_HISTORY_ROW = 32764
L_DELETE_TERM = 32070
L_CLEAR_CONFIRM = 32078
L_CLEAR_DONE = 32079
L_KEYBOARD_MOVIE = 32765
L_KEYBOARD_TV = 32766

_SEARCH_CFG = {
    'movie': {
        'content': 'movies',
        'icon': 'search.png',
        'folder_icon': 'DefaultMovies.png',
        'history_action': 'movieSearch',
        'new_action': 'movieSearchnew',
        'term_action': 'movieSearchterm',
        'delete_action': 'movieDeleteTerm',
        'keyboard_heading_id': L_KEYBOARD_MOVIE,
        'row_from_tmdb': VideoRow.from_tmdb_movie,
        'is_folder': False,
    },
    'tvshow': {
        'content': 'tvshows',
        'icon': 'search.png',
        'folder_icon': 'DefaultTVShows.png',
        'history_action': 'tvSearch',
        'new_action': 'tvSearchnew',
        'term_action': 'tvSearchterm',
        'delete_action': 'tvDeleteTerm',
        'keyboard_heading_id': L_KEYBOARD_TV,
        'row_from_tmdb': VideoRow.from_tmdb_tv,
        'is_folder': True,
    },
}


def _cfg(mediatype):
    return _SEARCH_CFG[history.normalize_mediatype(mediatype)]


def _plugin_root():
    return sys.argv[0]


def _lang(string_id, fallback):
    try:
        text = c.lang(string_id)
        if text and str(text) != str(string_id):
            return text
    except Exception:
        pass
    return fallback


def _refresh_container():
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def _prompt_search_term(mediatype):
    cfg = _cfg(mediatype)
    heading = _lang(cfg['keyboard_heading_id'], 'Search')
    kb = xbmc.Keyboard('', heading)
    kb.doModal()
    if not kb.isConfirmed():
        return None
    text = (kb.getText() or '').strip()
    return text.lower() if text else None


def _seasons_url(row):
    query = urlencode({
        'action': 'seasons',
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': row.tvshowtitle or row.title,
    })
    return f'{_plugin_root()}?{query}'


def _results_url(mediatype, term):
    cfg = _cfg(mediatype)
    return f'{_plugin_root()}?action={cfg["term_action"]}&name={quote_plus(term)}'


def _finish_dialog_route():
    '''Dismiss busy state for isFolder=False plugin routes (keyboard cancel).'''
    try:
        handle = int(sys.argv[1])
        if handle >= 0:
            kodi.directory(handle, succeeded=False)
    except Exception:
        pass
    try:
        from ..modules import control
        control.idle()
    except Exception:
        pass


def _open_results(mediatype, term):
    '''Navigate current container to TMDB results (works from isFolder=False routes).'''
    url = _results_url(mediatype, term)
    c.log(f'[Search] Container.Update(replace)  ->  {url}')
    xbmc.executebuiltin(f'Container.Update({url},replace)')


def _item_url(row, mediatype):
    if history.normalize_mediatype(mediatype) == 'tvshow':
        return _seasons_url(row)
    return play_url(row)


def history_directory(handle, mediatype):
    '''Search term list + New search + Clear history.'''
    mediatype = history.normalize_mediatype(mediatype)
    cfg = _cfg(mediatype)

    n.addDirectoryItem(
        L_NEW_SEARCH,
        cfg['new_action'],
        cfg['icon'],
        cfg['folder_icon'],
        isFolder=False,
    )

    terms = history.list_terms(mediatype)
    for term_id, term in terms:
        cm = (L_DELETE_TERM, f'{cfg["delete_action"]}&id={term_id}')
        n.addDirectoryItem(
            term,
            f'{cfg["term_action"]}&name={quote_plus(term)}',
            cfg['icon'],
            cfg['folder_icon'],
            context=cm,
        )

    if terms:
        n.addDirectoryItem(
            L_CLEAR_HISTORY_ROW,
            'clearCacheSearch',
            'tools.png',
            'DefaultAddonProgram.png',
            isFolder=False,
        )

    kodi.content(handle, cfg['content'])
    kodi.directory(handle, cacheToDisc=False)


def results_directory(handle, mediatype, query, page=1):
    '''TMDB search hits for a saved term.'''
    mediatype = history.normalize_mediatype(mediatype)
    cfg = _cfg(mediatype)
    ctx = listing.listing_context()
    term = str(query or '').strip().lower()
    if not term:
        listing.emit_empty(handle, 'Empty search', cfg['content'], ctx, cache=False)
        return

    history.touch_term(mediatype, term)
    page = max(1, int(page or 1))
    c.log(f'[Search] {mediatype} q={term!r} page={page} widget={ctx.is_widget}')

    data = tmdb.search(mediatype, term, page=page)
    if not data:
        listing.emit_empty(handle, 'Search failed', cfg['content'], ctx, cache=False)
        return

    rows = []
    factory = cfg['row_from_tmdb']
    for item in data.get('results') or []:
        if isinstance(item, dict):
            rows.append(factory(item))

    rows = listing.slice_rows(rows, ctx)
    if not rows:
        listing.emit_empty(handle, 'No results', cfg['content'], ctx, cache=False)
        return

    c.log(
        f'[Search] {mediatype} q={term!r} -> {len(rows)} row(s) '
        f'(page {page}/{max(1, int(data.get("total_pages") or 1))})'
    )

    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(
        handle, rows,
        lambda row: _item_url(row, mediatype),
        ctx,
        is_folder=cfg['is_folder'],
    )

    total_pages = max(1, int(data.get('total_pages') or 1))
    if ctx.paginate and page < total_pages:
        next_query = urlencode({
            'action': cfg['term_action'],
            'name': term,
            'page': page + 1,
        })
        label = f'Next Page ({page + 1}/{total_pages})'
        listing.add_next_page(handle, f'{_plugin_root()}?{next_query}', label, ctx)

    listing.finish_directory(handle, cfg['content'], ctx, cache=True)


def search_new(mediatype):
    from ..modules import control

    control.idle()
    try:
        term = _prompt_search_term(mediatype)
        if not term:
            return
        history.touch_term(mediatype, term)
        _open_results(mediatype, term)
    finally:
        _finish_dialog_route()


def search_term(mediatype, query, page=1):
    try:
        handle = int(sys.argv[1])
    except (TypeError, ValueError):
        handle = -1
    if handle < 0:
        return
    results_directory(handle, mediatype, query, page=page)


def delete_search_term(mediatype, term_id):
    try:
        history.delete_term(mediatype, int(term_id))
    except (TypeError, ValueError) as exc:
        c.log(f'[Search] delete term failed: {exc}', 1)
        return
    _refresh_container()


def clear_search_history():
    if not c.yesnoDialog(_lang(L_CLEAR_CONFIRM, 'Clear search history?')):
        return
    try:
        from ..modules import cache
        cache.cache_clear_search()
    except Exception:
        history.clear_all()
    c.infoDialog(
        _lang(L_CLEAR_DONE, 'Search history cleared'),
        sound=True,
        icon='INFO',
    )
    _refresh_container()

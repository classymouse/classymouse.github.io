# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file advanced.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Advanced Search dialog + saved filters + TMDB discover/search execute.'''

from __future__ import annotations

import json
import sys
from sqlite3 import dbapi2 as database
from urllib.parse import quote_plus, unquote_plus, urlencode

import xbmc
import xbmcgui

from ..apis.tmdb import tmdb
from ..indexers.navigator import n
from ..kodi import listing
from ..kodi.dialog_base import ClassyDialogBase
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..metadata.video_row import VideoRow
from ..modules import control
from ..modules import kodi
from ..modules.classy import c
from ..play.url import play_url


def _sort_options(media_type):
    is_tv = media_type == 'tv'
    return {
        'Popularity': 'popularity.desc',
        'Rating': 'vote_average.desc',
        'Release Date': (
            'first_air_date.desc' if is_tv else 'primary_release_date.desc'
        ),
        'Title': 'original_name.asc' if is_tv else 'original_title.asc',
    }


def _genre_choices(media_type):
    from ..indexers.genre_catalog import MOVIE_GENRES, TV_GENRES

    catalog = TV_GENRES if media_type == 'tv' else MOVIE_GENRES
    out = []
    for gid, label_id, name in catalog:
        if gid == 'anime':
            continue
        try:
            label = c.lang(label_id)
            if not label or str(label) == str(label_id):
                label = name
        except Exception:
            label = name
        out.append({'id': int(gid), 'name': label})
    return out


def encode_filter(filter_data):
    return quote_plus(json.dumps(filter_data or {}, separators=(',', ':')))


def decode_filter(params):
    raw = unquote_plus(str((params or {}).get('filter') or ''))
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _normalize_filter(filter_data):
    data = dict(filter_data or {})
    # Crew get_filter bug used genre_id  -  accept both.
    if not data.get('genre_ids') and data.get('genre_id'):
        data['genre_ids'] = data.get('genre_id')
    return data


class AdvancedSearchDialog(ClassyDialogBase):
    XML_FILE = 'AdvancedSearch.xml'

    BUTTON_SEARCH = 100
    BUTTON_SAVE_FILTER = 101
    BUTTON_CANCEL = 102
    EDIT_KEYWORD = 200
    EDIT_YEAR_FROM = 201
    EDIT_YEAR_TO = 202
    EDIT_RATING = 203
    BUTTON_GENRE = 204
    BUTTON_SORT = 205

    def __init__(self, *args, **kwargs):
        media_type = kwargs.pop('media_type', 'tv') or 'tv'
        filter_data = kwargs.pop('filter_data', None) or {}
        super().__init__(*args, **kwargs)
        self.media_type = 'tv' if media_type == 'tv' else 'movie'
        self.filter_data = _normalize_filter(filter_data)
        self.result = None
        self.save_filter = False
        self.selected_genres = []
        self.selected_sort = 'Popularity'
        self._sort_map = _sort_options(self.media_type)

    def onInit(self):
        try:
            data = self.filter_data
            if data.get('keyword'):
                self.getControl(self.EDIT_KEYWORD).setText(str(data['keyword']))
            if data.get('year_from'):
                self.getControl(self.EDIT_YEAR_FROM).setText(str(data['year_from']))
            if data.get('year_to'):
                self.getControl(self.EDIT_YEAR_TO).setText(str(data['year_to']))
            if data.get('min_rating'):
                self.getControl(self.EDIT_RATING).setText(str(data['min_rating']))

            genre_ids_raw = data.get('genre_ids') or ''
            if genre_ids_raw:
                try:
                    want = {int(gid) for gid in str(genre_ids_raw).split(',') if gid.strip()}
                except (TypeError, ValueError):
                    want = set()
                self.selected_genres = [
                    g for g in _genre_choices(self.media_type) if g['id'] in want
                ]

            sort_by = data.get('sort_by') or ''
            if sort_by:
                for label, value in self._sort_map.items():
                    if value == sort_by:
                        self.selected_sort = label
                        break

            self._update_genre_button()
            try:
                self.getControl(self.BUTTON_SORT).setLabel(self.selected_sort)
            except Exception:
                pass
            try:
                self.setFocusId(self.EDIT_KEYWORD)
            except Exception:
                pass
        except Exception as exc:
            c.log(f'[Advanced Search] onInit failed: {exc}', 1)

    def onClick(self, controlId):
        if controlId == self.BUTTON_SEARCH:
            self._execute_search()
        elif controlId == self.BUTTON_SAVE_FILTER:
            self.save_filter = True
            self._execute_search()
        elif controlId == self.BUTTON_CANCEL:
            self.result = None
            self.close_with(controlId)
        elif controlId == self.BUTTON_GENRE:
            self._select_genres()
        elif controlId == self.BUTTON_SORT:
            self._select_sort()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.result = None
            self.close_with(None)

    def _select_genres(self):
        genres = _genre_choices(self.media_type)
        if not genres:
            xbmcgui.Dialog().notification(
                'Advanced Search', 'No genres available', xbmcgui.NOTIFICATION_ERROR,
            )
            return
        names = [g['name'] for g in genres]
        preselected = [
            i for i, g in enumerate(genres)
            if any(sg['id'] == g['id'] for sg in self.selected_genres)
        ]
        selected = xbmcgui.Dialog().multiselect(
            'Select Genres (multiple allowed)',
            names,
            preselect=preselected,
        )
        if selected is not None:
            self.selected_genres = [genres[i] for i in selected]
            self._update_genre_button()

    def _update_genre_button(self):
        try:
            if self.selected_genres:
                label = f'Genres ({len(self.selected_genres)} selected)'
            else:
                label = 'Select Genres...'
            self.getControl(self.BUTTON_GENRE).setLabel(label)
        except Exception:
            pass

    def _select_sort(self):
        labels = list(self._sort_map.keys())
        selected = xbmcgui.Dialog().select('Sort Results By', labels)
        if selected >= 0:
            self.selected_sort = labels[selected]
            try:
                self.getControl(self.BUTTON_SORT).setLabel(self.selected_sort)
            except Exception:
                pass

    def _execute_search(self):
        try:
            keyword = self.getControl(self.EDIT_KEYWORD).getText()
            year_from = self.getControl(self.EDIT_YEAR_FROM).getText()
            year_to = self.getControl(self.EDIT_YEAR_TO).getText()
            rating_text = self.getControl(self.EDIT_RATING).getText()
            genre_ids = ','.join(str(g['id']) for g in self.selected_genres)
            sort_by = self._sort_map.get(self.selected_sort, 'popularity.desc')
            try:
                min_rating = float(rating_text) if (rating_text or '').strip() else 0.0
                min_rating = max(0.0, min(10.0, min_rating))
            except ValueError:
                min_rating = 0.0

            self.result = {
                'keyword': (keyword or '').strip(),
                'genre_ids': genre_ids,
                'year_from': int(year_from) if year_from and year_from.isdigit() else None,
                'year_to': int(year_to) if year_to and year_to.isdigit() else None,
                'min_rating': min_rating if min_rating > 0 else None,
                'sort_by': sort_by,
            }
            self.close_with(self.BUTTON_SEARCH)
        except Exception as exc:
            c.log(f'[Advanced Search] gather failed: {exc}', 1)
            self.result = None
            self.close_with(None)


class FilterManager:
    '''Saved advanced-search filters in search.db.'''

    def __init__(self):
        self.filters_db = control.searchFile
        self._init_db()

    def _init_db(self):
        try:
            dbcon = database.connect(self.filters_db)
            dbcur = dbcon.cursor()
            dbcur.execute('''
                CREATE TABLE IF NOT EXISTS saved_filters (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    media_type TEXT NOT NULL,
                    keyword TEXT,
                    genre_ids TEXT,
                    year_from INTEGER,
                    year_to INTEGER,
                    min_rating REAL,
                    sort_by TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            dbcur.execute('PRAGMA table_info(saved_filters)')
            columns = {row[1] for row in dbcur.fetchall()}
            for col, decl in (
                ('genre_ids', 'TEXT'),
                ('year_from', 'INTEGER'),
                ('year_to', 'INTEGER'),
                ('min_rating', 'REAL'),
                ('sort_by', 'TEXT'),
            ):
                if col not in columns:
                    dbcur.execute(f'ALTER TABLE saved_filters ADD COLUMN {col} {decl}')
            dbcon.commit()
            dbcur.close()
            dbcon.close()
        except Exception as exc:
            c.log(f'[Filter Manager] init failed: {exc}', 1)

    def save_filter(self, name, media_type, filter_data):
        name = (name or '').strip()
        if not name:
            return False
        filter_data = _normalize_filter(filter_data)
        try:
            dbcon = database.connect(self.filters_db)
            dbcur = dbcon.cursor()
            dbcur.execute(
                'SELECT id FROM saved_filters WHERE name = ? AND media_type = ?',
                (name, media_type),
            )
            existing = dbcur.fetchone()
            values = (
                filter_data.get('keyword'),
                filter_data.get('genre_ids'),
                filter_data.get('year_from'),
                filter_data.get('year_to'),
                filter_data.get('min_rating'),
                filter_data.get('sort_by'),
            )
            if existing:
                dbcur.execute(
                    '''
                    UPDATE saved_filters
                    SET keyword=?, genre_ids=?, year_from=?, year_to=?, min_rating=?, sort_by=?
                    WHERE id=?
                    ''',
                    values + (existing[0],),
                )
            else:
                dbcur.execute(
                    '''
                    INSERT INTO saved_filters
                    (name, media_type, keyword, genre_ids, year_from, year_to, min_rating, sort_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (name, media_type) + values,
                )
            dbcon.commit()
            dbcur.close()
            dbcon.close()
            c.infoDialog(f"Filter '{name}' saved!", sound=True, icon='INFO')
            return True
        except Exception as exc:
            c.log(f'[Filter Manager] save failed: {exc}', 1)
            return False

    def get_filter(self, filter_id):
        try:
            dbcon = database.connect(self.filters_db)
            dbcon.row_factory = database.Row
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT * FROM saved_filters WHERE id = ?', (int(filter_id),))
            row = dbcur.fetchone()
            dbcur.close()
            dbcon.close()
            if not row:
                return None
            keys = set(row.keys())
            genre_ids = row['genre_ids'] if 'genre_ids' in keys else None
            if not genre_ids and 'genre_id' in keys:
                genre_ids = row['genre_id']
            return _normalize_filter({
                'id': row['id'],
                'name': row['name'],
                'media_type': row['media_type'],
                'keyword': row['keyword'],
                'genre_ids': genre_ids,
                'year_from': row['year_from'] if 'year_from' in keys else None,
                'year_to': row['year_to'] if 'year_to' in keys else None,
                'min_rating': row['min_rating'] if 'min_rating' in keys else None,
                'sort_by': row['sort_by'] if 'sort_by' in keys else None,
            })
        except Exception as exc:
            c.log(f'[Filter Manager] get failed: {exc}', 1)
            return None

    def list_filters(self, media_type):
        try:
            dbcon = database.connect(self.filters_db)
            dbcur = dbcon.cursor()
            dbcur.execute(
                'SELECT id, name FROM saved_filters WHERE media_type = ? ORDER BY name',
                (media_type,),
            )
            rows = dbcur.fetchall()
            dbcur.close()
            dbcon.close()
            return [(row[0], row[1]) for row in rows]
        except Exception as exc:
            c.log(f'[Filter Manager] list failed: {exc}', 1)
            return []

    def delete_filter(self, filter_id):
        try:
            dbcon = database.connect(self.filters_db)
            dbcur = dbcon.cursor()
            dbcur.execute('DELETE FROM saved_filters WHERE id = ?', (int(filter_id),))
            dbcon.commit()
            dbcur.close()
            dbcon.close()
            try:
                xbmc.executebuiltin('Container.Refresh')
            except Exception:
                pass
            return True
        except Exception as exc:
            c.log(f'[Filter Manager] delete failed: {exc}', 1)
            return False

    def delete_all_filters(self, media_type):
        try:
            dbcon = database.connect(self.filters_db)
            dbcur = dbcon.cursor()
            dbcur.execute(
                'SELECT COUNT(*) FROM saved_filters WHERE media_type = ?',
                (media_type,),
            )
            count = int(dbcur.fetchone()[0] or 0)
            dbcur.execute(
                'DELETE FROM saved_filters WHERE media_type = ?',
                (media_type,),
            )
            dbcon.commit()
            dbcur.close()
            dbcon.close()
            return count
        except Exception as exc:
            c.log(f'[Filter Manager] clear failed: {exc}', 1)
            return 0


def show_advanced_search(media_type='tv', filter_data=None):
    '''Return (filter_dict|None, save_filter).'''
    try:
        dialog = AdvancedSearchDialog.create(
            media_type=media_type,
            filter_data=filter_data or {},
        )
        dialog.doModal()
        result = dialog.result
        save_filter = bool(dialog.save_filter)
        del dialog
        return result, save_filter
    except Exception as exc:
        c.log(f'[Advanced Search] dialog failed: {exc}', 1)
        return None, False


def build_discover_params(media_type, filter_data, page=1):
    '''TMDB discover query params (no keyword).'''
    filter_data = _normalize_filter(filter_data)
    params = {
        'language': 'en-US',
        'include_adult': 'false',
        'page': max(1, int(page or 1)),
    }
    if filter_data.get('genre_ids'):
        params['with_genres'] = filter_data['genre_ids']
    date_field = 'first_air_date' if media_type == 'tv' else 'release_date'
    if filter_data.get('year_from'):
        params[f'{date_field}.gte'] = f"{int(filter_data['year_from'])}-01-01"
    if filter_data.get('year_to'):
        params[f'{date_field}.lte'] = f"{int(filter_data['year_to'])}-12-31"
    if filter_data.get('min_rating'):
        params['vote_average.gte'] = filter_data['min_rating']
    if filter_data.get('sort_by'):
        params['sort_by'] = filter_data['sort_by']
    return params


def needs_postfilter(filter_data):
    filter_data = _normalize_filter(filter_data)
    if not filter_data.get('keyword'):
        return False
    if filter_data.get('genre_ids') or filter_data.get('min_rating'):
        return True
    # Search API year filters are sparse / TV-shaped  -  post-filter locally.
    if filter_data.get('year_from') or filter_data.get('year_to'):
        return True
    return False


def _item_year(item, media_type):
    key = 'first_air_date' if media_type == 'tv' else 'release_date'
    date = item.get(key) or ''
    if not date:
        return None
    try:
        return int(str(date).split('-')[0])
    except (TypeError, ValueError):
        return None


def postfilter_results(results, filter_data, media_type):
    filter_data = _normalize_filter(filter_data)
    required = []
    if filter_data.get('genre_ids'):
        try:
            required = [
                int(gid) for gid in str(filter_data['genre_ids']).split(',')
                if gid.strip()
            ]
        except (TypeError, ValueError):
            required = []
    kept = []
    for item in results or []:
        if not isinstance(item, dict):
            continue
        year = _item_year(item, media_type)
        if filter_data.get('year_from') and year is not None:
            if year < int(filter_data['year_from']):
                continue
        if filter_data.get('year_to') and year is not None:
            if year > int(filter_data['year_to']):
                continue
        if filter_data.get('min_rating'):
            try:
                if float(item.get('vote_average') or 0) < float(filter_data['min_rating']):
                    continue
            except (TypeError, ValueError):
                continue
        if required:
            item_genres = item.get('genre_ids') or []
            if not any(gid in item_genres for gid in required):
                continue
        kept.append(item)
    return kept


def _plugin_root():
    return sys.argv[0]


def _results_action(media_type):
    return 'tvAdvancedResults' if media_type == 'tv' else 'movieAdvancedResults'


def results_url(media_type, filter_data, page=1):
    '''Public: build Container.Update target for advanced results.'''
    payload = encode_filter(filter_data)
    page = max(1, int(page or 1))
    action = _results_action(media_type)
    return f'{_plugin_root()}?action={action}&filter={payload}&page={page}'


def _finish_dialog_route():
    try:
        handle = int(sys.argv[1])
        if handle >= 0:
            kodi.directory(handle, succeeded=False)
    except Exception:
        pass
    try:
        control.idle()
    except Exception:
        pass


def _container_update(url):
    '''Replace current container so Back leaves results (not a dead dialog layer).'''
    xbmc.executebuiltin(f'Container.Update({url},replace)')


def _seasons_url(row):
    query = urlencode({
        'action': 'seasons',
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': row.tvshowtitle or row.title,
    })
    return f'{_plugin_root()}?{query}'


def _item_url(row, media_type):
    if media_type == 'tv':
        return _seasons_url(row)
    return play_url(row)


def run_dialog_flow(media_type, filter_id=None, from_cm=False):
    '''Dialog then list results.

    Folder clicks (menus / Saved Filters): emit into this handle so Back works.
    Context-menu Edit (RunPlugin): Container.Update  -  RunPlugin cannot own history.
    '''
    try:
        handle = int(sys.argv[1])
    except (TypeError, ValueError):
        handle = -1

    try:
        control.idle()
        filter_data = None
        if filter_id not in (None, '', '0'):
            filter_data = FilterManager().get_filter(filter_id)
        result, save_filter = show_advanced_search(media_type, filter_data)
        if not result:
            _finish_dialog_route()
            return
        if save_filter:
            kb = xbmc.Keyboard('', 'Name this filter')
            kb.doModal()
            name = kb.getText() if kb.isConfirmed() else None
            if name:
                FilterManager().save_filter(name.strip(), media_type, result)
        if from_cm or handle < 0:
            url = results_url(media_type, result, page=1)
            c.log(f'[Advanced Search] CM Container.Update(replace)  ->  {url[:120]}...')
            _container_update(url)
            _finish_dialog_route()
            return
        c.log(f'[Advanced Search] folder results handle={handle}')
        results_directory(handle, media_type, result, page=1)
    except Exception as exc:
        c.log(f'[Advanced Search] flow failed: {exc}', 1)
        _finish_dialog_route()


def results_directory(handle, media_type, filter_data, page=1):
    '''Emit advanced search / discover results as a Classy listing.'''
    media_type = 'tv' if media_type == 'tv' else 'movie'
    filter_data = _normalize_filter(filter_data)
    page = max(1, int(page or 1))
    content = 'tvshows' if media_type == 'tv' else 'movies'
    factory = VideoRow.from_tmdb_tv if media_type == 'tv' else VideoRow.from_tmdb_movie
    is_folder = media_type == 'tv'
    ctx = listing.listing_context()

    if not any([
        filter_data.get('keyword'),
        filter_data.get('genre_ids'),
        filter_data.get('year_from'),
        filter_data.get('year_to'),
        filter_data.get('min_rating'),
    ]):
        # Allow popularity discover with only sort  -  still useful.
        pass

    keyword = (filter_data.get('keyword') or '').strip()
    data = None
    items = []
    total_pages = 1

    if keyword:
        data = tmdb.search(
            'tvshow' if media_type == 'tv' else 'movie',
            keyword,
            page=page,
        )
        items = list(data.get('results') or []) if data else []
        if needs_postfilter(filter_data):
            items = postfilter_results(items, filter_data, media_type)
            if not items and page == 1:
                c.infoDialog(
                    'No results after filters. Try fewer genres or a wider year range.',
                    sound=True,
                    icon='INFO',
                    time=4000,
                )
        total_pages = max(1, int((data or {}).get('total_pages') or 1))
    else:
        params = build_discover_params(media_type, filter_data, page=page)
        if media_type == 'tv':
            data = tmdb.discover_tv(params)
        else:
            data = tmdb.discover_movie(params)
        items = list(data.get('results') or []) if data else []
        total_pages = max(1, int((data or {}).get('total_pages') or 1))

    if data is None:
        listing.emit_empty(handle, 'Search failed', content, ctx, cache=False)
        return

    rows = [factory(item) for item in items if isinstance(item, dict)]
    rows = listing.slice_rows(rows, ctx)
    if not rows:
        listing.emit_empty(handle, 'No results', content, ctx, cache=False)
        return

    c.log(
        f'[Advanced Search] {media_type} page={page}/{total_pages} '
        f'rows={len(rows)} keyword={bool(keyword)}'
    )
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(
        handle, rows,
        lambda row: _item_url(row, media_type),
        ctx,
        is_folder=is_folder,
    )

    if ctx.paginate and page < total_pages:
        next_url = results_url(media_type, filter_data, page=page + 1)
        listing.add_next_page(
            handle, next_url, f'Next Page ({page + 1}/{total_pages})', ctx,
        )
    listing.finish_directory(handle, content, ctx, cache=True)


def saved_filters_directory(handle, media_type):
    media_type = 'tv' if media_type == 'tv' else 'movie'
    content = 'tvshows' if media_type == 'tv' else 'movies'
    adv_action = 'tvAdvancedSearch' if media_type == 'tv' else 'movieAdvancedSearch'
    exec_action = 'tvExecuteFilter' if media_type == 'tv' else 'movieExecuteFilter'
    del_action = 'tvDeleteFilter' if media_type == 'tv' else 'movieDeleteFilter'
    clear_action = (
        'tvClearAllFilters' if media_type == 'tv' else 'movieClearAllFilters'
    )
    icon = 'search.png'
    folder = 'DefaultTVShows.png' if media_type == 'tv' else 'DefaultMovies.png'

    # Folder items  -  results emit into the same history stack (Crew pattern).
    n.addDirectoryItem(
        'New Advanced Search',
        adv_action,
        icon,
        folder,
        isFolder=True,
    )

    filters = FilterManager().list_filters(media_type)
    root = _plugin_root()
    for filter_id, name in filters:
        cm = [
            (
                'Edit',
                f'RunPlugin({root}?action={adv_action}&filter_id={filter_id}&from_cm=1)',
            ),
            ('Delete', f'RunPlugin({root}?action={del_action}&id={filter_id})'),
        ]
        n.addDirectoryItem(
            name,
            f'{exec_action}&id={filter_id}',
            'saved-filters.png',
            folder,
            context=cm,
            isFolder=True,
        )

    if filters:
        n.addDirectoryItem(
            'Clear All Saved Filters',
            clear_action,
            'tools.png',
            'DefaultAddonProgram.png',
            isFolder=False,
        )

    kodi.content(handle, content)
    kodi.directory(handle, cacheToDisc=False)


def execute_saved_filter(media_type, filter_id):
    '''Folder open: list results on this handle so Back returns to Saved Filters.'''
    try:
        handle = int(sys.argv[1])
    except (TypeError, ValueError):
        handle = -1
    if handle < 0:
        return
    try:
        data = FilterManager().get_filter(filter_id)
        if not data:
            c.infoDialog('Filter not found', icon='INFO')
            listing.emit_empty(
                handle,
                'Filter not found',
                'tvshows' if media_type == 'tv' else 'movies',
                listing.listing_context(),
                cache=False,
            )
            return
        c.log(f'[Advanced Search] execute saved folder results id={filter_id}')
        results_directory(handle, media_type, data, page=1)
    except Exception as exc:
        c.log(f'[Advanced Search] execute saved failed: {exc}', 1)
        _finish_dialog_route()

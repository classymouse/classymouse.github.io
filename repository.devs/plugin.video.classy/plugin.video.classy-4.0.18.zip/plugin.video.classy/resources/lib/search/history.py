# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file history.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

SQLite search-term history  -  Crew-compatible tables (movies / tvshow).'''

from __future__ import annotations

import sqlite3

from ..modules import control

_TABLE_BY_MEDIATYPE = {
    'movie': 'movies',
    'tvshow': 'tvshow',
}


def normalize_mediatype(mediatype):
    text = str(mediatype or 'movie').strip().lower()
    if text in ('tv', 'tvshow', 'show', 'tvshows'):
        return 'tvshow'
    return 'movie'


def _table(mediatype):
    return _TABLE_BY_MEDIATYPE[normalize_mediatype(mediatype)]


def _connect():
    return sqlite3.connect(control.searchFile, timeout=30.0)


def ensure_table(mediatype):
    table = _table(mediatype)
    conn = _connect()
    try:
        cur = conn.cursor()
        cur.execute(
            f'CREATE TABLE IF NOT EXISTS {table} '
            '(id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT)'
        )
        conn.commit()
    finally:
        conn.close()


def list_terms(mediatype):
    '''Return [(id, term), ...] newest first, unique terms only.'''
    ensure_table(mediatype)
    table = _table(mediatype)
    conn = _connect()
    try:
        cur = conn.cursor()
        cur.execute(f'SELECT id, term FROM {table} ORDER BY id DESC')
        seen = set()
        out = []
        for row_id, term in cur.fetchall():
            text = str(term or '').strip()
            if not text or text in seen:
                continue
            seen.add(text)
            out.append((int(row_id), text))
        return out
    finally:
        conn.close()


def touch_term(mediatype, term):
    '''Move term to top of history (delete older dupes, insert fresh row).'''
    text = str(term or '').strip().lower()
    if not text:
        return
    ensure_table(mediatype)
    table = _table(mediatype)
    conn = _connect()
    try:
        cur = conn.cursor()
        cur.execute(f'DELETE FROM {table} WHERE term = ?', (text,))
        cur.execute(f'INSERT INTO {table} (id, term) VALUES (?, ?)', (None, text))
        conn.commit()
    finally:
        conn.close()


def delete_term(mediatype, term_id):
    ensure_table(mediatype)
    table = _table(mediatype)
    conn = _connect()
    try:
        cur = conn.cursor()
        cur.execute(f'DELETE FROM {table} WHERE id = ?', (int(term_id),))
        conn.commit()
    finally:
        conn.close()


def clear_all():
    '''Drop Crew-style history tables (movies + tvshow).'''
    conn = _connect()
    try:
        cur = conn.cursor()
        for table in _TABLE_BY_MEDIATYPE.values():
            cur.execute(f'DROP TABLE IF EXISTS {table}')
        conn.commit()
    finally:
        conn.close()
    try:
        conn = _connect()
        conn.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        conn.commit()
        conn.execute('VACUUM')
        conn.close()
    except Exception:
        pass

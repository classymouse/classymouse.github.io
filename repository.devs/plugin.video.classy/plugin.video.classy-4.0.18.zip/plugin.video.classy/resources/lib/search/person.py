# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file person.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB people search + filmography directories (movie / TV scope).'''

from __future__ import annotations

import sys
from urllib.parse import quote_plus, urlencode

import xbmc

from ..apis.tmdb import tmdb
from ..kodi import listing
from ..metadata import extract
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..metadata.video_row import VideoRow
from ..modules import kodi
from ..modules.classy import c
from ..modules.unaired import is_unaired, show_unaired_enabled
from ..play.url import play_url

L_KEYBOARD_PERSON = 32767

_SCOPE_CFG = {
    'movie': {
        'content': 'movies',
        'credits_content': 'movies',
        'icon': 'people-search.png',
        'folder_icon': 'DefaultMovies.png',
        'term_action': 'moviePersonterm',
        'credits_action': 'moviePersonCredits',
        'browse_action': 'moviePersons',
        'row_from_credit': VideoRow.from_tmdb_movie,
        'item_url': play_url,
        'is_folder': False,
    },
    'tvshow': {
        'content': 'actors',
        'credits_content': 'tvshows',
        'icon': 'people-search.png',
        'folder_icon': 'DefaultTVShows.png',
        'term_action': 'tvPersonterm',
        'credits_action': 'tvPersonCredits',
        'browse_action': 'moviePersons',
        'row_from_credit': VideoRow.from_tmdb_tv,
        'item_url': None,
        'is_folder': True,
    },
}


def normalize_scope(scope):
    text = str(scope or 'movie').strip().lower()
    if text in ('tv', 'tvshow', 'show', 'tvshows'):
        return 'tvshow'
    return 'movie'


def _cfg(scope):
    return _SCOPE_CFG[normalize_scope(scope)]


def _plugin_root():
    return sys.argv[0]


def _lang(string_id, fallback):
    try:
        text = c.lang(string_id)
        if text and str(text) != str(string_id):
            return text
    except Exception:
        pass
    return fallback


def _finish_dialog_route():
    try:
        handle = int(sys.argv[1])
        if handle >= 0:
            kodi.directory(handle, succeeded=False)
    except Exception:
        pass
    try:
        from ..modules import control
        control.idle()
    except Exception:
        pass


def _seasons_url(row):
    query = urlencode({
        'action': 'seasons',
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': row.tvshowtitle or row.title,
    })
    return f'{_plugin_root()}?{query}'


def _item_url(row, scope):
    cfg = _cfg(scope)
    if cfg['is_folder']:
        return _seasons_url(row)
    return play_url(row)


def _credit_sort_date(item):
    if not isinstance(item, dict):
        return '0000-00-00'
    return (item.get('release_date') or item.get('first_air_date') or '')[:10] or '0000-00-00'


def _latest_known_for_label(known_for):
    '''Pick the most recent title from TMDB person search known_for payloads.'''
    best_title = ''
    best_year = ''
    best_date = ''
    for item in known_for or []:
        if not isinstance(item, dict):
            continue
        title = (item.get('title') or item.get('name') or '').strip()
        if not title:
            continue
        date = _credit_sort_date(item)
        year = date[:4] if len(date) >= 4 else str(item.get('year') or '').strip()
        if date >= best_date:
            best_date = date
            best_title = title
            best_year = year
    if not best_title:
        return ''
    if best_year:
        return f'{best_title} ({best_year})'
    return best_title


def _sort_person_credits(items):
    return sorted(
        [item for item in (items or []) if isinstance(item, dict)],
        key=_credit_sort_date,
        reverse=True,
    )


def _add_person_item(handle, person_id, name, profile_path, known_for, scope):
    cfg = _cfg(scope)
    thumb = extract.profile_url(profile_path) or c.addon_poster()
    fanart = c.addon_fanart() or ''
    label = str(name or '').strip() or 'Person'
    subtitle = _latest_known_for_label(known_for)
    query = urlencode({
        'action': cfg['credits_action'],
        'person_id': int(person_id),
        'name': label,
    })
    url = f'{_plugin_root()}?{query}'
    li = kodi.item(label=label)
    if subtitle:
        li.setLabel2(subtitle)
    # Profile as poster; addon fanart for skin backdrop (people have no TMDB backdrop).
    li.setArt({
        'icon': thumb,
        'thumb': thumb,
        'poster': thumb,
        'banner': thumb,
        'fanart': fanart,
    })
    if fanart:
        li.setProperty('fanart', fanart)
        li.setProperty('Fanart_Image', fanart)
    kodi.addItem(handle=handle, url=url, listitem=li, isFolder=True)


def _results_url(scope, term):
    cfg = _cfg(scope)
    return f'{_plugin_root()}?action={cfg["term_action"]}&name={quote_plus(term)}'


def _prompt_person_query():
    heading = _lang(L_KEYBOARD_PERSON, 'Person Search')
    kb = xbmc.Keyboard('', heading)
    kb.doModal()
    if not kb.isConfirmed():
        return None
    text = (kb.getText() or '').strip()
    return text.lower() if text else None


def search_new(scope):
    from ..modules import control

    control.idle()
    try:
        term = _prompt_person_query()
        if not term:
            return
        url = _results_url(scope, term)
        c.log(f'[PersonSearch] Container.Update(replace)  ->  {url}')
        xbmc.executebuiltin(f'Container.Update({url},replace)')
    finally:
        _finish_dialog_route()


def search_term(scope, query, page=1):
    try:
        handle = int(sys.argv[1])
    except (TypeError, ValueError):
        handle = -1
    if handle < 0:
        return
    search_directory(handle, scope, query, page=page)


def search_directory(handle, scope, query, page=1):
    cfg = _cfg(scope)
    ctx = listing.listing_context()
    term = str(query or '').strip().lower()
    if not term:
        listing.emit_empty(handle, 'Empty search', cfg['content'], ctx, cache=False)
        return

    page = max(1, int(page or 1))
    c.log(f'[PersonSearch] {scope} q={term!r} page={page} widget={ctx.is_widget}')

    data = tmdb.search_person(term, page=page)
    if not data:
        listing.emit_empty(handle, 'Search failed', cfg['content'], ctx, cache=False)
        return

    hits = 0
    for item in data.get('results') or []:
        if not isinstance(item, dict):
            continue
        person_id = item.get('id')
        name = item.get('name')
        if not person_id or not name:
            continue
        _add_person_item(
            handle,
            person_id,
            name,
            item.get('profile_path'),
            item.get('known_for'),
            scope,
        )
        hits += 1

    if not hits:
        listing.emit_empty(handle, 'No results', cfg['content'], ctx, cache=False)
        return

    c.log(f'[PersonSearch] {scope} q={term!r} -> {hits} person(s)')

    total_pages = max(1, int(data.get('total_pages') or 1))
    if ctx.paginate and page < total_pages:
        next_query = urlencode({
            'action': cfg['term_action'],
            'name': term,
            'page': page + 1,
        })
        label = f'Next Page ({page + 1}/{total_pages})'
        listing.add_next_page(handle, f'{_plugin_root()}?{next_query}', label, ctx)

    listing.finish_directory(handle, cfg['content'], ctx, cache=True)


def browse_directory(handle, scope):
    '''Trending people  -  entry from moviePersons menu row.'''
    cfg = _cfg(scope)
    ctx = listing.listing_context()
    c.log(f'[PersonSearch] browse trending scope={scope} widget={ctx.is_widget}')

    data = tmdb.trending_person('day')
    if not data:
        listing.emit_empty(handle, 'Browse failed', cfg['content'], ctx, cache=False)
        return

    hits = 0
    for item in (data.get('results') or [])[:50]:
        if not isinstance(item, dict):
            continue
        person_id = item.get('id')
        name = item.get('name')
        if not person_id or not name:
            continue
        _add_person_item(
            handle,
            person_id,
            name,
            item.get('profile_path'),
            item.get('known_for'),
            scope,
        )
        hits += 1

    if not hits:
        listing.emit_empty(handle, 'No results', cfg['content'], ctx, cache=False)
        return

    listing.finish_directory(handle, cfg['content'], ctx, cache=True)


def credits_directory(handle, scope, person_id, name=''):
    cfg = _cfg(scope)
    ctx = listing.listing_context()
    pid = str(person_id or '').strip()
    if not pid.isdigit():
        listing.emit_empty(handle, 'Invalid person', cfg['credits_content'], ctx, cache=False)
        return

    label = str(name or '').strip() or pid
    c.log(f'[PersonSearch] credits scope={scope} person={label!r} id={pid}')

    if normalize_scope(scope) == 'tvshow':
        data = tmdb.person_tv_credits(pid)
    else:
        data = tmdb.person_movie_credits(pid)

    if not data:
        listing.emit_empty(handle, 'Credits failed', cfg['credits_content'], ctx, cache=False)
        return

    factory = cfg['row_from_credit']
    rows = []
    for item in _sort_person_credits(data.get('cast')):
        row = factory(item)
        if row.tmdb:
            rows.append(row)

    if not show_unaired_enabled():
        rows = [row for row in rows if not is_unaired(row)]

    rows = listing.slice_rows(rows, ctx)
    if not rows:
        listing.emit_empty(handle, 'No credits', cfg['credits_content'], ctx, cache=False)
        return

    c.log(f'[PersonSearch] {scope} person={label!r} -> {len(rows)} credit(s)')

    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(
        handle,
        rows,
        lambda row: _item_url(row, scope),
        ctx,
        is_folder=cfg['is_folder'],
    )
    listing.finish_directory(handle, cfg['credits_content'], ctx, cache=True)

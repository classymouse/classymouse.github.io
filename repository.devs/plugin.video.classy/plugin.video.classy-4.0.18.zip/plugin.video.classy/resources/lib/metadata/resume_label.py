# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resume_label.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Crew-style gold remaining-time suffix for partial-watch rows.'''

def resume_remaining_suffix(row):
    '''
    Append [COLOR gold](N mins left)[/COLOR] for episodes or
    (N min. remaining) for movies when resume % and duration are known.
    '''
    progress = float(getattr(row, 'resume_point', 0) or 0)
    if progress <= 0:
        return ''

    duration = int(getattr(row, 'duration', 0) or 0)
    if duration <= 0:
        return ''

    resume_secs = (duration * progress) / 100.0
    remaining_secs = duration - resume_secs
    remaining_mins = int(remaining_secs / 60)
    if remaining_mins <= 0:
        return ''

    mediatype = (getattr(row, 'mediatype', '') or '').lower()
    if mediatype == 'episode':
        return f' [COLOR gold]({remaining_mins} mins left)[/COLOR]'
    if mediatype == 'movie':
        return f' [COLOR gold]({remaining_mins} min. remaining)[/COLOR]'
    return ''

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_ref.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Scoped TV identity  -  show, season, or episode.

Use with trakt/watch_index.py for playcount / watched overlays at any browse level.'''

class VideoRef:
    __slots__ = ('tmdb', 'imdb', 'trakt', 'season', 'episode')

    def __init__(self, tmdb='', imdb='', trakt='', season=0, episode=0):
        self.tmdb = str(tmdb or '').strip()
        self.imdb = str(imdb or '').strip()
        self.trakt = str(trakt or '').strip()
        self.season = int(season or 0)
        self.episode = int(episode or 0)

    @classmethod
    def from_row(cls, row):
        return cls(
            tmdb=getattr(row, 'tmdb', '') or '',
            imdb=getattr(row, 'imdb', '') or '',
            trakt=getattr(row, 'trakt', '') or '',
            season=int(getattr(row, 'season', 0) or 0),
            episode=int(getattr(row, 'episode', 0) or 0),
        )

    @property
    def scope(self):
        if self.season > 0 and self.episode > 0:
            return 'episode'
        if self.season > 0:
            return 'season'
        return 'show'

    def is_show(self):
        return self.scope == 'show'

    def is_season(self):
        return self.scope == 'season'

    def is_episode(self):
        return self.scope == 'episode'

    def key(self):
        return (self.tmdb, self.season, self.episode)

    def __repr__(self):
        if self.is_episode():
            return f'VideoRef(tmdb={self.tmdb!r}, S{self.season:02d}E{self.episode:02d})'
        if self.is_season():
            return f'VideoRef(tmdb={self.tmdb!r}, S{self.season:02d})'
        return f'VideoRef(tmdb={self.tmdb!r})'

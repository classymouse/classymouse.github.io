# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cache_ttl.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TTL defaults for enrichment disk cache (not Trakt activity stamps).'''

# Cross-ids rarely change once mapped.
IDS_TTL = 90 * 86400

# TMDB text/art paths  -  session-hot + disk warm across Kodi restarts.
TMDB_TTL = 24 * 3600

# Fanart.tv JSON blobs (show/movie level).
FANART_TTL = 14 * 86400

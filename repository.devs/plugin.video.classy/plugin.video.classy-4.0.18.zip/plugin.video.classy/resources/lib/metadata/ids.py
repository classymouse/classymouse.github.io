# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file ids.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Cross-provider ID resolution  -  TMDB primary, TVDB for fanart.tv.'''

from .. import cache
from ..apis import tmdb as tmdb_api
from ..modules.classy import c
from . import cache_ttl
from .video_row import VideoRow

NS_IDS = 'ids'


def valid_id(value):
    text = str(value or '').strip()
    return text if text and text not in ('0', 'None') else ''


def _cache_key_tv(tmdb_id):
    return f'tv/tmdb/{tmdb_id}'


def _cache_key_movie(tmdb_id):
    return f'movie/tmdb/{tmdb_id}'


def _pack_ids(*, tmdb='', tvdb='', imdb='', trakt=''):
    out = {}
    for key, value in (
        ('tmdb', tmdb),
        ('tvdb', tvdb),
        ('imdb', imdb),
        ('trakt', trakt),
    ):
        vid = valid_id(value)
        if vid:
            out[key] = vid
    return out


def _ids_from_row(row):
    if row is None:
        return {}
    if isinstance(row, dict):
        return _pack_ids(
            tmdb=row.get('tmdb'),
            tvdb=row.get('tvdb'),
            imdb=row.get('imdb'),
            trakt=row.get('trakt'),
        )
    return _pack_ids(
        tmdb=getattr(row, 'tmdb', ''),
        tvdb=getattr(row, 'tvdb', ''),
        imdb=getattr(row, 'imdb', ''),
        trakt=getattr(row, 'trakt', ''),
    )


def apply_ids_to_row(row, ids):
    if not isinstance(row, VideoRow) or not ids:
        return row
    for key in ('tmdb', 'tvdb', 'imdb', 'trakt'):
        value = valid_id(ids.get(key))
        if value and not valid_id(getattr(row, key, '')):
            setattr(row, key, value)
    return row


def _merge_ids(base, extra):
    merged = dict(base or {})
    for key, value in (extra or {}).items():
        if valid_id(value):
            merged[key] = valid_id(value)
    return merged


def _tvdb_from_tmdb_show(show_json):
    if not isinstance(show_json, dict):
        return ''
    external = show_json.get('external_ids') or {}
    return valid_id(external.get('tvdb_id'))


def _imdb_from_tmdb_show(show_json):
    if not isinstance(show_json, dict):
        return ''
    external = show_json.get('external_ids') or {}
    return valid_id(external.get('imdb_id'))


def resolve_show_ids(row=None, *, tmdb=None):
    '''
    Return {tmdb, tvdb, imdb, trakt} for a TV show.

    Order: row ids  ->  disk cache  ->  TMDB external_ids (cached on disk).
    Mutates VideoRow when new ids are discovered.
    '''
    ids = _ids_from_row(row)
    tmdb_id = valid_id(tmdb) or ids.get('tmdb')
    if not tmdb_id:
        return ids

    ids['tmdb'] = tmdb_id
    cache_key = _cache_key_tv(tmdb_id)
    cached = cache.get_json(NS_IDS, cache_key, ttl_ok=True)
    if cached:
        ids = _merge_ids(ids, cached)

    if valid_id(ids.get('tvdb')) and valid_id(ids.get('imdb')):
        apply_ids_to_row(row, ids)
        return ids

    if not valid_id(ids.get('tvdb')) or not valid_id(ids.get('imdb')):
        try:
            show = tmdb_api.get_tv(tmdb_id, append='external_ids')
        except Exception as exc:
            c.log(f'[Ids] TMDB show lookup failed tmdb={tmdb_id}: {exc}', 1)
            show = None
        if isinstance(show, dict):
            if not valid_id(ids.get('tvdb')):
                tvdb = _tvdb_from_tmdb_show(show)
                if tvdb:
                    ids['tvdb'] = tvdb
            if not valid_id(ids.get('imdb')):
                imdb = _imdb_from_tmdb_show(show)
                if imdb:
                    ids['imdb'] = imdb

    if ids:
        cache.put_json(NS_IDS, cache_key, ids, ttl_seconds=cache_ttl.IDS_TTL)
    apply_ids_to_row(row, ids)
    return ids


def resolve_movie_ids(row=None, *, tmdb=None):
    ids = _ids_from_row(row)
    tmdb_id = valid_id(tmdb) or ids.get('tmdb')
    if not tmdb_id:
        return ids

    ids['tmdb'] = tmdb_id
    cache_key = _cache_key_movie(tmdb_id)
    cached = cache.get_json(NS_IDS, cache_key, ttl_ok=True)
    if cached:
        ids = _merge_ids(ids, cached)

    if valid_id(ids.get('imdb')):
        apply_ids_to_row(row, ids)
        return ids

    try:
        movie = tmdb_api.get(f'/movie/{tmdb_id}', {'append_to_response': 'external_ids'})
    except Exception as exc:
        c.log(f'[Ids] TMDB movie lookup failed tmdb={tmdb_id}: {exc}', 1)
        movie = None

    if isinstance(movie, dict):
        imdb = valid_id((movie.get('imdb_id') or (movie.get('external_ids') or {}).get('imdb_id')))
        if imdb:
            ids['imdb'] = imdb

    if ids:
        cache.put_json(NS_IDS, cache_key, ids, ttl_seconds=cache_ttl.IDS_TTL)
    apply_ids_to_row(row, ids)
    return ids


def resolve_row_ids(row):
    '''Resolve cross-ids for a VideoRow based on mediatype.'''
    if not isinstance(row, VideoRow):
        return _ids_from_row(row)
    if row.mediatype == 'movie':
        return resolve_movie_ids(row)
    if row.mediatype in ('tvshow', 'episode'):
        return resolve_show_ids(row)
    return _ids_from_row(row)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file artwork.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Artwork cascade  -  TMDB first, Fanart.tv for gaps, addon fallback last.'''

from . import extract
from ..modules.classy import c


def _fanart_lang():
    lang = (c.get_setting('fanart.lang') or c.get_setting('api.language') or 'en').strip()
    return lang[:2] if lang else 'en'


def pick_fanart_asset(fanart_json, asset_key, lang=None):
    '''
    Pick best URL for a fanart.tv asset list  -  lang match, then en, then neutral (00).

    Borrowed from Crew fanart lang-sort idea; returns '' when missing.
    '''
    if not fanart_json or not asset_key:
        return ''
    items = fanart_json.get(asset_key) or []
    if not isinstance(items, list) or not items:
        return ''
    lang = (lang or _fanart_lang() or 'en').strip()[:2]

    def _sort_key(item):
        if not isinstance(item, dict):
            return (True, True, True)
        item_lang = (item.get('lang') or '').strip()
        return (
            item_lang != lang,
            item_lang != 'en',
            item_lang not in ('00', ''),
        )

    for item in sorted(items, key=_sort_key):
        if isinstance(item, dict):
            url = (item.get('url') or '').strip()
            if url:
                return url
        elif isinstance(item, str) and item.strip():
            return item.strip()
    return ''


def fanart_tv_poster(fanart_json, lang=None):
    return pick_fanart_asset(fanart_json, 'tvposter', lang)


def fanart_tv_fanart(fanart_json, lang=None):
    return pick_fanart_asset(fanart_json, 'showbackground', lang)


def fanart_tv_banner(fanart_json, lang=None):
    return pick_fanart_asset(fanart_json, 'tvbanner', lang)


def fanart_tv_clearlogo(fanart_json, lang=None):
    if not fanart_json:
        return ''
    key = 'hdtvlogo' if fanart_json.get('hdtvlogo') else 'clearlogo'
    return pick_fanart_asset(fanart_json, key, lang)


def fanart_movie_poster(fanart_json, lang=None):
    return pick_fanart_asset(fanart_json, 'movieposter', lang)


def fanart_movie_fanart(fanart_json, lang=None):
    key = 'moviebackground' if fanart_json.get('moviebackground') else 'moviethumb'
    return pick_fanart_asset(fanart_json, key, lang)


def addon_poster():
    return c.addon_poster() if hasattr(c, 'addon_poster') else (c.icon or '')


def addon_fanart():
    return c.fanart or addon_poster()


def resolve_poster(row, fanart_json=None):
    '''TMDB row fields  ->  Fanart.tv  ->  addon default.'''
    for candidate in (
        getattr(row, 'poster', ''),
        getattr(row, 'thumb', ''),
        getattr(row, 'tmdb_poster_path', ''),
    ):
        url = candidate if str(candidate).startswith('http') else extract.poster_url(candidate)
        if url:
            return url
    mediatype = getattr(row, 'mediatype', '') or ''
    if fanart_json:
        if mediatype == 'movie':
            url = fanart_movie_poster(fanart_json)
        else:
            url = fanart_tv_poster(fanart_json)
        if url:
            return url
    return addon_poster()


def resolve_fanart(row, fanart_json=None):
    for candidate in (
        getattr(row, 'fanart', ''),
        getattr(row, 'tmdb_backdrop_path', ''),
    ):
        url = candidate if str(candidate).startswith('http') else extract.fanart_url(candidate)
        if url:
            return url
    mediatype = getattr(row, 'mediatype', '') or ''
    if fanart_json:
        if mediatype == 'movie':
            url = fanart_movie_fanart(fanart_json)
        else:
            url = fanart_tv_fanart(fanart_json)
        if url:
            return url
    return addon_fanart()


def resolve_thumb(row):
    for candidate in (getattr(row, 'thumb', ''), getattr(row, 'poster', '')):
        url = candidate if str(candidate).startswith('http') else extract.poster_url(candidate)
        if url:
            return url
    return resolve_poster(row)

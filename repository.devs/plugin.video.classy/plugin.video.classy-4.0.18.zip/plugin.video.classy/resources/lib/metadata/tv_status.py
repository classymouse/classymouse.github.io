# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_status.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB + Trakt TV status vocabulary (single source of truth for v4).

Use this module anywhere we gate "next episode", planned lists, or UpNext.

References
----------
TMDB TV Show Status (bible  -  Title Case in API ``/tv/{id}`` ``status`` field):
  Pilot, Planned, In Production, Returning Series, Canceled, Ended
  https://www.themoviedb.org/bible/tv#59f7403f9251416e7100002b

  ``Pilot`` = the *show entry* is an unpicked public pilot (rare). It is NOT
  "S01E01 is the pilot episode"  -  that episode is usually ``standard`` on a
  ``Returning Series`` show. Do not hard-block next on ``pilot``; use
  ``aired_episodes`` + TMDB episode probe instead (status may be stale after pickup).

TMDB ``with_status`` discover filter IDs (not the string on show objects):
  0 Returning Series, 1 Planned, 2 In Production, 3 Ended, 4 Canceled, 5 Pilot

TMDB episode ``episode_type`` (``/tv/{id}/season/{s}/episode/{e}`` and season details):
  standard, finale, mid_season_finale
  Only ``finale`` ends the season (``mid_season_finale`` still has episodes after).

Trakt episode ``episode_type`` (extended episode / season episode list):
  standard, season_finale, season_premiere, mid_season_finale (when used)
  ``season_finale`` == TMDB ``finale`` (e.g. The Rookie S07E18).

**Do not trust** Trakt ``GET /shows/{id}/progress/watched``  ->  ``next_episode``.
It is the next *unwatched* slot by naive season/episode numbering and can return
S07E19 when the season ended at S07E18 (episode 404 on Trakt/TMDB). Classy
derives next from furthest-watched + TMDB probe, never that field.

Trakt extended show ``status`` (lowercase phrases in API responses):
  returning series, continuing, in production, planned, upcoming, pilot, canceled, ended
  (Trakt also mirrors TMDB; ``continuing`` ~ TVDB legacy for ``returning series``.)

There is NO combined value ``ended production``  -  that is two separate show statuses:
  ``In Production`` = greenlit / shooting, may still get episodes.
  ``Ended`` = series over by design.'''

# --- TMDB show.status (normalized lowercase for matching) -------------------

TMDB_SHOW_STATUS_PILOT = 'pilot'
TMDB_SHOW_STATUS_PLANNED = 'planned'
TMDB_SHOW_STATUS_IN_PRODUCTION = 'in production'
TMDB_SHOW_STATUS_RETURNING = 'returning series'
TMDB_SHOW_STATUS_ENDED = 'ended'
TMDB_SHOW_STATUS_CANCELED = 'canceled'  # API US spelling; we also accept cancelled

TMDB_SHOW_STATUSES = frozenset({
    TMDB_SHOW_STATUS_PILOT,
    TMDB_SHOW_STATUS_PLANNED,
    TMDB_SHOW_STATUS_IN_PRODUCTION,
    TMDB_SHOW_STATUS_RETURNING,
    TMDB_SHOW_STATUS_ENDED,
    TMDB_SHOW_STATUS_CANCELED,
    'cancelled',  # defensive alias if ever seen in the wild
})

# Definite series over  -  hard block before TMDB
TMDB_SHOW_BLOCKS_NEXT = frozenset({
    TMDB_SHOW_STATUS_ENDED,
    TMDB_SHOW_STATUS_CANCELED,
    'cancelled',
})

# Still active or may return  -  do NOT treat as series over
TMDB_SHOW_ACTIVE = frozenset({
    TMDB_SHOW_STATUS_RETURNING,
    TMDB_SHOW_STATUS_IN_PRODUCTION,
    TMDB_SHOW_STATUS_PLANNED,
    TMDB_SHOW_STATUS_PILOT,  # resolve via aired_episodes + TMDB, not a hard block
})

# --- Trakt show.status (normalized lowercase) ------------------------------

TRAKT_SHOW_STATUS_RETURNING = 'returning series'
TRAKT_SHOW_STATUS_CONTINUING = 'continuing'
TRAKT_SHOW_STATUS_IN_PRODUCTION = 'in production'
TRAKT_SHOW_STATUS_PLANNED = 'planned'
TRAKT_SHOW_STATUS_UPCOMING = 'upcoming'
TRAKT_SHOW_STATUS_PILOT = 'pilot'
TRAKT_SHOW_STATUS_ENDED = 'ended'
TRAKT_SHOW_STATUS_CANCELED = 'canceled'

TRAKT_SHOW_STATUSES = frozenset({
    TRAKT_SHOW_STATUS_RETURNING,
    TRAKT_SHOW_STATUS_CONTINUING,
    TRAKT_SHOW_STATUS_IN_PRODUCTION,
    TRAKT_SHOW_STATUS_PLANNED,
    TRAKT_SHOW_STATUS_UPCOMING,
    TRAKT_SHOW_STATUS_PILOT,
    TRAKT_SHOW_STATUS_ENDED,
    TRAKT_SHOW_STATUS_CANCELED,
    'cancelled',
})

TRAKT_SHOW_BLOCKS_NEXT = frozenset({
    TRAKT_SHOW_STATUS_ENDED,
    TRAKT_SHOW_STATUS_CANCELED,
    'cancelled',
})

TRAKT_SHOW_ACTIVE = frozenset({
    TRAKT_SHOW_STATUS_RETURNING,
    TRAKT_SHOW_STATUS_CONTINUING,
    TRAKT_SHOW_STATUS_IN_PRODUCTION,
    TRAKT_SHOW_STATUS_PLANNED,
    TRAKT_SHOW_STATUS_UPCOMING,
    TRAKT_SHOW_STATUS_PILOT,  # same rule as TMDB  -  probe, don't assume
})

# --- Episode episode_type (TMDB + Trakt) ------------------------------------

TMDB_EPISODE_TYPE_STANDARD = 'standard'
TMDB_EPISODE_TYPE_FINALE = 'finale'
TMDB_EPISODE_TYPE_MID_SEASON_FINALE = 'mid_season_finale'

TRAKT_EPISODE_TYPE_STANDARD = 'standard'
TRAKT_EPISODE_TYPE_SEASON_FINALE = 'season_finale'
TRAKT_EPISODE_TYPE_SEASON_PREMIERE = 'season_premiere'
TRAKT_EPISODE_TYPE_MID_SEASON_FINALE = 'mid_season_finale'

TMDB_EPISODE_TYPES = frozenset({
    TMDB_EPISODE_TYPE_STANDARD,
    TMDB_EPISODE_TYPE_FINALE,
    TMDB_EPISODE_TYPE_MID_SEASON_FINALE,
})

TRAKT_EPISODE_TYPES = frozenset({
    TRAKT_EPISODE_TYPE_STANDARD,
    TRAKT_EPISODE_TYPE_SEASON_FINALE,
    TRAKT_EPISODE_TYPE_SEASON_PREMIERE,
    TRAKT_EPISODE_TYPE_MID_SEASON_FINALE,
})

# Season boundary  -  bump to S+1 E01 after this episode (both APIs)
SEASON_FINALE_EPISODE_TYPES = frozenset({
    TMDB_EPISODE_TYPE_FINALE,           # TMDB: The Rookie S07E18  ->  "finale"
    TRAKT_EPISODE_TYPE_SEASON_FINALE,   # Trakt: same ep  ->  "season_finale"
})

# Mid-season break  -  more episodes still air in the same season
MID_SEASON_FINALE_EPISODE_TYPES = frozenset({
    TMDB_EPISODE_TYPE_MID_SEASON_FINALE,
    TRAKT_EPISODE_TYPE_MID_SEASON_FINALE,
})

# Back-compat aliases
TMDB_SEASON_FINALE_TYPES = frozenset({TMDB_EPISODE_TYPE_FINALE})
TMDB_MID_SEASON_FINALE_TYPES = MID_SEASON_FINALE_EPISODE_TYPES


def norm_status(value):
    return (str(value or '')).strip().lower()


def trakt_show_blocks_next(show_data):
    '''True when Trakt show metadata means no next episode slot.'''
    if not isinstance(show_data, dict):
        return False
    return norm_status(show_data.get('status')) in TRAKT_SHOW_BLOCKS_NEXT


def tmdb_show_blocks_next(show_json):
    '''True when TMDB show root ``status`` means no next episode.'''
    if not isinstance(show_json, dict):
        return False
    return norm_status(show_json.get('status')) in TMDB_SHOW_BLOCKS_NEXT


def episode_type_is_season_finale(episode_type):
    '''True for TMDB ``finale`` or Trakt ``season_finale`` (and aliases).'''
    return norm_status(episode_type) in SEASON_FINALE_EPISODE_TYPES


def tmdb_episode_type_is_season_finale(episode_type):
    return episode_type_is_season_finale(episode_type)


def episode_type_is_mid_season_finale(episode_type):
    return norm_status(episode_type) in MID_SEASON_FINALE_EPISODE_TYPES


def tmdb_episode_type_is_mid_season_finale(episode_type):
    return episode_type_is_mid_season_finale(episode_type)


def classify_trakt_show_status(status):
    '''Return 'blocks_next', 'active', or 'unknown' for logging/tests.'''
    s = norm_status(status)
    if s in TRAKT_SHOW_BLOCKS_NEXT:
        return 'blocks_next'
    if s in TRAKT_SHOW_ACTIVE:
        return 'active'
    return 'unknown'


def classify_tmdb_show_status(status):
    s = norm_status(status)
    if s in TMDB_SHOW_BLOCKS_NEXT:
        return 'blocks_next'
    if s in TMDB_SHOW_ACTIVE:
        return 'active'
    return 'unknown'

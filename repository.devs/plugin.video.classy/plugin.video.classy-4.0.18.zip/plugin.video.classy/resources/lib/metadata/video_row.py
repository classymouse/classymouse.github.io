# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file video_row.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Internal row model  -  Trakt/TMDB merge target before Kodi ListItem.'''

class VideoRow:
    __slots__ = (
        'mediatype', 'title', 'originaltitle', 'tvshowtitle', 'label',
        'year', 'season', 'episode', 'premiered', 'plot', 'tagline', 'status',
        'genre', 'studio', 'network', 'mpaa', 'rating', 'votes', 'duration',
        'director', 'writer', 'castwiththumb', 'trailer',
        'imdb', 'tmdb', 'tvdb', 'trakt',
        'poster', 'fanart', 'thumb',
        'tmdb_poster_path', 'tmdb_backdrop_path', 'tmdb_still_path',
        'resume_point', 'playcount', 'overlay', 'url', 'action',
    )

    def __init__(self, mediatype='episode', **kwargs):
        self.mediatype = mediatype or 'episode'
        self.title = ''
        self.originaltitle = ''
        self.tvshowtitle = ''
        self.label = ''
        self.year = ''
        self.season = 0
        self.episode = 0
        self.premiered = ''
        self.plot = ''
        self.tagline = ''
        self.status = ''
        self.genre = ''
        self.studio = ''
        self.network = ''
        self.mpaa = ''
        self.rating = 0.0
        self.votes = 0
        self.duration = 0
        self.director = ''
        self.writer = ''
        self.castwiththumb = []
        self.trailer = ''
        self.imdb = ''
        self.tmdb = ''
        self.tvdb = ''
        self.trakt = ''
        self.poster = ''
        self.fanart = ''
        self.thumb = ''
        self.tmdb_poster_path = ''
        self.tmdb_backdrop_path = ''
        self.tmdb_still_path = ''
        self.resume_point = 0.0
        self.playcount = 0
        self.overlay = 0
        self.url = ''
        self.action = ''
        self.update(**kwargs)

    def update(self, **kwargs):
        for key, value in kwargs.items():
            if key not in self.__slots__:
                continue
            if key == 'castwiththumb' and value is None:
                value = []
            setattr(self, key, value)
        if not self.label:
            self.label = self._default_label()

    @staticmethod
    def _title_with_year(title, year):
        text = (title or '').strip() or 'Item'
        year_text = str(year or '').strip()
        if year_text and f'({year_text})' not in text:
            return f'{text} ({year_text})'
        return text

    def _default_label(self):
        if self.mediatype == 'episode' and int(self.episode or 0) > 0:
            return self._episode_label()
        if self.mediatype == 'season' and self.season:
            base = self.title or f'Season {int(self.season)}'
            if base.lower().startswith('season'):
                return base
            return f'Season {int(self.season):02d} - {base}'
        if self.mediatype == 'movie':
            return self._title_with_year(self.title, self.year)
        if self.mediatype == 'tvshow':
            return self._title_with_year(self.title or self.tvshowtitle, self.year)
        return self.title or self.tvshowtitle or 'Item'

    def _episode_label(self):
        '''Mixed lists (calendar / next / history) need the show name in the label.'''
        season = int(self.season or 0)
        episode = int(self.episode or 0)
        se = f'S{season:02d}E{episode:02d}'
        show = (self.tvshowtitle or '').strip()
        ep_title = (self.title or '').strip()
        if self._is_generic_episode_title(ep_title, episode):
            ep_title = ''
        if show and ep_title and ep_title.casefold() == show.casefold():
            ep_title = ''
        if show and ep_title:
            return f'{show} - {se} - {ep_title}'
        if show:
            return f'{show} - {se}'
        return f'{se} - {ep_title or f"Episode {episode}"}'

    @staticmethod
    def _is_generic_episode_title(title, episode_number):
        text = (title or '').strip()
        if not text:
            return True
        low = text.casefold()
        if low.startswith('episode ') and low[8:].strip().isdigit():
            return True
        if low == f'episode {int(episode_number or 0)}':
            return True
        return False

    def has_poster(self):
        return bool(self.poster or self.thumb or self.tmdb_poster_path or self.tmdb_still_path)

    def has_fanart(self):
        return bool(self.fanart or self.tmdb_backdrop_path)

    def has_plot(self):
        return bool((self.plot or '').strip())

    def has_crew(self):
        return bool((self.director or '').strip() or (self.writer or '').strip())

    def has_cast(self):
        return bool(self.castwiththumb)

    def has_trailer(self):
        return bool((self.trailer or '').strip())

    def to_dict(self):
        return {slot: getattr(self, slot) for slot in self.__slots__}

    @classmethod
    def from_dict(cls, data):
        data = dict(data or {})
        mediatype = data.pop('mediatype', 'episode')
        return cls(mediatype=mediatype, **data)

    @classmethod
    def from_trakt_watched_show(cls, item):
        '''Build a sparse tvshow row from Trakt watched/shows item.'''
        show = item.get('show') if isinstance(item.get('show'), dict) else item
        show_ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
        year = show.get('year')
        first_aired = str(show.get('first_aired') or '')[:10]
        from . import extract

        return cls(
            mediatype='tvshow',
            title=(show.get('title') or '').strip(),
            tvshowtitle=(show.get('title') or '').strip(),
            year=str(year) if year else (first_aired[:4] if first_aired else ''),
            premiered=first_aired,
            status=(show.get('status') or '').strip(),
            genre=extract.genres_string(show.get('genres')),
            imdb=str(show_ids.get('imdb') or ''),
            tmdb=str(show_ids.get('tmdb') or ''),
            tvdb=str(show_ids.get('tvdb') or ''),
            trakt=str(show_ids.get('trakt') or ''),
        )

    @classmethod
    def from_tmdb_tv(cls, item):
        '''Build a sparse tvshow row from TMDB discover/list/trending JSON.'''
        from . import extract

        first_air = (item.get('first_air_date') or '')[:10]
        year = first_air[:4] if first_air else ''
        row = cls(
            mediatype='tvshow',
            title=(item.get('name') or '').strip(),
            tvshowtitle=(item.get('name') or '').strip(),
            year=year,
            premiered=first_air,
            plot=(item.get('overview') or '').strip(),
            tmdb=str(item.get('id') or ''),
            rating=float(item.get('vote_average') or 0),
            votes=int(item.get('vote_count') or 0),
        )
        poster = item.get('poster_path')
        if poster:
            row.tmdb_poster_path = poster
            row.poster = extract.poster_url(poster)
        backdrop = item.get('backdrop_path')
        if backdrop:
            row.tmdb_backdrop_path = backdrop
            row.fanart = extract.fanart_url(backdrop)
        return row

    @classmethod
    def from_tmdb_movie(cls, item):
        '''Build a sparse movie row from TMDB discover/list/trending JSON.'''
        from . import extract

        release = (item.get('release_date') or '')[:10]
        year = release[:4] if release else str(item.get('year') or '')
        row = cls(
            mediatype='movie',
            title=(item.get('title') or '').strip(),
            year=year,
            premiered=release,
            plot=(item.get('overview') or '').strip(),
            genre=extract.genres_string(item.get('genres'))
            or extract.genres_from_tmdb_ids(item.get('genre_ids')),
            tmdb=str(item.get('id') or ''),
            rating=float(item.get('vote_average') or 0),
            votes=int(item.get('vote_count') or 0),
        )
        poster = item.get('poster_path')
        if poster:
            row.tmdb_poster_path = poster
            row.poster = extract.poster_url(poster)
        backdrop = item.get('backdrop_path')
        if backdrop:
            row.tmdb_backdrop_path = backdrop
            row.fanart = extract.fanart_url(backdrop)
        return row

    @classmethod
    def from_trakt_movie(cls, item):
        '''Build a sparse movie row from Trakt trending/history shape.'''
        movie = item.get('movie') if isinstance(item.get('movie'), dict) else item
        movie_ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
        year = movie.get('year')
        released = str(movie.get('released') or '')[:10]
        runtime_min = int(movie.get('runtime') or 0)
        from . import extract

        return cls(
            mediatype='movie',
            title=(movie.get('title') or '').strip(),
            year=str(year) if year else (released[:4] if released else ''),
            premiered=released,
            plot=(movie.get('overview') or '').strip(),
            genre=extract.genres_string(movie.get('genres')),
            mpaa=str(movie.get('certification') or ''),
            rating=float(movie.get('rating') or 0),
            votes=int(movie.get('votes') or 0),
            imdb=str(movie_ids.get('imdb') or ''),
            tmdb=str(movie_ids.get('tmdb') or ''),
            trakt=str(movie_ids.get('trakt') or ''),
            duration=int(runtime_min * 60) if runtime_min > 0 else 0,
        )

    @classmethod
    def from_trakt_episode(cls, item):
        '''Build a sparse row from Trakt progress/history shape.'''
        show = item.get('show') if isinstance(item.get('show'), dict) else {}
        ep = item.get('episode') if isinstance(item.get('episode'), dict) else item
        ids = ep.get('ids') if isinstance(ep.get('ids'), dict) else {}
        show_ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
        runtime_min = int(ep.get('runtime') or 0)
        premiered = (
            ep.get('first_aired') or ep.get('aired')
            or item.get('first_aired') or item.get('aired') or ''
        )
        return cls(
            mediatype='episode',
            title=(ep.get('title') or '').strip(),
            tvshowtitle=(show.get('title') or item.get('tvshowtitle') or '').strip(),
            season=int(ep.get('season') or item.get('season') or 0),
            episode=int(ep.get('number') or ep.get('episode') or item.get('episode') or 0),
            imdb=str(show_ids.get('imdb') or ids.get('imdb') or item.get('imdb') or ''),
            tmdb=str(show_ids.get('tmdb') or ids.get('tmdb') or item.get('tmdb') or ''),
            tvdb=str(show_ids.get('tvdb') or ids.get('tvdb') or item.get('tvdb') or ''),
            trakt=str(show_ids.get('trakt') or ids.get('trakt') or item.get('trakt') or ''),
            premiered=str(premiered)[:10],
            resume_point=float(item.get('progress') or item.get('resume_point') or 0),
            duration=int(runtime_min * 60) if runtime_min > 0 else 0,
        )

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

# Metadata pipeline  -  extract, artwork, enrich (phase 1b).

from .video_row import VideoRow
from . import extract

__all__ = ('VideoRow', 'extract')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file extract.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Pure TMDB/Trakt JSON  ->  display fields. No HTTP.'''

WRITER_JOBS = frozenset({'Writer', 'Screenplay', 'Story', 'Author'})
DIRECTOR_JOBS = frozenset({'Director'})

from . import image_sizes as _sizes

TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p'


def image_url(path, size=None, base=TMDB_IMAGE_BASE):
    if size is None:
        size = _sizes.poster_size()
    if _is_empty(path):
        return ''
    path = str(path)
    if path.startswith('http'):
        return path
    if not path.startswith('/'):
        path = '/' + path
    return f'{base.rstrip("/")}/{size}{path}'


def _is_empty(value):
    if value is None:
        return True
    if isinstance(value, str) and value.strip() in ('', '0'):
        return True
    return False


def poster_url(path, size=None):
    if size is None:
        size = _sizes.poster_size()
    return image_url(path, size=size)


def fanart_url(path, size=None):
    if size is None:
        size = _sizes.fanart_size()
    return image_url(path, size=size)


def profile_url(path, size=None):
    if size is None:
        size = _sizes.profile_size()
    return image_url(path, size=size)


def still_url(path, size=None):
    if size is None:
        size = _sizes.still_size()
    return image_url(path, size=size)


def directors_from_crew(crew):
    names = []
    for person in crew or []:
        if not isinstance(person, dict):
            continue
        job = person.get('job') or ''
        if job in DIRECTOR_JOBS and person.get('name'):
            names.append(str(person['name']).strip())
    return ' / '.join(dict.fromkeys(names))


def writers_from_crew(crew):
    names = []
    for person in crew or []:
        if not isinstance(person, dict):
            continue
        job = person.get('job') or ''
        if job in WRITER_JOBS and person.get('name'):
            names.append(str(person['name']).strip())
    return ' / '.join(dict.fromkeys(names))


def crew_from_credits(credits):
    if not isinstance(credits, dict):
        return []
    crew = credits.get('crew') or []
    if crew:
        return crew
    return []


def cast_with_thumbs(credits, limit=30, profile_size=None):
    if profile_size is None:
        profile_size = _sizes.profile_size()
    if not isinstance(credits, dict):
        return []
    cast = list(credits.get('cast') or [])[:limit]
    guest = list(credits.get('guest_stars') or [])[:limit]
    seen = set()
    out = []
    for person in cast + guest:
        if not isinstance(person, dict):
            continue
        name = (person.get('name') or '').strip()
        if not name or name in seen:
            continue
        seen.add(name)
        thumb = profile_url(person.get('profile_path'), size=profile_size)
        out.append({
            'name': name,
            'role': (person.get('character') or '').strip(),
            'thumbnail': thumb,
        })
    return out


def trailer_youtube(videos, plugin_prefix='plugin://plugin.video.youtube/play/?video_id='):
    if not isinstance(videos, dict):
        return ''
    results = videos.get('results') or []
    if not isinstance(results, list):
        return ''
    for prefer_official in (True, False):
        for video in results:
            if not isinstance(video, dict):
                continue
            if video.get('site') != 'YouTube' or video.get('type') != 'Trailer':
                continue
            if prefer_official and not video.get('official'):
                continue
            key = (video.get('key') or '').strip()
            if key:
                return f'{plugin_prefix}{key}'
    return ''


def genres_string(genres):
    if not genres:
        return ''
    if isinstance(genres, str):
        return genres
    names = []
    for item in genres:
        if isinstance(item, dict) and item.get('name'):
            names.append(str(item['name']))
        elif isinstance(item, str):
            names.append(item)
    return ' / '.join(names)


# TMDB movie genre_ids on list/trending payloads (no nested genres array).
MOVIE_GENRE_ID_TO_NAME = {
    28: 'Action',
    12: 'Adventure',
    16: 'Animation',
    35: 'Comedy',
    80: 'Crime',
    99: 'Documentary',
    18: 'Drama',
    10751: 'Family',
    14: 'Fantasy',
    36: 'History',
    27: 'Horror',
    10402: 'Music',
    9648: 'Mystery',
    10749: 'Romance',
    878: 'Science Fiction',
    53: 'Thriller',
    10752: 'War',
    37: 'Western',
}


def genres_from_tmdb_ids(genre_ids, id_map=None):
    mapping = id_map or MOVIE_GENRE_ID_TO_NAME
    names = []
    for gid in genre_ids or []:
        try:
            name = mapping.get(int(gid))
        except (TypeError, ValueError):
            name = None
        if name:
            names.append(name)
    return ' / '.join(names)


def split_to_list(value):
    if _is_empty(value):
        return []
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    text = str(value)
    if '/' in text:
        return [p.strip() for p in text.split('/') if p.strip()]
    if ',' in text:
        return [p.strip() for p in text.split(',') if p.strip()]
    return [text.strip()]


def rating_from_tmdb(vote_average):
    try:
        val = float(vote_average)
        return val if val > 0 else 0.0
    except (TypeError, ValueError):
        return 0.0


def votes_from_tmdb(vote_count):
    try:
        val = int(vote_count)
        return val if val > 0 else 0
    except (TypeError, ValueError):
        return 0


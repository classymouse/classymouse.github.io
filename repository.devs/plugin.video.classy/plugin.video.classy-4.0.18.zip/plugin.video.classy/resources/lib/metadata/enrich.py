# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file enrich.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Gap-only enrichment  -  fetch TMDB / Fanart only for missing fields.'''

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..apis import fanart as fanart_api
from ..apis import tmdb as tmdb_api
from ..modules.classy import c
from . import artwork
from . import extract
from . import image_sizes
from . import ids as idmap
from .video_row import VideoRow

NEED_POSTER = 'poster'
NEED_FANART = 'fanart'
NEED_THUMB = 'thumb'
NEED_PLOT = 'plot'
NEED_CREW = 'crew'
NEED_CAST = 'cast'
NEED_TRAILER = 'trailer'
NEED_RATING = 'rating'

_ALL_NEEDS = frozenset({
    NEED_POSTER, NEED_FANART, NEED_THUMB, NEED_PLOT, NEED_CREW,
    NEED_CAST, NEED_TRAILER, NEED_RATING,
})

# Route NEED profiles  -  pick one per screen; all go through enrich_batch + rate limit + cache.
#
# BASE (free ride on bare detail JSON): title/plot/premiered/year/rating/votes/duration/
# poster/fanart/still/genre/studio  -  always map when JSON is in hand; InfoTag push is ms.
# APPEND (same HTTP, fatter body): credits -> cast/director/writer; videos -> trailer.
# EXTRA (real extra HTTP): MPAA/content_ratings parked (no demand); fanart.tv = art fallback only.
#
# Progress: shelf art/plot + APPEND cast/crew/trailer (Telegram).
NEEDS_PROGRESS = (
    NEED_PLOT, NEED_POSTER, NEED_FANART, NEED_TRAILER, NEED_CREW, NEED_CAST,
)
NEEDS_CALENDAR = NEEDS_PROGRESS + (NEED_THUMB,)
NEEDS_FULL_SHOW = NEEDS_PROGRESS + (NEED_RATING,)
NEEDS_FULL_EPISODE = NEEDS_FULL_SHOW + (NEED_THUMB,)




class _BatchEnrichContext:
    '''Per-batch dedupe for show-level TMDB + fanart.tv JSON.'''

    __slots__ = ('_shows', '_fanart_tv', '_fanart_movie', '_lock')

    def __init__(self):
        self._shows = {}
        self._fanart_tv = {}
        self._fanart_movie = {}
        self._lock = threading.Lock()

    def get_tv_show(self, tmdb_id, append=None):
        tmdb_id = idmap.valid_id(tmdb_id)
        if not tmdb_id:
            return None
        key = (tmdb_id, append or '')
        with self._lock:
            if key in self._shows:
                return self._shows[key]
        show = tmdb_api.get_tv(tmdb_id, append=append)
        with self._lock:
            self._shows[key] = show
        return show

    def get_fanart_tv(self, tvdb_id):
        tvdb_id = idmap.valid_id(tvdb_id)
        if not tvdb_id:
            return None
        with self._lock:
            if tvdb_id in self._fanart_tv:
                return self._fanart_tv[tvdb_id]
        data = fanart_api.get_tv(tvdb_id)
        with self._lock:
            self._fanart_tv[tvdb_id] = data
        return data

    def get_fanart_movie(self, tmdb_id):
        tmdb_id = idmap.valid_id(tmdb_id)
        if not tmdb_id:
            return None
        with self._lock:
            if tmdb_id in self._fanart_movie:
                return self._fanart_movie[tmdb_id]
        data = fanart_api.get_movie(tmdb_id)
        with self._lock:
            self._fanart_movie[tmdb_id] = data
        return data


def _needs_set(needs):
    if not needs:
        return set()
    if isinstance(needs, str):
        needs = (needs,)
    return {n for n in needs if n in _ALL_NEEDS}


def _valid_id(value):
    text = str(value or '').strip()
    return text if text and text not in ('0', 'None') else ''


def ensure_episode_display_fields(row):
    '''Minimum episode identity for Kodi list + info dialog when TMDB ep is missing.'''
    if row.mediatype != 'episode':
        return row
    if not row.title:
        row.title = f'Episode {int(row.episode)}' if row.episode else 'Episode'
    if not row.originaltitle:
        row.originaltitle = row.title
    row.label = row._default_label()
    return row


def _apply_episode_show_fallback(row, show_json=None, batch_ctx=None):
    '''Episode 404 / empty  -  still apply show poster, fanart, and display identity.'''
    show = show_json
    if not show and _valid_id(row.tmdb):
        try:
            if batch_ctx:
                show = batch_ctx.get_tv_show(row.tmdb)
            else:
                show = tmdb_api.get_tv(row.tmdb)
        except Exception as exc:
            c.log(f'[Enrich] TMDB show fallback failed: {exc}', 1)
    if isinstance(show, dict):
        apply_tmdb_show(row, show, episode_context=True)
    ensure_episode_display_fields(row)
    return row


def apply_tmdb_episode(row, episode_json, show_json=None):
    if not isinstance(episode_json, dict):
        return row
    if not row.title:
        row.title = (episode_json.get('name') or '').strip()
    if not row.plot:
        row.plot = (episode_json.get('overview') or '').strip()
    if not row.premiered and episode_json.get('air_date'):
        row.premiered = str(episode_json['air_date'])[:10]
    if not row.year and row.premiered:
        row.year = str(row.premiered)[:4]
    if episode_json.get('still_path'):
        row.tmdb_still_path = episode_json['still_path']
        if not row.thumb:
            row.thumb = extract.still_url(episode_json['still_path'])
    # BASE: rating/votes/duration on bare episode JSON (no append).
    if not row.rating:
        row.rating = extract.rating_from_tmdb(episode_json.get('vote_average'))
    if not row.votes:
        row.votes = extract.votes_from_tmdb(episode_json.get('vote_count'))
    if not row.duration and episode_json.get('runtime'):
        row.duration = int(episode_json['runtime']) * 60
    # APPEND: credits/videos only present when request asked for them.
    crew = extract.crew_from_credits(episode_json.get('credits'))
    if not row.director:
        row.director = extract.directors_from_crew(crew)
    if not row.writer:
        row.writer = extract.writers_from_crew(crew)
    if not row.castwiththumb:
        row.castwiththumb = extract.cast_with_thumbs(episode_json.get('credits'))
    if not row.trailer:
        row.trailer = extract.trailer_youtube(episode_json.get('videos'))
    if show_json and isinstance(show_json, dict):
        apply_tmdb_show(row, show_json, episode_context=True)
    row.label = row._default_label()
    return row



def apply_tmdb_show(row, show_json, episode_context=False):
    if not isinstance(show_json, dict):
        return row
    if not row.tvshowtitle:
        row.tvshowtitle = (show_json.get('name') or '').strip()
    if not episode_context and not row.title:
        row.title = row.tvshowtitle
    if not row.plot:
        row.plot = (show_json.get('overview') or '').strip()
    if not row.year and show_json.get('first_air_date'):
        row.year = str(show_json['first_air_date'])[:4]
    if not row.genre:
        row.genre = extract.genres_string(show_json.get('genres'))
    if show_json.get('poster_path'):
        row.tmdb_poster_path = show_json['poster_path']
        if not row.poster:
            row.poster = extract.poster_url(show_json['poster_path'])
    if show_json.get('backdrop_path'):
        row.tmdb_backdrop_path = show_json['backdrop_path']
        if not row.fanart:
            row.fanart = extract.fanart_url(show_json['backdrop_path'])
    if not row.studio:
        networks = show_json.get('networks') or []
        if networks and isinstance(networks[0], dict):
            row.studio = networks[0].get('name') or ''
        row.network = row.studio
    # BASE: show episode_run_time fills duration when episode runtime was empty.
    if not row.duration:
        runtimes = show_json.get('episode_run_time') or []
        if runtimes:
            try:
                row.duration = int(runtimes[0]) * 60
            except (TypeError, ValueError):
                pass
    if not episode_context:
        # BASE show rating/votes (episode keeps its own vote_* from episode JSON).
        if not row.rating:
            row.rating = extract.rating_from_tmdb(show_json.get('vote_average'))
        if not row.votes:
            row.votes = extract.votes_from_tmdb(show_json.get('vote_count'))
        crew = extract.crew_from_credits(show_json.get('credits'))
        if not row.director:
            row.director = extract.directors_from_crew(crew)
        if not row.writer:
            row.writer = extract.writers_from_crew(crew)
        if not row.castwiththumb:
            row.castwiththumb = extract.cast_with_thumbs(show_json.get('credits'))
        if not row.trailer:
            row.trailer = extract.trailer_youtube(show_json.get('videos'))
    elif not row.trailer:
        # Episode rows: show-level YouTube trailer (episode videos are rarely useful).
        row.trailer = extract.trailer_youtube(show_json.get('videos'))
    return row



def apply_tmdb_movie(row, movie_json):
    if not isinstance(movie_json, dict):
        return row
    row.mediatype = 'movie'
    if not row.title:
        row.title = (movie_json.get('title') or '').strip()
    if not row.originaltitle:
        row.originaltitle = (movie_json.get('original_title') or row.title).strip()
    if not row.plot:
        row.plot = (movie_json.get('overview') or '').strip()
    if not row.year and movie_json.get('release_date'):
        row.year = str(movie_json['release_date'])[:4]
    if not row.genre:
        row.genre = extract.genres_string(movie_json.get('genres'))
    if movie_json.get('poster_path'):
        row.tmdb_poster_path = movie_json['poster_path']
        if not row.poster:
            row.poster = extract.poster_url(movie_json['poster_path'])
    if movie_json.get('backdrop_path'):
        row.tmdb_backdrop_path = movie_json['backdrop_path']
        if not row.fanart:
            row.fanart = extract.fanart_url(movie_json['backdrop_path'])
    crew = extract.crew_from_credits(movie_json.get('credits'))
    if not row.director:
        row.director = extract.directors_from_crew(crew)
    if not row.writer:
        row.writer = extract.writers_from_crew(crew)
    if not row.castwiththumb:
        row.castwiththumb = extract.cast_with_thumbs(movie_json.get('credits'))
    if not row.trailer:
        row.trailer = extract.trailer_youtube(movie_json.get('videos'))
    if not row.rating:
        row.rating = extract.rating_from_tmdb(movie_json.get('vote_average'))
    if not row.votes:
        row.votes = extract.votes_from_tmdb(movie_json.get('vote_count'))
    if not row.duration and movie_json.get('runtime'):
        row.duration = int(movie_json['runtime']) * 60
    row.label = row._default_label()
    return row


def _needs_tmdb_episode(row, needs):
    if row.mediatype != 'episode':
        return False
    if not _valid_id(row.tmdb) or not row.season or not row.episode:
        return False
    if NEED_PLOT in needs and not row.has_plot():
        return True
    if NEED_CREW in needs and not row.has_crew():
        return True
    if NEED_CAST in needs and not row.has_cast():
        return True
    if NEED_TRAILER in needs and not row.has_trailer():
        return True
    if NEED_RATING in needs and not row.rating:
        return True
    if NEED_THUMB in needs and not row.thumb and not row.tmdb_still_path:
        return True
    if NEED_POSTER in needs and not row.has_poster():
        return True
    if NEED_FANART in needs and not row.has_fanart():
        return True
    # BASE gaps: detail JSON already has these; worth one cached hit to show them.
    if not row.rating or not row.duration:
        return True
    if not (row.genre or '').strip():
        return True
    if not (row.studio or row.network or '').strip():
        return True
    return False


def _needs_tmdb_show(row, needs):
    if row.mediatype != 'tvshow':
        return False
    if not _valid_id(row.tmdb):
        return False
    if NEED_PLOT in needs and not row.has_plot():
        return True
    if NEED_CREW in needs and not row.has_crew():
        return True
    if NEED_CAST in needs and not row.has_cast():
        return True
    if NEED_TRAILER in needs and not row.has_trailer():
        return True
    if NEED_POSTER in needs and not row.has_poster():
        return True
    if NEED_FANART in needs and not row.has_fanart():
        return True
    if not row.rating or not (row.genre or '').strip():
        return True
    if not (row.studio or row.network or '').strip():
        return True
    return False



def _needs_fanart(row, needs):
    if not image_sizes.fanart_tv_fallback_enabled():
        return False
    if NEED_POSTER not in needs and NEED_FANART not in needs:
        return False
    if NEED_POSTER in needs and not row.poster and not row.thumb:
        gap_poster = True
    else:
        gap_poster = False
    if NEED_FANART in needs and not row.fanart:
        gap_fanart = True
    else:
        gap_fanart = False
    if not gap_poster and not gap_fanart:
        return False
    if row.mediatype == 'movie':
        return bool(_valid_id(row.tmdb))
    if row.mediatype in ('tvshow', 'episode'):
        return bool(_valid_id(row.tmdb) or _valid_id(row.tvdb))
    return False


def _fetch_fanart_json(row, batch_ctx=None):
    if row.mediatype == 'movie' and _valid_id(row.tmdb):
        if batch_ctx:
            return batch_ctx.get_fanart_movie(row.tmdb)
        return fanart_api.get_movie(row.tmdb)
    show_ids = idmap.resolve_show_ids(row)
    tvdb = show_ids.get('tvdb')
    if not tvdb:
        return None
    if batch_ctx:
        return batch_ctx.get_fanart_tv(tvdb)
    return fanart_api.get_tv(tvdb)


def _build_show_append(needs):
    parts = []
    if NEED_CREW in needs or NEED_CAST in needs:
        parts.append('credits')
    if NEED_TRAILER in needs:
        parts.append('videos')
    return ','.join(dict.fromkeys(parts)) if parts else None


def _build_episode_append(row, needs):
    parts = []
    if (NEED_CREW in needs and not row.has_crew()) or (NEED_CAST in needs and not row.has_cast()):
        parts.append('credits')
    if NEED_TRAILER in needs and not row.has_trailer():
        parts.append('videos')
    return ','.join(parts) if parts else None


def _fetch_tmdb_episode(row, needs, batch_ctx=None):
    append = _build_episode_append(row, needs)
    ep = tmdb_api.get_tv_episode(row.tmdb, row.season, row.episode, append=append)
    show = None
    # Show JSON carries BASE genre/studio/year (and trailer videos). Batch-deduped.
    want_show = bool(
        not ep
        or not row.has_poster()
        or not row.has_fanart()
        or not row.tvshowtitle
        or not (row.genre or '').strip()
        or not (row.studio or row.network or '').strip()
        or not str(row.year or '').strip()
        or (NEED_TRAILER in needs and not row.has_trailer())
    )
    if want_show and _valid_id(row.tmdb):
        show_append = None
        if NEED_TRAILER in needs and not row.has_trailer():
            show_append = 'videos'
        if batch_ctx:
            show = batch_ctx.get_tv_show(row.tmdb, append=show_append)
        else:
            show = tmdb_api.get_tv(row.tmdb, append=show_append)
    return ep, show


def enrich(row, needs=(), batch_ctx=None):
    '''
    Fill only requested gaps. Returns the same VideoRow (mutated).
    '''
    if not isinstance(row, VideoRow):
        row = VideoRow.from_dict(row)
    needs = _needs_set(needs)
    if not needs:
        return row

    if _needs_tmdb_episode(row, needs):
        try:
            ep, show = _fetch_tmdb_episode(row, needs, batch_ctx=batch_ctx)
            if ep:
                apply_tmdb_episode(row, ep, show)
                # cm - commented out because of an overcrowded log file
                #c.log(f'[Enrich] TMDB episode S{row.season}E{row.episode} tmdb={row.tmdb}')
            else:
                _apply_episode_show_fallback(row, show_json=show, batch_ctx=batch_ctx)
                c.log(
                    f'[Enrich] TMDB episode missing S{row.season}E{row.episode} '
                    f'tmdb={row.tmdb}  -  show fallback',
                    1,
                )
        except Exception as exc:
            _apply_episode_show_fallback(row, batch_ctx=batch_ctx)
            c.log(f'[Enrich] TMDB episode failed S{row.season}E{row.episode}: {exc}', 1)

    elif _needs_tmdb_show(row, needs):
        try:
            append = _build_show_append(needs)
            if batch_ctx:
                show = batch_ctx.get_tv_show(row.tmdb, append=append)
            else:
                show = tmdb_api.get_tv(row.tmdb, append=append)
            if show:
                apply_tmdb_show(row, show)
                # cm - commented out because of an overcrowded log file
                # c.log(f'[Enrich] TMDB show tmdb={row.tmdb}')
            else:
                c.log(f'[Enrich] TMDB show empty tmdb={row.tmdb}', 1)
        except Exception as exc:
            c.log(f'[Enrich] TMDB show failed: {exc}', 1)

    elif row.mediatype == 'movie' and _valid_id(row.tmdb):
        missing = (
            (NEED_PLOT in needs and not row.has_plot())
            or (NEED_CREW in needs and not row.has_crew())
            or (NEED_POSTER in needs and not row.has_poster())
            or (NEED_FANART in needs and not row.has_fanart())
            or not (row.genre or '').strip()
            or not str(row.year or '').strip()
            or (
                float(getattr(row, 'resume_point', 0) or 0) > 0
                and not int(getattr(row, 'duration', 0) or 0)
            )
        )
        if missing:
            try:
                movie = tmdb_api.get(
                    f'/movie/{row.tmdb}',
                    {'append_to_response': 'credits,videos'},
                )
                apply_tmdb_movie(row, movie)
            except Exception as exc:
                c.log(f'[Enrich] TMDB movie failed: {exc}', 1)

    fanart_json = None
    if _needs_fanart(row, needs):
        try:
            fanart_json = _fetch_fanart_json(row, batch_ctx=batch_ctx)
        except Exception as exc:
            c.log(f'[Enrich] Fanart failed: {exc}', 1)

    if NEED_POSTER in needs and not row.poster:
        row.poster = artwork.resolve_poster(row, fanart_json)
    if NEED_THUMB in needs and not row.thumb:
        row.thumb = artwork.resolve_thumb(row)
    if NEED_FANART in needs and not row.fanart:
        row.fanart = artwork.resolve_fanart(row, fanart_json)

    if row.mediatype == 'episode':
        ensure_episode_display_fields(row)
    else:
        row.label = row._default_label()
    return row


def enrich_batch(rows, needs=(), is_widget=False):
    '''
    Enrich many rows with a capped worker pool + shared TMDB cache + rate limit.

    Widget and browse both funnel through here so bursts stay manageable.
    '''
    if not rows:
        return []
    rows = [
        row if isinstance(row, VideoRow) else VideoRow.from_dict(row)
        for row in rows
    ]
    needs = _needs_set(needs)
    if not needs:
        return rows
    if len(rows) == 1:
        enrich(rows[0], needs=needs)
        return rows

    batch_ctx = _BatchEnrichContext()
    workers = c.get_progress_workers(len(rows), is_widget=is_widget)
    t0 = time.time()
    resize = image_sizes.get_resize_level()
    c.log(
        f'[Enrich] batch {len(rows)} rows ({workers} workers, '
        f'cpu={c.cpu_count}, widget={is_widget}, artwork={resize})'
    )

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(enrich, row, needs, batch_ctx) for row in rows]
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as exc:
                c.log(f'[Enrich] batch row failed: {exc}', 1)

    with_art = sum(1 for row in rows if row.has_poster() or row.has_fanart())
    c.log(
        f'[Enrich] batch done: {len(rows)} rows, {with_art} with art, '
        f'{time.time() - t0:.2f}s'
    )
    return rows

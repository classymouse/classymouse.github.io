# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file image_sizes.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB image size profiles  -  driven by Settings  ->  Artwork resize.'''

# TMDB /t/p/{size}/path tokens per user-facing level.
_PROFILES = {
    'min': {
        'poster': 'w342',
        'fanart': 'w780',
        'profile': 'w45',
        'still': 'w185',
    },
    'medium': {
        'poster': 'w500',
        'fanart': 'w1280',
        'profile': 'w185',
        'still': 'w300',
    },
    'max': {
        'poster': 'w780',
        'fanart': 'w1280',
        'profile': 'w185',
        'still': 'w780',
    },
    'original': {
        'poster': 'original',
        'fanart': 'original',
        'profile': 'original',
        'still': 'original',
    },
}

_DEFAULT_LEVEL = 'medium'
_VALID_LEVELS = frozenset(_PROFILES)

# Kodi enum / labelenum values from settings.xml (fallback: raw level name).
_SETTING_TO_LEVEL = {
    '32601': 'min',
    '32602': 'medium',
    '32603': 'max',
    '32604': 'original',
    '0': 'min',
    '1': 'medium',
    '2': 'max',
    '3': 'original',
    'min': 'min',
    'medium': 'medium',
    'max': 'max',
    'original': 'original',
}


def normalize_level(value):
    level = str(value or _DEFAULT_LEVEL).strip().lower()
    if level in _VALID_LEVELS:
        return level
    return _DEFAULT_LEVEL


def get_resize_level():
    try:
        from ..modules.classy import c
        raw = str(c.get_setting('artwork.resize') or '32602').strip()
        if raw in _SETTING_TO_LEVEL:
            return _SETTING_TO_LEVEL[raw]
        return normalize_level(raw)
    except Exception:
        return _DEFAULT_LEVEL


def get_size_profile(level=None):
    level = normalize_level(level) if level is not None else get_resize_level()
    return dict(_PROFILES[level])


def fanart_tv_fallback_enabled(level=None):
    '''Fanart.tv URLs are full-size  -  skip on min to save bandwidth.'''
    level = normalize_level(level) if level is not None else get_resize_level()
    return level != 'min'


def poster_size(level=None):
    return get_size_profile(level)['poster']


def fanart_size(level=None):
    return get_size_profile(level)['fanart']


def profile_size(level=None):
    return get_size_profile(level)['profile']


def still_size(level=None):
    return get_size_profile(level)['still']

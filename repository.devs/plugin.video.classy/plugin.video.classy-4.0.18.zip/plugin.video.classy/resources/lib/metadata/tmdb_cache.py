# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tmdb_cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB JSON cache  -  RAM (batch-hot) + SQLite (survives Kodi restart).'''

import threading
import time

from .. import cache
from . import cache_ttl

NS_TMDB = 'tmdb'
_RAM_MAX = 500

_store = {}
_lock = threading.Lock()


def cache_key(path, language, extra=None):
    parts = [str(path or ''), str(language or '')]
    if extra:
        for key in sorted(extra):
            parts.append(f'{key}={extra[key]}')
    return '|'.join(parts)


def get(key):
    now = time.time()
    with _lock:
        entry = _store.get(key)
        if entry and now - entry['ts'] <= entry['ttl']:
            return entry['data']

    data = cache.get_json(NS_TMDB, key, ttl_ok=True)
    if data is not None:
        with _lock:
            _store[key] = {'ts': now, 'ttl': cache_ttl.TMDB_TTL, 'data': data}
    return data


def set(key, data, ttl=None):
    if not key or data is None:
        return
    ttl = ttl if ttl is not None else cache_ttl.TMDB_TTL
    now = time.time()
    with _lock:
        _store[key] = {'ts': now, 'ttl': ttl, 'data': data}
        if len(_store) > _RAM_MAX:
            _purge_locked(now)
    cache.put_json(NS_TMDB, key, data, ttl_seconds=ttl)


def _purge_locked(now):
    stale = [k for k, entry in _store.items() if now - entry['ts'] > entry['ttl']]
    for key in stale:
        del _store[key]


def clear():
    with _lock:
        _store.clear()
    cache.clear_namespace(NS_TMDB)

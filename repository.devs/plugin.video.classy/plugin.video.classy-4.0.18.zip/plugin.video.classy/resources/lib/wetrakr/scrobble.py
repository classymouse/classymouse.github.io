# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scrobble.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr scrobble  -  home-tracker playback events via /scrobble/*.

Bypasses the sidecar should_scrobble() gate on purpose: when WeTrakr is the
XOR watch tracker, choosing it *is* the opt-in to scrobble. The sidecar path
is suppressed (apis.wetrakr.should_scrobble -> False) so events are not doubled.'''

from __future__ import annotations

from ..apis import wetrakr as api
from ..modules.classy import c
from ..progress import filters as slot_filters
from . import auth
from . import sync

MIN_POSITION_SEC = 60

_PATHS = {
    'start': '/scrobble/start',
    'pause': '/scrobble/pause',
    'stop': '/scrobble/stop',
}


def watched_percent():
    return slot_filters.resume_progress_max()


def scrobble_session(session, current_sec, total_sec, action):
    if not auth.has_credentials():
        return False

    try:
        total = float(total_sec or 0)
        current = float(current_sec or 0)
    except (TypeError, ValueError):
        return False
    if total <= 0:
        return False

    percent = max(0.0, min(100.0, (current / total) * 100.0))
    if action in ('start', 'pause') and current < MIN_POSITION_SEC and percent < 1:
        return False

    mediatype, body = api.scrobble_body_for_session(session, percent)
    if not body:
        c.log(f'[WeTrakr Scrobble] skip {action}  -  no tmdb', 1)
        return False

    path = _PATHS.get(action) or _PATHS['stop']
    # 1.0.10: pass min_progress (finished threshold) on scrobble events.
    params = {'min_progress': api._min_progress()}
    resp = api.authed_raw('POST', path, params=params, body=body, timeout=12)
    ok, ignored, _reason = api.interpret_scrobble_response(resp, action)
    if ok:
        if not ignored:
            # Soft invalidate: keep watched overlays; avoid 167-show refetch (A1e).
            sync.invalidate_tracking()
            try:
                from . import progress as wt_progress
                wt_progress.invalidate_next_episodes()
            except Exception:
                pass
            if action == 'stop':
                _maybe_patch_watched(session, mediatype, percent)
            try:
                from . import watch_sync
                watch_sync.adopt_activity_stamps()
            except Exception:
                pass
            if action in ('pause', 'stop'):
                try:
                    from ..progress.widget_signals import notify_progress_changed
                    notify_progress_changed(f'wetrakr_scrobble_{action}')
                except Exception:
                    pass
            c.log(f'[WeTrakr Scrobble] {action} {mediatype} {percent:.0f}%')
        return True
    return False


def _maybe_patch_watched(session, mediatype, percent):
    '''Local watched overlay paint when stop counts as watched.'''
    sess = session if isinstance(session, dict) else {}
    is_watched = bool(sess.get('_outcome_watched'))
    if not is_watched:
        try:
            is_watched = float(percent or 0) >= float(watched_percent())
        except (TypeError, ValueError):
            is_watched = False
    if not is_watched:
        return
    try:
        from . import watch_sync
    except Exception:
        return
    tmdb = sess.get('tmdb') or ''
    imdb = sess.get('imdb') or ''
    if (mediatype or '').lower() == 'episode':
        watch_sync.patch_episode_watched(
            tmdb,
            sess.get('season'),
            sess.get('episode'),
            watched=True,
            title=sess.get('tvshowtitle') or sess.get('title') or '',
            imdb=imdb,
            year=sess.get('year'),
        )
    else:
        watch_sync.patch_movie_watched(
            tmdb,
            watched=True,
            title=sess.get('title') or '',
            imdb=imdb,
            year=sess.get('year'),
        )

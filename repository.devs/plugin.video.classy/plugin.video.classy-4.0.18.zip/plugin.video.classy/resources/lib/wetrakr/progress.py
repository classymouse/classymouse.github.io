# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file progress.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr progress  -  next episodes + Continue Watching (slot-shaped).

Reads (verified live 2026-09):
  GET /sync/tracking/watching/shows?extended=episode_level_1
      -> each show carries next_watching_episode {season_number, number, ...}
  GET /sync/tracking/paused/shows?extended=episode_level_1  (On Hold; after Watching)
  GET /sync/tracking/playing/movies    -> playback {status, progress_percent, tracked_at}
  GET /sync/tracking/playing/episodes  -> same, with show{} + season_number/number

Next Episodes must page with fetch_tracking_all  -  bare fetch_tracking is one
API page (default ~20) and under-fills vs Watching / History.'''

from __future__ import annotations

from ..modules.classy import c
from ..progress import filters as slot_filters
from . import auth
from . import sync

_NEXT_CACHE = {'stamp': '', 'slots': None}
# 1.0.10: On Hold is 'hold'; keep reading legacy 'paused' for compatibility.
_NEXT_STATUSES = ('watching', 'hold', 'paused')


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _norm_id(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    return text


def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def invalidate_next_episodes():
    _NEXT_CACHE['stamp'] = ''
    _NEXT_CACHE['slots'] = None


def next_episode_sessions():
    '''Slots: show_data, season, episode, last_watched_at, episode_title.'''
    if not auth.has_credentials():
        return []
    stamp = sync.activity_stamp('shows') or 'unknown'
    if _NEXT_CACHE['slots'] is not None and _NEXT_CACHE['stamp'] == stamp:
        return list(_NEXT_CACHE['slots'])

    out = []
    seen = set()
    fetch_ok = False
    try:
        for status in _NEXT_STATUSES:
            entries = sync.fetch_tracking_all(
                status, 'shows', params={'extended': 'episode_level_1'},
            )
            if entries is None:
                # Page-1 failure (429 etc.)  -  keep prior mem cache if any.
                if _NEXT_CACHE['slots'] is not None:
                    c.log(
                        f'[WeTrakr] next_episode_sessions: {status} fetch failed  -  '
                        f'keeping {_NEXT_CACHE["stamp"] and len(_NEXT_CACHE["slots"]) or 0} cached'
                    )
                    return list(_NEXT_CACHE['slots'])
                c.log(f'[WeTrakr] next_episode_sessions: {status} fetch failed', 1)
                continue
            fetch_ok = True
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                ids = entry.get('ids') if isinstance(entry.get('ids'), dict) else {}
                title = (entry.get('title') or '').strip()
                tmdb = _norm_id(ids.get('tmdb'))
                if not title or not tmdb or tmdb in seen:
                    continue
                nxt = entry.get('next_watching_episode')
                if not isinstance(nxt, dict):
                    continue
                season = _int(nxt.get('season_number') or nxt.get('season'))
                episode = _int(nxt.get('number') if nxt.get('number') is not None else nxt.get('episode'))
                if season <= 0 or episode <= 0:
                    continue
                seen.add(tmdb)
                imdb = _norm_imdb(ids.get('imdb'))
                tvdb = _norm_id(ids.get('tvdb'))
                show_data = {
                    'title': title,
                    'year': entry.get('year'),
                    'ids': {
                        'imdb': imdb or None,
                        'tmdb': int(tmdb),
                        'tvdb': int(tvdb) if tvdb.isdigit() else None,
                    },
                }
                # Prefer user activity over next-ep air_date so just-watched
                # shows float onto the home widget shelf (PAGE_SIZE=25).
                activity_ts = (
                    entry.get('tracked_at')
                    or entry.get('updated_at')
                    or entry.get('last_watched_at')
                    or nxt.get('air_date')
                    or ''
                )
                out.append({
                    'show_data': show_data,
                    'season': season,
                    'episode': episode,
                    'last_watched_at': activity_ts,
                    'episode_title': (nxt.get('title') or '').strip(),
                })
        if not fetch_ok:
            return list(_NEXT_CACHE['slots'] or [])
        out.sort(key=lambda k: k.get('last_watched_at') or '', reverse=True)
        _NEXT_CACHE['stamp'] = stamp
        _NEXT_CACHE['slots'] = out
        c.log(
            f'[WeTrakr] next_episode_sessions: {len(out)} slot(s) '
            f'(watching+paused, paged)'
        )
    except Exception as exc:
        c.log(f'[WeTrakr] next_episode_sessions error: {exc}', 1)
        return list(_NEXT_CACHE['slots'] or [])
    return list(out)


def _playback_progress(item):
    pb = item.get('playback') if isinstance(item.get('playback'), dict) else {}
    try:
        return float(pb.get('progress_percent') or 0), (pb.get('tracked_at') or '')
    except (TypeError, ValueError):
        return 0.0, (pb.get('tracked_at') or '')


def movie_playback_items():
    '''Trakt-shaped playback rows for scan_in_progress_movie_slots.'''
    out = []
    pmax = slot_filters.resume_progress_max()
    for item in sync.fetch_tracking_all('playing', 'movies') or []:
        if not isinstance(item, dict):
            continue
        progress, paused_at = _playback_progress(item)
        if progress <= 0 or progress >= pmax:
            continue
        ids = item.get('ids') if isinstance(item.get('ids'), dict) else {}
        title = (item.get('title') or '').strip()
        if not title:
            continue
        movie = {
            'title': title,
            'year': None,
            'ids': {
                'tmdb': _int(ids.get('tmdb')) or None,
                'imdb': _norm_imdb(ids.get('imdb')) or None,
            },
            'runtime': _int(item.get('runtime')),
        }
        out.append({'movie': movie, 'progress': progress, 'paused_at': paused_at})
    out.sort(key=lambda k: k.get('paused_at') or '', reverse=True)
    return out


def episode_playback_items():
    '''Trakt-shaped playback rows for scan_in_progress_episode_slots.'''
    out = []
    pmax = slot_filters.resume_progress_max()
    for item in sync.fetch_tracking_all('playing', 'episodes') or []:
        if not isinstance(item, dict):
            continue
        progress, paused_at = _playback_progress(item)
        if progress <= 0 or progress >= pmax:
            continue
        show = item.get('show') if isinstance(item.get('show'), dict) else {}
        show_ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
        season = _int(item.get('season_number'))
        number = _int(item.get('number'))
        title = (show.get('title') or '').strip()
        if not title or season <= 0 or number <= 0:
            continue
        show_obj = {
            'title': title,
            'ids': {
                'tmdb': _int(show_ids.get('tmdb')) or None,
                'imdb': _norm_imdb(show_ids.get('imdb')) or None,
                'tvdb': _int(show_ids.get('tvdb')) or None,
            },
        }
        out.append({
            'show': show_obj,
            'episode': {'season': season, 'number': number},
            'progress': progress,
            'paused_at': paused_at,
        })
    out.sort(key=lambda k: k.get('paused_at') or '', reverse=True)
    return out


def watching_show_items():
    '''Trakt-shaped show rows for the in-progress shows bucket.'''
    from . import lists as wt_lists
    return wt_lists.show_items('watching')

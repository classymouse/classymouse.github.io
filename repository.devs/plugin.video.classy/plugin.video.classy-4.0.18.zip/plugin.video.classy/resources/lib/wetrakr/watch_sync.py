# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file watch_sync.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr  ->  Trakt-shaped watched payloads for WatchIndex / MovieWatchIndex.

Sources (verified live 2026-09):
  GET /sync/tracking/watched/movies    -> one row per watched movie
  GET /sync/tracking/watched/episodes  -> one row per watched episode (show{}, S/E)

Persistence: process mem + SQLite keyed by last_activities stamp (trakt/store pattern).'''

from __future__ import annotations

import copy
import threading
import time
from datetime import datetime, timezone

from ..modules.classy import c
from . import auth
from . import store
from . import sync

_WATCHED_CACHE = {
    'movies_stamp': '',
    'movies': None,
    'shows_stamp': '',
    'shows': None,
}
_RECONCILE_LOCK = threading.Lock()
_RECONCILE_GEN = 0


def invalidate():
    '''Drop process mem only. SQLite rows invalidate via activity stamp mismatch.'''
    _WATCHED_CACHE['movies_stamp'] = ''
    _WATCHED_CACHE['movies'] = None
    _WATCHED_CACHE['shows_stamp'] = ''
    _WATCHED_CACHE['shows'] = None


def _utc_now():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')


def _shows_stamp():
    return (sync.activity_stamp('shows') or 'unknown') + '|ae1'


def _movies_stamp():
    return sync.activity_stamp('movies') or 'unknown'


def _load_shows_base():
    if isinstance(_WATCHED_CACHE['shows'], list):
        return copy.deepcopy(_WATCHED_CACHE['shows'])
    cached = store.read_watched_shows_any()
    if isinstance(cached, list):
        return copy.deepcopy(cached)
    return None


def _load_movies_base():
    if isinstance(_WATCHED_CACHE['movies'], list):
        return copy.deepcopy(_WATCHED_CACHE['movies'])
    cached = store.read_watched_movies_any()
    if isinstance(cached, list):
        return copy.deepcopy(cached)
    return None


def _commit_shows(shows, stamp):
    _WATCHED_CACHE['shows'] = shows
    _WATCHED_CACHE['shows_stamp'] = stamp
    try:
        store.write_watched_shows(shows, stamp)
    except Exception as exc:
        c.log(f'[WeTrakr] watched_shows local write failed: {exc}', 1)


def _commit_movies(movies, stamp):
    _WATCHED_CACHE['movies'] = movies
    _WATCHED_CACHE['movies_stamp'] = stamp
    try:
        store.write_watched_movies(movies, stamp)
    except Exception as exc:
        c.log(f'[WeTrakr] watched_movies local write failed: {exc}', 1)


def adopt_activity_stamps():
    '''Re-key current watched mem/sqlite to the fresh activity stamp (no refetch).'''
    if not auth.has_credentials():
        return
    if not isinstance(_WATCHED_CACHE['shows'], list):
        cached = store.read_watched_shows_any()
        if isinstance(cached, list):
            _WATCHED_CACHE['shows'] = cached
    if isinstance(_WATCHED_CACHE['shows'], list):
        stamp = _shows_stamp()
        _commit_shows(list(_WATCHED_CACHE['shows']), stamp)
    if not isinstance(_WATCHED_CACHE['movies'], list):
        cached = store.read_watched_movies_any()
        if isinstance(cached, list):
            _WATCHED_CACHE['movies'] = cached
    if isinstance(_WATCHED_CACHE['movies'], list):
        stamp = _movies_stamp()
        _commit_movies(list(_WATCHED_CACHE['movies']), stamp)


def schedule_reconcile(delay_sec=2.0):
    '''Background full watched rebuild after local patch (validate without blocking Back).'''
    global _RECONCILE_GEN
    with _RECONCILE_LOCK:
        _RECONCILE_GEN += 1
        gen = _RECONCILE_GEN
    try:
        delay = max(0.0, float(delay_sec))
    except (TypeError, ValueError):
        delay = 2.0

    def worker():
        time.sleep(delay)
        with _RECONCILE_LOCK:
            if gen != _RECONCILE_GEN:
                return
        try:
            if not auth.has_credentials():
                return
            shows = _build_watched_shows()
            stamp = _shows_stamp()
            _commit_shows(shows, stamp)
            movies = _build_watched_movies()
            _commit_movies(movies, _movies_stamp())
            c.log(
                f'[WeTrakr] watched reconcile done: '
                f'{len(shows)} show(s), {len(movies)} movie(s)',
            )
        except Exception as exc:
            c.log(f'[WeTrakr] watched reconcile failed: {exc}', 1)

    try:
        threading.Thread(target=worker, name='wetrakr-watched-reconcile', daemon=True).start()
    except Exception as exc:
        c.log(f'[WeTrakr] watched reconcile schedule failed: {exc}', 1)


def _schedule_reconcile():
    schedule_reconcile(2.0)


def patch_episode_watched(
    tmdb, season, episode, *, watched=True, title='', imdb='', year=None,
):
    '''Optimistic watched_shows patch for one episode (A1e).

    Returns True when local cache was patched. Caller should soft-invalidate
    tracking and adopt_activity_stamps().'''
    tmdb_n = _norm_id(tmdb)
    season_n = _int(season)
    episode_n = _int(episode)
    if not tmdb_n or season_n <= 0 or episode_n <= 0:
        return False
    base = _load_shows_base()
    if base is None:
        c.log('[WeTrakr] watched_shows local patch skipped  -  no cache base', 1)
        return False

    shows = base
    idx = None
    for i, item in enumerate(shows):
        if not isinstance(item, dict):
            continue
        show = item.get('show') if isinstance(item.get('show'), dict) else {}
        ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
        if _norm_id(ids.get('tmdb')) == tmdb_n:
            idx = i
            break

    watched_at = _utc_now()
    if watched:
        if idx is None:
            out_ids = {'tmdb': int(tmdb_n)}
            imdb_n = _norm_imdb(imdb)
            if imdb_n:
                out_ids['imdb'] = imdb_n
            shows.append({
                'show': {
                    'title': (title or '').strip(),
                    'year': year,
                    'aired_episodes': 0,
                    'ids': out_ids,
                },
                'seasons': [{
                    'number': season_n,
                    'episodes': [{
                        'number': episode_n,
                        'plays': 1,
                        'last_watched_at': watched_at,
                    }],
                }],
                'last_watched_at': watched_at,
            })
        else:
            item = shows[idx]
            show = item.setdefault('show', {})
            if title and not (show.get('title') or '').strip():
                show['title'] = title
            seasons = item.setdefault('seasons', [])
            if not isinstance(seasons, list):
                seasons = []
                item['seasons'] = seasons
            season_entry = None
            for block in seasons:
                if _int(block.get('number')) == season_n:
                    season_entry = block
                    break
            if season_entry is None:
                season_entry = {'number': season_n, 'episodes': []}
                seasons.append(season_entry)
            eps = season_entry.setdefault('episodes', [])
            if not isinstance(eps, list):
                eps = []
                season_entry['episodes'] = eps
            found = False
            for ep in eps:
                if _int(ep.get('number')) == episode_n:
                    ep['plays'] = max(1, _int(ep.get('plays'), 1))
                    ep['last_watched_at'] = watched_at
                    found = True
                    break
            if not found:
                eps.append({
                    'number': episode_n,
                    'plays': 1,
                    'last_watched_at': watched_at,
                })
            item['last_watched_at'] = watched_at
    else:
        if idx is None:
            return True
        item = shows[idx]
        seasons = item.get('seasons') if isinstance(item.get('seasons'), list) else []
        new_seasons = []
        for block in seasons:
            if _int(block.get('number')) != season_n:
                new_seasons.append(block)
                continue
            eps = [
                ep for ep in (block.get('episodes') or [])
                if _int(ep.get('number')) != episode_n
            ]
            if eps:
                block = dict(block)
                block['episodes'] = eps
                new_seasons.append(block)
        item['seasons'] = new_seasons
        if not new_seasons:
            shows.pop(idx)

    _commit_shows(shows, _WATCHED_CACHE['shows_stamp'] or 'local')
    c.log(
        f'[WeTrakr] watched_shows local patch '
        f'{"add" if watched else "remove"} '
        f'tmdb={tmdb_n} S{season_n:02d}E{episode_n:02d}',
    )
    _schedule_reconcile()
    return True


def patch_movie_watched(tmdb, *, watched=True, title='', imdb='', year=None):
    '''Optimistic watched_movies patch for one movie (A1e).'''
    tmdb_n = _norm_id(tmdb)
    if not tmdb_n:
        return False
    base = _load_movies_base()
    if base is None:
        c.log('[WeTrakr] watched_movies local patch skipped  -  no cache base', 1)
        return False
    movies = base
    idx = None
    for i, item in enumerate(movies):
        if not isinstance(item, dict):
            continue
        movie = item.get('movie') if isinstance(item.get('movie'), dict) else {}
        ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
        if _norm_id(ids.get('tmdb')) == tmdb_n:
            idx = i
            break
    watched_at = _utc_now()
    if watched:
        if idx is None:
            out_ids = {'tmdb': int(tmdb_n)}
            imdb_n = _norm_imdb(imdb)
            if imdb_n:
                out_ids['imdb'] = imdb_n
            movies.append({
                'movie': {
                    'title': (title or '').strip(),
                    'year': year,
                    'ids': out_ids,
                },
                'plays': 1,
                'last_watched_at': watched_at,
            })
        else:
            item = movies[idx]
            item['plays'] = max(1, _int(item.get('plays'), 1))
            item['last_watched_at'] = watched_at
    else:
        if idx is not None:
            movies.pop(idx)
    _commit_movies(movies, _WATCHED_CACHE['movies_stamp'] or 'local')
    c.log(
        f'[WeTrakr] watched_movies local patch '
        f'{"add" if watched else "remove"} tmdb={tmdb_n}',
    )
    _schedule_reconcile()
    return True


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _norm_id(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    return text


def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _build_watched_movies():
    '''Return movie rows, or None when page-1 fetch failed (429 / transport).'''
    entries = sync.fetch_tracking_all('watched', 'movies')
    if entries is None:
        return None
    out = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        ids = entry.get('ids') if isinstance(entry.get('ids'), dict) else {}
        title = (entry.get('title') or '').strip()
        if not title:
            continue
        out_ids = {}
        imdb = _norm_imdb(ids.get('imdb'))
        tmdb = _norm_id(ids.get('tmdb'))
        if imdb:
            out_ids['imdb'] = imdb
        if tmdb:
            try:
                out_ids['tmdb'] = int(tmdb)
            except (TypeError, ValueError):
                pass
        if not out_ids:
            continue
        out.append({
            'movie': {
                'title': title,
                'year': entry.get('year'),
                'ids': out_ids,
            },
            'plays': _int(entry.get('watched_count'), 1) or 1,
            'last_watched_at': entry.get('watched_at') or '',
        })
    return out


def _completed_show_tmdbs():
    '''TMDB ids currently on /sync/tracking/watched/shows (caught up / finished).

    Episode payloads do not include an aired total. Using watched-episode count
    as aired_episodes made every in-progress show look 100% complete. Only shows
    WeTrakr itself lists as watched get the full checkmark.

    Returns None when the fetch itself failed (keep prior overlays).
    '''
    entries = sync.fetch_tracking_all('watched', 'shows')
    if entries is None:
        return None
    out = set()
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        ids = entry.get('ids') if isinstance(entry.get('ids'), dict) else {}
        tmdb = _norm_id(ids.get('tmdb'))
        if tmdb:
            out.add(tmdb)
    return out


def _build_watched_shows():
    '''Return show rows, or None when watched/episodes page-1 failed.'''
    episodes = sync.fetch_tracking_all('watched', 'episodes')
    if episodes is None:
        return None
    shows = {}
    for ep in episodes:
        if not isinstance(ep, dict):
            continue
        show = ep.get('show') if isinstance(ep.get('show'), dict) else {}
        ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
        tmdb = _norm_id(ids.get('tmdb'))
        if not tmdb:
            continue
        season = _int(ep.get('season_number'))
        number = _int(ep.get('number'))
        if season <= 0 or number <= 0:
            continue
        entry = shows.get(tmdb)
        if entry is None:
            out_ids = {'tmdb': int(tmdb)}
            imdb = _norm_imdb(ids.get('imdb'))
            tvdb = _norm_id(ids.get('tvdb'))
            if imdb:
                out_ids['imdb'] = imdb
            if tvdb and tvdb.isdigit():
                out_ids['tvdb'] = int(tvdb)
            entry = {
                'show': {
                    'title': (show.get('title') or '').strip(),
                    'year': show.get('year'),
                    'aired_episodes': 0,
                    'ids': out_ids,
                },
                '_seasons': {},
                'last_watched_at': '',
            }
            shows[tmdb] = entry
        watched_at = ep.get('watched_at') or ''
        season_map = entry['_seasons'].setdefault(season, {})
        if number not in season_map:
            season_map[number] = watched_at
        if watched_at and watched_at > (entry['last_watched_at'] or ''):
            entry['last_watched_at'] = watched_at

    completed = _completed_show_tmdbs()
    if completed is None:
        completed = set()
    out = []
    for tmdb, entry in shows.items():
        seasons_out = []
        watched_n = 0
        for sn in sorted(entry['_seasons'].keys()):
            eps = entry['_seasons'][sn]
            eps_out = [
                {'number': en, 'plays': 1, 'last_watched_at': eps[en] or ''}
                for en in sorted(eps.keys())
            ]
            watched_n += len(eps_out)
            seasons_out.append({'number': sn, 'episodes': eps_out})
        # Unknown aired total -> 0 (in-progress overlay). Finished shows only
        # when WeTrakr has them on the watched-shows tracking list.
        if tmdb in completed and watched_n > 0:
            entry['show']['aired_episodes'] = watched_n
        else:
            entry['show']['aired_episodes'] = 0
        out.append({
            'show': entry['show'],
            'seasons': seasons_out,
            'last_watched_at': entry['last_watched_at'],
        })
    return out


def watched_movies():
    '''Trakt-shaped watched movie rows from WeTrakr watched tracking.'''
    if not auth.has_credentials():
        return []
    stamp = sync.activity_stamp('movies') or 'unknown'
    if _WATCHED_CACHE['movies'] is not None and _WATCHED_CACHE['movies_stamp'] == stamp:
        return list(_WATCHED_CACHE['movies'])

    cached = store.read_watched_movies(stamp)
    if isinstance(cached, list):
        _WATCHED_CACHE['movies'] = cached
        _WATCHED_CACHE['movies_stamp'] = stamp
        c.log(f'[WeTrakr] watched_movies cache hit: {len(cached)} item(s)')
        return list(cached)

    try:
        out = _build_watched_movies()
        if out is None:
            stale = store.read_watched_movies_any()
            if isinstance(stale, list):
                c.log(
                    f'[WeTrakr] watched_movies fetch failed  -  '
                    f'keeping {len(stale)} cached'
                )
                return list(stale)
            c.log('[WeTrakr] watched_movies fetch failed  -  no cache', 1)
            return []
        _WATCHED_CACHE['movies'] = out
        _WATCHED_CACHE['movies_stamp'] = stamp
        if store.write_watched_movies(out, stamp):
            c.log(f'[WeTrakr] watched_movies fetched+stored: {len(out)} item(s)')
        else:
            c.log(f'[WeTrakr] watched_movies fetched: {len(out)} item(s)')
    except Exception as exc:
        c.log(f'[WeTrakr] watched_movies error: {exc}', 1)
        return []
    return list(out)


def watched_shows():
    '''Trakt-shaped watched show rows (seasons/episodes) from WeTrakr.

    Aggregates every watched episode by show tmdb. aired_episodes stays 0 unless
    the show is on /sync/tracking/watched/shows (true complete). Never use
    watched-episode count as aired  -  that painted In Progress Shows as done.'''
    if not auth.has_credentials():
        return []
    # |ae1 busts caches that stored aired_episodes == watched count.
    stamp = (sync.activity_stamp('shows') or 'unknown') + '|ae1'
    if _WATCHED_CACHE['shows'] is not None and _WATCHED_CACHE['shows_stamp'] == stamp:
        return list(_WATCHED_CACHE['shows'])

    cached = store.read_watched_shows(stamp)
    if isinstance(cached, list) and store.watched_has_episode_detail(cached):
        _WATCHED_CACHE['shows'] = cached
        _WATCHED_CACHE['shows_stamp'] = stamp
        c.log(f'[WeTrakr] watched_shows cache hit: {len(cached)} show(s)')
        return list(cached)

    try:
        out = _build_watched_shows()
        if out is None:
            stale = store.read_watched_shows_any()
            if isinstance(stale, list) and store.watched_has_episode_detail(stale):
                c.log(
                    f'[WeTrakr] watched_shows fetch failed  -  '
                    f'keeping {len(stale)} cached'
                )
                return list(stale)
            c.log('[WeTrakr] watched_shows fetch failed  -  no cache', 1)
            return []
        _WATCHED_CACHE['shows'] = out
        _WATCHED_CACHE['shows_stamp'] = stamp
        if store.write_watched_shows(out, stamp):
            c.log(f'[WeTrakr] watched_shows fetched+stored: {len(out)} show(s)')
        else:
            c.log(f'[WeTrakr] watched_shows fetched: {len(out)} show(s)')
    except Exception as exc:
        c.log(f'[WeTrakr] watched_shows error: {exc}', 1)
        return []
    return list(out)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file maintenance.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr cache clear + force-sync for Tools.'''

from __future__ import annotations

from ..modules.classy import c
from . import auth
from . import calendars
from . import progress
from . import store
from . import sync
from . import watch_sync


def clear_all_caches():
    '''Drop in-memory + SQLite WeTrakr caches (calendars, tracking, watched, next-ep).'''
    try:
        calendars.clear_cache()
    except Exception as exc:
        c.log(f'[WeTrakr] calendar clear failed: {exc}', 1)
    try:
        sync.invalidate()
    except Exception as exc:
        c.log(f'[WeTrakr] sync invalidate failed: {exc}', 1)
    try:
        progress.invalidate_next_episodes()
    except Exception as exc:
        c.log(f'[WeTrakr] next-ep clear failed: {exc}', 1)
    try:
        store.clear_watched()
    except Exception as exc:
        c.log(f'[WeTrakr] store clear failed: {exc}', 1)
    c.log('[WeTrakr] caches cleared')
    return True


def force_sync():
    '''Clear caches, refresh activities, rebuild watched movie/show indexes.'''
    clear_all_caches()
    if not auth.has_credentials():
        c.log('[WeTrakr] force_sync: no credentials', 1)
        return False
    try:
        sync.get_last_activities(force=True)
    except Exception as exc:
        c.log(f'[WeTrakr] force_sync activities failed: {exc}', 1)
    movies = []
    shows = []
    try:
        movies = watch_sync.watched_movies() or []
    except Exception as exc:
        c.log(f'[WeTrakr] force_sync movies failed: {exc}', 1)
    try:
        shows = watch_sync.watched_shows() or []
    except Exception as exc:
        c.log(f'[WeTrakr] force_sync shows failed: {exc}', 1)
    try:
        progress.invalidate_next_episodes()
        progress.next_episode_sessions()
    except Exception as exc:
        c.log(f'[WeTrakr] force_sync next-ep failed: {exc}', 1)
    c.log(
        f'[WeTrakr] force_sync done movies={len(movies)} shows={len(shows)}'
    )
    return True


def confirm_and_clear():
    if not c.yesnoDialog(c.lang(90418)):
        return False
    clear_all_caches()
    c.infoDialog(c.lang(90419), sound=True, icon='INFO')
    return True


def confirm_and_force_sync():
    if not c.yesnoDialog(c.lang(90420)):
        return False
    ok = force_sync()
    if ok:
        c.infoDialog(c.lang(90421), sound=True, icon='INFO')
    else:
        c.infoDialog(c.lang(90422), sound=True, icon='ERROR')
    return ok

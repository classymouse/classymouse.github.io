# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file sync.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr library sync  -  activities-gated tracking-list reads.

Endpoints (API through 1.0.10 beta):
  GET /sync/last_activities
  GET /sync/tracking/{status}/{target}
      status: watched | planning | watching | playing | dropped | paused | waiting
      target: movies | shows | episodes
  GET /sync/favorites/{movies|shows}
  Waiting is its own tracking shelf (caught-up / wait-list). Watched may also
  include caught-up shows when the user enables that WeTrakr site setting.
'''

from __future__ import annotations

import time

from .. import cache as disk_cache
from ..apis import wetrakr as api
from ..modules.classy import c
from . import auth

_STATUS_CACHE = {}
_ACTIVITIES_CACHE = {'ts': 0.0, 'data': {}}
_ACTIVITIES_TTL = 20 * 60  # seconds (process mem)
# Shared across LanguageInvoker processes so Home widget bursts share one probe.
_ACTIVITIES_DISK_NS = 'wetrakr'
_ACTIVITIES_DISK_KEY = 'last_activities'
_ACTIVITIES_DISK_TTL = 90  # seconds


def get_last_activities(force=False):
    now = time.time()
    if (
        not force
        and _ACTIVITIES_CACHE['data']
        and (now - _ACTIVITIES_CACHE['ts']) < _ACTIVITIES_TTL
    ):
        return _ACTIVITIES_CACHE['data']
    if not force:
        disk = disk_cache.get_json(
            _ACTIVITIES_DISK_NS, _ACTIVITIES_DISK_KEY, ttl_ok=True,
        )
        if isinstance(disk, dict) and disk:
            _ACTIVITIES_CACHE['data'] = disk
            _ACTIVITIES_CACHE['ts'] = now
            return disk
    if api.is_rate_limited():
        if _ACTIVITIES_CACHE['data']:
            return _ACTIVITIES_CACHE['data']
        disk = disk_cache.get_json(
            _ACTIVITIES_DISK_NS, _ACTIVITIES_DISK_KEY, ttl_ok=False,
        )
        if isinstance(disk, dict) and disk:
            return disk
        return {}
    data = api.authed_json('GET', '/sync/last_activities') if auth.has_credentials() else {}
    if not isinstance(data, dict) or not data:
        # 429 / transport miss  -  keep last-good stamps so overlays stay warm.
        if _ACTIVITIES_CACHE['data']:
            c.log('[WeTrakr] last_activities miss  -  keeping cached stamps', 1)
            return _ACTIVITIES_CACHE['data']
        disk = disk_cache.get_json(
            _ACTIVITIES_DISK_NS, _ACTIVITIES_DISK_KEY, ttl_ok=False,
        )
        if isinstance(disk, dict) and disk:
            return disk
        return {}
    _ACTIVITIES_CACHE['data'] = data
    _ACTIVITIES_CACHE['ts'] = now
    try:
        disk_cache.put_json(
            _ACTIVITIES_DISK_NS, _ACTIVITIES_DISK_KEY, data,
            ttl_seconds=_ACTIVITIES_DISK_TTL,
        )
    except Exception:
        pass
    return data


def activity_stamp(target):
    '''Stamp for cache invalidation. target: movies | shows | episodes.

    1.0.10: prefer last_playback_at so playing / Continue Watching refreshes as
    soon as a scrobble lands; fall back to the existing 'all' stamp.'''
    acts = get_last_activities()
    key = target if target in ('movies', 'shows', 'episodes') else 'all'
    block = acts.get(key) if isinstance(acts.get(key), dict) else {}
    stamp = (
        block.get('last_playback_at')
        or block.get('all')
        or acts.get('last_playback_at')
        or acts.get('all')
        or ''
    )
    return str(stamp or '')


def invalidate(*, watched=True):
    '''Drop activities + tracking page cache.

    watched=True also drops compiled watched_shows/movies (full rebuild next
    read). watched=False keeps overlays  -  scrobble/CM paths patch + restamp
    instead of refetching the whole library (A1e).'''
    _STATUS_CACHE.clear()
    _ACTIVITIES_CACHE['data'] = {}
    _ACTIVITIES_CACHE['ts'] = 0.0
    try:
        disk_cache.delete(_ACTIVITIES_DISK_NS, _ACTIVITIES_DISK_KEY)
    except Exception:
        pass
    if not watched:
        return
    try:
        from . import watch_sync
        watch_sync.invalidate()
    except Exception:
        pass


def invalidate_tracking():
    '''Soft invalidate  -  refresh playing/lists without wiping watched overlays.'''
    invalidate(watched=False)


def _stamp_target(target):
    return 'shows' if target in ('shows', 'episodes') else 'movies'


def fetch_tracking(status, target, params=None):
    '''GET /sync/tracking/{status}/{target}  -  activity-gated list, cached.'''
    if not auth.has_credentials():
        return []
    stamp = activity_stamp(_stamp_target(target)) or 'unknown'
    param_key = tuple(sorted((params or {}).items()))
    cache_key = (status, target, stamp, param_key)
    cached = _STATUS_CACHE.get(cache_key)
    if cached is not None:
        return list(cached)
    try:
        data = api.authed_json(
            'GET', f'/sync/tracking/{status}/{target}', params=params,
        )
        items = data if isinstance(data, list) else []
        _STATUS_CACHE[cache_key] = items
        c.log(
            f'[WeTrakr] fetch_tracking {status}/{target}: '
            f'{len(items)} item(s) (act={stamp[:19]})'
        )
        return list(items)
    except Exception as exc:
        c.log(f'[WeTrakr] fetch_tracking error ({status}/{target}): {exc}', 1)
        return []


_PAGE_LIMIT = 100
_MAX_PAGES = 50  # safety cap  -  up to 5,000 rows for the first watched sync


def fetch_tracking_all(status, target, params=None):
    '''Walk every page of /sync/tracking/{status}/{target} (limit 100).

    Used for the watched-history overlays where all rows are needed. Not cached
    per-page here; callers (watch_sync) cache the assembled payload by stamp.

    Returns None when page 1 fails (429 / transport) so callers can keep stale
    overlays instead of treating a rate-limit as an empty library.
    '''
    if not auth.has_credentials():
        return []
    out = []
    base = dict(params or {})
    base['limit'] = _PAGE_LIMIT
    for page in range(1, _MAX_PAGES + 1):
        req = dict(base)
        req['page'] = page
        try:
            data = api.authed_json(
                'GET', f'/sync/tracking/{status}/{target}', params=req,
            )
        except Exception as exc:
            c.log(f'[WeTrakr] fetch_tracking_all error ({status}/{target} p{page}): {exc}', 1)
            return None if page == 1 else out
        if data is None:
            c.log(
                f'[WeTrakr] fetch_tracking_all miss '
                f'({status}/{target} p{page})  -  rate-limit/transport',
                1,
            )
            return None if page == 1 else out
        if not isinstance(data, list):
            c.log(
                f'[WeTrakr] fetch_tracking_all bad payload '
                f'({status}/{target} p{page}): {type(data).__name__}',
                1,
            )
            return None if page == 1 else out
        out.extend(data)
        if len(data) < _PAGE_LIMIT:
            break
    return out


def _payload_rows(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ('data', 'items', 'results'):
            block = payload.get(key)
            if isinstance(block, list):
                return block
    return []


def fetch_favorites_all(target):
    '''Walk every page of GET /sync/favorites/{movies|shows}.'''
    if not auth.has_credentials():
        return []
    if target not in ('movies', 'shows'):
        return []
    out = []
    for page in range(1, _MAX_PAGES + 1):
        try:
            data = api.authed_json(
                'GET', f'/sync/favorites/{target}',
                params={'page': page, 'limit': _PAGE_LIMIT},
            )
        except Exception as exc:
            c.log(f'[WeTrakr] fetch_favorites_all error ({target} p{page}): {exc}', 1)
            break
        items = _payload_rows(data)
        out.extend(items)
        if len(items) < _PAGE_LIMIT:
            break
    return out

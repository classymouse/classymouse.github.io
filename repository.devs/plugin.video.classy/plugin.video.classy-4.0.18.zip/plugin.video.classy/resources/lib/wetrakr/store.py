# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file store.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr profile persistence  -  SQLite cache with activity-stamp invalidation
(same pattern as trakt/store.py).'''

from .. import cache
from ..modules.classy import c

NS_WETRAKR = 'wetrakr'
KEY_WATCHED_SHOWS = 'watched_shows'
KEY_WATCHED_MOVIES = 'watched_movies'


def watched_has_episode_detail(shows):
    '''True when at least one show has season/episode rows.'''
    if not isinstance(shows, list):
        return False
    for item in shows:
        if not isinstance(item, dict):
            continue
        seasons = item.get('seasons')
        if not seasons:
            continue
        if isinstance(seasons, dict):
            seasons = list(seasons.values())
        for season in seasons:
            if season.get('episodes'):
                return True
    return False


def read_watched_shows(invalidation):
    if not invalidation:
        return None
    shows = cache.get_json(NS_WETRAKR, KEY_WATCHED_SHOWS, invalidation=invalidation)
    if isinstance(shows, list) and watched_has_episode_detail(shows):
        return shows
    return None


def read_watched_shows_any():
    '''Latest watched_shows row ignoring activity stamp (local patch base).'''
    shows = cache.get_json(NS_WETRAKR, KEY_WATCHED_SHOWS, invalidation=None)
    if isinstance(shows, list) and watched_has_episode_detail(shows):
        return shows
    return None


def read_watched_movies_any():
    items = cache.get_json(NS_WETRAKR, KEY_WATCHED_MOVIES, invalidation=None)
    return items if isinstance(items, list) else None


def write_watched_shows(shows, invalidation):
    if not isinstance(shows, list) or not invalidation:
        return False
    if not watched_has_episode_detail(shows):
        c.log(
            '[WeTrakrStore] watched/shows not cached  -  response lacks season/episode detail',
            1,
        )
        return False
    return cache.put_json(
        NS_WETRAKR, KEY_WATCHED_SHOWS, shows, invalidation=invalidation,
    )


def read_watched_movies(invalidation):
    if not invalidation:
        return None
    items = cache.get_json(NS_WETRAKR, KEY_WATCHED_MOVIES, invalidation=invalidation)
    return items if isinstance(items, list) else None


def write_watched_movies(items, invalidation):
    if not isinstance(items, list) or not invalidation:
        return False
    return cache.put_json(
        NS_WETRAKR, KEY_WATCHED_MOVIES, items, invalidation=invalidation,
    )


def clear_watched():
    cache.delete(NS_WETRAKR, KEY_WATCHED_SHOWS)
    cache.delete(NS_WETRAKR, KEY_WATCHED_MOVIES)

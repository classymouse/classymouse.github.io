# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file calendars.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr calendars  -  What's On via GET /calendar/shows, movie releases
via GET /calendar/movies.

mode=following  ->  My (authorised)
mode=discover   ->  All (app key)

Show API embeds ids; movie rows may need GET /movies/{id} for TMDB.'''

from __future__ import annotations

import time
from datetime import date, datetime, timedelta

from ..apis import wetrakr as wetrakr_api
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from . import auth

_MY_PRESETS = frozenset({
    'mycalendar',
    'calendar_today',
    'calendar_thisweek',
    'calendar_nextweek',
})

_WHATS_ON_PRESETS = _MY_PRESETS | frozenset({
    'calendar_all_today',
    'calendar_all_thisweek',
    'calendar_all_thismonth',
})

_MOVIE_PRESETS = frozenset({
    'wetrakrmovie_all_thisweek',
    'wetrakrmovie_all_thismonth',
    'wetrakrmovie_my_thisweek',
    'wetrakrmovie_my_thismonth',
})

# Soft cap for public discover dumps (a week can be thousands of rows).
_DISCOVER_CAP = 400

# Match Trakt calendar_lists: in-memory TTL so reopen / page flips skip the API.
_CACHE_TTL = 7200
_global_cache = {}
_movie_tmdb_cache = {}


def _cache_get(key):
    entry = _global_cache.get(key)
    if not entry:
        return None
    ts, items = entry
    if (time.monotonic() - ts) > _CACHE_TTL:
        _global_cache.pop(key, None)
        return None
    return items


def _cache_put(key, items):
    _global_cache[key] = (time.monotonic(), list(items))


def clear_cache():
    _global_cache.clear()
    _movie_tmdb_cache.clear()


def is_movie_calendar_preset(preset):
    return (preset or '').strip() in _MOVIE_PRESETS


def _iana_tz():
    try:
        name = getattr(datetime.now().astimezone().tzinfo, 'key', None)
        if name and '/' in str(name):
            return str(name)
    except Exception:
        pass
    return 'UTC'


def _parse_int(value):
    if value in (None, '', 'None', 'null', 0, '0'):
        return None
    try:
        result = int(value)
        return result if result > 0 else None
    except (TypeError, ValueError):
        return None


def _norm_imdb(raw):
    text = str(raw or '').strip()
    if not text or text.lower() in ('none', 'null', '0'):
        return None
    if text.isdigit():
        return 'tt%s' % text
    return text


def _air_local_date(raw):
    try:
        air_dt = datetime.fromisoformat(str(raw).replace('Z', '+00:00'))
        return air_dt.astimezone().date() if air_dt.tzinfo else air_dt.date()
    except Exception:
        try:
            return date.fromisoformat(str(raw)[:10])
        except Exception:
            return None


def _window_spec(window):
    '''Return (mode, start, end, predicate(air_local_date) -> bool, sort_mode).'''
    today = date.today()
    w = (window or '').strip().lower()

    if w in ('calendar_today',):
        return (
            'following', today, today,
            lambda d: d == today,
            'alpha',
        )
    if w in ('calendar_thisweek',):
        end = today + timedelta(days=6)
        return (
            'following', today, end,
            lambda d: today <= d <= end,
            'date_asc',
        )
    if w in ('calendar_nextweek',):
        start = today + timedelta(days=7)
        end = today + timedelta(days=14)
        return (
            'following', today, end,
            lambda d: start <= d <= end,
            'date_asc',
        )
    if w in ('mycalendar', 'my'):
        start = today - timedelta(days=7)
        return (
            'following', start, today,
            lambda d: start <= d <= today,
            'date_desc',
        )
    if w in ('calendar_all_today',):
        return (
            'discover', today, today,
            lambda d: d == today,
            'alpha',
        )
    if w in ('calendar_all_thisweek',):
        end = today + timedelta(days=6)
        return (
            'discover', today, end,
            lambda d: today <= d <= end,
            'date_asc',
        )
    if w in ('calendar_all_thismonth',):
        end = today + timedelta(days=29)
        return (
            'discover', today, end,
            lambda d: today <= d <= end,
            'date_asc',
        )
    end = today + timedelta(days=6)
    return (
        'following', today, end,
        lambda d: today <= d <= end,
        'date_asc',
    )


def _sort_key(item, sort_mode):
    aired = item.get('first_aired') or ''
    title = ((item.get('show') or {}).get('title') or '').lower()
    if sort_mode == 'alpha':
        return (title, aired)
    if sort_mode == 'date_desc':
        return (aired, title)
    return (aired, title)


def _fetch_payload(mode, start, end):
    params = {
        'start': start.isoformat(),
        'end': end.isoformat(),
        'mode': mode,
        'tz': _iana_tz(),
    }
    user = mode == 'following'
    return wetrakr_api.api_json(
        'GET', '/calendar/shows',
        params=params,
        user=user,
        timeout=25,
    )


def _cache_key(window, mode, start, end):
    # Include local "today" so midnight rolls off stale Today / This week slices.
    user = auth.get_username() if mode == 'following' else 'public'
    return '%s|%s|%s|%s|%s|%s|%s' % (
        window,
        mode,
        start.isoformat(),
        end.isoformat(),
        date.today().isoformat(),
        _iana_tz(),
        user or 'user',
    )


def _raw_calendar_items(window):
    mode, start, end, in_window, sort_mode = _window_spec(window)
    if mode == 'following' and not auth.has_credentials():
        return []

    key = _cache_key(window, mode, start, end)
    cached = _cache_get(key)
    if cached is not None:
        c.log(f'[WeTrakr] calendar cache hit window={window} ({len(cached)} episode(s))', 1)
        return list(cached)

    payload = _fetch_payload(mode, start, end)
    if not isinstance(payload, dict):
        c.log('[WeTrakr] calendar: empty/invalid response', 1)
        return []

    days = payload.get('days') if isinstance(payload.get('days'), dict) else {}
    out = []
    for _day_key, items in days.items():
        if not isinstance(items, list):
            continue
        for entry in items:
            if not isinstance(entry, dict):
                continue
            show = entry.get('show') if isinstance(entry.get('show'), dict) else {}
            ids = show.get('ids') if isinstance(show.get('ids'), dict) else {}
            # 1.0.8+: calendar rows carry external ids on the entry too.
            entry_ids = entry.get('ids') if isinstance(entry.get('ids'), dict) else {}
            tmdb = _parse_int(
                ids.get('tmdb')
                or entry_ids.get('tmdb')
                or entry.get('tmdb_id')
                or entry.get('tmdb')
            )
            season = _parse_int(entry.get('season_number') or entry.get('season'))
            number = _parse_int(entry.get('number') or entry.get('episode'))
            title = (show.get('title') or '').strip()
            if not tmdb or season is None or not number or not title:
                continue
            if season < 0 or number < 1:
                continue

            air_raw = entry.get('air_datetime') or entry.get('air_date') or _day_key
            air_local = _air_local_date(air_raw)
            if air_local is None or not in_window(air_local):
                continue

            out.append({
                'show': {
                    'title': title,
                    'ids': {
                        'tmdb': tmdb,
                        'imdb': _norm_imdb(ids.get('imdb') or entry_ids.get('imdb')),
                        'tvdb': _parse_int(ids.get('tvdb') or entry_ids.get('tvdb')),
                    },
                },
                'episode': {
                    'season': season,
                    'number': number,
                    'title': (entry.get('title') or entry.get('episode_title') or '').strip(),
                },
                'first_aired': air_local.strftime('%Y-%m-%d'),
            })

    reverse = sort_mode == 'date_desc'
    out.sort(key=lambda item: _sort_key(item, sort_mode), reverse=reverse)

    if mode == 'discover' and len(out) > _DISCOVER_CAP:
        # Keep nearest to today so month dumps stay usable.
        today = date.today()

        def _distance(item):
            try:
                day = date.fromisoformat(str(item.get('first_aired') or '')[:10])
            except Exception:
                return 99999
            return abs((day - today).days)

        out = sorted(out, key=_distance)[:_DISCOVER_CAP]
        out.sort(key=lambda item: _sort_key(item, sort_mode), reverse=reverse)

    _cache_put(key, out)
    c.log(f'[WeTrakr] calendar window={window} mode={mode}: {len(out)} episode(s)', 1)
    return out


def calendar_episodes(window='calendar_thisweek'):
    '''Raw Trakt-shaped episode dicts for a What's On preset.'''
    try:
        preset = (window or '').strip()
        if preset and preset not in _WHATS_ON_PRESETS:
            return []
        return _raw_calendar_items(preset or 'calendar_thisweek')
    except Exception as exc:
        c.log(f'[WeTrakr] calendar_episodes error: {exc}', 1)
        return []


def fetch_page(preset, *, page=1, page_size=50, widget_limit=None, **_kwargs):
    '''Return (VideoRow list, total) matching simkl/trakt calendar fetch_page.'''
    preset = (preset or '').strip()
    if preset in _MY_PRESETS and not auth.has_credentials():
        return [], 0

    items = calendar_episodes(preset)
    rows = []
    for item in items:
        try:
            rows.append(VideoRow.from_trakt_episode(item))
        except Exception:
            continue

    total = len(rows)
    if widget_limit:
        try:
            limit = max(1, int(widget_limit))
        except (TypeError, ValueError):
            limit = 20
        return rows[:limit], total

    try:
        page = max(1, int(page))
        page_size = max(1, int(page_size))
    except (TypeError, ValueError):
        page, page_size = 1, 50
    start = (page - 1) * page_size
    return rows[start:start + page_size], total


def _movie_region():
    '''ISO region for /calendar/movies (theatrical windows). Default US.'''
    try:
        import xbmc
        region = (xbmc.getRegion('locale') or '').strip()
        # locale can be "en_US" / "en-GB"  -  take country segment.
        for sep in ('_', '-', '.'):
            if sep in region:
                part = region.rsplit(sep, 1)[-1]
                if len(part) == 2 and part.isalpha():
                    return part.upper()
        if len(region) == 2 and region.isalpha():
            return region.upper()
    except Exception:
        pass
    return 'US'


def _movie_window_spec(window):
    '''Return (mode, start, end) for movie calendar presets.'''
    today = date.today()
    w = (window or '').strip().lower()
    if w in ('wetrakrmovie_all_thisweek',):
        return 'discover', today, today + timedelta(days=6)
    if w in ('wetrakrmovie_all_thismonth',):
        return 'discover', today, today + timedelta(days=29)
    if w in ('wetrakrmovie_my_thisweek',):
        return 'following', today, today + timedelta(days=6)
    if w in ('wetrakrmovie_my_thismonth',):
        return 'following', today, today + timedelta(days=29)
    return 'discover', today, today + timedelta(days=6)


def _tmdb_from_movie_entry(entry):
    if not isinstance(entry, dict):
        return None
    for key in ('tmdb_id', 'tmdb'):
        parsed = _parse_int(entry.get(key))
        if parsed:
            return parsed
    ids = entry.get('ids') if isinstance(entry.get('ids'), dict) else {}
    parsed = _parse_int(ids.get('tmdb'))
    if parsed:
        return parsed
    movie = entry.get('movie') if isinstance(entry.get('movie'), dict) else {}
    mids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
    return _parse_int(mids.get('tmdb') or movie.get('tmdb'))


def _catalog_tmdb(wetrakr_id):
    wid = _parse_int(wetrakr_id)
    if not wid:
        return None
    if wid in _movie_tmdb_cache:
        return _movie_tmdb_cache[wid]
    try:
        data = wetrakr_api.api_json(
            'GET', f'/movies/{wid}', user=False, timeout=15,
        )
    except Exception:
        data = None
    tmdb = None
    if isinstance(data, dict):
        ids = data.get('ids') if isinstance(data.get('ids'), dict) else {}
        tmdb = _parse_int(ids.get('tmdb') or data.get('tmdb'))
    _movie_tmdb_cache[wid] = tmdb
    return tmdb


def _fetch_movie_payload(mode, start, end):
    params = {
        'start': start.isoformat(),
        'end': end.isoformat(),
        'mode': mode,
        'region': _movie_region(),
    }
    return wetrakr_api.api_json(
        'GET', '/calendar/movies',
        params=params,
        user=(mode == 'following'),
        timeout=25,
    )


def _raw_movie_calendar_items(window):
    mode, start, end = _movie_window_spec(window)
    if mode == 'following' and not auth.has_credentials():
        return []

    key = 'movie|%s' % _cache_key(window, mode, start, end)
    cached = _cache_get(key)
    if cached is not None:
        c.log(
            f'[WeTrakr] movie calendar cache hit window={window} '
            f'({len(cached)} movie(s))',
            1,
        )
        return list(cached)

    payload = _fetch_movie_payload(mode, start, end)
    if not isinstance(payload, dict):
        c.log('[WeTrakr] movie calendar: empty/invalid response', 1)
        return []

    days = payload.get('days') if isinstance(payload.get('days'), dict) else {}
    out = []
    seen = set()
    for day_key, items in days.items():
        if not isinstance(items, list):
            continue
        for entry in items:
            if not isinstance(entry, dict):
                continue
            release = str(
                entry.get('release_date') or day_key or ''
            )[:10]
            try:
                release_day = date.fromisoformat(release)
            except Exception:
                continue
            if release_day < start or release_day > end:
                continue

            tmdb = _tmdb_from_movie_entry(entry)
            if not tmdb:
                tmdb = _catalog_tmdb(entry.get('id') or entry.get('media_id'))
            if not tmdb or tmdb in seen:
                continue
            seen.add(tmdb)

            movie = entry.get('movie') if isinstance(entry.get('movie'), dict) else {}
            title = (
                (movie.get('title') or entry.get('title') or '').strip()
            )
            ids = movie.get('ids') if isinstance(movie.get('ids'), dict) else {}
            if not isinstance(ids, dict):
                ids = {}
            out.append({
                'movie': {
                    'title': title or f'TMDB {tmdb}',
                    'year': _parse_int(str(release)[:4]),
                    'released': release,
                    'overview': (
                        movie.get('overview') or entry.get('overview') or ''
                    ),
                    'ids': {
                        'tmdb': tmdb,
                        'imdb': _norm_imdb(
                            ids.get('imdb') or entry.get('imdb')
                        ),
                    },
                },
            })

    out.sort(key=lambda item: (
        (item.get('movie') or {}).get('released') or '',
        ((item.get('movie') or {}).get('title') or '').lower(),
    ))

    if mode == 'discover' and len(out) > _DISCOVER_CAP:
        today = date.today()

        def _distance(item):
            try:
                day = date.fromisoformat(
                    str((item.get('movie') or {}).get('released') or '')[:10]
                )
            except Exception:
                return 99999
            return abs((day - today).days)

        out = sorted(out, key=_distance)[:_DISCOVER_CAP]
        out.sort(key=lambda item: (
            (item.get('movie') or {}).get('released') or '',
            ((item.get('movie') or {}).get('title') or '').lower(),
        ))

    _cache_put(key, out)
    c.log(
        f'[WeTrakr] movie calendar window={window} mode={mode}: '
        f'{len(out)} movie(s) region={_movie_region()}',
        1,
    )
    return out


def fetch_movie_page(preset, *, page=1):
    '''movies_calendar&url=wetrakrmovie_*  -  Trakt-shaped movie page.'''
    preset = (preset or '').strip()
    if preset not in _MOVIE_PRESETS:
        return None
    if preset.startswith('wetrakrmovie_my_') and not auth.has_credentials():
        c.log(f'[WeTrakr] {preset} requires auth', 1)
        return None

    items = _raw_movie_calendar_items(preset)
    try:
        page = max(1, int(page or 1))
    except (TypeError, ValueError):
        page = 1
    limit = 40
    total = len(items)
    total_pages = max(1, (total + limit - 1) // limit) if total else 1
    if page > total_pages:
        page = total_pages
    start = (page - 1) * limit
    page_items = items[start:start + limit]
    c.log(
        f'[WeTrakr] movie calendar {preset} page={page}/{total_pages} '
        f'({len(page_items)}/{total} items)'
    )
    return {
        'results': page_items,
        'page': page,
        'total_pages': total_pages,
        '_source': 'trakt_movies',
        '_preset': preset,
    }

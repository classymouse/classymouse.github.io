# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file auth.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr credentials  -  thin re-export of the OAuth sidecar (apis.wetrakr).

Tokens rotate via refresh; apis.wetrakr owns the device flow + refresh.'''

from ..apis import wetrakr as _api


def has_credentials() -> bool:
    return bool(_api.has_credentials())


def get_username() -> str:
    from ..modules.classy import c
    return (c.get_setting('wetrakr.user') or '').strip()


def live() -> bool:
    '''Authorised and usable as the home tracker.

    Presence of a token is enough  -  requests refresh lazily (apis.wetrakr),
    so we never fire a network call on the frequent menu-visibility checks.'''
    return has_credentials()

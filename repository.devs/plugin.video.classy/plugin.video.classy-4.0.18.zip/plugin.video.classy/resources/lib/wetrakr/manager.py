# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file manager.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr Manager dialog  -  tracking, favorites, personal list housekeeping.'''

from __future__ import annotations

from ..apis import wetrakr as api
from ..modules import control
from ..modules.classy import c
from . import auth
from . import sync
from . import user_lists as wt_lists

L_ADD_STATUS = 'Add to %s'
L_REMOVE_STATUS = 'Remove from %s'
L_ADD_LIST = 'Add to %s'
L_REMOVE_LIST = 'Remove from %s'
L_ADD_FAVORITE = 'Add to Favorites'
L_REMOVE_FAVORITE = 'Remove from Favorites'


def _success_message(label):
    '''Action menu uses Add/Remove; toast uses past tense.'''
    text = str(label or '').strip()
    if text.startswith('Add to '):
        return 'Added to ' + text[len('Add to '):]
    if text.startswith('Remove from '):
        return 'Removed from ' + text[len('Remove from '):]
    return text

_MOVIE_STATUSES = (
    ('planning', 'Plan to Watch'),
    ('watched', 'Watched'),
    ('dropped', 'Dropped'),
)
_SHOW_STATUSES = (
    ('planning', 'Plan to Watch'),
    ('watching', 'Watching'),
    # 1.0.10: On Hold writes as 'hold' (legacy 'paused' still readable in lists).
    ('hold', 'On Hold'),
    ('watched', 'Watched'),
    ('dropped', 'Dropped'),
)


def _valid_id(value):
    text = str(value or '').strip()
    return text and text not in ('0', 'None', 'null')


def _norm_content(content):
    text = str(content or '').strip().lower()
    if text in ('movie', 'movies'):
        return 'movie'
    return 'show'


def _write_item(imdb, tmdb, status=None):
    ids = {}
    if _valid_id(imdb):
        imdb = str(imdb).strip()
        ids['imdb'] = imdb if imdb.startswith('tt') else f'tt{imdb}'
    if _valid_id(tmdb):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    if not ids:
        return None
    item = {'ids': ids}
    if status:
        item['status'] = status
    return item


def _payload_rows(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ('data', 'items', 'results'):
            block = payload.get(key)
            if isinstance(block, list):
                return block
    return []


def _batch_ok(payload):
    if payload is None:
        return False
    if not isinstance(payload, dict):
        return True
    if payload.get('_locked') or payload.get('_missing'):
        return False
    not_found = payload.get('notFound') or {}
    if isinstance(not_found, dict):
        for items in not_found.values():
            if items:
                return False
    return True


def _post_tracking(path, content, imdb, tmdb, status=None):
    item = _write_item(imdb, tmdb, status)
    if not item:
        return False
    key = 'movies' if content == 'movie' else 'shows'
    body = {key: [item]}
    # WeTrakr 1.0.9: watched adds require allow_rewatch (false = no duplicate play).
    if (path or '').rstrip('/').endswith('/sync/tracking') and status == 'watched':
        body['allow_rewatch'] = False
    data = api.authed_json('POST', path, body=body)
    return _batch_ok(data)


def _remove_watched(content, imdb, tmdb):
    '''Watched plays clear via remove/all (same as Red Light).'''
    item = _write_item(imdb, tmdb, 'watched')
    if not item:
        return False
    key = 'movies' if content == 'movie' else 'shows'
    data = api.authed_json('POST', '/sync/tracking/remove/all', body={key: [item]})
    if data is None:
        return False
    if not isinstance(data, dict):
        return True
    if data.get('removed'):
        return True
    # Already clear counts as success.
    errored = data.get('errored') or {}
    if isinstance(errored, dict):
        for items in errored.values():
            if not items:
                continue
            if not isinstance(items, list):
                return False
            for entry in items:
                if not isinstance(entry, dict) or entry.get('error') != 'Nothing to remove':
                    return False
        return True
    return _batch_ok(data)


def _resolve_media_id(tmdb, content):
    if not _valid_id(tmdb):
        return None
    kind = 'movie' if content == 'movie' else 'show'
    try:
        data = api.authed_json(
            'GET', f'/media/external/tmdb/{int(tmdb)}', params={'type': kind},
        )
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    mid = data.get('id')
    return mid if mid not in (None, '', 0, '0') else None


def _lists_for_item(content, media_id):
    if not media_id:
        return []
    target = 'movie' if content == 'movie' else 'show'
    try:
        data = api.authed_json('GET', f'/sync/lists/item/{target}/{media_id}')
    except Exception as exc:
        c.log(f'[WeTrakr Manager] lists-for-item failed: {exc}', 1)
        return []
    rows = [
        item for item in _payload_rows(data)
        if isinstance(item, dict) and item.get('id') and not item.get('locked')
    ]
    rows.sort(key=lambda item: str(item.get('name') or '').casefold())
    return rows


def _ids_match(entry, imdb, tmdb):
    ids = entry.get('ids') if isinstance(entry, dict) else None
    if not isinstance(ids, dict):
        return False
    if _valid_id(tmdb):
        try:
            if int(ids.get('tmdb') or 0) == int(tmdb):
                return True
        except (TypeError, ValueError):
            pass
    want = str(imdb or '').strip()
    if want and not want.startswith('tt') and want.isdigit():
        want = f'tt{want}'
    have = str(ids.get('imdb') or '').strip()
    return bool(want.startswith('tt') and have == want)


def _favorite_has(content, imdb, tmdb):
    '''True when title is already in /sync/favorites/{movies|shows}.'''
    target = 'movies' if content == 'movie' else 'shows'
    for page in range(1, 6):
        try:
            data = api.authed_json(
                'GET', f'/sync/favorites/{target}',
                params={'page': page, 'limit': 100},
            )
        except Exception:
            return False
        rows = _payload_rows(data)
        if not rows:
            break
        for entry in rows:
            if _ids_match(entry, imdb, tmdb):
                return True
        if len(rows) < 100:
            break
    return False


def _post_favorites(path, content, imdb, tmdb):
    item = _write_item(imdb, tmdb)
    if not item:
        return False
    key = 'movies' if content == 'movie' else 'shows'
    data = api.authed_json('POST', path, body={key: [item]})
    return _batch_ok(data)


def _build_actions(content, imdb, tmdb):
    actions = []
    statuses = _MOVIE_STATUSES if content == 'movie' else _SHOW_STATUSES
    for status, label in statuses:
        actions.append((L_ADD_STATUS % label, f'add_status:{status}'))
        actions.append((L_REMOVE_STATUS % label, f'remove_status:{status}'))

    # Favorites: show the useful line (Add or Remove), not both.
    if _favorite_has(content, imdb, tmdb):
        actions.append((L_REMOVE_FAVORITE, 'remove_favorite'))
    else:
        actions.append((L_ADD_FAVORITE, 'add_favorite'))

    media_id = _resolve_media_id(tmdb, content)
    membership = _lists_for_item(content, media_id) if media_id else []
    if membership:
        for entry in membership:
            name = (entry.get('name') or 'List').strip() or 'List'
            list_id = entry.get('id')
            if entry.get('included'):
                actions.append((L_REMOVE_LIST % name, f'remove_list:{list_id}'))
            else:
                actions.append((L_ADD_LIST % name, f'add_list:{list_id}'))
    else:
        for entry in wt_lists.fetch_index():
            name = entry.get('name') or 'List'
            list_id = entry.get('id')
            if list_id is None:
                continue
            actions.append((L_ADD_LIST % name, f'add_list:{list_id}'))
            actions.append((L_REMOVE_LIST % name, f'remove_list:{list_id}'))
    return actions


def manager(name, imdb, tmdb, content):
    '''Context menu entry  -  WeTrakr tracking + personal lists.'''
    if not auth.has_credentials():
        c.infoDialog(
            'WeTrakr not connected  -  authorize in Settings',
            heading=name or 'WeTrakr',
            sound=True,
            icon='ERROR',
        )
        return

    content = _norm_content(content)
    if not _valid_id(imdb) and not _valid_id(tmdb):
        c.infoDialog('No valid ID for this item', heading=name or 'WeTrakr', sound=True, icon='ERROR')
        return

    actions = _build_actions(content, imdb, tmdb)
    if not actions:
        c.infoDialog('Nothing to manage', heading=name or 'WeTrakr', sound=True)
        return

    select = control.selectDialog([label for label, _key in actions], 'WeTrakr Manager')
    if select < 0:
        return

    label, key = actions[select]
    ok = False
    try:
        if key.startswith('add_status:'):
            status = key.split(':', 1)[1]
            ok = _post_tracking('/sync/tracking', content, imdb, tmdb, status)
        elif key.startswith('remove_status:'):
            status = key.split(':', 1)[1]
            if status == 'watched':
                ok = _remove_watched(content, imdb, tmdb)
            else:
                ok = _post_tracking('/sync/tracking/remove', content, imdb, tmdb, status)
        elif key == 'add_favorite':
            ok = _post_favorites('/sync/favorites', content, imdb, tmdb)
        elif key == 'remove_favorite':
            ok = _post_favorites('/sync/favorites/remove', content, imdb, tmdb)
        elif key.startswith('add_list:'):
            list_id = key.split(':', 1)[1]
            ok = wt_lists.add_title(list_id, content, tmdb_id=tmdb, imdb_id=imdb, title=name)
        elif key.startswith('remove_list:'):
            list_id = key.split(':', 1)[1]
            ok = wt_lists.remove_title(list_id, content, tmdb_id=tmdb, imdb_id=imdb, title=name)
        else:
            ok = False

        if not ok:
            c.log(f'[WeTrakr Manager] failed key={key} tmdb={tmdb} imdb={imdb}', 1)
            c.infoDialog('WeTrakr request failed  -  see classy.log', heading=name, sound=True, icon='ERROR')
            return

        sync.invalidate()
        try:
            from . import progress as wt_progress
            wt_progress.invalidate_next_episodes()
        except Exception:
            pass
        try:
            from ..progress.widget_signals import notify_progress_changed
            notify_progress_changed('wetrakr_manager')
        except Exception:
            pass
        control.execute('Container.Refresh')
        success = _success_message(label)
        c.log(f'[WeTrakr Manager] {success} ({content}, imdb={imdb}, tmdb={tmdb})')
        c.infoDialog(success, heading=name or 'WeTrakr', sound=True)
    except Exception as exc:
        c.log(f'[WeTrakr Manager] error: {exc}', 1)
        c.infoDialog('WeTrakr Manager error', heading=name or 'WeTrakr', sound=True, icon='ERROR')
    finally:
        control.idle()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file watched_actions.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr mark watched / playcount actions.

Writes (WeTrakr API 1.0.9):
  POST /sync/tracking          -> add items to a tracking list (status names it)
  POST /sync/tracking/remove   -> remove items (same body; status names the list)

Watched adds send allow_rewatch=false so a re-mark does not invent a second play
(API deprecates omitting the flag; true is only for intentional rewatch).

Movie item : {ids:{tmdb,imdb}, status:"watched"}
Show item  : {ids:{tmdb}, status:"watched"}
Episode    : nested under show by number:
             {ids:{tmdb}, seasons:[{number:S, episodes:[{number:E, status:"watched"}]}]}'''

from __future__ import annotations

from ..apis import wetrakr as api
from ..modules import control
from ..modules.classy import c
from . import auth
from . import sync


def _ids(imdb='', tmdb=''):
    ids = {}
    imdb = str(imdb or '').strip()
    if imdb and imdb not in ('0', 'None'):
        ids['imdb'] = imdb if imdb.startswith('tt') else f'tt{imdb}'
    tmdb = str(tmdb or '').strip()
    if tmdb and tmdb not in ('0', 'None'):
        try:
            ids['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    return ids


def _parse_watched(query, watched_param=None):
    '''CM sends query=6 (unwatched) or 7 (watched)  -  same as Trakt/Simkl routes.'''
    if query is not None and str(query).strip() != '':
        try:
            value = int(query)
        except (TypeError, ValueError):
            return None
        if value == 7:
            return True
        if value == 6:
            return False
        return None
    if watched_param is not None:
        text = str(watched_param).lower()
        if text in ('false', '0', 'no'):
            return False
        if text in ('true', '1', 'yes'):
            return True
    return None


def _after_success():
    try:
        from ..progress.widget_signals import notify_progress_changed
        notify_progress_changed('wetrakr_playcount')
    except Exception:
        pass
    try:
        control.execute('Container.Refresh')
    except Exception:
        pass


def _send(body, watched):
    path = '/sync/tracking' if watched else '/sync/tracking/remove'
    # 1.0.9: watched adds need allow_rewatch (false = no duplicate play).
    if watched and isinstance(body, dict):
        body = dict(body)
        body.setdefault('allow_rewatch', False)
    resp = api.authed_raw('POST', path, body=body, timeout=20)
    ok = resp is not None and resp.ok
    if ok:
        # Soft invalidate (A1e)  -  callers patch overlays then adopt stamps.
        sync.invalidate_tracking()
        try:
            from . import progress as wt_progress
            wt_progress.invalidate_next_episodes()
        except Exception:
            pass
    return ok


def _patch_after_mark(mediatype, watched, imdb='', tmdb='', season=0, episode=0, title=''):
    try:
        from . import watch_sync
    except Exception:
        return
    if mediatype == 'episode':
        watch_sync.patch_episode_watched(
            tmdb, season, episode, watched=watched, title=title, imdb=imdb,
        )
    elif mediatype == 'movie':
        watch_sync.patch_movie_watched(
            tmdb, watched=watched, title=title, imdb=imdb,
        )
    try:
        watch_sync.adopt_activity_stamps()
    except Exception:
        pass


def mark_movie(imdb, tmdb='', watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False
    body = {'movies': [{'ids': ids, 'status': 'watched'}]}
    try:
        ok = _send(body, watched)
        if ok:
            _patch_after_mark('movie', watched, imdb=imdb, tmdb=tmdb)
            c.log(f'[WeTrakr] mark_movie watched={watched} imdb={imdb} tmdb={tmdb}')
            _after_success()
        return ok
    except Exception as exc:
        c.log(f'[WeTrakr] mark_movie failed: {exc}', 1)
        return False


def mark_episode(imdb, tmdb, season, episode, watched=True):
    if not auth.has_credentials():
        return False, 'no credentials'
    ids = _ids(imdb, tmdb)
    if not ids:
        return False, 'missing ids'
    try:
        season = int(season)
        episode = int(episode)
    except (TypeError, ValueError):
        return False, 'bad season/episode'
    body = {
        'shows': [{
            'ids': ids,
            'seasons': [{
                'number': season,
                'episodes': [{'number': episode, 'status': 'watched'}],
            }],
        }],
    }
    try:
        ok = _send(body, watched)
        if ok:
            _patch_after_mark(
                'episode', watched, imdb=imdb, tmdb=tmdb,
                season=season, episode=episode,
            )
            c.log(
                f'[WeTrakr] mark_episode watched={watched} '
                f'S{season:02d}E{episode:02d} imdb={imdb} tmdb={tmdb}',
            )
            _after_success()
        return ok, ''
    except Exception as exc:
        c.log(f'[WeTrakr] mark_episode failed: {exc}', 1)
        return False, str(exc)


def mark_season(imdb, tmdb, season, watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False
    try:
        season = int(season)
    except (TypeError, ValueError):
        return False
    if season < 0:
        return False
    body = {
        'shows': [{
            'ids': ids,
            'seasons': [{'number': season, 'status': 'watched'}],
        }],
    }
    try:
        ok = _send(body, watched)
        if ok:
            # Season-wide: force watched rebuild (no per-ep patch).
            try:
                from . import watch_sync
                watch_sync.invalidate()
                watch_sync.schedule_reconcile()
            except Exception:
                sync.invalidate()
            c.log(
                f'[WeTrakr] mark_season watched={watched} '
                f'S{season:02d} imdb={imdb} tmdb={tmdb}',
            )
            _after_success()
        return ok
    except Exception as exc:
        c.log(f'[WeTrakr] mark_season failed: {exc}', 1)
        return False


def mark_show(imdb, tmdb='', watched=True):
    if not auth.has_credentials():
        return False
    ids = _ids(imdb, tmdb)
    if not ids:
        return False
    body = {'shows': [{'ids': ids, 'status': 'watched'}]}
    try:
        ok = _send(body, watched)
        if ok:
            try:
                from . import watch_sync
                watch_sync.invalidate()
                watch_sync.schedule_reconcile()
            except Exception:
                sync.invalidate()
            c.log(f'[WeTrakr] mark_show watched={watched} imdb={imdb} tmdb={tmdb}')
            _after_success()
        return ok
    except Exception as exc:
        c.log(f'[WeTrakr] mark_show failed: {exc}', 1)
        return False


def apply_playcount(params, *, mediatype):
    if not auth.has_credentials():
        return False, 'Connect WeTrakr to mark watched'

    params = params or {}
    watched = _parse_watched(params.get('query'), params.get('watched'))
    if watched is None:
        return False, 'Invalid playcount action'

    imdb = params.get('imdb') or ''
    tmdb = params.get('tmdb') or ''
    mediatype = (mediatype or params.get('mediatype') or 'movie').lower()

    if mediatype == 'movie':
        ok = mark_movie(imdb, tmdb, watched=watched)
    elif mediatype in ('tvshow', 'show'):
        ok = mark_show(imdb, tmdb, watched=watched)
    elif mediatype == 'episode':
        ok, _detail = mark_episode(
            imdb, tmdb, params.get('season'), params.get('episode'), watched=watched,
        )
    elif mediatype == 'season':
        ok = mark_season(imdb, tmdb, params.get('season'), watched=watched)
    else:
        return False, 'Unsupported media type'

    if ok:
        return True, 'Marked as watched' if watched else 'Marked as unwatched'
    return False, 'WeTrakr request failed  -  see classy.log'

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr watch-tracker package  -  XOR tracker backend slice.

Auth / OAuth / device flow lives in resources.lib.apis.wetrakr (the scrobble
sidecar). This package adds the sync read/write helpers the tracker gate needs
(watched history, planning, playing, next episodes, calendars) mirroring
resources.lib.simkl.
'''

from . import auth
from . import calendars
from . import discover
from . import lists
from . import maintenance
from . import manager
from . import movie_lists
from . import progress
from . import scrobble
from . import sync
from . import tv_lists
from . import user_lists
from . import watch_sync
from . import watched_actions

__all__ = [
    'auth',
    'calendars',
    'discover',
    'lists',
    'maintenance',
    'manager',
    'movie_lists',
    'progress',
    'scrobble',
    'sync',
    'tv_lists',
    'user_lists',
    'watch_sync',
    'watched_actions',
]

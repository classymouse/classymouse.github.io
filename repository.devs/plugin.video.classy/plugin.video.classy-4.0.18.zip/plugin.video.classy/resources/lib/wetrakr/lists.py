# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr list converters  -  Trakt-shaped rows for VideoRow.from_trakt_*.

WeTrakr tracking rows are flat: {type, ids:{tmdb,imdb,tvdb}, title, ...}.
We reshape into {'movie': {...}} / {'show': {...}} to reuse the shared rows.'''

from __future__ import annotations

import re

from . import sync


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _norm_id(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    return text


def _out_ids(ids):
    ids = ids if isinstance(ids, dict) else {}
    out = {}
    imdb = _norm_imdb(ids.get('imdb'))
    if imdb:
        out['imdb'] = imdb
    tmdb = _norm_id(ids.get('tmdb'))
    if tmdb:
        try:
            out['tmdb'] = int(tmdb)
        except (TypeError, ValueError):
            pass
    tvdb = _norm_id(ids.get('tvdb'))
    if tvdb:
        try:
            out['tvdb'] = int(tvdb)
        except (TypeError, ValueError):
            pass
    return out


def _year(value):
    year = re.sub(r'[^0-9]', '', str(value or ''))[:4]
    return int(year) if year else None


def _to_trakt_movie_item(entry):
    if not isinstance(entry, dict):
        return None
    movie = entry.get('movie') if isinstance(entry.get('movie'), dict) else entry
    title = (movie.get('title') or '').strip()
    if not title:
        return None
    body = {
        'title': title,
        'year': _year(movie.get('year') or movie.get('release_date')),
        'overview': movie.get('overview') or '',
        'runtime': movie.get('runtime') or 0,
        'ids': _out_ids(movie.get('ids')),
    }
    return {'movie': body}


def _to_trakt_show_item(entry):
    if not isinstance(entry, dict):
        return None
    show = entry.get('show') if isinstance(entry.get('show'), dict) else entry
    title = (show.get('title') or '').strip()
    if not title:
        return None
    body = {
        'title': title,
        'year': _year(show.get('year') or show.get('first_air_date')),
        'overview': show.get('overview') or '',
        'ids': _out_ids(show.get('ids')),
    }
    return {'show': body}


def to_trakt_item(entry):
    '''Flat WeTrakr row or already-wrapped movie/show -> Trakt-shaped item.'''
    if not isinstance(entry, dict):
        return None
    if isinstance(entry.get('movie'), dict):
        return _to_trakt_movie_item(entry)
    if isinstance(entry.get('show'), dict):
        return _to_trakt_show_item(entry)
    kind = (entry.get('type') or entry.get('media_type') or '').strip().lower()
    if kind in ('movie', 'movies'):
        return _to_trakt_movie_item(entry)
    if kind in ('show', 'shows', 'tv', 'tvshow', 'series'):
        return _to_trakt_show_item(entry)
    return None


def movie_items(status='planning'):
    '''Full tracking list (paged). Default API page size is 20 without limit.'''
    out = []
    for entry in sync.fetch_tracking_all(status, 'movies') or []:
        item = _to_trakt_movie_item(entry)
        if item:
            out.append(item)
    return out


def show_items(status='planning'):
    '''Full tracking list (paged). Default API page size is 20 without limit.'''
    out = []
    for entry in sync.fetch_tracking_all(status, 'shows') or []:
        item = _to_trakt_show_item(entry)
        if item:
            out.append(item)
    return out


def _show_item_key(item):
    '''Dedup key for a Trakt-shaped show item (tmdb first, then imdb).'''
    show = item.get('show') if isinstance(item, dict) else None
    ids = show.get('ids') if isinstance(show, dict) else None
    ids = ids if isinstance(ids, dict) else {}
    tmdb = _norm_id(ids.get('tmdb'))
    if tmdb:
        return f'tmdb:{tmdb}'
    imdb = _norm_imdb(ids.get('imdb'))
    if imdb:
        return f'imdb:{imdb}'
    return ''


def show_items_combined(statuses):
    '''Merge several tracking statuses into one deduped show list.

    Used for On Hold (1.0.10 'hold' + legacy 'paused'). First status wins on
    a tmdb/imdb collision.'''
    out = []
    seen = set()
    for status in statuses:
        for item in show_items(status):
            key = _show_item_key(item)
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            out.append(item)
    return out


def favorite_items(target='movies'):
    '''Full favorites list via GET /sync/favorites/{movies|shows}.'''
    target = 'shows' if target in ('shows', 'show', 'tv') else 'movies'
    converter = _to_trakt_show_item if target == 'shows' else _to_trakt_movie_item
    out = []
    for entry in sync.fetch_favorites_all(target):
        item = converter(entry)
        if item:
            out.append(item)
    return out

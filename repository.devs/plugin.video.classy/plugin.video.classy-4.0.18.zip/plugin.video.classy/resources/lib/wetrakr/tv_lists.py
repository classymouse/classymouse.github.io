# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr My TV presets  -  tvshows&url=wetrakr* keys.

Statuses: planning (watchlist), watching, waiting, paused (on hold), watched
(history), dropped. Favorites use /sync/favorites/shows (not a tracking status).'''

from ..modules.classy import c
from . import auth
from . import lists as wetrakr_lists

MY_TV_PRESETS = frozenset({
    'wetrakrwatchlist',
    'wetrakrwatching',
    'wetrakrwaiting',
    'wetrakrhold',
    'wetrakrfavorites',
    'wetrakrhistory',
    'wetrakrdropped',
})

_STATUS_MAP = {
    'wetrakrwatchlist': 'planning',
    'wetrakrwatching': 'watching',
    'wetrakrwaiting': 'waiting',
    'wetrakrhold': 'paused',
    'wetrakrhistory': 'watched',
    'wetrakrdropped': 'dropped',
}


def is_my_tv_preset(preset):
    return (preset or '').strip() in MY_TV_PRESETS


def fetch_page(preset, *, page=1):
    preset = (preset or '').strip()
    if preset not in MY_TV_PRESETS:
        return None
    if not auth.has_credentials():
        c.log(f'[WeTrakrTvLists] {preset} requires auth', 1)
        return None

    if preset == 'wetrakrfavorites':
        items = wetrakr_lists.favorite_items('shows')
    elif preset == 'wetrakrhold':
        # 1.0.10: On Hold is 'hold'; keep reading legacy 'paused' too.
        items = wetrakr_lists.show_items_combined(('hold', 'paused'))
    else:
        items = wetrakr_lists.show_items(_STATUS_MAP[preset])
    c.log(f'[WeTrakrTvLists] {preset} ({len(items)} items)')
    return {
        'results': items,
        'page': 1,
        'total_pages': 1,
        '_source': 'trakt_list_items',
        '_preset': preset,
    }

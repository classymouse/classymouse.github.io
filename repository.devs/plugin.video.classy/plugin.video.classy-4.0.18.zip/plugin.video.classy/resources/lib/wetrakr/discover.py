# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file discover.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr public discovery  -  feeds, catalog search, public list items.

App-key only (user=False). No Watch-home requirement at the API layer;
menus gate rows with tracker.is_wetrakr() when desired.'''

from __future__ import annotations

from ..apis import wetrakr as api
from ..modules.classy import c
from . import lists as wetrakr_lists

_PAGE_LIMIT = 20
_LIST_PAGE_LIMIT = 100

_FEED_PATHS = {
    'wetrakrtrending': '/discover/trending',
    'wetrakrpopular': '/discover/popular',
    'wetrakrtoprated': '/discover/toprated',
}

MOVIE_PRESETS = frozenset(set(_FEED_PATHS) | {'wetrakrsearch'})
TV_PRESETS = frozenset(set(_FEED_PATHS) | {'wetrakrsearch'})


def is_movie_preset(preset):
    return (preset or '').strip() in MOVIE_PRESETS


def is_tv_preset(preset):
    return (preset or '').strip() in TV_PRESETS


def _payload_rows(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        if payload.get('_locked') or payload.get('_missing'):
            return []
        for key in ('data', 'items', 'results'):
            block = payload.get(key)
            if isinstance(block, list):
                return block
    return []


def _header_get(headers, name, default=None):
    want = (name or '').lower()
    for key, value in (headers or {}).items():
        if str(key).lower() == want:
            return value
    return default


def _page_count(headers, fallback=1):
    try:
        return max(1, int(_header_get(headers, 'X-Pagination-Page-Count') or fallback))
    except (TypeError, ValueError):
        return max(1, int(fallback or 1))


def _to_items(rows, media):
    want_key = 'show' if media == 'show' else 'movie'
    out = []
    for entry in rows:
        # Prefer typed conversion; fall back to media kind when API omits type.
        if isinstance(entry, dict) and not (
            isinstance(entry.get('movie'), dict)
            or isinstance(entry.get('show'), dict)
            or (entry.get('type') or entry.get('media_type'))
        ):
            entry = dict(entry)
            entry['type'] = want_key
        item = wetrakr_lists.to_trakt_item(entry)
        if item and want_key in item:
            out.append(item)
    return out


def _fetch_feed_page(path, media, page, *, query=None, list_id=None):
    kind = 'show' if media == 'show' else 'movie'
    page = max(1, int(page or 1))
    if path == '/search':
        params = {
            'q': query or '',
            'filter_type': kind,
            'page': page,
            'limit': _PAGE_LIMIT,
        }
    elif list_id:
        target = 'shows' if media == 'show' else 'movies'
        path = f'/lists/{list_id}/items/{target}'
        params = {
            'sort_by': 'editor_rank',
            'sort_dir': 'asc',
            'page': page,
            'limit': _LIST_PAGE_LIMIT,
        }
    else:
        params = {
            'filter_type': kind,
            'page': page,
            'limit': _PAGE_LIMIT,
        }

    payload, headers = api.api_json_headers(
        'GET', path, params=params, user=False, notify_locked=True,
    )
    if isinstance(payload, dict) and payload.get('_locked'):
        return [], 1
    rows = _payload_rows(payload)
    items = _to_items(rows, media)
    pages = _page_count(headers, 1 if not items else page)
    # If API omits page count, infer "maybe more" when a full page arrived.
    if pages <= 1 and len(rows) >= (params.get('limit') or _PAGE_LIMIT):
        pages = page + 1
    return items, pages


def fetch_page(preset, *, media='movie', page=1, query=None, list_id=None):
    '''movies|tvshows&url=wetrakr* discover / search page.'''
    preset = (preset or '').strip()
    media = 'show' if media in ('show', 'shows', 'tv', 'tvshow') else 'movie'
    source = 'trakt_list_items' if media == 'show' else 'trakt_movies'

    if preset == 'wetrakrsearch':
        if not (query or '').strip():
            c.log('[WeTrakrDiscover] search needs query', 1)
            return {
                'results': [],
                'page': 1,
                'total_pages': 1,
                '_source': source,
                '_preset': preset,
            }
        items, pages = _fetch_feed_page(
            '/search', media, page, query=(query or '').strip(),
        )
    elif preset in _FEED_PATHS:
        items, pages = _fetch_feed_page(_FEED_PATHS[preset], media, page)
    else:
        return None

    c.log(
        f'[WeTrakrDiscover] {preset} media={media} page={page}/{pages} '
        f'({len(items)} items)'
    )
    return {
        'results': items,
        'page': max(1, int(page or 1)),
        'total_pages': max(1, int(pages or 1)),
        '_source': source,
        '_preset': preset,
    }


def fetch_public_list_items_page(list_id, *, media='movie', page=1):
    '''One page of a public list (no auth).'''
    list_id = str(list_id or '').strip()
    if not list_id:
        return None
    media = 'show' if media in ('show', 'shows', 'tv', 'tvshow') else 'movie'
    source = 'trakt_list_items' if media == 'show' else 'trakt_movies'
    items, pages = _fetch_feed_page(
        '', media, page, list_id=list_id,
    )
    c.log(
        f'[WeTrakrDiscover] public list {list_id} media={media} '
        f'page={page}/{pages} ({len(items)} items)'
    )
    return {
        'results': items,
        'page': max(1, int(page or 1)),
        'total_pages': max(1, int(pages or 1)),
        '_source': source,
        '_preset': f'wetrakrpubliclist:{list_id}',
    }


def public_list_items_url(list_id, media='movie'):
    '''Plugin-facing url key: wetrakrpubliclist:{id}:{movie|show}.'''
    list_id = str(list_id or '').strip()
    if not list_id:
        return ''
    kind = 'show' if media in ('show', 'shows', 'tv', 'tvshow') else 'movie'
    return f'wetrakrpubliclist:{list_id}:{kind}'


def parse_public_list_url(preset):
    '''Return (list_id, media) when preset is wetrakrpubliclist:{id}:{media}.'''
    text = (preset or '').strip()
    if not text.startswith('wetrakrpubliclist:'):
        return None, None
    parts = text.split(':', 2)
    if len(parts) < 2:
        return None, None
    list_id = (parts[1] or '').strip()
    media = (parts[2] if len(parts) > 2 else 'movie').strip() or 'movie'
    return (list_id or None), media


def is_public_list_url(preset):
    list_id, _media = parse_public_list_url(preset)
    return bool(list_id)


def _list_media_kinds(item):
    '''movie/show kinds for a public-list index row (targets + preview).'''
    kinds = set()
    if not isinstance(item, dict):
        return kinds
    dynamic = item.get('dynamic')
    if isinstance(dynamic, dict):
        for target in dynamic.get('targets') or []:
            text = str(target or '').strip().lower()
            if text in ('movie', 'movies'):
                kinds.add('movie')
            elif text in ('show', 'shows', 'tv', 'tvshow'):
                kinds.add('show')
    for preview in item.get('preview') or []:
        if not isinstance(preview, dict):
            continue
        text = str(preview.get('type') or preview.get('media_type') or '').strip().lower()
        if text in ('movie', 'movies') or isinstance(preview.get('movie'), dict):
            kinds.add('movie')
        elif text in ('show', 'shows', 'tv', 'tvshow') or isinstance(preview.get('show'), dict):
            kinds.add('show')
    return kinds


def _list_matches_media(item, media):
    '''True when list belongs in the movie or show hub. Unknown -> keep.'''
    if not media:
        return True
    want = 'show' if media in ('show', 'shows', 'tv', 'tvshow') else 'movie'
    kinds = _list_media_kinds(item)
    if not kinds:
        return True
    return want in kinds


def _public_lists_index_page(kind, *, page, query=None, with_preview=False):
    '''One API page of public list index rows + pagination meta.'''
    page = max(1, int(page or 1))
    q = (query or '').strip()
    if q:
        path = '/search'
        params = {
            'q': q,
            'filter_type': 'list',
            'page': page,
            'limit': _PAGE_LIMIT,
        }
    elif kind == 'latest':
        path = '/lists/last'
        params = {'page': page, 'limit': _PAGE_LIMIT}
    else:
        path = '/lists/trending'
        params = {'page': page, 'limit': _PAGE_LIMIT}
    if with_preview:
        params['extended'] = 'preview'

    payload, headers = api.api_json_headers(
        'GET', path, params=params, user=False, notify_locked=True,
    )
    if isinstance(payload, dict) and payload.get('_locked'):
        return [], 1, True
    rows = _payload_rows(payload)
    pages = _page_count(headers, 1 if not rows else page)
    if pages <= 1 and len(rows) >= _PAGE_LIMIT:
        pages = page + 1
    return rows, pages, False


def fetch_public_lists_index(kind='trending', *, page=1, query=None, media=None):
    '''Folder rows: [{id, name}, ...] + page meta.

    media=movie|show filters via extended=preview / dynamic.targets (client-side
    until WeTrakr can filter list feeds by media on the API).
    '''
    page = max(1, int(page or 1))
    media_key = None
    if media:
        media_key = 'show' if media in ('show', 'shows', 'tv', 'tvshow') else 'movie'
    with_preview = bool(media_key)

    if not media_key:
        rows, pages, locked = _public_lists_index_page(
            kind, page=page, query=query, with_preview=False,
        )
        if locked:
            return [], 1
        out = []
        for item in rows:
            if not isinstance(item, dict):
                continue
            list_id = item.get('id')
            if list_id in (None, '', 0, '0') or item.get('locked'):
                continue
            name = (item.get('name') or 'List').strip() or 'List'
            out.append({'id': list_id, 'name': name})
        c.log(
            f'[WeTrakrDiscover] public lists kind={kind or "search"} '
            f'page={page}/{pages} ({len(out)} lists)'
        )
        return out, pages

    # Fill one UI page of media-matching lists (may span several API pages).
    skip = (page - 1) * _PAGE_LIMIT
    out = []
    matched = 0
    api_page = 1
    api_pages = 1
    max_scan = 12
    while api_page <= max_scan and api_page <= api_pages and len(out) < _PAGE_LIMIT:
        rows, api_pages, locked = _public_lists_index_page(
            kind, page=api_page, query=query, with_preview=with_preview,
        )
        if locked:
            if not out:
                return [], 1
            break
        for item in rows:
            if not isinstance(item, dict):
                continue
            list_id = item.get('id')
            if list_id in (None, '', 0, '0') or item.get('locked'):
                continue
            if not _list_matches_media(item, media_key):
                continue
            matched += 1
            if matched <= skip:
                continue
            name = (item.get('name') or 'List').strip() or 'List'
            out.append({'id': list_id, 'name': name})
            if len(out) >= _PAGE_LIMIT:
                break
        api_page += 1

    # More UI pages when this page filled, or unread API pages remain.
    if len(out) >= _PAGE_LIMIT or api_page <= api_pages:
        pages = page + 1
    else:
        pages = page
    c.log(
        f'[WeTrakrDiscover] public lists kind={kind or "search"} '
        f'media={media_key} page={page}/{pages} ({len(out)} lists, '
        f'matched={matched}, api_to={min(api_page - 1, api_pages)}/{api_pages})'
    )
    return out, pages


# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file about_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr attribution dialog  -  fanart + glass band + logo (API Terms credit).'''

from __future__ import annotations

import os
import threading

import xbmc

from ..kodi.dialog_base import ClassyDialogBase
from ..modules.classy import c

# Popular TMDB movies for backdrop rotation (best-effort; falls back to addon fanart).
_FANART_TMDB_IDS = (
    '299534',  # Avengers: Endgame
    '157336',  # Interstellar
    '155',     # The Dark Knight
    '27205',   # Inception
    '24428',   # The Avengers
    '603',     # The Matrix
)

SITE_URL = 'https://wetrakr.com'


class WeTrakrAboutDialog(ClassyDialogBase):
    XML_FILE = 'AboutWetrakr.xml'
    LOGO_ID = 9000
    BUTTON_VISIT = 9101
    BUTTON_CLOSE = 9102

    def __init__(self, *args, **kwargs):
        logo_path = kwargs.pop('logo_path', '')
        fanart = kwargs.pop('fanart', '')
        super().__init__(*args, **kwargs)
        self.logo_path = logo_path or ''
        self.fanart = fanart or ''
        self.user_choice = None
        self._rotate = True
        self._fanart_index = 0

    def onInit(self):
        self.set_properties({
            'title': 'About WeTrakr',
            'message1': 'Tracking and scrobble data can come from WeTrakr (wetrakr.com).',
            'message2': 'Credit: Alberto and the WeTrakr team. Used under the WeTrakr API Terms.',
            'message3': (
                'Kodi cannot put a live link on every list row. '
                'This screen is our attribution.'
            ),
            'fanart': self.fanart or c.addon_fanart() or '',
        })
        try:
            if self.logo_path and os.path.isfile(self.logo_path):
                self.getControl(self.LOGO_ID).setImage(self.logo_path)
        except Exception as exc:
            c.log(f'[WeTrakr About] logo failed: {exc}', 1)
        try:
            self.setFocusId(self.BUTTON_CLOSE)
        except Exception:
            pass
        self._fanart_paths = self._collect_fanarts()
        threading.Thread(target=self._rotate_fanart, daemon=True).start()

    def _collect_fanarts(self):
        paths = []
        seen = set()
        try:
            from ..modules import cache as caching
            for tmdb_id in _FANART_TMDB_IDS:
                path = caching.get_image(tmdb_id, image_type='backdrop', rotate=True)
                if path and path not in seen:
                    seen.add(path)
                    paths.append(path)
        except Exception:
            pass
        fallback = c.addon_fanart() or self.fanart or ''
        if fallback and fallback not in seen:
            paths.append(fallback)
        return paths or ([self.fanart] if self.fanart else [])

    def _rotate_fanart(self):
        if len(self._fanart_paths) < 2:
            return
        while self._rotate and not self.closing:
            for _ in range(100):
                if not self._rotate or self.closing:
                    return
                xbmc.sleep(100)
            self._fanart_index = (self._fanart_index + 1) % len(self._fanart_paths)
            path = self._fanart_paths[self._fanart_index]
            if path and self._rotate and not self.closing:
                try:
                    self.setProperty('fanart', str(path))
                except Exception:
                    return

    def onClick(self, controlId):
        if controlId == self.BUTTON_VISIT:
            self.user_choice = 'visit'
            self._rotate = False
            self.close_with(controlId)
        elif controlId == self.BUTTON_CLOSE:
            self.user_choice = 'close'
            self._rotate = False
            self.close_with(controlId)

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.user_choice = 'close'
            self._rotate = False
            self.close_with(None)


def _open_site(url):
    url = (url or '').strip()
    if not url:
        return False
    try:
        import webbrowser
        return bool(webbrowser.open(url))
    except Exception:
        return False


def show_about_dialog(logo_path=''):
    '''Show skinned About; return True. Falls back to okDialog on skin errors.'''
    fanart = ''
    try:
        from ..modules import cache as caching
        fanart = caching.get_image(_FANART_TMDB_IDS[0], image_type='backdrop', rotate=True) or ''
    except Exception:
        fanart = ''
    fanart = fanart or c.addon_fanart() or ''
    try:
        dialog = WeTrakrAboutDialog.run_modal(
            logo_path=logo_path or '',
            fanart=fanart,
        )
        choice = getattr(dialog, 'user_choice', None)
        try:
            dialog._rotate = False
        except Exception:
            pass
        del dialog
        if choice == 'visit':
            if not _open_site(SITE_URL):
                from ..modules import control
                control.okDialog(
                    'Could not open a browser on this device.[CR][CR]'
                    f'Visit: {SITE_URL}',
                    heading='WeTrakr',
                )
        return True
    except Exception as exc:
        c.log(f'[WeTrakr About] skinned dialog failed: {exc}', 1)
        return False

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file user_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Personal WeTrakr lists  -  index (/sync/lists) + list items pages.

Browse UI under My Movies / My TV; add/remove used by WeTrakr Manager CM.'''

from urllib.parse import parse_qsl, urlencode, urlparse

from ..apis import wetrakr as api
from ..modules.classy import c
from . import auth
from . import lists as wt_lists

BASE = api.BASE_URL
_LIST_ITEMS_LIMIT = 100


def items_url(list_id, *, media=''):
    list_id = str(list_id or '').strip()
    if not list_id:
        return ''
    url = f'{BASE}/sync/lists/{list_id}/items'
    media = str(media or '').strip().lower()
    if media in ('show', 'tv', 'tvshow'):
        return f'{url}?{urlencode({"mediatype": "show"})}'
    if media in ('movie', 'movies'):
        return f'{url}?{urlencode({"mediatype": "movie"})}'
    return url


def is_list_items_url(url):
    text = (url or '').strip()
    if 'wetrakr.com' not in text.lower():
        return False
    path = (urlparse(text).path or '').lower().rstrip('/')
    return '/sync/lists/' in path and path.endswith('/items')


def is_personal_list_url(url):
    return is_list_items_url(url)


def _name_sort_key(entry):
    return str(entry.get('name') or '').casefold()


def _payload_rows(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ('data', 'items', 'results'):
            block = payload.get(key)
            if isinstance(block, list):
                return block
    return []


def _normalize_list(item, *, media=''):
    if not isinstance(item, dict):
        return None
    list_id = item.get('id')
    if list_id is None and isinstance(item.get('ids'), dict):
        list_id = item['ids'].get('wetrakr') or item['ids'].get('id')
    name = (item.get('name') or '').strip()
    if list_id is None or not name:
        return None
    return {
        'name': name,
        'id': list_id,
        'slug': (item.get('slug') or '').strip(),
        'items': item.get('item_count') or item.get('items'),
        'items_url': items_url(list_id, media=media),
    }


def fetch_index(*, media=''):
    '''Owned personal lists sorted by name.'''
    if not auth.has_credentials():
        c.log('[WeTrakrUserLists] auth required for index', 1)
        return []

    try:
        data = api.authed_json(
            'GET', '/sync/lists', params={'sort': 'name', 'dir': 'asc'},
        )
    except Exception as exc:
        c.log(f'[WeTrakrUserLists] index failed: {exc}', 1)
        return []

    out = []
    for item in _payload_rows(data):
        row = _normalize_list(item, media=media)
        if row:
            out.append(row)
    out.sort(key=_name_sort_key)
    if c.is_devmode():
        names = ', '.join(e['name'] for e in out[:12])
        suffix = '...' if len(out) > 12 else ''
        c.log(f'[WeTrakrUserLists] index {len(out)} list(s): {names}{suffix}')
    return out


def _list_path_from_url(url):
    text = (url or '').strip()
    parsed = urlparse(text)
    path = parsed.path or ''
    extra_q = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if not path.startswith('/'):
        path = '/' + path
    return path, extra_q


def _list_id_from_path(path):
    parts = [p for p in (path or '').strip('/').split('/') if p]
    # sync / lists / {id} / items
    try:
        idx = parts.index('lists')
        return parts[idx + 1]
    except (ValueError, IndexError):
        return ''


def _want_kind(media):
    media = str(media or '').strip().lower()
    if media in ('show', 'tv', 'tvshow', 'shows'):
        return 'show'
    if media in ('movie', 'movies'):
        return 'movie'
    return ''


def _typed_items_path(list_id, kind):
    target = 'shows' if kind == 'show' else 'movies'
    return f'/lists/{list_id}/items/{target}'


def _entry_kind(entry):
    if isinstance(entry.get('movie'), dict):
        return 'movie'
    if isinstance(entry.get('show'), dict):
        return 'show'
    kind = (entry.get('type') or entry.get('media_type') or '').strip().lower()
    if kind in ('movie', 'movies'):
        return 'movie'
    if kind in ('show', 'shows', 'tv', 'tvshow', 'series'):
        return 'show'
    return ''


def _convert_entries(entries, *, want_kind=''):
    out = []
    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        kind = _entry_kind(entry)
        if want_kind and kind and kind != want_kind:
            continue
        item = wt_lists.to_trakt_item(entry)
        if not item:
            continue
        if want_kind == 'movie' and 'movie' not in item:
            continue
        if want_kind == 'show' and 'show' not in item:
            continue
        out.append(item)
    return out


def fetch_items_page(url, *, page=1):
    '''One page of list items; discover-shaped dict for movie/tv discover.'''
    if not is_list_items_url(url):
        return None
    if not auth.has_credentials():
        c.log('[WeTrakrUserLists] items require auth', 1)
        return None

    page = max(1, int(page or 1))
    path, extra_q = _list_path_from_url(url)
    list_id = _list_id_from_path(path)
    if not list_id:
        c.log(f'[WeTrakrUserLists] bad list path={path}', 1)
        return None

    want_kind = _want_kind(extra_q.get('mediatype'))
    params = {
        'page': page,
        'limit': _LIST_ITEMS_LIMIT,
        'sort_by': 'editor_rank',
        'sort_dir': 'asc',
    }

    raw = None
    used_path = f'/sync/lists/{list_id}/items'
    if want_kind:
        typed = _typed_items_path(list_id, want_kind)
        raw = api.authed_json('GET', typed, params=params)
        if raw is not None:
            used_path = typed
    if raw is None:
        raw = api.authed_json('GET', used_path, params=params)

    if raw is None:
        c.log(f'[WeTrakrUserLists] items failed path={used_path}', 1)
        return None

    entries = _payload_rows(raw)
    items = _convert_entries(entries, want_kind=want_kind)
    raw_len = len(entries)
    if raw_len < _LIST_ITEMS_LIMIT:
        total_pages = page
    else:
        total_pages = page + 1

    c.log(
        f'[WeTrakrUserLists] items list={list_id} kind={want_kind or "mixed"} '
        f'page={page}/{total_pages} ({len(items)}/{raw_len})'
    )
    return {
        'results': items,
        'page': page,
        'total_pages': max(1, total_pages),
        '_source': 'trakt_list_items',
        '_preset': url,
        '_personal_list': True,
    }


def _write_item(tmdb_id=None, imdb_id=None, title=None, year=None):
    ids = {}
    if tmdb_id not in (None, '', 0, '0'):
        try:
            ids['tmdb'] = int(tmdb_id)
        except (TypeError, ValueError):
            pass
    imdb = str(imdb_id or '').strip()
    if imdb.startswith('tt'):
        ids['imdb'] = imdb
    if not ids:
        return None
    item = {'ids': ids}
    if title:
        item['title'] = str(title).strip()
    if year not in (None, '', 0, '0'):
        try:
            item['year'] = int(year)
        except (TypeError, ValueError):
            pass
    return item


def add_items(list_id, *, movies=None, shows=None):
    '''POST /sync/lists/{id}/items  -  body movies=/shows= lists of {ids,...}.'''
    list_id = str(list_id or '').strip()
    if not list_id or not auth.has_credentials():
        return False
    body = {}
    if movies:
        body['movies'] = list(movies)
    if shows:
        body['shows'] = list(shows)
    if not body:
        return False
    data = api.authed_json('POST', f'/sync/lists/{list_id}/items', body=body)
    return data is not None


def remove_items(list_id, *, movies=None, shows=None):
    '''POST /sync/lists/{id}/items/remove.'''
    list_id = str(list_id or '').strip()
    if not list_id or not auth.has_credentials():
        return False
    body = {}
    if movies:
        body['movies'] = list(movies)
    if shows:
        body['shows'] = list(shows)
    if not body:
        return False
    data = api.authed_json('POST', f'/sync/lists/{list_id}/items/remove', body=body)
    return data is not None


def add_title(list_id, media_type, *, tmdb_id=None, imdb_id=None, title=None, year=None):
    item = _write_item(tmdb_id, imdb_id, title, year)
    if not item:
        return False
    kind = str(media_type or '').strip().lower()
    if kind in ('show', 'tv', 'tvshow', 'shows'):
        return add_items(list_id, shows=[item])
    return add_items(list_id, movies=[item])


def remove_title(list_id, media_type, *, tmdb_id=None, imdb_id=None, title=None, year=None):
    item = _write_item(tmdb_id, imdb_id, title, year)
    if not item:
        return False
    kind = str(media_type or '').strip().lower()
    if kind in ('show', 'tv', 'tvshow', 'shows'):
        return remove_items(list_id, shows=[item])
    return remove_items(list_id, movies=[item])

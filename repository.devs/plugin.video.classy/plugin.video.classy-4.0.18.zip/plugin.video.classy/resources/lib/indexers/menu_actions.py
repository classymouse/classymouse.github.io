# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file menu_actions.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Which Crew-style menu actions are wired in Classy v4 (live vs ** stub rows).'''

from ..modules.router import route_registered

STUB_MARKER = '** '


def mark_stub_label(label):
    text = str(label or '')
    if text.startswith(STUB_MARKER):
        return text
    return f'{STUB_MARKER}{text}'

# movies&url= / tvshows&url= presets backed by apis/tmdb_discover.py
_MOVIE_PRESETS = frozenset({
    'trending', 'popular', 'rating', 'views', 'theaters', 'upcoming',
    'boxoffice', 'oscars', 'xristmas', 'halloween',
    'tmdb_movie_now_playing', 'tmdb_movie_upcoming', 'tmdb_movie_popular',
    'tmdb_movie_top_rated', 'tmdb_movie_trending_day', 'tmdb_movie_trending_week',
    'tmdb_movie_featured', 'tmdb_movie_latest_releases', 'tmdb_movie_premieres',
    'tmdb_movie_discover_year',
    'tmdb_networks_no_unaired', 'tmdb_certification', 'tmdb_language',
    'tmdb_genre',
    'calendar_thisweek', 'calendar_thismonth',
    'calendar_dvd_thisweek', 'calendar_dvd_thismonth',
    'tmdb_similar',
    'kids_movies_all', 'kids_movies_animation', 'kids_movies_family',
    'kids_movies_disney',
})

_MOVIE_STUB_PRESETS = frozenset({
})

_TV_PRESETS = frozenset({
    'premiere', 'airing', 'popular', 'rating', 'views', 'active', 'trending',
    'tmdb_networks', 'tmdb_certification', 'tmdb_language', 'tmdb_tv_on_the_air', 'tmdb_tv_airing_today',
    'tmdb_tv_popular_tv', 'tmdb_tv_top_rated', 'tmdb_tv_trending_day',
    'tmdb_tv_trending_week', 'tmdb_tv_upcoming',
    'tmdb_genre',
    'tmdb_similar',
    'kids_tv_all', 'kids_tv_animation', 'kids_tv_family', 'kids_tv_kids',
})

# My Movies submenu  -  wired via trakt/movie_lists.py + movie_discover.directory.
_TRAKT_MY_MOVIE_PRESETS = frozenset({
    'traktcollection', 'traktwatchlist', 'traktfeatured', 'traktrecommendations',
    'traktpopular', 'traktanticipated', 'trakthistory',
})

_TRAKT_MOVIE_PRESETS = _TRAKT_MY_MOVIE_PRESETS | frozenset({
    'traktplayed', 'traktwatched', 'traktcollected',
})

# My TV Shows submenu  -  wired via trakt/tv_lists.py + tv_discover.directory.
_TRAKT_MY_TV_PRESETS = frozenset({
    'traktcollection', 'traktwatchlist', 'traktfeatured', 'traktrecommendations',
    'traktpopular', 'traktanticipated', 'traktplayed', 'traktwatched',
    'traktcollected', 'trakthidden',
})

_TRAKT_TV_PRESETS = _TRAKT_MY_TV_PRESETS | frozenset({
    'trakthistory',
})

_SIMKL_MY_MOVIE_PRESETS = frozenset({
    'simklwatchlist', 'simklhistory', 'simkldropped', 'simklratings',
})

_SIMKL_MY_TV_PRESETS = frozenset({
    'simklwatchlist', 'simklwatching', 'simklhold', 'simklhistory',
    'simkldropped', 'simklratings',
})

_WETRAKR_MY_MOVIE_PRESETS = frozenset({
    'wetrakrwatchlist', 'wetrakrplaying', 'wetrakrfavorites', 'wetrakrhistory',
    'wetrakrdropped',
})

_WETRAKR_MY_TV_PRESETS = frozenset({
    'wetrakrwatchlist', 'wetrakrwatching', 'wetrakrwaiting', 'wetrakrhold',
    'wetrakrfavorites', 'wetrakrhistory', 'wetrakrdropped',
})

_WETRAKR_DISCOVER_PRESETS = frozenset({
    'wetrakrtrending', 'wetrakrpopular', 'wetrakrtoprated', 'wetrakrsearch',
})


def _is_wetrakr_discover_preset(preset):
    text = (preset or '').strip()
    if text in _WETRAKR_DISCOVER_PRESETS:
        return True
    return text.startswith('wetrakrpubliclist:')

_PLANNED_BASE_ACTIONS = frozenset({
    'traktMyRatings',
    'traktMyStatistics',
})

_TV_STUB_PRESETS = frozenset({
})

_WHATS_ON_PRESETS = frozenset({
    'mycalendar', 'calendar_today', 'calendar_thisweek', 'calendar_nextweek',
    'calendar_all_today', 'calendar_all_thisweek', 'calendar_all_thismonth',
})

_CALENDAR_STUB_PRESETS = frozenset({
    'added',
})

_HISTORY_PRESETS = frozenset({
    'trakthistory',
})

_CALENDAR_PRESETS = _WHATS_ON_PRESETS | _CALENDAR_STUB_PRESETS | _HISTORY_PRESETS

_MOVIES_CALENDAR_PRESETS = frozenset({
    'calendar_thisweek', 'calendar_thismonth',
    'calendar_dvd_thisweek', 'calendar_dvd_thismonth',
    'wetrakrmovie_all_thisweek', 'wetrakrmovie_all_thismonth',
    'wetrakrmovie_my_thisweek', 'wetrakrmovie_my_thismonth',
})

# Folder actions that open a MENUS submenu (registered in routes/navigator.py).
_SUBMENU_ACTIONS = frozenset({
    'mymovieliteNavigator',
    'mytvliteNavigator',
    'tmdbmovieslist',
    'tmdbtvlist',
    'calendars_menu',
    'calendarsAllNavigator',
    'movies_calendars_menu',
    'wetrakrDiscoverMovies',
    'wetrakrDiscoverTV',
    'halloweenNavigator',
    'holidaysNavigator',
    'navTVProgress',
    'docuNavigator',
    'tvCertificates',
    'tvLanguages',
    'tvNetworks',
    'tvGenres',
    'searchNavigator',
    'whatsOnSection',
    'traktlist',
    'movieGenres',
    'movieCertificates',
    'movieLanguages',
    'libraryNavigator',
})


def parse_action(action):
    '''Split plugin action query into base action + param dict.'''
    text = str(action or '').strip()
    if not text:
        return '', {}
    parts = text.split('&')
    base = parts[0]
    params = {}
    for part in parts[1:]:
        if '=' not in part:
            continue
        key, value = part.split('=', 1)
        params[key] = value
    return base, params


def action_is_live(action):
    '''True when the route exists and list presets are implemented.'''
    base, params = parse_action(action)
    if not base:
        return False

    if base in _SUBMENU_ACTIONS:
        return route_registered(base)

    if base == 'movies':
        preset = (params.get('url') or '').strip()
        if preset.startswith('http'):
            from ..trakt import user_lists as trakt_user_lists
            from ..mdblist import lists as mdblist_lists
            from ..wetrakr import user_lists as wetrakr_user_lists
            if trakt_user_lists.is_list_items_url(preset):
                return route_registered('movies')
            if mdblist_lists.is_list_items_url(preset):
                return route_registered('movies')
            if wetrakr_user_lists.is_list_items_url(preset):
                return route_registered('movies')
            return False
        if (
            preset not in _MOVIE_PRESETS
            and preset not in _TRAKT_MY_MOVIE_PRESETS
            and preset not in _SIMKL_MY_MOVIE_PRESETS
            and preset not in _WETRAKR_MY_MOVIE_PRESETS
            and not _is_wetrakr_discover_preset(preset)
        ):
            return False
        return route_registered('movies')

    if base == 'tvshows':
        preset = (params.get('url') or '').strip()
        if preset.startswith('http'):
            from ..mdblist import lists as mdblist_lists
            from ..wetrakr import user_lists as wetrakr_user_lists
            if mdblist_lists.is_list_items_url(preset):
                return route_registered('tvshows')
            if wetrakr_user_lists.is_list_items_url(preset):
                return route_registered('tvshows')
            return False
        if (
            preset not in _TV_PRESETS
            and preset not in _TRAKT_MY_TV_PRESETS
            and preset not in _SIMKL_MY_TV_PRESETS
            and preset not in _WETRAKR_MY_TV_PRESETS
            and not _is_wetrakr_discover_preset(preset)
        ):
            return False
        return route_registered('tvshows')

    if base == 'calendar':
        preset = (params.get('url') or '').strip()
        if preset in _WHATS_ON_PRESETS or preset in _HISTORY_PRESETS:
            return route_registered('calendar')
        return preset in _CALENDAR_STUB_PRESETS and False

    if base == 'movies_calendar':
        preset = (params.get('url') or '').strip()
        return preset in _MOVIES_CALENDAR_PRESETS and route_registered('movies_calendar')

    if base in (
        'progress_shows',
        'progress_next_episodes',
        'progress_in_progress_episodes',
        'movieProgress',
        'movieUserlists',
        'mdbLists',
        'wetrakrUserlists',
        'wetrakrPubliclists',
        'wetrakrSearch',
        'wetrakrManager',
        'clearCacheWetrakr',
        'wetrakrForceSync',
        'authTrakt',
        'authSimkl',
        'revokeSimkl',
        'simklManager',
        'openResolveUrlSettings',
        'debridManagement',
        'debridService',
        'scraperPacks',
        'opensettings',
        'seasons',
        'episodes',
        'play',
        'movieWidget',
        'tvWidget',
        'tvliteNavigator',
        'movieliteNavigator',
        'tvNavigator',
        'movieNavigator',
        'mytvliteNavigator',
        'mymovieliteNavigator',
        'docuNavigator',
        'tvCertificates',
        'tvLanguages',
        'tvNetworks',
        'tvGenres',
        'traktlist',
        'movieGenres',
        'movieCertificates',
    'movieLanguages',
    'libraryNavigator',
    'setupLibrarySources',
    'updateLibrary',
    'moviesToLibrary',
    'tvshowsToLibrary',
    'searchNavigator',
        'whatsOnSection',
    ):
        return route_registered(base)

    return route_registered(base) and base not in (
        'calendar', 'movies_calendar', *_PLANNED_BASE_ACTIONS,
    )


def action_is_planned(action):
    '''True for menu rows we intend to ship  -  show with ** until live.'''
    base, params = parse_action(action)
    if not base:
        return False

    if base in _SUBMENU_ACTIONS:
        return route_registered(base)

    if base == 'movies':
        preset = (params.get('url') or '').strip()
        if preset in _MOVIE_PRESETS:
            return route_registered('movies')
        if (
            preset in _SIMKL_MY_MOVIE_PRESETS
            or preset in _WETRAKR_MY_MOVIE_PRESETS
            or _is_wetrakr_discover_preset(preset)
        ):
            return route_registered('movies')
        if preset.startswith('http'):
            from ..trakt import user_lists as trakt_user_lists
            from ..mdblist import lists as mdblist_lists
            from ..wetrakr import user_lists as wetrakr_user_lists
            if trakt_user_lists.is_list_items_url(preset):
                return route_registered('movies')
            if mdblist_lists.is_list_items_url(preset):
                return route_registered('movies')
            if wetrakr_user_lists.is_list_items_url(preset):
                return route_registered('movies')
            return False
        return preset in _TRAKT_MOVIE_PRESETS or preset in _MOVIE_STUB_PRESETS

    if base == 'tvshows':
        preset = (params.get('url') or '').strip()
        if preset in _TV_PRESETS:
            return route_registered('tvshows')
        if (
            preset in _TRAKT_MY_TV_PRESETS
            or preset in _SIMKL_MY_TV_PRESETS
            or preset in _WETRAKR_MY_TV_PRESETS
            or _is_wetrakr_discover_preset(preset)
        ):
            return route_registered('tvshows')
        if preset.startswith('http'):
            from ..mdblist import lists as mdblist_lists
            from ..wetrakr import user_lists as wetrakr_user_lists
            if mdblist_lists.is_list_items_url(preset):
                return route_registered('tvshows')
            if wetrakr_user_lists.is_list_items_url(preset):
                return route_registered('tvshows')
            return False
        return preset in _TRAKT_TV_PRESETS or preset in _TV_STUB_PRESETS

    if base == 'calendar':
        preset = (params.get('url') or '').strip()
        return preset in _CALENDAR_PRESETS

    if base == 'movies_calendar':
        return (params.get('url') or '').strip() in _MOVIES_CALENDAR_PRESETS

    if base in (
        'progress_shows',
        'progress_next_episodes',
        'progress_in_progress_episodes',
        'movieProgress',
        'movieUserlists',
        'mdbLists',
        'wetrakrUserlists',
        'wetrakrManager',
        'authTrakt',
        'authSimkl',
        'revokeSimkl',
        'simklManager',
        'openResolveUrlSettings',
        'debridManagement',
        'debridService',
        'scraperPacks',
        'opensettings',
        'seasons',
        'episodes',
        'play',
        'movieWidget',
        'tvWidget',
        'tvliteNavigator',
        'movieliteNavigator',
        'tvNavigator',
        'movieNavigator',
        'mytvliteNavigator',
        'mymovieliteNavigator',
    ):
        return True

    if base in _PLANNED_BASE_ACTIONS:
        return True

    return False


def action_needs_work(action):
    return action_is_planned(action) and not action_is_live(action)


def format_menu_label(label, action, row_style=None):
    from . import menu_labels

    if isinstance(label, str) and ('**' in label or label.startswith(STUB_MARKER)):
        return label

    display = menu_labels.display_label(label, row_style)
    if action_needs_work(action):
        return mark_stub_label(display)
    return display

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file wetrakr_userlists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

My Movies / My TV  ->  WeTrakr Lists  -  personal list folders.'''

from urllib.parse import quote

from ..modules import kodi
from ..modules.classy import c
from ..wetrakr import auth
from ..wetrakr import user_lists as wt_user_lists
from .navigator import n


def _media_from_params(params):
    raw = str((params or {}).get('media') or 'movie').strip().lower()
    return 'show' if raw in ('show', 'tv', 'tvshow') else 'movie'


def _content_type(media):
    return 'tvshows' if media == 'show' else 'movies'


def _action_prefix(media):
    return 'tvshows' if media == 'show' else 'movies'


def _icon2(media):
    return 'DefaultTVShows.png' if media == 'show' else 'DefaultMovies.png'


def directory(handle, params):
    media = _media_from_params(params)

    if not auth.has_credentials():
        c.log('[WeTrakrUserlists] auth required', 1)
        li = kodi.item(label='Authorize WeTrakr to see your lists')
        poster = c.addon_poster()
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)
        kodi.content(handle, _content_type(media))
        kodi.directory(handle, cacheToDisc=False)
        return

    # Movies browser shows mixed lists (Trakt Movie Lists parity); TV filters to shows.
    entries = wt_user_lists.fetch_index(media='show' if media == 'show' else '')
    if not entries:
        li = kodi.item(label='No WeTrakr lists found')
        poster = c.addon_poster()
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)
        kodi.content(handle, _content_type(media))
        kodi.directory(handle, cacheToDisc=True)
        return

    prefix = _action_prefix(media)
    for entry in entries:
        items_url = entry.get('items_url') or ''
        if not items_url:
            continue
        n.addDirectoryItem(
            entry['name'],
            f'{prefix}&url={quote(items_url, safe="")}',
            'wetrakr.png',
            _icon2(media),
            queue=True,
        )

    kodi.content(handle, _content_type(media))
    kodi.directory(handle, cacheToDisc=True)

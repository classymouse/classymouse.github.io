# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file genre_catalog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Fixed TMDB genre catalogs for Movies / TV Genres menus.

IDs match TMDB discover `with_genres`. Labels live in strings.po (no cleangenre).
`art_name` is the English stem for skin / genre-icon packs (Aeon Action.jpg, ...).
TV Anime is not a TMDB genre  -  compound filter (Animation + JP); see tmdb_discover.'''

from . import menu_ids as I

# (tmdb_genre_id | 'anime', string_id, art_name)
MOVIE_GENRES = (
    (28, I.GENRE_ACTION, 'Action'),
    (12, I.GENRE_ADVENTURE, 'Adventure'),
    (16, I.GENRE_ANIMATION, 'Animation'),
    (35, I.GENRE_COMEDY, 'Comedy'),
    (80, I.GENRE_CRIME, 'Crime'),
    (99, I.GENRE_DOCUMENTARY, 'Documentary'),
    (18, I.GENRE_DRAMA, 'Drama'),
    (10751, I.GENRE_FAMILY, 'Family'),
    (14, I.GENRE_FANTASY, 'Fantasy'),
    (36, I.GENRE_HISTORY, 'History'),
    (27, I.GENRE_HORROR, 'Horror'),
    (10402, I.GENRE_MUSIC, 'Music'),
    (9648, I.GENRE_MYSTERY, 'Mystery'),
    (10749, I.GENRE_ROMANCE, 'Romance'),
    (878, I.GENRE_SCIENCE_FICTION, 'Science Fiction'),
    (53, I.GENRE_THRILLER, 'Thriller'),
    (10752, I.GENRE_WAR, 'War'),
    (37, I.GENRE_WESTERN, 'Western'),
)

TV_GENRES = (
    (10759, I.GENRE_ACTION_ADVENTURE, 'Action & Adventure'),
    (16, I.GENRE_ANIMATION, 'Animation'),
    ('anime', I.GENRE_ANIME, 'Anime'),
    (35, I.GENRE_COMEDY, 'Comedy'),
    (80, I.GENRE_CRIME, 'Crime'),
    (99, I.GENRE_DOCUMENTARY, 'Documentary'),
    (18, I.GENRE_DRAMA, 'Drama'),
    (10751, I.GENRE_FAMILY, 'Family'),
    (10762, I.GENRE_KIDS, 'Kids'),
    (9648, I.GENRE_MYSTERY, 'Mystery'),
    (10763, I.GENRE_NEWS, 'News'),
    (10764, I.GENRE_REALITY, 'Reality'),
    (10765, I.GENRE_SCI_FI_FANTASY, 'Sci-Fi & Fantasy'),
    (10766, I.GENRE_SOAP, 'Soap'),
    (10767, I.GENRE_TALK, 'Talk'),
    (10768, I.GENRE_WAR_POLITICS, 'War & Politics'),
    (37, I.GENRE_WESTERN, 'Western'),
)

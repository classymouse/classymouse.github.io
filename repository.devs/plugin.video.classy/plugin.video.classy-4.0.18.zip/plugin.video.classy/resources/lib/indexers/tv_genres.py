# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_genres.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Shows  ->  Genres submenu  -  fixed TMDB genre list  ->  discover (+ Anime).'''

from __future__ import annotations

from ..modules import kodi
from .genre_catalog import TV_GENRES
from . import genre_posters
from .navigator import n


def genres_directory(handle):
    '''List TV genres  ->  tvshows&url=tmdb_genre&tid={id|anime}.'''
    thumbs = genre_posters.resolve_thumbs(art for _, _, art in TV_GENRES)
    for genre_id, label_id, art_name in TV_GENRES:
        n.addDirectoryItem(
            label_id,
            f'tvshows&url=tmdb_genre&tid={genre_id}',
            thumbs.get(art_name, genre_posters.FALLBACK_THUMB),
            'DefaultTVShows.png',
        )
    kodi.content(handle, 'genres')
    kodi.directory(handle, cacheToDisc=True)

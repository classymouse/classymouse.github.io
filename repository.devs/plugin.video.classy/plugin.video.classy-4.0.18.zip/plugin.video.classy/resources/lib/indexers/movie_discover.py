# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_discover.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB / Trakt movie discovery lists  -  preset  ->  rows  ->  enrich  ->  directory.'''

import sys
from urllib.parse import urlencode

from ..indexers import menu_actions
from ..routes.stub import notify_not_implemented
from ..apis import tmdb_discover
from ..kodi import listing
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from ..modules.unaired import is_unaired, show_unaired_enabled
from ..play.url import play_url
from ..trakt import auth
from ..trakt import user_lists as trakt_user_lists
from ..trakt.browse_context import MovieBrowseContext

_RELEASE_DATE_PRESETS = frozenset({
    'tmdb_movie_latest_releases',
    'latest_releases',
    'tmdb_movie_premieres',
})

# Lists that exist to show not-yet-released titles  -  never hide via showunaired filter.
_FUTURE_RELEASE_PRESETS = frozenset({
    'traktanticipated',
    'tmdb_movie_upcoming',
    'upcoming',
    'calendar_thisweek',
    'calendar_thismonth',
    'calendar_dvd_thisweek',
    'calendar_dvd_thismonth',
    'wetrakrmovie_all_thisweek',
    'wetrakrmovie_all_thismonth',
    'wetrakrmovie_my_thisweek',
    'wetrakrmovie_my_thismonth',
})


def _prepend_release_plot(row):
    '''Crew parity  -  show formatted release date in plot for JustWatch-style lists.'''
    premiered = (row.premiered or '').strip()
    if not premiered or premiered == '0':
        return
    try:
        from datetime import datetime
        release_dt = datetime.strptime(premiered[:10], '%Y-%m-%d')
        formatted = release_dt.strftime('%B %d, %Y')
    except (ValueError, TypeError):
        return
    plot = (row.plot or '').strip()
    prefix = f'[B]Released:[/B] {formatted}'
    row.plot = f'{prefix}\n\n{plot}' if plot else prefix


def _seasons_url(row):
    query = urlencode({
        'action': 'seasons',
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': row.tvshowtitle or row.title,
    })
    return f'{sys.argv[0]}?{query}'


def _rows_from_results(results, source, preset=''):
    rows = []
    for item in results or []:
        if not isinstance(item, dict):
            continue
        if source == 'trakt_list_items':
            if 'movie' in item:
                rows.append(VideoRow.from_trakt_movie(item))
            elif 'show' in item:
                rows.append(VideoRow.from_trakt_watched_show(item))
        elif source in ('trakt_trending', 'trakt_boxoffice', 'trakt_movies'):
            rows.append(VideoRow.from_trakt_movie(item))
        else:
            rows.append(VideoRow.from_tmdb_movie(item))
    if preset in _RELEASE_DATE_PRESETS:
        for row in rows:
            _prepend_release_plot(row)
    return rows


def _next_page_url(preset, page, tid=None, search_query=None):
    query = {'action': 'movies', 'url': preset, 'page': page + 1}
    if tid:
        query['tid'] = tid
    if search_query:
        query['query'] = search_query
    return f'{sys.argv[0]}?{urlencode(query)}'


def directory(handle, params):
    ctx = listing.listing_context()
    preset = (params or {}).get('url') or (params or {}).get('preset') or ''
    preset = str(preset).strip()
    page = listing.parse_page(params, ctx)
    tid = str((params or {}).get('tid') or '').strip() or None
    search_query = str((params or {}).get('query') or '').strip() or None

    if not preset:
        c.log('[MovieDiscover] missing url/preset', 1)
        listing.finish_directory(handle, 'movies', ctx, cache=False)
        return

    action_key = f'movies&url={preset}'
    if menu_actions.action_needs_work(action_key):
        notify_not_implemented({'action': 'movies', 'url': preset})
        listing.finish_directory(handle, 'movies', ctx, cache=False)
        return

    c.log(
        f'[MovieDiscover] {preset} page={page} tid={tid or " - "} '
        f'widget={ctx.is_widget}'
    )
    if ctx.is_widget and page == 1 and str((params or {}).get('page') or '') not in ('', '1'):
        c.log(
            f'[MovieDiscover] WARNING widget forced page=1 but url page='
            f'{(params or {}).get("page")!r}  -  check is_widget_listing',
            1,
        )
    data = tmdb_discover.fetch_movie_page(
        preset, page=page, tid=tid, query=search_query,
    )
    if not data:
        c.log(f'[MovieDiscover] fetch failed for {preset}', 1)
        listing.finish_directory(handle, 'movies', ctx, cache=False)
        return

    source = data.get('_source') or 'discover'
    personal_list = bool(data.get('_personal_list'))
    rows = _rows_from_results(data.get('results') or [], source, preset=preset)
    if (
        not show_unaired_enabled()
        and preset not in _FUTURE_RELEASE_PRESETS
        and not personal_list
        and not trakt_user_lists.is_personal_list_url(preset)
        and not (
            isinstance(preset, str)
            and 'wetrakr.com' in preset.lower()
            and '/sync/lists/' in preset.lower()
        )
        and not (
            isinstance(preset, str)
            and preset.startswith((
                'wetrakrtrending', 'wetrakrpopular', 'wetrakrtoprated',
                'wetrakrsearch', 'wetrakrpubliclist:',
            ))
        )
    ):
        rows = [row for row in rows if not is_unaired(row)]
    rows = listing.slice_rows(rows, ctx)
    if not rows:
        c.log(f'[MovieDiscover] empty results for {preset}')
        listing.finish_directory(handle, 'movies', ctx, cache=True)
        return

    if auth.has_credentials():
        try:
            browse_ctx = MovieBrowseContext.load(
                log_label=f'movie_discover:{preset}', clear_probe=True,
            )
            browse_ctx.apply_watch_rows(rows)
            if c.is_devmode():
                for row in rows:
                    if row.overlay or row.playcount:
                        c.log(
                            f'[Watch] {row.title!r} tmdb={row.tmdb} '
                            f'playcount={row.playcount} overlay={row.overlay} '
                            f'resume={row.resume_point}',
                        )
        except Exception as exc:
            c.log(f'[MovieDiscover] watch overlay skipped: {exc}', 1)

    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    if source == 'trakt_list_items':
        for row in rows:
            is_folder = row.mediatype == 'tvshow'
            row_url = _seasons_url(row) if is_folder else play_url(row)
            listing.emit_video_row(handle, row, row_url, ctx, is_folder=is_folder)
    else:
        listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)

    total_pages = max(1, int(data.get('total_pages') or 1))
    if ctx.paginate and page < total_pages:
        next_url = _next_page_url(preset, page, tid, search_query=search_query)
        label = f'Next Page ({page + 1}/{total_pages})'
        listing.add_next_page(handle, next_url, label, ctx)

    listing.finish_directory(handle, 'movies', ctx, cache=True)

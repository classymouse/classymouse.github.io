# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_discover.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB / Trakt TV discovery lists  -  preset  ->  rows  ->  enrich  ->  directory.'''

import sys
from urllib.parse import urlencode

from ..indexers import menu_actions
from ..routes.stub import notify_not_implemented
from ..apis import tmdb_discover
from ..kodi import listing
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..metadata.video_row import VideoRow
from ..modules.classy import c
from ..modules.unaired import is_unaired, show_unaired_enabled
from ..trakt import auth
from ..trakt.browse_context import TVBrowseContext


_FUTURE_RELEASE_PRESETS = frozenset({
    'traktanticipated',
    'tmdb_tv_upcoming',
    'upcoming',
})

_PERSONAL_TV_PRESETS = frozenset({
    'traktcollection',
    'traktwatchlist',
    'trakthidden',
})


def _rows_from_results(results, source):
    rows = []
    for item in results or []:
        if not isinstance(item, dict):
            continue
        if source == 'trakt_list_items':
            if 'show' in item or 'movie' not in item:
                rows.append(VideoRow.from_trakt_watched_show(item))
        elif source in ('trakt_trending', 'trakt_shows'):
            rows.append(VideoRow.from_trakt_watched_show(item))
        else:
            rows.append(VideoRow.from_tmdb_tv(item))
    return rows


def _seasons_url(row):
    query = urlencode({
        'action': 'seasons',
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': row.tvshowtitle or row.title,
    })
    return f'{sys.argv[0]}?{query}'


def _next_page_url(preset, page, tid=None, search_query=None):
    query = {'action': 'tvshows', 'url': preset, 'page': page + 1}
    if tid:
        query['tid'] = tid
    if search_query:
        query['query'] = search_query
    return f'{sys.argv[0]}?{urlencode(query)}'


def directory(handle, params):
    ctx = listing.listing_context()
    preset = (params or {}).get('url') or (params or {}).get('preset') or ''
    preset = str(preset).strip()
    page = listing.parse_page(params, ctx)
    tid = str((params or {}).get('tid') or '').strip() or None
    search_query = str((params or {}).get('query') or '').strip() or None

    if not preset:
        c.log('[TVDiscover] missing url/preset', 1)
        listing.finish_directory(handle, 'tvshows', ctx, cache=False)
        return

    action_key = f'tvshows&url={preset}'
    if menu_actions.action_needs_work(action_key):
        notify_not_implemented({'action': 'tvshows', 'url': preset})
        listing.finish_directory(handle, 'tvshows', ctx, cache=False)
        return

    c.log(
        f'[TVDiscover] {preset} page={page} tid={tid or " - "} '
        f'widget={ctx.is_widget}'
    )
    data = tmdb_discover.fetch_tv_page(
        preset, page=page, tid=tid, query=search_query,
    )
    if not data:
        c.log(f'[TVDiscover] fetch failed for {preset}', 1)
        listing.finish_directory(handle, 'tvshows', ctx, cache=False)
        return

    source = data.get('_source') or 'discover'
    rows = _rows_from_results(data.get('results') or [], source)
    if (
        not show_unaired_enabled()
        and preset not in _FUTURE_RELEASE_PRESETS
        and preset not in _PERSONAL_TV_PRESETS
        and not (isinstance(preset, str) and 'mdblist.com' in preset.lower())
        and not (
            isinstance(preset, str)
            and 'wetrakr.com' in preset.lower()
            and '/sync/lists/' in preset.lower()
        )
        and not (
            isinstance(preset, str)
            and preset.startswith((
                'wetrakrtrending', 'wetrakrpopular', 'wetrakrtoprated',
                'wetrakrsearch', 'wetrakrpubliclist:',
            ))
        )
    ):
        rows = [row for row in rows if not is_unaired(row)]
    rows = listing.slice_rows(rows, ctx)
    if not rows:
        c.log(f'[TVDiscover] empty results for {preset}')
        listing.finish_directory(handle, 'tvshows', ctx, cache=True)
        return

    if auth.has_credentials():
        try:
            browse_ctx = TVBrowseContext.load(log_label=f'tv_discover:{preset}', clear_probe=True)
            browse_ctx.apply_watch_rows(rows)
            if c.is_devmode():
                for row in rows:
                    if row.overlay or row.playcount:
                        c.log(
                            f'[Watch] {row.tvshowtitle!r} tmdb={row.tmdb} '
                            f'playcount={row.playcount} overlay={row.overlay}',
                        )
        except Exception as exc:
            c.log(f'[TVDiscover] watch overlay skipped: {exc}', 1)

    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, _seasons_url, ctx, is_folder=True)

    total_pages = max(1, int(data.get('total_pages') or 1))
    if ctx.paginate and page < total_pages:
        next_url = _next_page_url(preset, page, tid, search_query=search_query)
        label = f'Next Page ({page + 1}/{total_pages})'
        listing.add_next_page(handle, next_url, label, ctx)

    listing.finish_directory(handle, 'tvshows', ctx, cache=True)

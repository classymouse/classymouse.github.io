# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_years.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Movies  ->  Year submenu  -  pick a release year (TMDB discover).'''

from __future__ import annotations

from datetime import datetime

from ..modules import kodi
from .navigator import n

# Crew listed ~1900 -> now; 1970 is enough for practical browsing.
MOVIE_YEAR_MIN = 1970


def years_directory(handle):
    '''Newest year first  ->  movies&url=tmdb_movie_discover_year&tid={year}.'''
    current = datetime.now().year
    for year in range(current, MOVIE_YEAR_MIN - 1, -1):
        n.addDirectoryItem(
            str(year),
            f'movies&url=tmdb_movie_discover_year&tid={year}',
            'years.png',
            'DefaultMovies.png',
        )
    kodi.content(handle, 'years')
    kodi.directory(handle, cacheToDisc=True)

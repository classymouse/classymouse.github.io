# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file mdb_lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

MDBList browser  -  My / Top / Liked list folders  ->  movies|tvshows&url=.'''

from urllib.parse import quote, urlencode

from ..mdblist import lists as mdb_lists
from ..modules import kodi
from ..modules.classy import c
from .navigator import n


def _media_from_params(params):
    raw = str((params or {}).get('media') or 'movie').strip().lower()
    return 'show' if raw in ('show', 'tv', 'tvshow') else 'movie'


def _content_type(media):
    return 'tvshows' if media == 'show' else 'movies'


def _action_prefix(media):
    return 'tvshows' if media == 'show' else 'movies'


def _icon2(media):
    return 'DefaultTVShows.png' if media == 'show' else 'DefaultMovies.png'


def _empty(handle, label, media):
    li = kodi.item(label=label)
    poster = c.addon_poster()
    li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
    kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)
    kodi.content(handle, _content_type(media))
    kodi.directory(handle, cacheToDisc=False)


def _section_query(section, media):
    return 'mdbLists&' + urlencode({'media': media, 'section': section})


def directory(handle, params):
    media = _media_from_params(params)
    section = str((params or {}).get('section') or '').strip().lower()

    if not mdb_lists.has_credentials():
        c.log('[MDBList] API key required', 1)
        _empty(handle, 'Add your MDBList API key in Settings  ->  Accounts', media)
        return

    if not section:
        for key, label in (
            ('my', c.lang(30793) or 'My Lists'),
            ('top', c.lang(30794) or 'Top Lists'),
            ('liked', c.lang(30795) or 'Liked Lists'),
        ):
            n.addDirectoryItem(
                label,
                _section_query(key, media),
                'userlists.png',
                _icon2(media),
            )
        kodi.content(handle, _content_type(media))
        kodi.directory(handle, cacheToDisc=True)
        return

    if section == 'my':
        entries = mdb_lists.fetch_my_lists(media=media)
    elif section == 'top':
        entries = mdb_lists.fetch_top_lists(media=media)
    elif section == 'liked':
        entries = mdb_lists.fetch_liked_lists(media=media)
    else:
        entries = []

    if not entries:
        _empty(
            handle,
            'No MDBList lists found (check API key in Settings  ->  Accounts)',
            media,
        )
        return

    prefix = _action_prefix(media)
    for entry in entries:
        items_url = entry.get('items_url') or ''
        if not items_url:
            continue
        n.addDirectoryItem(
            entry['name'],
            f'{prefix}&url={quote(items_url, safe="")}',
            'userlists.png',
            _icon2(media),
            queue=True,
        )

    kodi.content(handle, _content_type(media))
    kodi.directory(handle, cacheToDisc=True)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file wetrakr_publiclists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr public list hub  -  trending / latest / search (app key, no auth).'''

from urllib.parse import quote

import xbmcgui

from ..modules import kodi
from ..modules.classy import c
from ..wetrakr import discover as wt_discover
from .navigator import n


def _media_from_params(params):
    raw = str((params or {}).get('media') or 'movie').strip().lower()
    return 'show' if raw in ('show', 'tv', 'tvshow') else 'movie'


def _kind_from_params(params):
    raw = str((params or {}).get('kind') or 'trending').strip().lower()
    if raw in ('latest', 'last'):
        return 'latest'
    if raw == 'search':
        return 'search'
    return 'trending'


def _content_type(media):
    return 'tvshows' if media == 'show' else 'movies'


def _action_prefix(media):
    return 'tvshows' if media == 'show' else 'movies'


def _icon2(media):
    return 'DefaultTVShows.png' if media == 'show' else 'DefaultMovies.png'


def _hub(handle, media):
    '''Top folder: Trending Lists / Latest Lists / Search Lists.'''
    n.addDirectoryItem(
        'Trending Lists',
        f'wetrakrPubliclists&media={media}&kind=trending',
        'wetrakr.png',
        _icon2(media),
    )
    n.addDirectoryItem(
        'Latest Lists',
        f'wetrakrPubliclists&media={media}&kind=latest',
        'wetrakr.png',
        _icon2(media),
    )
    n.addDirectoryItem(
        'Search Lists',
        f'wetrakrPubliclists&media={media}&kind=search',
        'wetrakr.png',
        _icon2(media),
    )
    kodi.content(handle, _content_type(media))
    kodi.directory(handle, cacheToDisc=True)


def _prompt_query():
    keyboard = xbmcgui.Dialog().input('Search WeTrakr Lists', type=xbmcgui.INPUT_ALPHANUM)
    return (keyboard or '').strip()


def directory(handle, params):
    media = _media_from_params(params)
    kind = _kind_from_params(params)
    page = 1
    try:
        page = max(1, int((params or {}).get('page') or 1))
    except (TypeError, ValueError):
        page = 1
    query = str((params or {}).get('query') or '').strip()

    # No kind=hub: when kind omitted and no query, show hub.
    if not (params or {}).get('kind') and not query:
        _hub(handle, media)
        return

    if kind == 'search' and not query:
        query = _prompt_query()
        if not query:
            kodi.content(handle, _content_type(media))
            kodi.directory(handle, cacheToDisc=False)
            return

    entries, total_pages = wt_discover.fetch_public_lists_index(
        'search' if query else kind,
        page=page,
        query=query or None,
        media=media,
    )
    if not entries:
        li = kodi.item(label='No WeTrakr public lists found')
        poster = c.addon_poster()
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)
        kodi.content(handle, _content_type(media))
        kodi.directory(handle, cacheToDisc=True)
        return

    prefix = _action_prefix(media)
    for entry in entries:
        items_url = wt_discover.public_list_items_url(entry['id'], media=media)
        if not items_url:
            continue
        n.addDirectoryItem(
            entry['name'],
            f'{prefix}&url={quote(items_url, safe="")}',
            'wetrakr.png',
            _icon2(media),
            queue=True,
        )

    if page < total_pages:
        next_action = (
            f'wetrakrPubliclists&media={media}&kind='
            f'{"search" if query else kind}&page={page + 1}'
        )
        if query:
            next_action += f'&query={quote(query)}'
        n.addDirectoryItem(
            f'Next Page ({page + 1}/{total_pages})',
            next_action,
            'next.png',
            'DefaultFolder.png',
        )

    kodi.content(handle, _content_type(media))
    kodi.directory(handle, cacheToDisc=True)

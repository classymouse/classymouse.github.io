# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file documentaries.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Documentaries hub  -  recent TMDB Documentary genre for Movies + TV.

Replaces the old topdocumentaryfilms stub. Same discover filters as
Genres  ->  Documentary (genre 99, ~15y floor).'''

from __future__ import annotations

from ..modules import kodi
from . import menu_labels as L
from .navigator import n


def documentaries_directory(handle):
    '''Movie Documentaries + TV Documentaries  ->  tmdb_genre&tid=99.'''
    n.addDirectoryItem(
        L.MOVIE_DOCUMENTARIES,
        'movies&url=tmdb_genre&tid=99',
        'documentaries.png',
        'DefaultMovies.png',
    )
    n.addDirectoryItem(
        L.TV_DOCUMENTARIES,
        'tvshows&url=tmdb_genre&tid=99',
        'documentaries.png',
        'DefaultTVShows.png',
    )
    kodi.content(handle, 'addons')
    kodi.directory(handle, cacheToDisc=True)

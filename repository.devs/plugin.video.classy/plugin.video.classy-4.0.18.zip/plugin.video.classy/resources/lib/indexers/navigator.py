# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file navigator.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import sys
import os
import traceback

import xbmc
import xbmcplugin
import xbmcgui

from ..modules.classy import c
from ..modules import kodi
from .menu_render import render_menu
from . import menu_actions
from . import menu_labels as L


def _devmode():
    return c.is_devmode()


sysaddon = sys.argv[0]
addon_handle = int(sys.argv[1])
syshandle = int(sys.argv[1])



class navigator:
    def __init__(self):
        pass

    def __del__(self):
        pass

    def deinit(self):
        pass

    def root(self):
        render_menu(self, 'root')

    def show_menu(self, menu_key):
        render_menu(self, menu_key)

    def navTools(self):
        # Authorize row follows active watch home (Trakt / Simkl / WeTrakr).
        try:
            from .. import tracker
            if tracker.is_wetrakr():
                auth_label, auth_action, auth_icon = L.WETRAKR_AUTHORIZE, 'authWetrakr', 'wetrakr.png'
            elif tracker.is_simkl():
                auth_label, auth_action, auth_icon = L.SIMKL_AUTHORIZE, 'authSimkl', 'simkl.png'
            else:
                auth_label, auth_action, auth_icon = L.TRAKT_AUTHORIZE, 'authTrakt', 'trakt.png'
        except Exception:
            auth_label, auth_action, auth_icon = L.TRAKT_AUTHORIZE, 'authTrakt', 'trakt.png'
        self.addDirectoryItem(
            menu_actions.format_menu_label(auth_label, auth_action),
            auth_action, auth_icon, auth_icon, isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.RESOLVEURL_SETTINGS, 'openResolveUrlSettings'),
            'openResolveUrlSettings', 'resolveurl.png', 'resolveurl.png', isFolder=False,
        )
        # Keep Settings pinned 3rd  -  new Tools rows go below this block.
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.TOOLS_MENU_SETTINGS, 'opensettings&query=0.0'),
            'opensettings&query=0.0', 'tools.png', 'tools.png', isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.DEBRID_MANAGEMENT, 'debridManagement'),
            'debridManagement', 'resolveurl.png', 'resolveurl.png',
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.SCRAPER_PACKS, 'scraperPacks'),
            'scraperPacks', 'tools.png', 'tools.png', isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.LIBRARY, 'libraryNavigator'),
            'libraryNavigator', 'library_update.png', 'DefaultAddonProgram.png',
        )
        try:
            from ..modules.downloader import downloads_path, downloads_ready
            from ..modules import control as ctrl
            if downloads_ready():
                folder = ctrl.transPath(downloads_path())
                self.addDirectoryItem(
                    menu_actions.format_menu_label(L.DOWNLOADS, 'downloadNavigator'),
                    folder, 'tools.png', 'DefaultFolder.png',
                    isFolder=True, isAction=False,
                )
        except Exception:
            pass
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.VIEWTYPES, 'viewsNavigator'),
            'viewsNavigator', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.ORION, 'OrionNavigator'),
            'OrionNavigator', 'orion.png', 'orion.png',
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.CLEAR_CACHES, 'clearCaches'),
            'clearCaches', 'tools.png', 'DefaultAddonProgram.png',
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.UPLOAD_LOGS, 'uploadLogs'),
            'uploadLogs', 'tools.png', 'DefaultAddonProgram.png',
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.CHANGELOG, 'changelog'),
            'changelog', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )

        self.endDirectory()

    def navOrion(self):
        '''Orion install / auth / settings  -  mirrors Crew Tools submenu.'''
        rows = (
            (32143, 'installOrion'),
            (32136, 'authorizeOrion'),
            (32142, 'registerOrion'),
            (32137, 'userInfoOrion'),
            (32139, 'settingsOrion'),
            (32138, 'filtersOrion'),
            (32140, 'globalFiltersOrion'),
            (32141, 'serverOrion'),
        )
        for label_id, action in rows:
            self.addDirectoryItem(
                menu_actions.format_menu_label(L.NavLabel(label_id, 'plain'), action),
                action, 'orion.png', 'orion.png', isFolder=False,
            )
        self.endDirectory()

    def navClearCaches(self):
        '''Crew cachingTools parity  -  same row names and split main/meta.'''
        rows = (
            (L.CACHE_PROVIDERS, 'clearSources'),
            (L.CACHE_SEARCH, 'clearCacheSearch'),
            (L.CACHE_MAIN, 'clearCache'),
            (L.CACHE_META, 'clearMetaCache'),
            (L.CACHE_DEBRID, 'clearCacheDebrid'),
            (L.CACHE_WETRAKR, 'clearCacheWetrakr'),
            (L.WETRAKR_FORCE_SYNC, 'wetrakrForceSync'),
            (L.CACHE_ALL, 'clearAllCache'),
        )
        for label, action in rows:
            self.addDirectoryItem(
                menu_actions.format_menu_label(label, action),
                action, 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
            )
        self.endDirectory()

    def navDebridManagement(self):
        '''Lean Debrid management  -  status + clear (B1 scrub) + ResolveURL.'''
        from ..tools import debrid_manager

        for row in debrid_manager.service_rows():
            label = (
                f"[B]{row['label']}[/B]  -  {row['status']}"
            )
            self.addDirectoryItem(
                label,
                f"debridService&provider={row['provider']}",
                'resolveurl.png',
                'resolveurl.png',
                isFolder=False,
            )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.RESOLVEURL_SETTINGS, 'openResolveUrlSettings'),
            'openResolveUrlSettings', 'resolveurl.png', 'resolveurl.png', isFolder=False,
        )
        self.endDirectory()

    def navUploadLogs(self):
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.UPLOAD_KODI_LOG, 'uploadKodiLog'),
            'uploadKodiLog', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.UPLOAD_CREW_LOG, 'uploadCrewLog'),
            'uploadCrewLog', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )
        self.endDirectory()

    def navViews(self):
        '''Pick content type, then open a folder route to save the view (handle -1 on is_folder=False).'''
        from ..modules import control

        try:
            control.idle()
            items = (
                (L.VIEW_MOVIES, 'movies'),
                (L.VIEW_TVSHOWS, 'tvshows'),
                (L.VIEW_SEASONS, 'seasons'),
                (L.VIEW_EPISODES, 'episodes'),
            )
            select = control.selectDialog(
                [L.plain_text(label_id) for label_id, _content in items],
                L.plain_text(L.VIEWTYPES_HEADING),
            )
            if select == -1:
                return

            content = items[select][1]
            plugin_url = f'{sysaddon}?action=viewsSaveMenu&content={content}'
            c.log(f'[Navigator] views -> viewsSaveMenu content={content}', 1)
            control.execute(f'ActivateWindow(Videos,{plugin_url},return)')
        except Exception as e:
            c.log(f'[Navigator] views error: {e}')
            c.log(traceback.format_exc())
        finally:
            control.finish_dialog_route()

    def navViewsSaveMenu(self, content):
        from ..kodi import views

        try:
            content = (content or '').strip().lower()
            if content not in ('movies', 'tvshows', 'seasons', 'episodes'):
                c.log('[Navigator] views_save_menu: missing content param', 1)
                self.endDirectory(cacheToDisc=False)
                return

            title = L.plain_text(L.SAVE_VIEW) or 'CLICK HERE TO SAVE VIEW'
            url = f'{sysaddon}?action=addView&content={content}'

            poster = c.addon_poster()
            banner = c.addon_banner()
            fanart = c.addon_fanart() or c.fanart or ''
            item = kodi.item(label=title)
            item.setArt({
                'icon': poster,
                'thumb': poster,
                'poster': poster,
                'banner': banner,
                'fanart': fanart,
            })
            if fanart:
                item.setProperty('fanart', fanart)

            kodi.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
            kodi.content(syshandle, content)
            kodi.directory(syshandle, cacheToDisc=True)
            views.apply_view(content, {})
        except Exception as e:
            c.log(f'[Navigator] views_save_menu error: {e}')
            c.log(traceback.format_exc())
            self.endDirectory(cacheToDisc=False)

    def navLibrary(self):
        render_menu(self, 'library')


    def navMovies(self):
        render_menu(self, 'movies')

    def navMovieDiscover(self):
        '''Legacy alias  -  same presets as movies menu (discover rows).'''
        render_menu(self, 'movies')

    def navTVShows(self):
        render_menu(self, 'tvshows')

    def navTVDiscover(self):
        '''Legacy alias  -  same presets as tvshows menu (discovery rows).'''
        render_menu(self, 'tvshows')

    def mymovies(self, lite=False):
        self._lite_mode = lite
        render_menu(self, 'mymovies')

    def mytvshows(self, lite=False):
        self._lite_mode = lite
        render_menu(self, 'mytvshows')

    def navTVProgress(self):
        '''Legacy route  -  same rows as My TV Shows submenu.'''
        self.mytvshows(lite=True)

    def navDevs(self):
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.COPY_OS_CREDS, 'copyOsCreds'),
            'copyOsCreds', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.ASCII_CHECK, 'checkUserAscii'),
            'checkUserAscii', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )
        self.addDirectoryItem(
            menu_actions.format_menu_label(L.ASCII_FIX, 'fixUserAscii'),
            'fixUserAscii', 'tools.png', 'DefaultAddonProgram.png', isFolder=False,
        )
        self.addDirectoryItem('Test Threads', 'test1', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('Client + CDN test', 'test2', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('APIs smoke test', 'test3', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('Trakt smoke test', 'test4', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('Metadata smoke test', 'test6', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('Progress slots test', 'test7', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('Search smoke test', 'testSearch', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('VideoLibrary probe', 'testVideoLibrary', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('XML Lists', 'navDevLists', 'main_classy.png', 'main_classy.png')

        self.endDirectory()

    def navDevLists(self):
        '''Dev-only  -  probe + sample remote list feeds.'''
        self.addDirectoryItem('Lists bridge probe', 'test8', 'main_classy.png', 'main_classy.png', isFolder=False)
        self.addDirectoryItem('White test streams', 'testWhiteStreams', 'main_whitehat.png', 'main_whitehat.png')
        self.addDirectoryItem('Classy', 'classy', 'main_classy.png', 'main_classy.png')
        self.addDirectoryItem('NBA', 'nba', 'main_bluehat.png', 'main_bluehat.png')
        self.addDirectoryItem('Greenhat', 'greenhat', 'main_greenhat.png', 'main_greenhat.png')
        self.addDirectoryItem('Purplehat', 'purplehat', 'main_purplehat.png', 'main_purplehat.png')
        self.endDirectory()

    def traktMovies(self):
        self.navMovieDiscover()

    def traktTVShows(self):
        self.navTVDiscover()


    def addDirectoryItem(
        self, name, query, thumb, icon, fanart=None, isFolder=True, isAction=True,
        infolabels=None, context=None, context_menu=None, queue=False,
    ):
        try:
            if isinstance(name, int):
                name = c.lang(name)
            elif isinstance(name, L.NavLabel):
                name = L.display_label(name)

            url = f'{sysaddon}?action={query}' if isAction is True else query

            if isinstance(thumb, str) and thumb.startswith(('http://', 'https://', 'resource://', 'special://')):
                if thumb.startswith('special://'):
                    try:
                        import xbmcvfs
                        thumb = xbmcvfs.translatePath(thumb)
                    except Exception:
                        pass
            elif c.get_art_path() and thumb:
                thumb = os.path.join(c.get_art_path(), thumb)
            else:
                thumb = icon
            if fanart is None:
                fanart = c.addon_fanart() or c.fanart or ''

            if infolabels is None:
                infolabels = {}

            cm = []
            if queue:
                cm.append(('Queue', f'RunPlugin({sysaddon}?action=queueItem)'))

            if context is not None:
                if isinstance(context, list):
                    cm.extend(context)
                else:
                    cm.append((c.lang(context[0]), f'RunPlugin({sysaddon}?action={context[1]})'))

            if context_menu:
                cm.extend(context_menu)

            # List row: themed icon/thumb. Right-panel poster slot is portrait (~2:3) in
            # Aeon - feeding square/wide logos there stretches them (WeTrakr etc.). Use the
            # addon poster for Art(poster); keep the menu PNG on icon/thumb only.
            item = kodi.item(label=name)
            item.addContextMenuItems(cm)
            poster = c.addon_poster() or thumb
            item.setArt({
                'icon': thumb,
                'thumb': thumb,
                'poster': poster,
                'fanart': fanart,
            })
            if fanart:
                item.setProperty('fanart', fanart)

            kodi.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 112 in navigator.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 112 in navigator.py]Exception raised. Error = {e}')
            pass


    def endDirectory(self, cacheToDisc=True) -> None:
        try:
            kodi.content(addon_handle, 'addons')
            kodi.directory(syshandle, cacheToDisc)

        except Exception as e:
            import traceback
            failure = traceback.format_exc()
            c.log(f'[CM Debug @ 124 in navigator.py]Traceback:: {failure}')
            c.log(f'[CM Debug @ 124 in navigator.py]Exception raised. Error = {e}')
            pass



n = navigator()

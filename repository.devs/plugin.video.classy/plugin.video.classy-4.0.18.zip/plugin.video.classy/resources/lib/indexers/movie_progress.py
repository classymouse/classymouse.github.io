# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_progress.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Continue Watching  -  tracker playback movies  ->  resume rows  ->  directory.'''

from .. import tracker
from ..kodi import listing
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..modules.classy import c
from ..play.url import play_url
from ..progress import slots as progress_slots


def directory(handle, params):
    ctx = listing.listing_context()
    page = listing.parse_page(params, ctx)

    if not tracker.live():
        c.log(f'[MovieProgress] {tracker.display_label()} auth required', 1)
        listing.emit_empty(
            handle,
            f'Authorize {tracker.display_label()} to see continue watching',
            'movies',
            ctx,
        )
        return

    c.log(f'[MovieProgress] page={page} widget={ctx.is_widget}')
    page_slots, total, _fp, unchanged, filtered = progress_slots.in_progress_movie_slots(
        page=page,
        limit=ctx.page_size,
        log_label='movie_progress',
    )
    c.log(
        f'[MovieProgress] page {page}  ->  {len(page_slots)} of {total} '
        f'(unchanged={unchanged}, filtered={filtered})'
    )

    if not page_slots and page == 1:
        listing.emit_empty(handle, 'No movies in progress', 'movies', ctx, cache=True)
        return

    rows = [progress_slots.slot_to_movie_resume_row(slot) for slot in page_slots]
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)

    next_url, next_label = listing.pagination_next(
        'movieProgress', page, total, ctx, page_size=ctx.page_size,
    )
    listing.add_next_page(handle, next_url, next_label, ctx)
    listing.finish_directory(handle, 'movies', ctx, cache=True)

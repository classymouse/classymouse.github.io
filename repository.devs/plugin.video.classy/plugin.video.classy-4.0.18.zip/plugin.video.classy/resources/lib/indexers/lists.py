# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Crew-compatible lists indexer shim for CDN $pyFunction blocks.

Remote regex payloads call:
    from resources.lib.indexers import lists
    lists.indexer().get(url)'''

import sys

from ..lists.bridge import install_lists_ecosystem_shims
from ..lists.directory import show_directory
from ..lists.fetch import fetch_list
from ..lists.parse import parse_list
from ..modules.classy import c


class Indexer:
    '''Minimal Crew Indexer  -  fetch remote list/XML and render directory.'''

    def get(self, url):
        install_lists_ecosystem_shims()
        handle = int(sys.argv[1])
        text = str(url or '').strip()
        if not text:
            c.log('[Lists shim] indexer.get() empty url', 1)
            show_directory(handle, [])
            return []

        raw = fetch_list(text)
        if not raw:
            c.log(f'[Lists shim] indexer.get() fetch empty url={text[:80]}', 1)
            show_directory(handle, [])
            return []

        items, _regex = parse_list(raw, source_url=text[:80])
        c.log(f'[Lists shim] indexer.get() items={len(items)} url={text[:80]}')
        show_directory(handle, items)
        return items


def indexer():
    return Indexer()

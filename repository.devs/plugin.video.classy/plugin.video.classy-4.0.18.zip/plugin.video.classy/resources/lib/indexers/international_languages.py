# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file international_languages.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Crew International menus  -  display name + ISO 639-1 for with_original_language.'''

# script.module.thecrew tvshows.languages()
TV_LANGUAGES = (
    ('Arabic', 'ar'),
    ('Bosnian', 'bs'),
    ('Bulgarian', 'bg'),
    ('Chinese', 'zh'),
    ('Croatian', 'hr'),
    ('Dutch', 'nl'),
    ('English', 'en'),
    ('Finnish', 'fi'),
    ('French', 'fr'),
    ('German', 'de'),
    ('Greek', 'el'),
    ('Hebrew', 'he'),
    ('Hindi', 'hi'),
    ('Hungarian', 'hu'),
    ('Icelandic', 'is'),
    ('Italian', 'it'),
    ('Japanese', 'ja'),
    ('Korean', 'ko'),
    ('Norwegian', 'no'),
    ('Persian', 'fa'),
    ('Polish', 'pl'),
    ('Portuguese', 'pt'),
    ('Punjabi', 'pa'),
    ('Romanian', 'ro'),
    ('Russian', 'ru'),
    ('Serbian', 'sr'),
    ('Spanish', 'es'),
    ('Swedish', 'sv'),
    ('Turkish', 'tr'),
    ('Ukrainian', 'uk'),
)

# script.module.thecrew movies.languages()
MOVIE_LANGUAGES = (
    ('Arabic', 'ar'),
    ('Bosnian', 'bs'),
    ('Bulgarian', 'bg'),
    ('Chinese', 'zh'),
    ('Croatian', 'hr'),
    ('Dutch', 'nl'),
    ('English', 'en'),
    ('Finnish', 'fi'),
    ('French', 'fr'),
    ('German', 'de'),
    ('Greek', 'el'),
    ('Hebrew', 'he'),
    ('Hindi', 'hi'),
    ('Hungarian', 'hu'),
    ('Icelandic', 'is'),
    ('Italian', 'it'),
    ('Japanese', 'ja'),
    ('Korean', 'ko'),
    ('Macedonian', 'mk'),
    ('Norwegian', 'no'),
    ('Persian', 'fa'),
    ('Polish', 'pl'),
    ('Portuguese', 'pt'),
    ('Punjabi', 'pa'),
    ('Romanian', 'ro'),
    ('Russian', 'ru'),
    ('Serbian', 'sr'),
    ('Slovenian', 'sl'),
    ('Spanish', 'es'),
    ('Swedish', 'sv'),
    ('Turkish', 'tr'),
    ('Ukrainian', 'uk'),
)

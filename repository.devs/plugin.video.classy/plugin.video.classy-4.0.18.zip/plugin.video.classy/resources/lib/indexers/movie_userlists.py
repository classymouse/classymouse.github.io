# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_userlists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

My Movies  ->  Movie Lists  -  personal Trakt list folders.'''

from ..modules import kodi
from ..modules.classy import c
from ..trakt import auth
from ..trakt import user_lists as trakt_user_lists
from .navigator import n


def directory(handle, _params):
    if not auth.has_credentials():
        c.log('[MovieUserlists] Trakt auth required', 1)
        li = kodi.item(label='Authorize Trakt to see your lists')
        poster = c.addon_poster()
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)
        kodi.content(handle, 'movies')
        kodi.directory(handle, cacheToDisc=False)
        return

    entries = trakt_user_lists.fetch_index()
    if not entries:
        li = kodi.item(label='No Trakt lists found')
        poster = c.addon_poster()
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)
        kodi.content(handle, 'movies')
        kodi.directory(handle, cacheToDisc=True)
        return

    for entry in entries:
        items_url = entry.get('items_url') or ''
        if not items_url:
            continue
        action = f'movies&url={items_url}'
        n.addDirectoryItem(
            entry['name'],
            action,
            'userlists.png',
            'DefaultMovies.png',
            queue=True,
        )

    kodi.content(handle, 'movies')
    kodi.directory(handle, cacheToDisc=True)

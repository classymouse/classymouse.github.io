# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file menu_format.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Navigator label markup  -  plain text in PO, formatting applied here only.'''

import re

_ORCHID = 'orchid'
_WHITE = 'white'
_GRAY = 'gray'
_COIN = '\u00a4'  # currency sign  -  orchid flank marker (Crew day-one)
_BBCODE = re.compile(r'\[/?[^\]]+\]', re.IGNORECASE)


def _plain(title):
    return str(title or '').strip()


def _auth_action(title):
    '''PO should be plain Authorize; strip leftover markup / brand prefix if present.'''
    text = _BBCODE.sub('', _plain(title))
    if ':' in text:
        text = text.split(':')[-1]
    return text.strip() or 'Authorize'


def menu_item(title):
    text = _plain(title)
    return (
        f'[COLOR {_ORCHID}]{_COIN}[/COLOR] [B][COLOR {_WHITE}]{text}[/COLOR][/B] '
        f'[COLOR {_ORCHID}]{_COIN}[/COLOR]'
    )


def menu_section(title):
    text = _plain(title)
    return f'[COLOR {_GRAY}][B]{text}[/B][/COLOR]'


def menu_hint(title):
    text = _plain(title)
    return f'[COLOR {_GRAY}]{text}[/COLOR]'


def menu_developers(title):
    text = _plain(title)
    return f'[COLOR {_ORCHID}]{_COIN}[/COLOR] [B][COLOR orange]{text}[/COLOR][/B]'


def menu_trakt_auth(title):
    text = _auth_action(title)
    return f'[B][COLOR crimson]TRAKT[/COLOR][/B] : [COLOR {_WHITE}]{text}[/COLOR]'


def menu_simkl_auth(title):
    text = _auth_action(title)
    return f'[B][COLOR lightskyblue]SIMKL[/COLOR][/B] : [COLOR {_WHITE}]{text}[/COLOR]'


def menu_wetrakr_auth(title):
    text = _auth_action(title)
    return f'[B][COLOR yellow]WETRAKR[/COLOR][/B] : [COLOR {_WHITE}]{text}[/COLOR]'


def menu_resolveurl_settings(title):
    text = str(title or '').strip()
    return f'[COLOR lightblue]ResolveUrl[/COLOR][B][COLOR {_WHITE}]: {text}[/COLOR][/B]'


def menu_cal_theatrical_week(title):
    text = str(title or '').strip()
    return f'[B][COLOR cyan]{text}[/COLOR][/B]'


def menu_cal_theatrical_month(title):
    text = str(title or '').strip()
    return f'[B][COLOR lime]{text}[/COLOR][/B]'


def menu_cal_dvd(title):
    return str(title or '').strip()


def menu_plain(title):
    '''PO string already includes markup (Tools cache rows, etc.).'''
    return str(title or '').strip()


_FORMATTERS = {
    'item': menu_item,
    'section': menu_section,
    'hint': menu_hint,
    'plain': menu_plain,
    'developers': menu_developers,
    'trakt_auth': menu_trakt_auth,
    'simkl_auth': menu_simkl_auth,
    'wetrakr_auth': menu_wetrakr_auth,
    'resolveurl_settings': menu_resolveurl_settings,
    'cal_theatrical_week': menu_cal_theatrical_week,
    'cal_theatrical_month': menu_cal_theatrical_month,
    'cal_dvd': menu_cal_dvd,
}


def format_label(style, title):
    fn = _FORMATTERS.get(style or 'item', menu_item)
    return fn(title)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file genre_posters.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Genre picker art  -  same posters the skin shows on focus when content=genres.

Aeon Nox (and similar) map ListItem label  ->  extras/moviegenres/*.jpg for the
info panel. We reuse that file for icon/thumb/poster so the list matches hover.
Fallback: addon genres.png. Not the first discover movie poster.'''

from __future__ import annotations

import os

FALLBACK_THUMB = 'genres.png'

_SKIN_SUBDIRS = (
    'extras/moviegenres/default',
    'extras/moviegenres/colored',
    'extras/moviegenres/coloured',
    'extras/moviegenres',
)

_RESOURCE_ADDONS = (
    'resource.images.moviegenreicons.poster',
    'resource.images.moviegenreicons.coloured',
    'resource.images.moviegenreicons.colored',
    'resource.images.moviegenreicons.xzener',
    'resource.images.moviegenreicons.filmstrip',
)

_NAME_ALIASES = {
    'Action & Adventure': ('Action & Adventure', 'Action and Adventure', 'Action'),
    'Sci-Fi & Fantasy': ('Sci-Fi & Fantasy', 'Sci-Fi', 'Science Fiction'),
    'Science Fiction': ('Science Fiction', 'Science-Fiction', 'Sci-Fi'),
    'War & Politics': ('War & Politics', 'War'),
}


def _xbmcvfs():
    try:
        import xbmcvfs
        return xbmcvfs
    except Exception:
        return None


def _translate(path):
    vfs = _xbmcvfs()
    if not vfs:
        return path
    try:
        return vfs.translatePath(path)
    except Exception:
        try:
            import xbmc
            return xbmc.translatePath(path)
        except Exception:
            return path


def _exists(path):
    if not path:
        return False
    vfs = _xbmcvfs()
    if vfs:
        try:
            return bool(vfs.exists(path))
        except Exception:
            pass
    return os.path.isfile(path)


def _art_candidates(art_name):
    names = _NAME_ALIASES.get(art_name, (art_name,))
    for name in names:
        yield name
        # some packs use lowercase stems
        lower = name.lower()
        if lower != name:
            yield lower


def _skin_genre_path(art_name):
    skin_root = _translate('special://skin/')
    if not skin_root:
        return ''
    for sub in _SKIN_SUBDIRS:
        folder = os.path.join(skin_root, sub.replace('/', os.sep))
        for name in _art_candidates(art_name):
            for ext in ('.jpg', '.png', '.jpeg', '.JPG', '.PNG'):
                path = os.path.join(folder, name + ext)
                if _exists(path):
                    return path
    return ''


def _resource_genre_path(art_name):
    '''resource:// URLs work with XBT packs; also try unpacked files.'''
    try:
        import xbmcaddon
    except Exception:
        return ''

    for addon_id in _RESOURCE_ADDONS:
        try:
            base = xbmcaddon.Addon(addon_id).getAddonInfo('path')
        except Exception:
            continue
        for name in _art_candidates(art_name):
            for ext in ('.jpg', '.png', '.jpeg'):
                for candidate in (
                    os.path.join(base, name + ext),
                    os.path.join(base, 'resources', name + ext),
                ):
                    if _exists(candidate):
                        return candidate
                # XBT-backed pack: let Kodi resolve via resource://
                return f'resource://{addon_id}/{name}{ext}'
    return ''


def genre_thumb(art_name):
    '''Absolute path, resource:// URI, or FALLBACK_THUMB.'''
    name = str(art_name or '').strip()
    if not name:
        return FALLBACK_THUMB
    path = _skin_genre_path(name)
    if path:
        return path
    path = _resource_genre_path(name)
    if path:
        return path
    return FALLBACK_THUMB


def resolve_thumbs(art_names):
    '''art_name  ->  thumb path/uri (or genres.png).'''
    return {name: genre_thumb(name) for name in art_names}

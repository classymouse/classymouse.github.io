# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file adult.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Adult section indexer  -  generic controller over provider plugins.'''

import sys
import traceback
from urllib.parse import quote_plus

import xbmc
import xbmcgui
import xbmcplugin

from ..modules import control
from ..modules.classy import c
from ..plugins.adult.base import ClassyAdultProvider
from ..plugins import adult as adult_plugins  # noqa: F401  -  register providers


class Adult:
    def __init__(self):
        self.icon = c.addon_adult_icon()
        self.fanart = c.addon_fanart()

    def root(self):
        try:
            providers = ClassyAdultProvider.get_all_providers()
            sysaddon = sys.argv[0]
            handle = int(sys.argv[1])
            items = []

            for site in providers:
                if site.name == 'redtube':
                    url = f'{sysaddon}?action=adult_search&site={site.name}'
                else:
                    url = f'{sysaddon}?action=adult_site_handler&site={site.name}'
                items.append((site.title, url, site.icon, site.fanart, True))

            if not items:
                c.log('[Adult] No providers registered')

            self._add_directory(handle, items)
        except Exception as exc:
            c.log(f'[Adult] root error: {exc}', 1)
            c.log(traceback.format_exc(), 1)

    def site_handler(self, site_name):
        try:
            site = ClassyAdultProvider.get_provider(site_name)
            if not site:
                c.log(f'[Adult] site not found: {site_name}', 1)
                self._fail_directory(int(sys.argv[1]), 'Site not found')
                return

            sysaddon = sys.argv[0]
            handle = int(sys.argv[1])
            items = []
            categories = site.get_categories()

            if site_name == 'redtube':
                items.append(('** Search **', f'{sysaddon}?action=adult_search&site={site_name}', site.icon, site.fanart, True))

            for cat_url, cat_name, cat_thumb in categories:
                url = f'{sysaddon}?action=adult_videos&site={site_name}&url={quote_plus(cat_url)}'
                items.append((cat_name, url, cat_thumb or site.icon, site.fanart, True))

            if not categories and site_name != 'redtube':
                fallback_url = getattr(site, 'base_url', None)
                return self.videos(site_name, url=fallback_url)

            self._add_directory(handle, items)
        except Exception as exc:
            c.log(f'[Adult] site_handler error: {exc}', 1)
            c.log(traceback.format_exc(), 1)
            self._fail_directory(int(sys.argv[1]), f'Site error: {exc}')

    def videos(self, site_name, url=None, page='1'):
        try:
            site = ClassyAdultProvider.get_provider(site_name)
            if not site:
                return

            page_num = int(page or 1)
            videos = site.get_videos(url=url, page=page_num)
            sysaddon = sys.argv[0]
            handle = int(sys.argv[1])
            items = []

            for video_url, title, thumbnail in videos:
                if video_url == 'NEXT_PAGE':
                    if url:
                        next_url = (
                            f'{sysaddon}?action=adult_videos&site={site_name}'
                            f'&url={quote_plus(url)}&page={page_num + 1}'
                        )
                    else:
                        next_url = f'{sysaddon}?action=adult_videos&site={site_name}&page={page_num + 1}'
                    items.append((f'[COLOR orange]{title}[/COLOR]', next_url, c.addon_next(), site.fanart, True))
                else:
                    play_url = f'{sysaddon}?action=adult_play&site={site_name}&url={quote_plus(video_url)}'
                    items.append((title, play_url, thumbnail or site.icon, site.fanart, False))

            self._add_directory(handle, items)
        except Exception as exc:
            c.log(f'[Adult] videos error: {exc}', 1)
            c.log(traceback.format_exc(), 1)
            self._fail_directory(int(sys.argv[1]), f'Could not load videos: {exc}')

    def search(self, site_name):
        try:
            site = ClassyAdultProvider.get_provider(site_name)
            if not site:
                return

            keyboard = xbmc.Keyboard('', site.title)
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return

            keyword = keyboard.getText()
            if not keyword:
                return

            results = site.search(keyword)
            sysaddon = sys.argv[0]
            handle = int(sys.argv[1])
            items = []
            for video_url, title, thumbnail in results:
                play_url = f'{sysaddon}?action=adult_play&site={site_name}&url={quote_plus(video_url)}'
                items.append((title, play_url, thumbnail or site.icon, site.fanart, False))

            self._add_directory(handle, items)
        except Exception as exc:
            c.log(f'[Adult] search error: {exc}', 1)

    def play(self, site_name, video_url):
        try:
            site = ClassyAdultProvider.get_provider(site_name)
            if not site:
                control.infoDialog('Site not found', icon='ERROR')
                return

            playable_url = site.resolve(video_url)
            if not playable_url:
                control.infoDialog('Could not resolve video', icon='ERROR')
                return

            xbmc.Player().play(playable_url)
        except Exception as exc:
            c.log(f'[Adult] play error: {exc}', 1)
            control.infoDialog(f'Playback error: {exc}', icon='ERROR')

    def _fail_directory(self, handle, message):
        c.log(f'[Adult] {message}', 1)
        try:
            item = xbmcgui.ListItem(label=f'[COLOR red]{message}[/COLOR]')
            item.setArt({'icon': self.icon, 'thumb': self.icon, 'fanart': self.fanart})
            xbmcplugin.addDirectoryItem(handle, '', item, isFolder=False)
        except Exception:
            pass
        xbmcplugin.endOfDirectory(handle, succeeded=False)

    def _add_directory(self, handle, items):
        if not items:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        for name, url, icon, fanart, is_folder in items:
            item = xbmcgui.ListItem(label=name)
            item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': fanart or self.fanart})
            xbmcplugin.addDirectoryItem(handle, url, item, isFolder=is_folder)

        xbmcplugin.setContent(handle, 'addons')
        xbmcplugin.endOfDirectory(handle)

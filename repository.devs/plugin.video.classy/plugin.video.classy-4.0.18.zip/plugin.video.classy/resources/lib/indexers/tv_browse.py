# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_browse.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Season + episode directories  -  TMDB list + WatchIndex overlays.'''

import sys
from urllib.parse import urlencode

from ..apis import tmdb as tmdb_api
from ..kodi import listing
from ..metadata import extract
from ..metadata.enrich import NEEDS_PROGRESS, NEED_THUMB, apply_tmdb_show, enrich_batch
from ..metadata.video_row import VideoRow

from ..modules.classy import c
from ..modules.unaired import is_unaired, show_unaired_enabled
from ..play.url import play_url
from ..trakt.browse_context import TVBrowseContext


def _parse_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _show_params(params):
    params = params or {}
    return {
        'tmdb': str(params.get('tmdb') or '').strip(),
        'imdb': str(params.get('imdb') or '').strip(),
        'tvdb': str(params.get('tvdb') or '').strip(),
        'tvshowtitle': str(params.get('tvshowtitle') or '').strip(),
    }


def _season_row(show_ids, tvshowtitle, season_json, *, show_fanart='', show_status=''):
    sn = _parse_int(season_json.get('season_number'))
    name = (season_json.get('name') or '').strip() or f'Season {sn}'
    premiered = (season_json.get('air_date') or '')[:10]
    row = VideoRow(
        mediatype='season',
        title=name,
        tvshowtitle=tvshowtitle,
        season=sn,
        status=show_status,
        plot=(season_json.get('overview') or '').strip(),
        premiered=premiered,
        year=premiered[:4] if premiered else '',
        tmdb=show_ids['tmdb'],
        imdb=show_ids['imdb'],
        tvdb=show_ids['tvdb'],
        fanart=show_fanart,
    )
    if season_json.get('poster_path'):
        row.tmdb_poster_path = season_json['poster_path']
        row.poster = extract.poster_url(season_json['poster_path'])
    return row, _parse_int(season_json.get('episode_count'))


def _episode_row(show_ids, tvshowtitle, season, episode_json, *, show_status=''):
    en = _parse_int(episode_json.get('episode_number'))
    runtime_min = _parse_int(episode_json.get('runtime'))
    premiered = (episode_json.get('air_date') or '')[:10]
    row = VideoRow(
        mediatype='episode',
        title=(episode_json.get('name') or '').strip() or f'Episode {en}',
        tvshowtitle=tvshowtitle,
        season=season,
        episode=en,
        status=show_status,
        plot=(episode_json.get('overview') or '').strip(),
        premiered=premiered,
        year=premiered[:4] if premiered else '',
        tmdb=show_ids['tmdb'],
        imdb=show_ids['imdb'],
        tvdb=show_ids['tvdb'],
        duration=runtime_min * 60 if runtime_min > 0 else 0,
        rating=extract.rating_from_tmdb(episode_json.get('vote_average')),
        votes=extract.votes_from_tmdb(episode_json.get('vote_count')),
    )
    if episode_json.get('still_path'):
        row.tmdb_still_path = episode_json['still_path']
        row.thumb = extract.still_url(episode_json['still_path'])
    return row



def _episodes_url(show_ids, season):
    query = urlencode({
        'action': 'episodes',
        'tmdb': show_ids['tmdb'],
        'tvdb': show_ids['tvdb'],
        'imdb': show_ids['imdb'],
        'tvshowtitle': show_ids['tvshowtitle'],
        'season': season,
    })
    return f'{sys.argv[0]}?{query}'


def seasons_directory(handle, params):
    '''Show  ->  seasons  -  watch overlay per season (complete vs partial).'''
    ctx = listing.listing_context()
    show_ids = _show_params(params)
    tmdb_id = show_ids['tmdb']
    if not tmdb_id:
        c.log('[TV] seasons: missing tmdb', 1)
        listing.emit_empty(handle, 'Missing show id', 'seasons', ctx, cache=False)
        return

    c.log(f'[TV] seasons tmdb={tmdb_id} title={show_ids["tvshowtitle"]!r} widget={ctx.is_widget}')
    browse_ctx = TVBrowseContext.load(log_label='seasons')

    # One show detail (+ credits/videos) for the whole season list  -  BASE + APPEND on Info.
    show = tmdb_api.get_tv(tmdb_id, append='credits,videos')
    if not isinstance(show, dict):
        c.log(f'[TV] seasons: TMDB show missing tmdb={tmdb_id}', 1)
        listing.emit_empty(handle, 'Show not found', 'seasons', ctx, cache=False)
        return

    tvshowtitle = show_ids['tvshowtitle'] or (show.get('name') or '').strip()
    show_ids['tvshowtitle'] = tvshowtitle
    show_fanart = extract.fanart_url(show.get('backdrop_path'))
    show_status = (show.get('status') or '').strip()

    seasons = show.get('seasons') or []
    rows = []
    episode_counts = []
    for season_json in sorted(seasons, key=lambda s: _parse_int(s.get('season_number'))):
        if not isinstance(season_json, dict):
            continue
        sn = _parse_int(season_json.get('season_number'))
        ep_count = _parse_int(season_json.get('episode_count'))
        if sn < 0 or ep_count <= 0:
            continue
        row, ep_count = _season_row(
            show_ids, tvshowtitle, season_json,
            show_fanart=show_fanart, show_status=show_status,
        )
        # Stamp show BASE + APPEND onto season Info (JSON already in hand).
        apply_tmdb_show(row, show, episode_context=False)
        if is_unaired(row) and not show_unaired_enabled():
            continue
        state = browse_ctx.apply_watch(row, season_episode_count=ep_count)
        if c.is_devmode():
            c.log(
                f'[Watch] season {tvshowtitle!r} S{sn:02d} '
                f'playcount={row.playcount} watched={state.watched_count}/{ep_count}'
            )
        rows.append(row)
        episode_counts.append(ep_count)

    rows = listing.slice_rows(rows, ctx)
    if not rows:
        listing.emit_empty(handle, 'No seasons', 'seasons', ctx, cache=False)
        return

    def _folder_url(row):
        return _episodes_url(show_ids, row.season)

    listing.emit_video_rows(handle, rows, _folder_url, ctx, is_folder=True)
    listing.finish_directory(handle, 'seasons', ctx, cache=True)


def episodes_directory(handle, params):
    '''Season  ->  episodes  -  watch overlay per episode.'''
    ctx = listing.listing_context()
    show_ids = _show_params(params)
    tmdb_id = show_ids['tmdb']
    season = _parse_int(params.get('season'))
    if not tmdb_id or season <= 0:
        c.log('[TV] episodes: missing tmdb or season', 1)
        listing.emit_empty(handle, 'Missing show or season', 'episodes', ctx, cache=False)
        return

    c.log(
        f'[TV] episodes tmdb={tmdb_id} S{season:02d} '
        f'title={show_ids["tvshowtitle"]!r} widget={ctx.is_widget}'
    )
    browse_ctx = TVBrowseContext.load(log_label='episodes')

    season_data = tmdb_api.get_tv_season(tmdb_id, season)
    if not isinstance(season_data, dict):
        c.log(f'[TV] episodes: TMDB season missing tmdb={tmdb_id} S{season}', 1)
        listing.emit_empty(handle, 'Season not found', 'episodes', ctx, cache=False)
        return

    tvshowtitle = show_ids['tvshowtitle'] or (season_data.get('name') or '').strip()
    if not show_ids['tvshowtitle']:
        show_ids['tvshowtitle'] = tvshowtitle

    show_status = ''
    show = tmdb_api.get_tv(tmdb_id, append='credits,videos')
    if isinstance(show, dict):
        show_status = (show.get('status') or '').strip()

    rows = []
    for episode_json in season_data.get('episodes') or []:
        if not isinstance(episode_json, dict):
            continue
        en = _parse_int(episode_json.get('episode_number'))
        if en <= 0:
            continue
        row = _episode_row(show_ids, tvshowtitle, season, episode_json, show_status=show_status)
        # Show BASE (genre/studio) from JSON already fetched; enrich fills episode gaps.
        if isinstance(show, dict):
            apply_tmdb_show(row, show, episode_context=True)
        if is_unaired(row) and not show_unaired_enabled():
            continue
        state = browse_ctx.apply_watch(row)
        if c.is_devmode():
            c.log(
                f'[Watch] episode {tvshowtitle!r} S{season:02d}E{en:02d} '
                f'playcount={row.playcount} overlay={row.overlay} '
                f'resume={row.resume_point:.0f}% watched={state.watched}'
            )
        rows.append(row)

    rows = listing.slice_rows(rows, ctx)
    if not rows:
        listing.emit_empty(handle, 'No episodes', 'episodes', ctx, cache=False)
        return

    needs = NEEDS_PROGRESS + (NEED_THUMB,)
    enrich_batch(rows, needs=needs, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)
    listing.finish_directory(handle, 'episodes', ctx, cache=True)

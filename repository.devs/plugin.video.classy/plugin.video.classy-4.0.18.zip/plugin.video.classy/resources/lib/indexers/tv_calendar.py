# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_calendar.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

What's On + tracker TV history  -  calendar&url=... episode directories.'''

import time

from .. import tracker
from ..kodi import listing
from ..metadata.enrich import NEEDS_CALENDAR, enrich_batch
from ..modules.classy import c
from ..play.url import play_url
from ..trakt import calendar_lists
from ..trakt.browse_context import TVBrowseContext


def directory(handle, params):
    preset = (params.get('url') or '').strip()
    if not calendar_lists.is_calendar_preset(preset):
        c.log(f'[Calendar] unsupported preset: {preset!r}')
        listing.emit_empty(handle, 'Not implemented yet', 'episodes', listing.listing_context(), cache=False)
        return

    ctx = listing.listing_context()
    config = calendar_lists.preset_config(preset) or {}
    is_history = calendar_lists.is_history_preset(preset)
    personal = is_history or config.get('scope') == 'my'
    if personal and not tracker.live():
        listing.emit_empty(
            handle,
            f'Connect {tracker.display_label()} for personal calendars',
            'episodes',
            ctx,
            cache=False,
        )
        return

    page = listing.parse_page(params, ctx)
    t0 = time.perf_counter()

    if ctx.is_widget:
        rows, total = tracker.calendar_episodes(preset, page=1, widget_limit=ctx.limit)
    else:
        if is_history:
            rows, total = tracker.calendar_episodes(preset, page=page)
        else:
            page_size = ctx.page_size if not config.get('paginate') else 50
            rows, total = tracker.calendar_episodes(preset, page=page, page_size=page_size)

    if not rows and page == 1:
        empty = 'No watch history' if is_history else 'No episodes in this window'
        listing.emit_empty(handle, empty, 'episodes', ctx, cache=False)
        return

    browse_ctx = TVBrowseContext.load(log_label=f'calendar_{preset}', clear_probe=True)
    for row in rows:
        browse_ctx.apply_watch(row)

    enrich_batch(rows, needs=NEEDS_CALENDAR, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)

    if not ctx.is_widget:
        if is_history:
            next_url, next_label = listing.pagination_next(
                'calendar', page, total, ctx,
                page_size=40,
                extra_query={'url': preset},
            )
        elif config.get('paginate'):
            next_url, next_label = listing.pagination_next(
                'calendar', page, total, ctx,
                page_size=50,
                extra_query={'url': preset},
            )
        else:
            next_url, next_label = None, None
        listing.add_next_page(handle, next_url, next_label, ctx)

    listing.finish_directory(handle, 'episodes', ctx, cache=True)
    c.log(f'[Calendar] {preset} page={page} done in {time.perf_counter() - t0:.2f}s ({len(rows)} rows)')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file menu_render.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Render navigator menus from MENUS dict (filter + addDirectoryItem).'''

import inspect

from ..modules.classy import c
from ..modules.adult_gate import is_adult_section_enabled, section_menu_label
from ..lists.registry import url_for_action
from ..kodi import context_menus
from . import menu_actions
from . import menu_labels
from .menus import MENUS

_ADULT_INSERT_BEFORE = frozenset({'toolNavigator', 'searchNavigator'})


def menu_enabled(setting_id, default=True):
    if setting_id and str(setting_id).startswith('navi.'):
        return True
    if not setting_id:
        return default
    value = c.get_setting(setting_id)
    if value is None or value == '':
        return default
    return str(value).lower() != 'false'


def _submenu_has_visible_children(menu_key, navigator=None):
    items = MENUS.get(menu_key) or []
    return any(should_show(row, navigator, _skip_submenu_parent=True) for row in items)


def should_show(item, navigator=None, _skip_submenu_parent=False):
    if item.get('setting') and not menu_enabled(item['setting']):
        return False

    if item.get('requires_feed'):
        action = item.get('action')
        if not action or not url_for_action(action):
            return False

    if not _skip_submenu_parent:
        submenu_key = item.get('submenu_key')
        if submenu_key and not _submenu_has_visible_children(submenu_key, navigator):
            return False

    if item.get('requires_route'):
        action = resolve_action(item, navigator)
        if not action:
            return False
        if not menu_actions.action_is_live(action) and not menu_actions.action_is_planned(action):
            return False

    condition = item.get('condition')
    if not condition:
        return True

    try:
        params = len(inspect.signature(condition).parameters)
        if params > 0:
            return bool(condition(navigator))
        return bool(condition())
    except Exception:
        return False


def resolve_action(item, navigator=None):
    action = item.get('action')
    if not callable(action):
        return action
    try:
        params = len(inspect.signature(action).parameters)
        if params > 0:
            return action(navigator)
        return action()
    except Exception:
        return None


def render_menu(navigator, menu_key):
    '''Load MENUS[menu_key], filter rows, emit Kodi directory listing.'''
    items = MENUS.get(menu_key) or []
    visible = [row for row in items if should_show(row, navigator)]

    if not visible:
        c.log(f'[Navigator] empty menu {menu_key!r}')
        navigator.endDirectory()
        return

    insert_adult = menu_key == 'root' and is_adult_section_enabled()
    adult_inserted = False

    for row in visible:
        action_key = row.get('action')
        if insert_adult and not adult_inserted and action_key in _ADULT_INSERT_BEFORE:
            navigator.addDirectoryItem(
                section_menu_label(),
                'porn_check_pin',
                'main_pinkhat.png',
                'DefaultMovies.png',
            )
            adult_inserted = True

        action = resolve_action(row, navigator)
        if not action:
            continue

        label = menu_actions.format_menu_label(row['label'], action, row.get('label_style'))
        plain = menu_labels.plain_text(row['label'], row.get('label_style'))
        extra_cm = context_menus.build_menu_pin_items(action, label=plain, icon=row['icon'])
        navigator.addDirectoryItem(
            label,
            action,
            row['icon'],
            row.get('icon2', row['icon']),
            isFolder=row.get('is_folder', True),
            isAction=row.get('is_action', True),
            context=row.get('context'),
            context_menu=extra_cm,
            queue=row.get('queue', False),
        )

    if insert_adult and not adult_inserted:
        navigator.addDirectoryItem(
            section_menu_label(),
            'porn_check_pin',
            'main_pinkhat.png',
            'DefaultMovies.png',
        )

    navigator.endDirectory()

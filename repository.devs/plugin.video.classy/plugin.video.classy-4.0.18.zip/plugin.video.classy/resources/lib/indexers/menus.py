# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file menus.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Navigator menu definitions  -  single source of truth per submenu.

Crew parity: action strings match plugin.video.thecrew URLs. Labels use
Crew string IDs (resolved in navigator.addDirectoryItem).'''

from datetime import datetime

from .. import tracker
from ..modules.classy import c
from . import menu_labels as L
from .international_languages import MOVIE_LANGUAGES, TV_LANGUAGES


def _devmode(_nav=None):
    return c.is_devmode()


def _testings_present(_nav=None):
    '''Root Testings row  -  only when profile has testings.xml.'''
    from ..lists.testings import testings_present
    return testings_present()


def _tracker_live(_nav=None):
    return tracker.live()


def _trakt_live(_nav=None):
    '''Trakt-only personal/browse lists (collection, featured, custom lists).'''
    return tracker.is_trakt() and tracker.live()


def _no_tracker(_nav=None):
    return not tracker.live()


def _no_trakt(_nav=None):
    return tracker.is_trakt() and not tracker.live()


def _no_simkl(_nav=None):
    return tracker.is_simkl() and not tracker.live()


def _collection(_nav=None):
    return tracker.live() and tracker.supports_collection()


def _progress(_nav=None):
    return tracker.is_trakt() and tracker.live() and tracker.supports_progress()


def _calendars(_nav=None):
    return tracker.live() and tracker.supports_calendars()


def _watchlist(_nav=None):
    return tracker.is_trakt() and tracker.live() and tracker.supports_watchlist()


def _simkl_live(_nav=None):
    return tracker.is_simkl() and tracker.live()


def _simkl_watchlist(_nav=None):
    return tracker.is_simkl() and tracker.live() and tracker.supports_watchlist()


def _simkl_progress(_nav=None):
    return tracker.is_simkl() and tracker.live() and tracker.supports_progress()


def _no_wetrakr(_nav=None):
    return tracker.is_wetrakr() and not tracker.live()


def _wetrakr_live(_nav=None):
    return tracker.is_wetrakr() and tracker.live()


def _wetrakr_watchlist(_nav=None):
    return tracker.is_wetrakr() and tracker.live() and tracker.supports_watchlist()


def _wetrakr_progress(_nav=None):
    return tracker.is_wetrakr() and tracker.live() and tracker.supports_progress()


def _mdblist_live(_nav=None):
    try:
        from ..mdblist import has_credentials
        return has_credentials()
    except Exception:
        return False


def _not_lite(nav):
    return not getattr(nav, '_lite_mode', False)


def _december_or_dev(_nav=None):
    return _devmode(_nav) or datetime.now().month == 12


def _october_or_dev(_nav=None):
    return _devmode(_nav) or datetime.now().month == 10


def _sport(action, label, icon):
    return {
        'label': label,
        'action': action,
        'icon': icon,
        'icon2': icon,
        'requires_feed': True,
    }


def _feed(action, label, icon, icon2=None, setting=None):
    '''Root menu row  ->  direct list feed (greenhat, purplehat, ...).'''
    row = {
        'label': label,
        'action': action,
        'icon': icon,
        'icon2': icon2 or icon,
        'requires_feed': True,
    }
    if setting:
        row['setting'] = setting
    return row


def _section(label, icon='tvcalendar.png', **extra):
    '''Non-navigating section header inside a submenu.'''
    row = {
        'label': label,
        'action': 'whatsOnSection',
        'icon': icon,
        'icon2': icon,
        'is_folder': False,
        'requires_route': True,
    }
    row.update(extra)
    return row


def _row(label, action, icon, icon2, **extra):
    '''Discovery / list row  -  hidden until action_is_live passes.'''
    row = {
        'label': label,
        'action': action,
        'icon': icon,
        'icon2': icon2,
        'requires_route': True,
    }
    row.update(extra)
    return row


def _submenu(label, action, icon, icon2, submenu_key=None, **extra):
    '''Folder into another MENUS key  -  hidden when submenu has no live rows.'''
    row = {
        'label': label,
        'action': action,
        'icon': icon,
        'icon2': icon2,
        'submenu_key': submenu_key or action,
    }
    row.update(extra)
    return row


def _tv_language_rows():
    '''Crew tvLanguages submenu  -  discover/tv?with_original_language={code}.'''
    return [
        _row(
            name,
            f'tvshows&url=tmdb_language&tid={code}',
            'international2.png',
            'international2.png',
        )
        for name, code in TV_LANGUAGES
    ]


def _movie_language_rows():
    '''Crew movieLanguages submenu  -  discover/movie?with_original_language={code}.'''
    return [
        _row(
            name,
            f'movies&url=tmdb_language&tid={code}',
            'international.png',
            'international.png',
        )
        for name, code in MOVIE_LANGUAGES
    ]


MENUS = {
    'root': [
        {
            'label': L.DEVELOPERS,
            'action': 'developers',
            'icon': 'main_classy.png',
            'icon2': 'main_classy.png',
            'condition': _devmode,
        },
        {
            # Local cheat XML in addon_data  -  not behind adult PIN.
            'label': L.TESTINGS,
            'action': 'testings',
            'icon': 'testings.png',
            'icon2': 'main_classy.png',
            'condition': _testings_present,
        },
        {
            'label': L.MY_CREW,
            'action': 'pinboardNavigator',
            'icon': 'mycrew.png',
            'icon2': 'mycrew.png',
        },
        _submenu(
            L.HALLOWEEN, 'halloweenNavigator', 'halloween.png', 'halloween.png',
            submenu_key='halloween', condition=_october_or_dev,
        ),
        _submenu(
            L.HOLIDAYS, 'holidaysNavigator', 'holidays.png', 'holidays.png',
            submenu_key='holidays', condition=_december_or_dev,
        ),
        {
            'label': L.MOVIES,
            'action': 'movieNavigator',
            'icon': 'main_movies.png',
            'icon2': 'DefaultMovies.png',
            'setting': 'navi.movies',
        },
        {
            'label': L.TVSHOWS,
            'action': 'tvNavigator',
            'icon': 'main_tvshows.png',
            'icon2': 'DefaultTVShows.png',
            'setting': 'navi.tvshows',
        },
        {
            'label': L.SPORTS,
            'action': 'bluehat',
            'icon': 'main_bluehat.png',
            'icon2': 'DefaultMovies.png',
            'setting': 'navi.sports',
        },
        {
            'label': L.KIDS,
            'action': 'kidsNavigator',
            'icon': 'main_greyhat.png',
            'icon2': 'DefaultTVShows.png',
            'setting': 'navi.kids',
        },
        _feed(
            'greenhat',
            L.ONE_CLICKS,
            'main_greenhat.png',
            'DefaultMovies.png',
            setting='navi.1clicks',
        ),
        _feed(
            'purplehat',
            L.CC_COLLECTIONS,
            'main_purplehat.png',
            'DefaultMovies.png',
            setting='navi.purplehat',
        ),
        {
            'label': L.TOOLS,
            'action': 'toolNavigator',
            'icon': 'tools.png',
            'icon2': 'DefaultAddonProgram.png',
        },
        {
            'label': L.SEARCH,
            'action': 'searchNavigator',
            'icon': 'search.png',
            'icon2': 'DefaultFolder.png',
        },
    ],
    # Seasonal root hubs (month-gated; always visible in DEVMODE).
    'halloween': [
        _row(
            L.HALLOWEEN_FUN,
            'movies&url=https://api.trakt.tv/users/istoit/lists/halloween-fun-frights/items',
            'halloween.png', 'halloween.png', queue=True,
        ),
        _row(
            L.HALLOWEEN_LIST,
            'movies&url=https://api.trakt.tv/users/29zombies/lists/halloween/items',
            'halloween.png', 'halloween.png', queue=True,
        ),
        _row(
            L.HALLOWEEN_MOVIES,
            'movies&url=https://api.trakt.tv/users/movistapp/lists/halloween-movies/items',
            'halloween.png', 'halloween.png', queue=True,
        ),
        _row(
            L.POPULAR_HORROR,
            'movies&url=halloween',
            'halloween.png', 'halloween.png', queue=True,
        ),
    ],
    # Crew Christmas Collection on WeTrakr (public lists)  -  one row per section.
    'holidays': [
        _row(
            L.CHRISTMAS_MOVIES,
            'movies&url=wetrakrpubliclist:30242:movie',
            'holidays.png', 'holidays.png', queue=True,
        ),
        _row(
            L.CHRISTMAS_SPECIALS,
            'movies&url=wetrakrpubliclist:30243:movie',
            'holidays.png', 'holidays.png', queue=True,
        ),
        _row(
            L.CHRISTMAS_SERIES,
            'tvshows&url=wetrakrpubliclist:30244:show',
            'holidays.png', 'holidays.png', queue=True,
        ),
        _row(
            L.CHRISTMAS_STAGE,
            'movies&url=wetrakrpubliclist:30245:movie',
            'holidays.png', 'holidays.png', queue=True,
        ),
        _row(
            # Mostly series; one stray movie stays on the WeTrakr list.
            L.CHRISTMAS_DAY_BINGE,
            'tvshows&url=wetrakrpubliclist:30246:show',
            'holidays.png', 'holidays.png', queue=True,
        ),
    ],
    # --- Movies (Crew movieNavigator order) ---------------------------------
    'movies': [
        _submenu(L.MY_MOVIES, 'mymovieliteNavigator', 'mymovies.png', 'DefaultVideoPlaylists.png', submenu_key='mymovies'),
        {
            'label': L.NEW_MOVIES,
            'action': 'movieWidget',
            'icon': 'latest-movies.png',
            'icon2': 'DefaultMovies.png',
            'setting': 'navi.moviewidget',
            'requires_route': True,
        },
        _row(L.IN_THEATERS, 'movies&url=theaters', 'in-theaters.png', 'DefaultMovies.png', setting='navi.movietheaters'),
        _row(L.TRENDING, 'movies&url=trending', 'trending.png', 'DefaultMovies.png', setting='navi.movietrending'),
        _row(L.MOST_POPULAR, 'movies&url=popular', 'most-popular.png', 'DefaultMovies.png', setting='navi.moviepopular'),
        _row(L.LATEST_RELEASES, 'movies&url=tmdb_movie_latest_releases', 'latest-releases.png', 'latest-releases.png', setting='navi.latestrelease'),
        _row(L.PREMIERES, 'movies&url=tmdb_movie_premieres', 'premieres.png', 'premieres.png', setting='navi.premieres'),
        _row(L.DISNEY_PLUS, 'movies&url=tmdb_networks_no_unaired&tid=337', 'disney.png', 'disney.png', setting='navi.disneym'),
        _submenu(L.TRAKT_LISTS, 'traktlist', 'trakt.png', 'DefaultMovies.png', setting='navi.traktlist'),
        _submenu(L.TMDB_LISTS, 'tmdbmovieslist', 'tmdb.png', 'DefaultMovies.png', setting='navi.tvTmdb'),
        _row(L.BOX_OFFICE, 'movies&url=boxoffice', 'box-office.png', 'DefaultMovies.png', setting='navi.movieboxoffice'),
        _row(L.OSCAR_WINNERS, 'movies&url=oscars', 'oscar-winners.png', 'oscar-winners.png', setting='navi.movieoscars'),
        _submenu(L.MOVIE_RELEASES_CALENDAR, 'movies_calendars_menu', 'tvcalendar.png', 'DefaultMovies.png'),
        {
            'label': L.GENRES,
            'action': 'movieGenres',
            'icon': 'genres.png',
            'icon2': 'DefaultMovies.png',
            'setting': 'navi.moviegenre',
            'requires_route': True,
        },
        _submenu(
            L.CERTIFICATES, 'movieCertificates', 'certificates.png', 'certificates.png',
            submenu_key='movie_certificates_menu', setting='navi.movieCertificates',
        ),
        {
            'label': L.YEARS,
            'action': 'movieYears',
            'icon': 'years.png',
            'icon2': 'DefaultMovies.png',
            'setting': 'navi.movieyears',
            'requires_route': True,
        },
        _submenu(
            L.INTERNATIONAL, 'movieLanguages', 'international.png', 'DefaultMovies.png',
            submenu_key='movie_languages_menu', setting='navi.movielanguages',
        ),
        _row(L.MOST_VOTED, 'movies&url=views', 'most-voted.png', 'DefaultMovies.png', setting='navi.movieviews'),
        {
            'label': L.PEOPLE,
            'action': 'moviePersons',
            'icon': 'people.png',
            'icon2': 'DefaultMovies.png',
            'setting': 'navi.moviepersons',
            'requires_route': True,
        },
        {
            'label': L.PEOPLE_SEARCH,
            'action': 'moviePerson',
            'icon': 'people-search.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'requires_route': True,
        },
        {
            'label': L.MOVIE_SEARCH,
            'action': 'movieSearch',
            'icon': 'search.png',
            'icon2': 'DefaultMovies.png',
            'requires_route': True,
        },
        {
            'label': L.ADVANCED_SEARCH,
            'action': 'movieAdvancedSearch',
            'icon': 'search.png',
            'icon2': 'DefaultMovies.png',
            'requires_route': True,
        },
        {
            'label': L.SAVED_FILTERS,
            'action': 'movieSavedFilters',
            'icon': 'saved-filters.png',
            'icon2': 'DefaultMovies.png',
            'requires_route': True,
        },
    ],
    'mymovies': [
        {
            'label': L.TRAKT_AUTHORIZE,
            'action': 'authTrakt',
            'icon': 'trakt.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _no_trakt,
        },
        {
            'label': L.SIMKL_AUTHORIZE,
            'action': 'authSimkl',
            'icon': 'simkl.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _no_simkl,
        },
        _row(L.CONTINUE_WATCHING, 'movieProgress', 'simkl.png', 'DefaultMovies.png', condition=_simkl_progress),
        _row(L.WATCHLIST, 'movies&url=simklwatchlist', 'simkl.png', 'DefaultMovies.png', condition=_simkl_watchlist, queue=True),
        _row(L.HISTORY, 'movies&url=simklhistory', 'simkl.png', 'DefaultMovies.png', condition=_simkl_live, queue=True),
        _row(L.MY_RATINGS, 'movies&url=simklratings', 'simkl.png', 'DefaultMovies.png', condition=_simkl_live, queue=True),
        {
            'label': L.SIMKL_DROPPED,
            'action': 'movies&url=simkldropped',
            'icon': 'simkl.png',
            'icon2': 'DefaultMovies.png',
            'condition': _simkl_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_AUTHORIZE,
            'action': 'authWetrakr',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _no_wetrakr,
        },
        _row(L.CONTINUE_WATCHING, 'movieProgress', 'wetrakr.png', 'DefaultMovies.png', condition=_wetrakr_progress),
        _row(L.WATCHLIST, 'movies&url=wetrakrwatchlist', 'wetrakr.png', 'DefaultMovies.png', condition=_wetrakr_watchlist, queue=True),
        {
            'label': L.WETRAKR_PLAYING,
            'action': 'movies&url=wetrakrplaying',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_FAVORITES,
            'action': 'movies&url=wetrakrfavorites',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        _row(L.HISTORY, 'movies&url=wetrakrhistory', 'wetrakr.png', 'DefaultMovies.png', condition=_wetrakr_live, queue=True),
        {
            'label': L.SIMKL_DROPPED,
            'action': 'movies&url=wetrakrdropped',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_LISTS,
            'action': 'wetrakrUserlists&media=movie',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'requires_route': True,
        },
        _submenu(
            L.WETRAKR_DISCOVER, 'wetrakrDiscoverMovies', 'wetrakr.png', 'DefaultMovies.png',
            submenu_key='wetrakr_discover_movies', condition=_wetrakr_live,
        ),
        {
            'label': L.WETRAKR_PUBLIC_LISTS,
            'action': 'wetrakrPubliclists&media=movie',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'requires_route': True,
        },
        {
            'label': L.WETRAKR_SEARCH,
            'action': 'wetrakrSearch&media=movie',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'requires_route': True,
        },
        _row(L.CONTINUE_WATCHING, 'movieProgress', 'trakt.png', 'DefaultMovies.png', condition=_progress),
        _row(L.COLLECTION, 'movies&url=traktcollection', 'trakt.png', 'DefaultMovies.png', condition=_collection, queue=True),
        _row(L.WATCHLIST, 'movies&url=traktwatchlist', 'trakt.png', 'DefaultMovies.png', condition=_watchlist, queue=True),
        _row(L.FEATURED, 'movies&url=traktfeatured', 'trakt.png', 'DefaultMovies.png', condition=_trakt_live, queue=True),
        _row(L.RECOMMENDED_FOR_YOU, 'movies&url=traktrecommendations', 'trakt.png', 'DefaultMovies.png', condition=_trakt_live, queue=True),
        _row(L.POPULAR_MOVIES, 'movies&url=traktpopular', 'trakt.png', 'DefaultMovies.png', condition=_trakt_live, queue=True),
        _row(L.ANTICIPATED_MOVIES, 'movies&url=traktanticipated', 'trakt.png', 'DefaultMovies.png', condition=_trakt_live, queue=True),
        {
            'label': L.MY_RATINGS,
            'action': 'traktMyRatings',
            'icon': 'trakt.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _trakt_live,
            'requires_route': True,
        },
        {
            'label': L.MY_STATISTICS,
            'action': 'traktMyStatistics',
            'icon': 'trakt.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _trakt_live,
            'requires_route': True,
        },
        _row(L.HISTORY, 'movies&url=trakthistory', 'trakt.png', 'DefaultMovies.png', condition=_trakt_live, queue=True),
        {
            'label': L.MOVIE_LISTS,
            'action': 'movieUserlists',
            'icon': 'userlists.png',
            'icon2': 'DefaultMovies.png',
            'condition': _trakt_live,
            'requires_route': True,
        },
        {
            'label': L.MDBLIST_LISTS,
            'action': 'mdbLists&media=movie',
            'icon': 'userlists.png',
            'icon2': 'DefaultMovies.png',
            'condition': _mdblist_live,
            'requires_route': True,
        },
        {
            'label': L.MOVIE_DISCOVER_ALL,
            'action': 'movieliteNavigator',
            'icon': 'movies.png',
            'icon2': 'DefaultMovies.png',
            'condition': _not_lite,
        },
        {
            'label': L.PEOPLE_SEARCH,
            'action': 'moviePerson',
            'icon': 'people-search.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _not_lite,
            'requires_route': True,
        },
        {
            'label': L.MOVIE_SEARCH,
            'action': 'movieSearch',
            'icon': 'search.png',
            'icon2': 'DefaultMovies.png',
            'condition': _not_lite,
            'requires_route': True,
        },
    ],
    'traktlist': [
        _row(L.TRAKT_LATEST_RELEASES, 'movies&url=https://api.trakt.tv/users/giladg/lists/latest-releases/items?', 'fhd_releases.png', 'DefaultMovies.png'),
        _row(L.TRAKT_LATEST_4K, 'movies&url=https://api.trakt.tv/users/giladg/lists/latest-4k-releases/items?', '4k_releases.png', 'DefaultMovies.png'),
        _row(L.BOX_OFFICE, 'movies&url=boxoffice', 'top_10.png', 'DefaultMovies.png'),
        _row(L.TRAKT_ACTION, 'movies&url=https://api.trakt.tv/users/movistapp/lists/action/items?', 'trakt.png', 'DefaultMovies.png'),
        _row(L.TRAKT_COMEDY, 'movies&url=https://api.trakt.tv/users/hdlists/lists/comedy-movies-top-rated-from-1960-to-today/items?', 'trakt.png', 'DefaultMovies.png'),
        _row(L.TRAKT_HORROR, 'movies&url=https://api.trakt.tv/users/movistapp/lists/horror/items?', 'trakt.png', 'DefaultMovies.png'),
    ],
    'movie_certificates_menu': [
        _row(L.MOVIE_CERT_G, 'movies&url=tmdb_certification&tid=G', 'certificates.png', 'certificates.png'),
        _row(L.MOVIE_CERT_PG, 'movies&url=tmdb_certification&tid=PG', 'certificates.png', 'certificates.png'),
        _row(L.MOVIE_CERT_PG13, 'movies&url=tmdb_certification&tid=PG-13', 'certificates.png', 'certificates.png'),
        _row(L.MOVIE_CERT_R, 'movies&url=tmdb_certification&tid=R', 'certificates.png', 'certificates.png'),
        _row(L.MOVIE_CERT_NC17, 'movies&url=tmdb_certification&tid=NC-17', 'certificates.png', 'certificates.png'),
    ],
    'movie_languages_menu': _movie_language_rows(),
    'tmdbmovieslist': [
        _row(L.TOP_RATED, 'movies&url=tmdb_movie_top_rated', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.POPULAR, 'movies&url=tmdb_movie_popular', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.NOW_PLAYING, 'movies&url=tmdb_movie_now_playing', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.UPCOMING_RELEASES, 'movies&url=tmdb_movie_upcoming', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.LATEST_RELEASES, 'movies&url=tmdb_movie_latest_releases', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.PREMIERES, 'movies&url=tmdb_movie_premieres', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.TRENDING_TODAY, 'movies&url=tmdb_movie_trending_day', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.TRENDING_WEEK, 'movies&url=tmdb_movie_trending_week', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.YEARS, 'movieYears', 'tmdb.png', 'DefaultTVShows.png'),
    ],
    'movies_calendars_menu': [
        _row(L.MOVIE_CAL_THEATRICAL_WEEK, 'movies_calendar&url=calendar_thisweek', 'moviecalendar.png', 'DefaultMovies.png', queue=True),
        _row(L.MOVIE_CAL_THEATRICAL_MONTH, 'movies_calendar&url=calendar_thismonth', 'moviecalendar.png', 'DefaultMovies.png', queue=True),
        _row(L.MOVIE_CAL_DVD_WEEK, 'movies_calendar&url=calendar_dvd_thisweek', 'moviecalendar.png', 'DefaultMovies.png', queue=True),
        _row(L.MOVIE_CAL_DVD_MONTH, 'movies_calendar&url=calendar_dvd_thismonth', 'moviecalendar.png', 'DefaultMovies.png', queue=True),
        {
            'label': L.WETRAKR_MOVIE_WEEK,
            'action': 'movies_calendar&url=wetrakrmovie_all_thisweek',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_MOVIE_MONTH,
            'action': 'movies_calendar&url=wetrakrmovie_all_thismonth',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_MOVIE_MY_WEEK,
            'action': 'movies_calendar&url=wetrakrmovie_my_thisweek',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_MOVIE_MY_MONTH,
            'action': 'movies_calendar&url=wetrakrmovie_my_thismonth',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultMovies.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
    ],
    'wetrakr_discover_movies': [
        _row(L.WETRAKR_TRENDING, 'movies&url=wetrakrtrending', 'wetrakr.png', 'DefaultMovies.png', queue=True),
        _row(L.WETRAKR_POPULAR, 'movies&url=wetrakrpopular', 'wetrakr.png', 'DefaultMovies.png', queue=True),
        _row(L.WETRAKR_TOP_RATED, 'movies&url=wetrakrtoprated', 'wetrakr.png', 'DefaultMovies.png', queue=True),
    ],
    'wetrakr_discover_tv': [
        _row(L.WETRAKR_TRENDING, 'tvshows&url=wetrakrtrending', 'wetrakr.png', 'DefaultTVShows.png', queue=True),
        _row(L.WETRAKR_POPULAR, 'tvshows&url=wetrakrpopular', 'wetrakr.png', 'DefaultTVShows.png', queue=True),
        _row(L.WETRAKR_TOP_RATED, 'tvshows&url=wetrakrtoprated', 'wetrakr.png', 'DefaultTVShows.png', queue=True),
    ],
    # --- TV Shows (Crew tvNavigator order) ----------------------------------
    'tvshows': [
        _submenu(L.MY_TV_SHOWS, 'mytvliteNavigator', 'mytvshows.png', 'DefaultVideoPlaylists.png', submenu_key='mytvshows'),
        {
            'label': L.TV_EVENING,
            'action': 'tvevening',
            'icon': 'tv_evening.png',
            'icon2': 'tv_evening.png',
            'is_folder': False,
            'requires_route': True,
        },
        _row(L.NEW_TV_SHOWS, 'tvshows&url=premiere', 'new-tvshows.png', 'DefaultTVShows.png', setting='navi.tvPremier'),
        _row(L.AIRING_TODAY, 'tvshows&url=airing', 'airing-today.png', 'DefaultTVShows.png', setting='navi.tvAiring'),
        _submenu(L.WHATS_ON, 'calendars_menu', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', setting='navi.tvCalendar'),
        _row(L.TRENDING, 'tvshows&url=trending', 'trending.png', 'DefaultRecentlyAddedEpisodes.png', setting='navi.tvTrending'),
        _row(L.MOST_POPULAR, 'tvshows&url=popular', 'most-popular.png', 'DefaultTVShows.png', setting='navi.tvPopular'),
        _submenu(L.TMDB_LISTS, 'tmdbtvlist', 'tmdb.png', 'DefaultVideoPlaylists.png', setting='navi.tvTmdb'),
        _row(L.DISNEY_PLUS, 'tvshows&url=tmdb_networks&tid=2739', 'disney.png', 'disney.png', setting='navi.disney'),
        _row(L.NETFLIX, 'tvshows&url=tmdb_networks&tid=213', 'netflix.png', 'netflix.png', setting='navi.netflix'),
        _row(L.HBO, 'tvshows&url=tmdb_networks&tid=49', 'hbo.png', 'hbo.png', setting='navi.hbo'),
        _row(L.APPLE_TV_PLUS, 'tvshows&url=tmdb_networks&tid=2552', 'apple.png', 'apple.png', setting='navi.apple'),
        {
            'label': L.DOCUMENTARIES,
            'action': 'docuNavigator',
            'icon': 'documentaries.png',
            'icon2': 'DefaultMovies.png',
            'requires_route': True,
        },
        {
            'label': L.GENRES,
            'action': 'tvGenres',
            'icon': 'genres.png',
            'icon2': 'DefaultTVShows.png',
            'setting': 'navi.tvGenres',
            'requires_route': True,
        },
        _submenu(
            L.CERTIFICATES, 'tvCertificates', 'certificates.png', 'certificates.png',
            submenu_key='tv_certificates_menu', setting='navi.tvCertificates',
        ),
        {
            'label': L.NETWORKS,
            'action': 'tvNetworks',
            'icon': 'networks.png',
            'icon2': 'DefaultTVShows.png',
            'setting': 'navi.tvNetworks',
            'requires_route': True,
        },
        _row(L.HIGHLY_RATED, 'tvshows&url=rating', 'highly-rated.png', 'DefaultTVShows.png', setting='navi.tvRating'),
        _row(L.MOST_VOTED, 'tvshows&url=views', 'most-voted2.png', 'DefaultTVShows.png', setting='navi.tvViews'),
        _submenu(
            L.INTERNATIONAL, 'tvLanguages', 'international.png', 'DefaultTVShows.png',
            submenu_key='tv_languages_menu', setting='navi.tvLanguages',
        ),
        _row(L.RETURNING_SHOWS, 'tvshows&url=active', 'returning-tvshows.png', 'DefaultTVShows.png', setting='navi.tvActive'),
        {
            'label': L.PEOPLE_SEARCH,
            'action': 'tvPerson',
            'icon': 'people-search.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'requires_route': True,
        },
        {
            'label': L.TV_SEARCH,
            'action': 'tvSearch',
            'icon': 'search.png',
            'icon2': 'DefaultTVShows.png',
            'requires_route': True,
        },
        {
            'label': L.ADVANCED_SEARCH,
            'action': 'tvAdvancedSearch',
            'icon': 'search.png',
            'icon2': 'DefaultTVShows.png',
            'requires_route': True,
        },
        {
            'label': L.SAVED_FILTERS,
            'action': 'tvSavedFilters',
            'icon': 'saved-filters.png',
            'icon2': 'DefaultTVShows.png',
            'requires_route': True,
        },
    ],
    'mytvshows': [
        {
            'label': L.TRAKT_AUTHORIZE,
            'action': 'authTrakt',
            'icon': 'trakt.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _no_trakt,
        },
        {
            'label': L.SIMKL_AUTHORIZE,
            'action': 'authSimkl',
            'icon': 'simkl.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _no_simkl,
        },
        {
            'label': L.WETRAKR_AUTHORIZE,
            'action': 'authWetrakr',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _no_wetrakr,
        },
        _row(L.IN_PROGRESS_SHOWS, 'progress_shows', 'simkl.png', 'DefaultTVShows.png', condition=_simkl_progress),
        _row(L.NEXT_EPISODES, 'progress_next_episodes', 'simkl.png', 'DefaultRecentlyAddedEpisodes.png', condition=_simkl_progress, queue=True),
        _row(L.IN_PROGRESS_EPISODES, 'progress_in_progress_episodes', 'simkl.png', 'DefaultRecentlyAddedEpisodes.png', condition=_simkl_progress, queue=True),
        _row(L.IN_PROGRESS_SHOWS, 'progress_shows', 'wetrakr.png', 'DefaultTVShows.png', condition=_wetrakr_progress),
        _row(L.NEXT_EPISODES, 'progress_next_episodes', 'wetrakr.png', 'DefaultRecentlyAddedEpisodes.png', condition=_wetrakr_progress, queue=True),
        _row(L.IN_PROGRESS_EPISODES, 'progress_in_progress_episodes', 'wetrakr.png', 'DefaultRecentlyAddedEpisodes.png', condition=_wetrakr_progress, queue=True),
        _row(L.WATCHLIST, 'tvshows&url=wetrakrwatchlist', 'wetrakr.png', 'DefaultTVShows.png', condition=_wetrakr_watchlist, queue=True),
        {
            'label': L.SIMKL_WATCHING,
            'action': 'tvshows&url=wetrakrwatching',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_WAITING,
            'action': 'tvshows&url=wetrakrwaiting',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.SIMKL_ON_HOLD,
            'action': 'tvshows&url=wetrakrhold',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_FAVORITES,
            'action': 'tvshows&url=wetrakrfavorites',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        _row(L.HISTORY, 'tvshows&url=wetrakrhistory', 'wetrakr.png', 'DefaultTVShows.png', condition=_wetrakr_live, queue=True),
        {
            'label': L.SIMKL_DROPPED,
            'action': 'tvshows&url=wetrakrdropped',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'queue': True,
        },
        {
            'label': L.WETRAKR_LISTS,
            'action': 'wetrakrUserlists&media=show',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'requires_route': True,
        },
        _submenu(
            L.WETRAKR_DISCOVER, 'wetrakrDiscoverTV', 'wetrakr.png', 'DefaultTVShows.png',
            submenu_key='wetrakr_discover_tv', condition=_wetrakr_live,
        ),
        {
            'label': L.WETRAKR_PUBLIC_LISTS,
            'action': 'wetrakrPubliclists&media=show',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'requires_route': True,
        },
        {
            'label': L.WETRAKR_SEARCH,
            'action': 'wetrakrSearch&media=show',
            'icon': 'wetrakr.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _wetrakr_live,
            'requires_route': True,
        },
        _row(L.WATCHLIST, 'tvshows&url=simklwatchlist', 'simkl.png', 'DefaultTVShows.png', condition=_simkl_watchlist, queue=True),
        {
            'label': L.SIMKL_WATCHING,
            'action': 'tvshows&url=simklwatching',
            'icon': 'simkl.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _simkl_live,
            'queue': True,
        },
        {
            'label': L.SIMKL_ON_HOLD,
            'action': 'tvshows&url=simklhold',
            'icon': 'simkl.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _simkl_live,
            'queue': True,
        },
        _row(L.HISTORY, 'tvshows&url=simklhistory', 'simkl.png', 'DefaultTVShows.png', condition=_simkl_live, queue=True),
        {
            'label': L.SIMKL_DROPPED,
            'action': 'tvshows&url=simkldropped',
            'icon': 'simkl.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _simkl_live,
            'queue': True,
        },
        _row(L.MY_RATINGS, 'tvshows&url=simklratings', 'simkl.png', 'DefaultTVShows.png', condition=_simkl_live, queue=True),
        _row(L.TRAKT_COLLECTION, 'tvshows&url=traktcollection', 'trakt.png', 'DefaultTVShows.png', condition=_collection, queue=True),
        _row(L.TRAKT_WATCHLIST, 'tvshows&url=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', condition=_watchlist, queue=True),
        _row(L.TRAKT_FEATURED, 'tvshows&url=traktfeatured', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.RECOMMENDED_SHOWS, 'tvshows&url=traktrecommendations', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.POPULAR_SHOWS, 'tvshows&url=traktpopular', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.ANTICIPATED_SHOWS, 'tvshows&url=traktanticipated', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.MOST_PLAYED_SHOWS, 'tvshows&url=traktplayed', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        {
            'label': L.MY_RATINGS,
            'action': 'traktMyRatings',
            'icon': 'trakt.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _trakt_live,
            'requires_route': True,
        },
        {
            'label': L.MY_STATISTICS,
            'action': 'traktMyStatistics',
            'icon': 'trakt.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _trakt_live,
            'requires_route': True,
        },
        _submenu(L.WHATS_ON, 'calendars_menu', 'tvcalendar.png', 'DefaultTVShows.png'),
        _row(L.MOST_WATCHED_SHOWS, 'tvshows&url=traktwatched', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.MOST_COLLECTED_SHOWS, 'tvshows&url=traktcollected', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.TRAKT_HISTORY, 'calendar&url=trakthistory', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        _row(L.IN_PROGRESS_SHOWS, 'progress_shows', 'trakt.png', 'DefaultTVShows.png', condition=_progress, queue=True),
        _row(L.NEXT_EPISODES, 'progress_next_episodes', 'trakt.png', 'DefaultRecentlyAddedEpisodes.png', condition=_progress, queue=True),
        _row(L.IN_PROGRESS_EPISODES, 'progress_in_progress_episodes', 'trakt.png', 'DefaultRecentlyAddedEpisodes.png', condition=_progress, queue=True),
        _row(L.HIDDEN_SHOWS, 'tvshows&url=trakthidden', 'trakt.png', 'DefaultTVShows.png', condition=_trakt_live, queue=True),
        {
            'label': L.MDBLIST_LISTS,
            'action': 'mdbLists&media=show',
            'icon': 'userlists.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _mdblist_live,
            'requires_route': True,
        },
        {
            'label': L.TV_DISCOVER_ALL,
            'action': 'tvliteNavigator',
            'icon': 'tvshows.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _not_lite,
        },
        {
            'label': L.PEOPLE_SEARCH,
            'action': 'tvPerson',
            'icon': 'people-search2.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _not_lite,
            'requires_route': True,
        },
        {
            'label': L.TV_SEARCH,
            'action': 'tvSearch',
            'icon': 'search.png',
            'icon2': 'DefaultTVShows.png',
            'condition': _not_lite,
            'requires_route': True,
        },
    ],
    'tv_certificates_menu': [
        _row(L.TV_CERT_ALL_CHILDREN, 'tvshows&url=tmdb_certification&tid=TV-Y', 'tv_y.png', 'tv_y.png'),
        _row(L.TV_CERT_GENERAL, 'tvshows&url=tmdb_certification&tid=TV-G', 'tv_g.png', 'tv_g.png'),
        _row(L.TV_CERT_PARENTAL, 'tvshows&url=tmdb_certification&tid=TV-PG', 'tv_pg.png', 'tv_pg.png'),
        _row(L.TV_CERT_STRONGLY_CAUTIONED, 'tvshows&url=tmdb_certification&tid=TV-14', 'tv_14.png', 'tv_14.png'),
        _row(L.TV_CERT_MATURE, 'tvshows&url=tmdb_certification&tid=TV-MA', 'tv_ma.png', 'tv_ma.png'),
    ],
    'tv_languages_menu': _tv_language_rows(),
    'search': [
        {
            'label': L.MOVIE_SEARCH,
            'action': 'movieSearch',
            'icon': 'search.png',
            'icon2': 'DefaultMovies.png',
            'requires_route': True,
        },
        {
            'label': L.TV_SEARCH,
            'action': 'tvSearch',
            'icon': 'search.png',
            'icon2': 'DefaultTVShows.png',
            'requires_route': True,
        },
        {
            'label': L.PEOPLE_SEARCH,
            'action': 'moviePerson',
            'icon': 'people-search.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'requires_route': True,
        },
        {
            'label': L.PEOPLE_SEARCH,
            'action': 'tvPerson',
            'icon': 'people-search.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'requires_route': True,
        },
    ],
    'tmdbtvlist': [
        _row(L.TOP_RATED, 'tvshows&url=tmdb_tv_top_rated', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.POPULAR, 'tvshows&url=tmdb_tv_popular_tv', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.ON_THE_AIR, 'tvshows&url=tmdb_tv_on_the_air', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.AIRING_TODAY, 'tvshows&url=tmdb_tv_airing_today', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.UPCOMING_SHOWS, 'tvshows&url=tmdb_tv_upcoming', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.TRENDING_TODAY, 'tvshows&url=tmdb_tv_trending_day', 'tmdb.png', 'DefaultTVShows.png'),
        _row(L.TRENDING_WEEK, 'tvshows&url=tmdb_tv_trending_week', 'tmdb.png', 'DefaultTVShows.png'),
    ],
    'calendars_menu': [
        _section(L.MY_TV_SECTION, condition=_calendars),
        _row(L.MY_AIRING_TODAY, 'calendar&url=calendar_today', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', condition=_calendars, queue=True),
        _row(L.MY_AIRING_THIS_WEEK, 'calendar&url=calendar_thisweek', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', condition=_calendars, queue=True),
        _row(L.MY_AIRING_NEXT_WEEK, 'calendar&url=calendar_nextweek', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', condition=_calendars, queue=True),
        _row(L.MY_NEW_AIRED, 'calendar&url=mycalendar', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', condition=_calendars, queue=True),
        _section(L.ALL_TV_SECTION),
        _row(L.ALL_AIRING_TODAY, 'calendar&url=calendar_all_today', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', queue=True),
        _row(L.ALL_AIRING_THIS_WEEK, 'calendar&url=calendar_all_thisweek', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', queue=True),
        _row(L.ALL_AIRING_THIS_MONTH, 'calendar&url=calendar_all_thismonth', 'tvcalendar.png', 'DefaultRecentlyAddedEpisodes.png', queue=True),
    ],
    'kids': [
        # TMDB kids hub only  -  White debridkids/learning/songs/disney_years dropped.
        _row(L.KIDS_MOVIES_ALL, 'movies&url=kids_movies_all', 'kids_movies.png', 'DefaultMovies.png'),
        _row(L.KIDS_MOVIES_ANIMATION, 'movies&url=kids_movies_animation', 'kids_movies.png', 'DefaultMovies.png'),
        _row(L.KIDS_MOVIES_FAMILY, 'movies&url=kids_movies_family', 'kids_movies.png', 'DefaultMovies.png'),
        _row(L.KIDS_DISNEY, 'movies&url=kids_movies_disney', 'disney.png', 'DefaultMovies.png'),
        _row(L.KIDS_TV_ALL, 'tvshows&url=kids_tv_all', 'kids_tv.png', 'DefaultTVShows.png'),
        _row(L.KIDS_TV_ANIMATION, 'tvshows&url=kids_tv_animation', 'kids_tv.png', 'DefaultTVShows.png'),
        _row(L.KIDS_TV_FAMILY, 'tvshows&url=kids_tv_family', 'kids_tv.png', 'DefaultTVShows.png'),
        _row(L.KIDS_TV_KIDS, 'tvshows&url=kids_tv_kids', 'kids_tv.png', 'DefaultTVShows.png'),
    ],
    'bluehat': [
        # Crew 3.2.26-27: FULL LIVE SITES first. Misc Sports parked (Xbox; 3.2.25).
        _sport('fullsites', L.SPORT_FULLSITES, 'misc_sports.png'),
        _sport('nfl', L.SPORT_NFL, 'nfl.png'),
        _sport('nhl', L.SPORT_NHL, 'nhl.png'),
        _sport('nba', L.SPORT_NBA, 'nba.png'),
        _sport('mlb', L.SPORT_MLB, 'mlb.png'),
        _sport('ncaa', L.SPORT_NCAA, 'ncaa.png'),
        _sport('ncaab', L.SPORT_NCAAB, 'ncaab.png'),
        _sport('ufc', L.SPORT_UFC, 'ufc.png'),
        _sport('wwe', L.SPORT_WWE, 'wwe.png'),
        _sport('boxing', L.SPORT_BOXING, 'boxing.png'),
        _sport('fifa', L.SPORT_FIFA, 'fifa.png'),
        _sport('tennis', L.SPORT_TENNIS, 'tennis.png'),
        _sport('motogp', L.SPORT_MOTOGP, 'motogp.png'),
        _sport('f1', L.SPORT_F1, 'f1.png'),
        _sport('pga', L.SPORT_PGA, 'pga.png'),
        _sport('nascar', L.SPORT_NASCAR, 'nascar.png'),
        # _sport('misc_sports', L.SPORT_MISC, 'misc_sports.png'),  # parked; router still has feed
        _sport('sreplays', L.SPORT_REPLAYS, 'sports_replays.png'),
    ],
    'library': [
        {
            'label': L.LIBRARY_SETTINGS,
            'action': 'opensettings&query=5.0',
            'icon': 'tools.png',
            'icon2': 'DefaultAddonProgram.png',
            'is_folder': False,
        },
        {
            'label': L.LIBRARY_SETUP_SOURCES,
            'action': 'setupLibrarySources',
            'icon': 'library_update.png',
            'icon2': 'DefaultAddonProgram.png',
            'is_folder': False,
        },
        {
            'label': L.LIBRARY_UPDATE,
            'action': 'updateLibrary&query=tool',
            'icon': 'library_update.png',
            'icon2': 'DefaultAddonProgram.png',
            'is_folder': False,
        },
        {
            'label': L.LIBRARY_MOVIE_FOLDER,
            'action': lambda _nav: c.get_setting('library.movie'),
            'icon': 'movies.png',
            'icon2': 'DefaultMovies.png',
            'is_action': False,
            'is_folder': True,
        },
        {
            'label': L.LIBRARY_TV_FOLDER,
            'action': lambda _nav: c.get_setting('library.tv'),
            'icon': 'tvshows.png',
            'icon2': 'DefaultTVShows.png',
            'is_action': False,
            'is_folder': True,
        },
        {
            'label': L.LIBRARY_TRAKT_MOVIES_COLLECTION,
            'action': 'moviesToLibrary&url=traktcollection',
            'icon': 'trakt.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _collection,
        },
        {
            'label': L.LIBRARY_TRAKT_MOVIES_WATCHLIST,
            'action': 'moviesToLibrary&url=traktwatchlist',
            'icon': 'trakt.png',
            'icon2': 'DefaultMovies.png',
            'is_folder': False,
            'condition': _watchlist,
        },
        {
            'label': L.LIBRARY_TRAKT_TV_COLLECTION,
            'action': 'tvshowsToLibrary&url=traktcollection',
            'icon': 'trakt.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _collection,
        },
        {
            'label': L.LIBRARY_TRAKT_TV_WATCHLIST,
            'action': 'tvshowsToLibrary&url=traktwatchlist',
            'icon': 'trakt.png',
            'icon2': 'DefaultTVShows.png',
            'is_folder': False,
            'condition': _watchlist,
        },
    ],
}

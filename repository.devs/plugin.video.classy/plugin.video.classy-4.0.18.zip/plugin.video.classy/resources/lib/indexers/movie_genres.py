# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movie_genres.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Movies  ->  Genres submenu  -  fixed TMDB genre list  ->  discover.'''

from __future__ import annotations

from ..modules import kodi
from .genre_catalog import MOVIE_GENRES
from . import genre_posters
from .navigator import n


def genres_directory(handle):
    '''List movie genres  ->  movies&url=tmdb_genre&tid={id}.'''
    thumbs = genre_posters.resolve_thumbs(art for _, _, art in MOVIE_GENRES)
    for genre_id, label_id, art_name in MOVIE_GENRES:
        n.addDirectoryItem(
            label_id,
            f'movies&url=tmdb_genre&tid={genre_id}',
            thumbs.get(art_name, genre_posters.FALLBACK_THUMB),
            'DefaultMovies.png',
        )
    kodi.content(handle, 'genres')
    kodi.directory(handle, cacheToDisc=True)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file network_catalog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Fixed TMDB TV network catalog (Crew tvshows.networks parity).

Logos are TMDB image paths under https://image.tmdb.org/t/p/original/
Brand names stay as plain English (same as International language rows).'''

# (tmdb_network_id, display_name, logo_file)
TV_NETWORKS = (
    (129, 'A&E', 'ptSTdU4GPNJ1M8UVEOtA0KgtuNk.png'),
    (2, 'ABC', 'an88sKsFz0KX5CQngAM95WkncX4.png'),
    (1024, 'Amazon', 'uK6yuqMkUvKhCgVJjg5JWDUoabA.png'),
    (174, 'AMC', 'alqLicR1ZMHMaZGP3xRQxn9sq7p.png'),
    (91, 'Animal Planet', 'xQ25rzpv83d74V1zpOzSHbYlwJq.png'),
    (2552, 'Apple TV+', ''),  # local apple.png preferred in directory builder
    (173, 'AT-X', 'fERjndErEpveJmQZccJbJDi93rj.png'),
    (493, 'BBC America', '8Js4sUaxjE3RSxJcOCDjfXvhZqz.png'),
    (4, 'BBC One', 'uJjcCg3O4DMEjM0xtno9OWFciRP.png'),
    (332, 'BBC Two', '7HVPn1p2w1nC5oRKBehXVHpss7e.png'),
    (3, 'BBC Three', 's22fRhj8xFPbiexrJwiAOcDEIrS.png'),
    (100, 'BBC Four', 'AgsOSxGvfxIonhPgrfkWCmsOKfA.png'),
    (24, 'BET', 'gaouRlJrfZlEA5EPHhO5qqZ1Fgu.png'),
    (74, 'Bravo', 'wX5HsfS47u6UUCSpYXqaQ1x2qdu.png'),
    (56, 'Cartoon Network', 'c5OC6oVCg6QP4eqzW6XIq17CQjI.png'),
    (201, 'CBC', 'qNooLje0YQh1y3y9LUM2Y5QCtiF.png'),
    (16, 'CBS', 'wju8KhOUsR5y4bH9p3Jc50hhaLO.png'),
    (26, 'Channel 4', 'zCUWm0Xb6AnjUbxzjL5OkzmHhd7.png'),
    (99, 'Channel 5', 'bMuKs6xuhI0GHSsq4WWd9FsntUN.png'),
    (47, 'Comedy Central', '6ooPjtXufjsoskdJqj6pxuvHEno.png'),
    (403, 'CTV', 'volHUxY1MHjSPI4ju7j36EdhR2m.png'),
    (928, 'Crackle', 'bR8S6Fjv3VGtEKyKF5lvvRJ5xfw.png'),
    (71, 'The CW', 'ge9hzeaU7nMtQ4PjkFlc68dGAJ9.png'),
    (1049, 'CW Seed', 'wwo3PZyBpHL3Wz8eg4cr3kqVZQY.png'),
    (64, 'Discovery', '8qkdZlbrTSVfkJ73DjOBrwYtMSC.png'),
    (4883, 'discovery+', 'iKvdFk5lpbvs4g0vd6yVUcV36i3.png'),
    (244, 'Discovery ID', 'yfkdPLHjsed7vwUNuh20eMuDiDO.png'),
    (2739, 'Disney+', 'PQxvkeK8cTtD7vjataBsNpjbJ5.png'),
    (54, 'Disney Channel', 'gvhBea9OGqChmGKHa5CntbmsDBp.png'),
    (44, 'Disney XD', 'nKM9EnV7jTpt3MKRbhBusJ03lAY.png'),
    (76, 'E!', 'ptpx2Ag52sYJG6LiX9zBlnKsQOS.png'),
    (136, 'E4', 'fJPM9Rj12us4HF03N3qvakz7WuZ.png'),
    (19, 'FOX', '1DSpHrWyOORkL9N2QHX7Adt31mQ.png'),
    (1267, 'Freeform', 'jk2Z7WH6JnHSZrxouYh4sireM3a.png'),
    (88, 'FX', 'aexGjtcs42DgRtZh7zOxayiry4J.png'),
    (384, 'Hallmark Channel', '9JTL7HcaiVxq7M6eu5m7giFqaxR.png'),
    (65, 'History', '9fGgdJz17aBX7dOyfHJtsozB7bf.png'),
    (49, 'HBO', 'hizvY65SpyF3BPY2qsBZMgUOxjs.png'),
    (3186, 'HBO Max', 'nmU0UMDJB3dRRQSTUqawzF2Od1a.png'),
    (210, 'HGTV', 'tzTtKdQ7vC2FkBvJDUErOhBPdKJ.png'),
    (453, 'Hulu', 'pqUTCleNUiTLAVlelGxUgWn1ELh.png'),
    (9, 'ITV', 'j3KAlTmxGDCHQZqs1A2hagzjYqu.png'),
    (34, 'Lifetime', 'kU18GafTybg4uMhkj3wvsGBgn8s.png'),
    (33, 'MTV USA', 'w4qtv7xBkSVsbOQdSzjUjlyOuSr.png'),
    (488, 'MTV UK', 'w4qtv7xBkSVsbOQdSzjUjlyOuSr.png'),
    (43, 'National Geographic', 'q9rPBG1rHbUjII1Qn98VG2v7cFa.png'),
    (6, 'NBC', 'cm111bsDVlYaC1foL0itvEI4yLG.png'),
    (213, 'Netflix', 'wwemzKWzjKYJFfCeiB57q3r4Bcm.png'),
    (13, 'Nickelodeon', 'aYkLXz4dxHgOrFNH7Jv7Cpy56Ms.png'),
    (14, 'PBS', 'hp2Fs7AIdsMlEjiDUC1V8Ows2jM.png'),
    (67, 'Showtime', 'Allse9kbjiP6ExaQrnSpIhkurEi.png'),
    (1755, 'Sky History', 'xhTdszjVRy1tABMix2dffBcdDJ1.png'),
    (1431, 'Sky One', 'dVBHOr0nYCx9GSNesTVb1TT52Xj.png'),
    (318, 'Starz', 'GMDGZk9iDG4WDijY3VgUgJeyus.png'),
    (270, 'SundanceTV', 'xhTdszjVRy1tABMix2dffBcdDJ1.png'),
    (77, 'Syfy', 'iYfrkobwDhTOFJ4AXYPSLIEeaAT.png'),
    (68, 'TBS', '9PYsQf3YbDUJo1rg3pgtaiOrb6s.png'),
    (84, 'TLC', '6GRfZSrYh9D6C88n9kWlyrySB2l.png'),
    (41, 'TNT', '6ISsKwa2XUhSC6oBtHZjYf6xFqv.png'),
    (209, 'Travel Channel', '8SwN81R7P5vD5mhtOE0taw5mji4.png'),
    (364, 'truTV', 'c48pVcWAEYhEFXrWFsYxx343mjx.png'),
    (30, 'USA Network', 'g1e0H0Ka97IG5SyInMXdJkHGKiH.png'),
    (158, 'VH1', 'w9oUxxUiXTC1O1MzJSvsMjQbgft.png'),
    (202, 'WGN America', 'kCNFRiqVRMgNWKSWu0LzAIpy9um.png'),
    (247, 'YouTube', '9Ga8A5QegQmiSVHp4hyusfMfpVk.png'),
    (1436, 'YouTube Premium', '3p05CgodUb9gPayuliuhawNj1Wo.png'),
)

LOGO_BASE = 'https://image.tmdb.org/t/p/original'
FALLBACK_THUMB = 'networks.png'


def logo_url(logo_file):
    if not logo_file:
        return FALLBACK_THUMB
    return f'{LOGO_BASE}/{logo_file.lstrip("/")}'

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file my_crew.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

My Crew root submenu  -  user shortcut directory.'''

import sys

from ..modules.classy import c
from ..kodi import context_menus
from ..pinboard import store as pinboard_store
from . import menu_labels as L
from .navigator import n


def directory():
    handle = int(sys.argv[1])
    pinboard_store.ensure_defaults()
    items = pinboard_store.list_items()

    if not items:
        c.log('[MyCrew] empty shortcut list')
        n.addDirectoryItem(
            L.display_label(L.MY_CREW_EMPTY),
            'whatsOnSection',
            'mycrew.png',
            'mycrew.png',
            isFolder=False,
        )
    else:
        for row in items:
            action = row.get('action') or ''
            icon = row.get('icon') or 'mycrew.png'
            pin_label = row.get('label') or action
            n.addDirectoryItem(
                L.display_label(pin_label),
                action,
                icon,
                icon,
                context_menu=context_menus.build_my_crew_menu(row['id']),
            )

    n.addDirectoryItem(
        L.display_label(L.MY_CREW_MANAGE),
        'myCrewManage',
        'tools.png',
        'tools.png',
        isFolder=False,
    )
    n.endDirectory()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv_networks.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Shows  ->  Networks submenu  -  fixed TMDB network list  ->  discover.'''

from __future__ import annotations

from ..modules import kodi
from .network_catalog import TV_NETWORKS, FALLBACK_THUMB, logo_url
from .navigator import n

# Prefer bundled brand icons when TMDB logo path is missing.
_LOCAL_ICONS = {
    'Apple TV+': 'apple.png',
    'Disney+': 'disney.png',
    'Netflix': 'netflix.png',
    'HBO': 'hbo.png',
}


def networks_directory(handle):
    '''List TV networks  ->  tvshows&url=tmdb_networks&tid={id}.'''
    for network_id, name, logo_file in TV_NETWORKS:
        if logo_file:
            thumb = logo_url(logo_file)
        else:
            thumb = _LOCAL_ICONS.get(name, FALLBACK_THUMB)
        n.addDirectoryItem(
            name,
            f'tvshows&url=tmdb_networks&tid={network_id}',
            thumb,
            'DefaultTVShows.png',
        )
    kodi.content(handle, 'tvshows')
    kodi.directory(handle, cacheToDisc=True)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file progress.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Progress routes  -  thin: slots  ->  enrich  ->  directory.'''

import sys
from urllib.parse import urlencode

from .. import tracker
from ..kodi import listing
from ..metadata.enrich import NEEDS_PROGRESS, enrich_batch
from ..modules.classy import c
from ..progress import slots as progress_slots
from ..progress import widget_cache
from ..play.url import play_url
from ..trakt.browse_context import TVBrowseContext


def _require_tracker(handle, content, ctx, empty_label):
    if tracker.live():
        return True
    listing.emit_empty(handle, empty_label, content, ctx, cache=False)
    return False


def _read_prepared_widget_rows(route):
    '''Prepared home-widget rows (allow_stale OK  -  warm overwrites on success).'''
    return widget_cache.read_prepared_rows(route, allow_stale=True)


def in_progress_shows(handle, params):
    ctx = listing.listing_context()
    if ctx.is_widget:
        in_progress_shows_widget(handle, ctx)
    else:
        in_progress_shows_browse(handle, listing.parse_page(params, ctx), ctx)


def in_progress_episodes(handle, params):
    ctx = listing.listing_context()
    if ctx.is_widget:
        in_progress_episodes_widget(handle, ctx)
    else:
        in_progress_episodes_browse(handle, listing.parse_page(params, ctx), ctx)


def in_progress_shows_widget(handle, ctx):
    c.log('[Progress] In Progress Shows widget')
    if not _require_tracker(handle, 'tvshows', ctx, f'Connect {tracker.display_label()} to see in-progress shows'):
        return
    rows = _read_prepared_widget_rows(widget_cache.ROUTE_IN_PROGRESS_SHOWS)
    if rows:
        listing.emit_video_rows(handle, rows, _stub_seasons_url, ctx, is_folder=True)
        listing.finish_directory(handle, 'tvshows', ctx, cache=True)
        return
    if _wetrakr_rate_limited():
        c.log('[Progress] shows widget: WeTrakr rate-limited  -  skip rebuild')
        listing.emit_empty(handle, 'No in-progress shows', 'tvshows', ctx, cache=False)
        return

    browse_ctx = TVBrowseContext.load(log_label='in_progress_shows', clear_probe=True)
    top_slots, total, fp, unchanged, filtered = progress_slots.in_progress_show_slots(
        limit=ctx.limit,
        log_label='in_progress_shows',
        widget=True,
        probe=browse_ctx.probe,
        watched=browse_ctx.watched,
    )
    c.log(
        f'[Progress] shows widget: {len(top_slots)} of {total} '
        f'(fp={fp[:8] + "..." if fp else " - "}, unchanged={unchanged}, filtered={filtered})'
    )
    if filtered:
        c.log(f'[Progress] skipped {filtered} shows (completed / no episode progress)')
    if not top_slots:
        listing.emit_empty(handle, 'No in-progress shows', 'tvshows', ctx, cache=False)
        return
    rows = _render_show_rows(handle, top_slots, ctx, browse_ctx=browse_ctx)
    widget_cache.save_after_widget_render(widget_cache.ROUTE_IN_PROGRESS_SHOWS, fp, rows)
    listing.finish_directory(handle, 'tvshows', ctx, cache=True)


def in_progress_shows_browse(handle, page, ctx):
    c.log(f'[Progress] In Progress Shows browse page={page}')
    if not _require_tracker(handle, 'tvshows', ctx, f'Connect {tracker.display_label()} to see in-progress shows'):
        return
    browse_ctx = TVBrowseContext.load(log_label='in_progress_shows', clear_probe=True)
    page_slots, total, fp, unchanged, filtered = progress_slots.in_progress_show_slots(
        page=page,
        limit=ctx.page_size,
        log_label='in_progress_shows',
        widget=False,
        probe=browse_ctx.probe,
        watched=browse_ctx.watched,
    )
    c.log(
        f'[Progress] shows browse: page {page}  ->  {len(page_slots)} of {total} '
        f'(unchanged={unchanged})'
    )
    if not page_slots and page == 1:
        listing.emit_empty(handle, 'No in-progress shows', 'tvshows', ctx, cache=False)
        return
    next_url, next_label = listing.pagination_next(
        'progress_shows', page, total, ctx, page_size=ctx.page_size,
    )
    _render_show_rows(handle, page_slots, ctx, browse_ctx=browse_ctx)
    listing.add_next_page(handle, next_url, next_label, ctx)
    listing.finish_directory(handle, 'tvshows', ctx, cache=True)


def in_progress_episodes_widget(handle, ctx):
    c.log('[Progress] In Progress Episodes widget')
    if not _require_tracker(handle, 'episodes', ctx, f'Connect {tracker.display_label()} to see in-progress episodes'):
        return
    rows = _read_prepared_widget_rows(widget_cache.ROUTE_IN_PROGRESS_EPISODES)
    if rows:
        listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)
        listing.finish_directory(handle, 'episodes', ctx, cache=True)
        return
    if _wetrakr_rate_limited():
        c.log('[Progress] resume widget: WeTrakr rate-limited  -  skip rebuild')
        listing.emit_empty(handle, 'No in-progress episodes', 'episodes', ctx, cache=False)
        return

    from ..trakt import activity
    probe = activity.probe_last_activities(log_label='in_progress_episodes')
    top_slots, total, fp, unchanged, filtered = progress_slots.in_progress_episode_slots(
        limit=ctx.limit,
        log_label='in_progress_episodes',
        widget=True,
        probe=probe,
    )
    c.log(
        f'[Progress] resume widget: {len(top_slots)} of {total} '
        f'(fp={fp[:8] + "..." if fp else " - "}, unchanged={unchanged}, filtered={filtered})'
    )
    if not top_slots:
        listing.emit_empty(handle, 'No in-progress episodes', 'episodes', ctx, cache=False)
        return
    rows = _render_resume_rows(handle, top_slots, ctx)
    widget_cache.save_after_widget_render(widget_cache.ROUTE_IN_PROGRESS_EPISODES, fp, rows)
    listing.finish_directory(handle, 'episodes', ctx, cache=True)


def in_progress_episodes_browse(handle, page, ctx):
    c.log(f'[Progress] In Progress Episodes browse page={page}')
    if not _require_tracker(handle, 'episodes', ctx, f'Connect {tracker.display_label()} to see in-progress episodes'):
        return
    from ..trakt import activity
    probe = activity.probe_last_activities(log_label='in_progress_episodes')
    page_slots, total, fp, unchanged, filtered = progress_slots.in_progress_episode_slots(
        page=page,
        limit=ctx.page_size,
        log_label='in_progress_episodes',
        widget=False,
        probe=probe,
    )
    c.log(
        f'[Progress] resume browse: page {page}  ->  {len(page_slots)} of {total} '
        f'(unchanged={unchanged})'
    )
    if not page_slots and page == 1:
        listing.emit_empty(handle, 'No in-progress episodes', 'episodes', ctx, cache=False)
        return
    next_url, next_label = listing.pagination_next(
        'progress_in_progress_episodes', page, total, ctx, page_size=ctx.page_size,
    )
    _render_resume_rows(handle, page_slots, ctx)
    listing.add_next_page(handle, next_url, next_label, ctx)
    listing.finish_directory(handle, 'episodes', ctx, cache=True)


def next_episodes(handle, params):
    ctx = listing.listing_context()
    if ctx.is_widget:
        next_episodes_widget(handle, ctx)
    else:
        next_episodes_browse(handle, listing.parse_page(params, ctx), ctx)


def _wetrakr_rate_limited():
    try:
        if not tracker.is_wetrakr():
            return False
        from ..apis import wetrakr as wt_api
        return wt_api.is_rate_limited()
    except Exception:
        return False


def next_episodes_widget(handle, ctx):
    c.log('[Progress] Next Episodes widget')
    if not _require_tracker(handle, 'episodes', ctx, f'Connect {tracker.display_label()} to see next episodes'):
        return
    rows = _read_prepared_widget_rows(widget_cache.ROUTE_NEXT_EPISODES)
    if rows:
        listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)
        listing.finish_directory(handle, 'episodes', ctx, cache=True)
        return

    # Cross-process 429 cooldown  -  do not rebuild (each Home widget is its
    # own LanguageInvoker; a rebuild storm is what trips WeTrakr).
    if _wetrakr_rate_limited():
        c.log('[Progress] widget: WeTrakr rate-limited  -  skip rebuild')
        listing.emit_empty(handle, 'No next episodes', 'episodes', ctx, cache=False)
        return

    browse_ctx = TVBrowseContext.load(log_label='next_episodes', clear_probe=True)
    top_slots, total, fp, unchanged = tracker.next_episode_sessions(
        limit=ctx.limit,
        log_label='next_episodes',
        widget=True,
        probe=browse_ctx.probe,
        watched=browse_ctx.watched,
    )
    c.log(
        f'[Progress] widget: {len(top_slots)} of {total} slots '
        f'(fp={fp[:8] + "..." if fp else " - "}, unchanged={unchanged})'
    )

    if not top_slots:
        # API miss / 429  -  keep last good prepared shelf instead of empty.
        stale = widget_cache.read_prepared_rows(
            widget_cache.ROUTE_NEXT_EPISODES, allow_stale=True,
        )
        if stale:
            c.log(
                f'[Progress] widget rebuild empty  -  serving stale prepared '
                f'({len(stale)} rows)'
            )
            listing.emit_video_rows(handle, stale, play_url, ctx, is_folder=False)
            listing.finish_directory(handle, 'episodes', ctx, cache=True)
            return
        listing.emit_empty(handle, 'No next episodes', 'episodes', ctx, cache=False)
        return

    rows = _render_episode_rows(handle, top_slots, ctx, browse_ctx=browse_ctx)
    widget_cache.save_after_widget_render(widget_cache.ROUTE_NEXT_EPISODES, fp, rows)
    listing.finish_directory(handle, 'episodes', ctx, cache=True)


def next_episodes_browse(handle, page, ctx):
    c.log(f'[Progress] Next Episodes browse page={page}')
    if not _require_tracker(handle, 'episodes', ctx, f'Connect {tracker.display_label()} to see next episodes'):
        return
    browse_ctx = TVBrowseContext.load(log_label='next_episodes', clear_probe=True)
    page_slots, total, fp, unchanged = tracker.next_episode_sessions(
        page=page,
        limit=ctx.page_size,
        log_label='next_episodes',
        widget=False,
        probe=browse_ctx.probe,
        watched=browse_ctx.watched,
    )
    c.log(
        f'[Progress] browse: page {page}  ->  {len(page_slots)} of {total} '
        f'(unchanged={unchanged})'
    )

    if not page_slots and page == 1:
        listing.emit_empty(handle, 'No next episodes', 'episodes', ctx, cache=False)
        return

    next_url, next_label = listing.pagination_next(
        'progress_next_episodes', page, total, ctx, page_size=ctx.page_size,
    )
    _render_episode_rows(handle, page_slots, ctx, browse_ctx=browse_ctx)
    listing.add_next_page(handle, next_url, next_label, ctx)
    listing.finish_directory(handle, 'episodes', ctx, cache=True)


def _render_episode_rows(handle, slots, ctx, browse_ctx=None):
    rows = [progress_slots.slot_to_video_row(slot) for slot in slots]
    if browse_ctx is not None:
        for row in rows:
            state = browse_ctx.apply_watch(row)
            if c.is_devmode():
                c.log(
                    f'[Watch] {row.tvshowtitle!r} S{row.season:02d}E{row.episode:02d} '
                    f'playcount={row.playcount} watched={state.watched}'
                )
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)
    return rows


def _render_resume_rows(handle, slots, ctx):
    rows = [progress_slots.slot_to_resume_row(slot) for slot in slots]
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, play_url, ctx, is_folder=False)
    return rows


def _render_show_rows(handle, slots, ctx, browse_ctx=None):
    rows = [progress_slots.slot_to_show_row(slot) for slot in slots]
    if browse_ctx is not None:
        states = browse_ctx.apply_watch_rows(rows)
        if c.is_devmode():
            for row, state in zip(rows, states):
                c.log(
                    f'[Watch] {row.tvshowtitle!r} tmdb={row.tmdb} '
                    f'playcount={row.playcount} watched={state.watched_count}/{state.aired}'
                )
    enrich_batch(rows, needs=NEEDS_PROGRESS, is_widget=ctx.enrich_widget)
    listing.emit_video_rows(handle, rows, _stub_seasons_url, ctx, is_folder=True)
    return rows


def _stub_seasons_url(row):
    query = urlencode({
        'action': 'seasons',
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': row.tvshowtitle or row.title,
    })
    return f'{sys.argv[0]}?{query}'

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file upnext.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Up Next  -  binge-watch dialog + autoplay for episodes.

Plugin and service are separate interpreters: arm via window properties from
play_stream; ClassyMonitor polls progress and queues the dialog for service-thread
doModal (RunPlugin is blocked during fullscreen playback).

Property namespace is thecrew.upnext.* (same as Crew 3.x)  -  Classy is the
working title for the plugin.video.thecrew 4.x rebrand.'''

from __future__ import annotations

import json
import threading
import time
from urllib.parse import quote_plus, urlencode

import xbmc

from ..kodi.dialog_base import ClassyDialogBase
from ..metadata.extract import image_url
from ..modules import control
from ..modules.classy import c
from ..play.mode import MODE_AUTOPLAY
from ..progress import next_episode as next_ep_mod

_PREFIX = 'thecrew.upnext.'
ACTIVE_PROP = _PREFIX + 'active'
DIALOG_PROP = _PREFIX + 'dialog.params'
DIALOG_PENDING_PROP = _PREFIX + 'dialog.pending'
PLUGIN_ID_PROP = _PREFIX + 'plugin_id'

_ARM_KEYS = ('title', 'year', 'imdb', 'tmdb', 'season', 'episode', 'tvshowtitle', 'content')

_dialog_lock = threading.Lock()
_dialog_showing = False
_play_lock = threading.Lock()
_last_play_time = 0.0


def _window():
    return control.homeWindow


def _plugin_owner():
    return (_window().getProperty(PLUGIN_ID_PROP) or '').strip()


def _owns_upnext():
    '''Require an explicit owner  -  empty plugin_id is not claimable (dual-install).'''
    owner = _plugin_owner()
    if not owner:
        return False
    return owner == c.addon_id


def _set_plugin_owner():
    _window().setProperty(PLUGIN_ID_PROP, c.addon_id)


def _clear_plugin_owner():
    _window().clearProperty(PLUGIN_ID_PROP)


def _is_future_air_date(air_date):
    '''True when YYYY-MM-DD is after today (unaired next episode).'''
    digits = ''.join(ch for ch in str(air_date or '') if ch.isdigit())
    if len(digits) < 8:
        return False
    try:
        from datetime import date

        air = date(int(digits[0:4]), int(digits[4:6]), int(digits[6:8]))
        return air > date.today()
    except (TypeError, ValueError):
        return False


def is_enabled():
    return str(control.setting('upnext.enabled') or 'true').lower() in ('true', '1')


def get_trigger_percent():
    try:
        return int(float(control.setting('upnext.trigger_percent') or 97))
    except (TypeError, ValueError):
        return 97


def get_countdown_seconds():
    try:
        return int(float(control.setting('upnext.countdown_seconds') or 15))
    except (TypeError, ValueError):
        return 15


def get_end_seconds():
    try:
        return int(float(control.setting('upnext.end_seconds') or 0))
    except (TypeError, ValueError):
        return 0


def get_timing_mode():
    '''0=Percentage, 1=Credits (IntroDB), 2=End seconds.'''
    try:
        return int(float(control.setting('upnext.timing_mode') or 0))
    except (TypeError, ValueError):
        return 0


def _credits_trigger_time(total_time):
    raw = _window().getProperty('thecrew.introdb.credits_start') or ''
    try:
        credits_start = float(raw)
    except (TypeError, ValueError):
        return None
    if credits_start <= 0 or total_time <= 0:
        return None
    countdown = get_countdown_seconds()
    dialog_at = credits_start - countdown
    return max(0.0, dialog_at)


def get_autoplay():
    return str(control.setting('upnext.autoplay') or 'true').lower() in ('true', '1')


def arm(request):
    '''Mark episode playback for service UpNext monitoring.'''
    if not is_enabled():
        return
    try:
        from ..tvevening.monitor import evening_blocks_upnext
        if evening_blocks_upnext():
            return
    except Exception:
        pass
    if request is None or not getattr(request, 'is_episode', False):
        return
    win = _window()
    mapping = {
        'title': getattr(request, 'tvshowtitle', None) or getattr(request, 'title', '') or '',
        'year': str(getattr(request, 'year', '') or ''),
        'imdb': str(getattr(request, 'imdb', '') or ''),
        'tmdb': str(getattr(request, 'tmdb', '') or ''),
        'season': str(int(getattr(request, 'season', 0) or 0)),
        'episode': str(int(getattr(request, 'episode', 0) or 0)),
        'tvshowtitle': getattr(request, 'tvshowtitle', '') or '',
        'content': 'episode',
    }
    for key, value in mapping.items():
        win.setProperty(_PREFIX + key, value)
    win.setProperty(ACTIVE_PROP, 'true')
    _set_plugin_owner()
    c.log(
        f'[UpNext] armed {mapping.get("title")} '
        f'S{mapping.get("season")}E{mapping.get("episode")} ({c.addon_id})',
    )


def disarm():
    win = _window()
    win.clearProperty(ACTIVE_PROP)
    for key in _ARM_KEYS:
        win.clearProperty(_PREFIX + key)


def clear_session():
    '''Full Up Next cleanup including dual-install owner tag.'''
    disarm()
    win = _window()
    win.clearProperty(DIALOG_PROP)
    win.clearProperty(DIALOG_PENDING_PROP)
    _clear_plugin_owner()


def armed_payload():
    win = _window()
    if win.getProperty(ACTIVE_PROP) != 'true':
        return None
    data = {key: win.getProperty(_PREFIX + key) or '' for key in _ARM_KEYS}
    if data.get('content') == 'movie':
        return None
    try:
        data['season'] = int(data.get('season') or 0)
        data['episode'] = int(data.get('episode') or 0)
    except (TypeError, ValueError):
        return None
    if data['season'] <= 0 or data['episode'] <= 0:
        return None
    return data


def should_trigger(current_time, total_time):
    '''True when playback is far enough for the Up Next dialog.'''
    if total_time <= 0 or current_time < 0:
        return False
    # Per-episode IntroDB credits start beats global percent/seconds when available.
    dialog_at = _credits_trigger_time(total_time)
    if dialog_at is not None:
        return current_time >= dialog_at
    mode = get_timing_mode()
    countdown = get_countdown_seconds()
    if mode == 2:
        end_seconds = get_end_seconds()
        if end_seconds > 0:
            dialog_at = total_time - end_seconds - countdown
            return current_time >= max(0.0, dialog_at)
        mode = 0
    end_seconds = get_end_seconds()
    if end_seconds > 0 and mode == 0:
        dialog_at = total_time - end_seconds - countdown
        return current_time >= max(0.0, dialog_at)
    percent = current_time / total_time
    return percent >= (get_trigger_percent() / 100.0)


def get_next_episode(imdb, tmdb, season, episode, tvshowtitle='', year=''):
    '''Resolve next S/E via next_episode + TMDB episode meta.'''
    resolved = next_ep_mod.resolve_next_season_episode(
        tmdb,
        season,
        episode,
        show_title=tvshowtitle or '',
    )
    if not resolved:
        return None

    next_season, next_episode = resolved
    from ..apis.tmdb import tmdb as tmdb_api

    ep_data = {}
    try:
        ep_data = tmdb_api.get_tv_episode(tmdb, next_season, next_episode) or {}
    except Exception as exc:
        c.log(f'[UpNext] episode meta failed: {exc}', 1)

    air_date = (ep_data.get('air_date') or '').strip()
    if air_date and _is_future_air_date(air_date):
        c.log(
            f'[UpNext] S{next_season:02d}E{next_episode:02d} unaired '
            f'({air_date})  -  skip',
        )
        return None

    poster = ''
    thumb = ''
    try:
        show = tmdb_api.get_tv(tmdb) or {}
        poster = image_url(show.get('poster_path'), size='w500')
    except Exception:
        pass
    if ep_data.get('still_path'):
        thumb = image_url(ep_data.get('still_path'), size='w500')

    return {
        'imdb': imdb or '',
        'tmdb': str(tmdb or ''),
        'season': next_season,
        'episode': next_episode,
        'tvshowtitle': tvshowtitle or '',
        'year': year or '',
        'title': ep_data.get('name') or f'Episode {next_episode}',
        'plot': ep_data.get('overview') or '',
        'premiered': air_date,
        'poster': poster,
        'thumb': thumb or poster,
    }


class UpNextDialog(ClassyDialogBase):
    XML_FILE = 'UpNext.xml'

    def __init__(self, *args, **kwargs):
        countdown_seconds = int(kwargs.pop('countdown_seconds', None) or 15)
        next_episode_data = kwargs.pop('next_episode_data', None) or {}
        autoplay = bool(kwargs.pop('autoplay', True))
        # WindowXML must construct before any self.* (service SWIG is strict)
        super().__init__(*args, **kwargs)
        self.action_taken = None
        self.countdown_seconds = countdown_seconds
        self.next_episode_data = next_episode_data
        self.autoplay = autoplay
        self.cancelled = False
        self._button_clicked = False
        self._countdown_thread = None

    def onInit(self):
        try:
            ep = self.next_episode_data
            self.set_properties({
                'upnext.show': ep.get('tvshowtitle', 'Unknown Show'),
                'upnext.title': ep.get('title', 'Unknown Episode'),
                'upnext.season': str(ep.get('season', '')),
                'upnext.episode': str(ep.get('episode', '')),
                'upnext.thumb': ep.get('thumb', ''),
                'upnext.poster': ep.get('poster', ''),
                'upnext.countdown': str(self.countdown_seconds),
            })
            c.log(
                f'[UpNext] dialog onInit '
                f'{ep.get("tvshowtitle")} S{ep.get("season")}E{ep.get("episode")}',
            )
            self._start_countdown()
        except Exception as exc:
            c.log(f'[UpNext] onInit error: {exc}', 1)

    def _start_countdown(self):
        self._countdown_thread = threading.Thread(target=self._countdown_loop, daemon=True)
        self._countdown_thread.start()

    def _countdown_loop(self):
        try:
            for i in range(self.countdown_seconds, 0, -1):
                if self.cancelled or self.action_taken is not None:
                    return
                self.setProperty('upnext.countdown', str(i))
                xbmc.sleep(1000)
            if self.autoplay and not self.cancelled and self.action_taken is None:
                self.action_taken = 'play'
                self.close()
        except Exception as exc:
            c.log(f'[UpNext] countdown error: {exc}', 1)

    def onClick(self, control_id):
        if self._button_clicked:
            return
        self._button_clicked = True
        if control_id == 100:
            self.cancelled = True
            self.action_taken = 'play'
            self.close()
        elif control_id == 101:
            self.cancelled = True
            self.action_taken = 'cancel'
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            if self._button_clicked:
                return
            self._button_clicked = True
            self.cancelled = True
            self.action_taken = 'cancel'
            self.close()


def request_upnext_dialog(payload):
    '''Queue dialog for ClassyMonitor service dispatch.'''
    try:
        _set_plugin_owner()
        # Start silent next-ep scrape while the current episode still plays.
        try:
            next_ep = get_next_episode(
                payload.get('imdb'),
                payload.get('tmdb'),
                int(payload.get('season') or 0),
                int(payload.get('episode') or 0),
                payload.get('tvshowtitle') or payload.get('title') or '',
                payload.get('year') or '',
            )
            if next_ep:
                from . import upnext_prescrape
                upnext_prescrape.start(next_ep)
        except Exception as scrape_exc:
            c.log(f'[UpNext] prescrape start failed: {scrape_exc}', 1)
        # A1c: drop stale sourceList under the player while credits/dialog run.
        try:
            from ..sources.directory import collapse_to_origin
            collapse_to_origin(reason='upnext_queue')
        except Exception:
            pass
        _window().setProperty(DIALOG_PROP, json.dumps(payload))
        _window().setProperty(DIALOG_PENDING_PROP, 'true')
        c.log(
            f'[UpNext] queued dialog '
            f'{payload.get("title")} '
            f'(current S{payload.get("season")}E{payload.get("episode")}; next at show)',
        )
    except Exception as exc:
        c.log(f'[UpNext] queue failed: {exc}', 1)


def dispatch_pending_dialog():
    '''Service-thread entry  -  show queued Up Next dialog.'''
    if not _owns_upnext():
        return False
    win = _window()
    if win.getProperty(DIALOG_PENDING_PROP) != 'true':
        return False
    win.clearProperty(DIALOG_PENDING_PROP)
    c.log('[UpNext] service dispatch  -  showing dialog')
    run_dialog_from_property()
    return True


def run_dialog_from_property():
    win = _window()
    raw = win.getProperty(DIALOG_PROP)
    win.clearProperty(DIALOG_PROP)
    if not raw:
        return
    try:
        data = json.loads(raw)
    except Exception as exc:
        c.log(f'[UpNext] bad dialog payload: {exc}', 1)
        return
    show_upnext_dialog(data)


def show_upnext_dialog(current):
    global _dialog_showing

    if not is_enabled():
        return None

    if not _dialog_lock.acquire(blocking=False):
        c.log('[UpNext] dialog already showing  -  skip')
        return None

    try:
        if _dialog_showing:
            return None
        _dialog_showing = True

        title = current.get('title') or current.get('tvshowtitle') or ''
        year = current.get('year') or ''
        imdb = current.get('imdb') or ''
        tmdb = current.get('tmdb') or ''
        season = int(current.get('season') or 0)
        episode = int(current.get('episode') or 0)
        tvshowtitle = current.get('tvshowtitle') or title

        next_ep = get_next_episode(imdb, tmdb, season, episode, tvshowtitle, year)
        if not next_ep:
            c.log('[UpNext] no next episode  -  skip dialog')
            return None

        # Prescrape is started in request_upnext_dialog (single call site).

        dialog = UpNextDialog.create(
            countdown_seconds=get_countdown_seconds(),
            next_episode_data=next_ep,
            autoplay=get_autoplay(),
        )
        dialog.doModal()
        action = dialog.action_taken
        try:
            dialog.close()
        except Exception:
            pass
        del dialog

        c.log(f'[UpNext] user action={action!r}')
        if action == 'play':
            play_next_episode(next_ep)
        else:
            clear_session()
        return action
    except Exception as exc:
        c.log(f'[UpNext] show dialog failed: {exc}', 1)
        clear_session()
        return None
    finally:
        _dialog_showing = False
        _dialog_lock.release()


def play_next_episode(episode_data):
    '''Stop current playback and RunPlugin the next episode play route.'''
    global _last_play_time

    if not _play_lock.acquire(blocking=False):
        c.log('[UpNext] play already in progress  -  skip')
        return

    try:
        now = time.time()
        if now - _last_play_time < 2.0:
            return
        _last_play_time = now

        params = {
            'action': 'play',
            'mediatype': 'episode',
            'title': episode_data.get('title') or '',
            'tvshowtitle': episode_data.get('tvshowtitle') or '',
            'year': episode_data.get('year') or '',
            'imdb': episode_data.get('imdb') or '',
            'tmdb': episode_data.get('tmdb') or '',
            'season': episode_data.get('season') or '',
            'episode': episode_data.get('episode') or '',
            'premiered': episode_data.get('premiered') or '',
        }
        if get_autoplay():
            params['select'] = str(MODE_AUTOPLAY)
            params['upnext'] = '1'
        meta = {
            'mediatype': 'episode',
            'title': params['title'],
            'tvshowtitle': params['tvshowtitle'],
            'year': params['year'],
            'imdb': params['imdb'],
            'tmdb': params['tmdb'],
            'season': params['season'],
            'episode': params['episode'],
            'premiered': params['premiered'],
            'poster': episode_data.get('poster') or '',
            'thumb': episode_data.get('thumb') or '',
            'plot': episode_data.get('plot') or '',
        }
        clean = {k: v for k, v in params.items() if v not in (None, '', 0)}
        query = urlencode(clean)
        blob = quote_plus(json.dumps(meta, separators=(',', ':')))
        url = f'plugin://{c.addon_id}/?{query}&meta={blob}'

        disarm()
        try:
            from . import session as playback_session

            win = _window()
            # Initiated handoff  -  prior episode must complete even if next play fails.
            win.setProperty(playback_session.UPNEXT_HANDOFF_PROP, '1')
            win.setProperty(playback_session.UPNEXT_COMPLETE_PROP, '1')
            stop_snap = playback_session.scrobble_snapshot()
            if stop_snap:
                win.setProperty(
                    playback_session.STOPPING_SCROBBLE_SNAPSHOT_PROP,
                    json.dumps(stop_snap),
                )
        except Exception:
            pass
        # A1c belt: ensure origin under player before next play starts.
        try:
            from ..sources.directory import collapse_to_origin
            collapse_to_origin(reason='upnext_handoff')
        except Exception:
            pass
        try:
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
                xbmc.sleep(500)
        except Exception:
            pass

        _set_plugin_owner()
        mode_note = 'autoplay' if get_autoplay() else 'hosts.mode'
        c.log(
            f'[UpNext] playing next '
            f'{params.get("tvshowtitle")} S{params.get("season")}E{params.get("episode")} '
            f'({mode_note})',
        )
        xbmc.executebuiltin(f'RunPlugin({url})')

    except Exception as exc:
        c.log(f'[UpNext] play_next failed: {exc}', 1)
    finally:
        _play_lock.release()


def service_tick(monitor):
    '''
    Called from ClassyMonitor each poll.

    When armed: watch xbmc.Player progress and queue the dialog at trigger.
    Always dispatch a pending dialog on the service thread.
    '''
    try:
        from ..tvevening.monitor import evening_blocks_upnext
        if evening_blocks_upnext():
            dispatch_pending_dialog()
            return
    except Exception:
        pass

    dispatch_pending_dialog()

    payload = armed_payload()
    if not payload:
        return

    player = xbmc.Player()
    if not player.isPlayingVideo():
        return

    # Dual-install: shared thecrew.upnext.* with Crew. If another plugin is
    # playing, do not fire Classy Up Next for a stale arm (#241 wrong-show).
    try:
        playing = player.getPlayingFile() or ''
    except Exception:
        playing = ''
    if playing.startswith('plugin://') and c.addon_id not in playing:
        c.log(f'[UpNext] foreign playback ({playing.split("?", 1)[0]})  -  disarm stale arm')
        disarm()
        return

    try:
        current = float(player.getTime() or 0)
        total = float(player.getTotalTime() or 0)
    except Exception:
        return

    if total <= 0:
        return

    if not should_trigger(current, total):
        return

    # One-shot for this arm  -  clear active before queue so we don't re-fire.
    disarm()
    request_upnext_dialog(payload)
    dispatch_pending_dialog()


def service_on_playback_ended():
    '''Fallback autoplay if dialog was still pending when the episode ended.'''
    try:
        from ..tvevening.monitor import evening_blocks_upnext
        if evening_blocks_upnext():
            return
    except Exception:
        pass
    if not _owns_upnext():
        return
    win = _window()
    if win.getProperty(DIALOG_PENDING_PROP) != 'true':
        return
    if not is_enabled() or not get_autoplay():
        win.clearProperty(DIALOG_PENDING_PROP)
        win.clearProperty(DIALOG_PROP)
        return

    raw = win.getProperty(DIALOG_PROP)
    win.clearProperty(DIALOG_PENDING_PROP)
    win.clearProperty(DIALOG_PROP)
    if not raw:
        return
    try:
        data = json.loads(raw)
    except Exception:
        return
    next_ep = get_next_episode(
        data.get('imdb'),
        data.get('tmdb'),
        int(data.get('season') or 0),
        int(data.get('episode') or 0),
        data.get('tvshowtitle') or data.get('title') or '',
        data.get('year') or '',
    )
    if next_ep:
        c.log('[UpNext] episode ended with pending dialog  -  autoplay fallback')
        play_next_episode(next_ep)

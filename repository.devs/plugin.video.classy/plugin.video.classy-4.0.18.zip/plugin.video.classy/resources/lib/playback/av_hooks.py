# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file av_hooks.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Post-AVStarted hooks: preferred audio + subtitle fetch (background).'''

import threading

from ..modules.classy import c
from . import session as playback_session
from . import audio_tracks
from . import subtitles as subtitles_mod


def on_av_started(player):
    '''Run after resume seek on onAVStarted.'''
    sess = playback_session.load()
    if not sess:
        return

    try:
        audio_tracks.select_preferred_audio(player)
    except Exception as exc:
        c.log(f'[AVHooks] audio track failed: {exc}', 1)

    thread = threading.Thread(
        target=subtitles_mod.fetch_for_session,
        args=(dict(sess),),
        name='classy-subtitles',
        daemon=True,
    )
    thread.start()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file session.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Window-property playback session  -  shared between play route and service player.'''

import json
import os

import xbmcgui

from ..modules.client import addon_data_path

# Session field prefix. New writes use thecrew.*; classy.* kept as read fallback
# during dual-install soak / migration (see docs/architecture-audit/WINDOW_PROPS.md).
_PREFIX = 'thecrew.playback.session.'
_PREFIX_LEGACY = 'classy.playback.'

# Set before Up Next stop(); cleared on onAVStarted after hooks.
UPNEXT_HANDOFF_PROP = 'thecrew.playback.upnext_handoff'
# Set with handoff when Up Next actually initiates next play (not dialog-only).
UPNEXT_COMPLETE_PROP = 'thecrew.playback.upnext_complete'

# Cross-interpreter playback helpers (plugin play(), service callbacks).
POS_TRACKER_PROP = 'thecrew.playback.pos_tracker'
TEARDOWN_LOCK_PROP = 'thecrew.playback.teardown_lock'
RESUME_APPLIED_PROP = 'thecrew.playback.resume_applied'
PLAY_SEQ_PROP = 'thecrew.playback.play_seq'
SCROBBLE_SNAPSHOT_PROP = 'thecrew.playback.scrobble_snapshot'
# Frozen at Up Next stop()  -  late Stop scrobbles this, must not teardown the next play.
STOPPING_SCROBBLE_SNAPSHOT_PROP = 'thecrew.playback.stopping_snapshot'
INTRO_RESET_PENDING_PROP = 'thecrew.introskip.reset_pending'
OWNER_PROP = 'thecrew.playback.plugin_id'
_PERSIST_FILENAME = 'playback_session.json'

_FIELDS = (
    'mediatype', 'title', 'year', 'imdb', 'tmdb', 'tvdb', 'trakt',
    'season', 'episode', 'tvshowtitle', 'resume_offset', 'resume_progress',
    'playback_id', 'duration',
)


def _window():
    return xbmcgui.Window(10000)


def _persist_path():
    return os.path.join(addon_data_path(), _PERSIST_FILENAME)


def _write_persisted(data):
    if not isinstance(data, dict) or not data:
        return
    try:
        profile = addon_data_path()
        if profile and not os.path.isdir(profile):
            os.makedirs(profile)
        path = _persist_path()
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, separators=(',', ':'))
    except Exception:
        pass


def _read_persisted():
    try:
        path = _persist_path()
        if not os.path.isfile(path):
            return {}
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _clear_persisted():
    try:
        path = _persist_path()
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass


def _prop_get(win, key):
    value = win.getProperty(_PREFIX + key) or ''
    if value:
        return value
    return win.getProperty(_PREFIX_LEGACY + key) or ''


def _prop_clear_both(win, key):
    win.clearProperty(_PREFIX + key)
    win.clearProperty(_PREFIX_LEGACY + key)


def set_plugin_owner():
    try:
        from ..modules.classy import c
        _window().setProperty(OWNER_PROP, str(c.addon_id or ''))
    except Exception:
        pass


def clear_plugin_owner():
    try:
        _window().clearProperty(OWNER_PROP)
    except Exception:
        pass


def owns_playback():
    '''True when this addon owns thecrew.playback.* (empty owner = foreign/stale).'''
    try:
        from ..modules.classy import c
        owner = (_window().getProperty(OWNER_PROP) or '').strip()
        if not owner:
            return False
        return owner == str(c.addon_id or '')
    except Exception:
        return False


def _apply_snapshot(data):
    win = _window()
    for key in _FIELDS:
        value = data.get(key)
        if value not in (None, ''):
            win.setProperty(_PREFIX + key, str(value))
            win.clearProperty(_PREFIX_LEGACY + key)
    win.setProperty(_PREFIX + 'active', '1')
    win.clearProperty(_PREFIX_LEGACY + 'active')
    seq = str(data.get('play_seq') or data.get('playseq') or '1')
    win.setProperty(PLAY_SEQ_PROP, seq)
    win.clearProperty('classy.playback.play_seq')
    set_plugin_owner()
    try:
        win.setProperty(SCROBBLE_SNAPSHOT_PROP, json.dumps(dict(data)))
        win.clearProperty('classy.playback.scrobble_snapshot')
    except Exception:
        pass


def _snapshot_matches_player(data, player):
    try:
        tag = player.getVideoInfoTag()
    except Exception:
        return True
    try:
        snap_mt = (data.get('mediatype') or '').lower()
        mt = (tag.getMediaType() or '').lower()
        if mt and snap_mt and mt != snap_mt:
            return False
        unique = tag.getUniqueIDs() or {}
        tmdb = unique.get('tmdb')
        if tmdb and data.get('tmdb') and str(tmdb) != str(data.get('tmdb')):
            return False
        imdb = unique.get('imdb') or ''
        if imdb and data.get('imdb'):
            snap_imdb = str(data.get('imdb') or '')
            if not snap_imdb.startswith('tt'):
                snap_imdb = 'tt%s' % snap_imdb
            if str(imdb) != snap_imdb:
                return False
        if snap_mt == 'episode' or mt == 'episode':
            if tag.getSeason() and data.get('season'):
                if int(tag.getSeason()) != int(data.get('season')):
                    return False
            if tag.getEpisode() and data.get('episode'):
                if int(tag.getEpisode()) != int(data.get('episode')):
                    return False
    except Exception:
        return True
    return True


def _tag_str(tag, *method_names):
    '''InfoTag getters differ by Kodi version (e.g. getTVShowTitle vs getTvShowTitle).'''
    for name in method_names:
        fn = getattr(tag, name, None)
        if not callable(fn):
            continue
        try:
            value = fn()
        except Exception:
            continue
        if value is None:
            return ''
        return value if isinstance(value, str) else str(value)
    return ''


def _hydrate_from_player(player):
    try:
        tag = player.getVideoInfoTag()
    except Exception:
        return {}
    try:
        unique = tag.getUniqueIDs() or {}
    except Exception:
        unique = {}
    imdb = str(unique.get('imdb') or '').strip()
    if imdb.startswith('tt'):
        imdb = imdb[2:]
    tmdb = unique.get('tmdb')
    tvdb = unique.get('tvdb')
    mt = (_tag_str(tag, 'getMediaType') or '').lower()
    season = 0
    episode = 0
    try:
        season = int(tag.getSeason() or 0)
    except Exception:
        season = 0
    try:
        episode = int(tag.getEpisode() or 0)
    except Exception:
        episode = 0
    if mt not in ('movie', 'episode'):
        mt = 'episode' if season or episode else 'movie'
    year = ''
    try:
        year = str(tag.getYear() or '')
    except Exception:
        year = ''
    duration = 0
    try:
        duration = int(tag.getDuration() or 0)
    except Exception:
        duration = 0
    data = {
        'mediatype': mt,
        'title': _tag_str(tag, 'getTitle'),
        'year': year,
        'imdb': imdb,
        'tmdb': str(tmdb or ''),
        'tvdb': str(tvdb or ''),
        'trakt': '',
        'season': str(season),
        'episode': str(episode),
        'tvshowtitle': _tag_str(tag, 'getTVShowTitle', 'getTvShowTitle', 'getShowTitle'),
        'resume_offset': '0',
        'resume_progress': '0',
        'playback_id': '',
        'duration': str(duration),
    }
    if not data.get('imdb') and not data.get('tmdb'):
        return {}
    return data


def restore_if_needed(player):
    '''Rehydrate session after Kodi restart when video is still playing.'''
    if load():
        return False
    data = _read_persisted()
    if data and player and not _snapshot_matches_player(data, player):
        data = {}
    if not data and player:
        data = _hydrate_from_player(player)
    if not data:
        return False
    if not data.get('imdb') and not data.get('tmdb'):
        return False
    _apply_snapshot(data)
    return True


def current_play_seq():
    win = _window()
    return win.getProperty(PLAY_SEQ_PROP) or win.getProperty('classy.playback.play_seq') or ''


def store(request, resume=None):
    '''Persist active playback metadata for ClassyPlayer callbacks.'''
    win = _window()
    resume = resume or {}
    mediatype = 'episode' if getattr(request, 'is_episode', False) else 'movie'
    mapping = {
        'mediatype': mediatype,
        'title': getattr(request, 'title', '') or '',
        'year': str(getattr(request, 'year', '') or ''),
        'imdb': str(getattr(request, 'imdb', '') or ''),
        'tmdb': str(getattr(request, 'tmdb', '') or ''),
        'tvdb': str(getattr(request, 'tvdb', '') or ''),
        'trakt': str(getattr(request, 'trakt', '') or ''),
        'season': str(int(getattr(request, 'season', 0) or 0)),
        'episode': str(int(getattr(request, 'episode', 0) or 0)),
        'tvshowtitle': getattr(request, 'tvshowtitle', '') or '',
        'resume_offset': str(float(resume.get('resume_seconds') or 0)),
        'resume_progress': str(float(resume.get('progress') or 0)),
        'playback_id': str(resume.get('playback_id') or ''),
        'duration': str(int(resume.get('duration') or 0)),
    }
    for key, value in mapping.items():
        win.setProperty(_PREFIX + key, value)
        win.clearProperty(_PREFIX_LEGACY + key)
    try:
        seq = int(current_play_seq() or '0') + 1
    except (TypeError, ValueError):
        seq = 1
    win.setProperty(PLAY_SEQ_PROP, str(seq))
    win.clearProperty('classy.playback.play_seq')
    win.setProperty(_PREFIX + 'active', '1')
    win.clearProperty(_PREFIX_LEGACY + 'active')
    set_plugin_owner()
    win.clearProperty(RESUME_APPLIED_PROP)
    win.clearProperty(TEARDOWN_LOCK_PROP)
    win.clearProperty(UPNEXT_COMPLETE_PROP)
    try:
        snapshot = dict(load())
        snapshot['play_seq'] = str(seq)
        win.setProperty(SCROBBLE_SNAPSHOT_PROP, json.dumps(snapshot))
        win.clearProperty('classy.playback.scrobble_snapshot')
        _write_persisted(snapshot)
    except Exception:
        pass


def scrobble_snapshot():
    '''Episode metadata frozen at store()  -  survives cross-interpreter stop.'''
    win = _window()
    raw = win.getProperty(SCROBBLE_SNAPSHOT_PROP) or ''
    if not raw:
        raw = win.getProperty('classy.playback.scrobble_snapshot') or ''
    if raw:
        try:
            data = json.loads(raw)
            if isinstance(data, dict) and data:
                return data
        except Exception:
            pass
    data = load()
    if data:
        return data
    return _read_persisted()


def load():
    '''Return session dict; empty strings when inactive.'''
    win = _window()
    active = win.getProperty(_PREFIX + 'active') or win.getProperty(_PREFIX_LEGACY + 'active')
    if active != '1':
        return {}
    data = {}
    for key in _FIELDS:
        data[key] = _prop_get(win, key)
    return data


def clear():
    win = _window()
    for key in _FIELDS:
        _prop_clear_both(win, key)
    win.clearProperty(_PREFIX + 'active')
    win.clearProperty(_PREFIX_LEGACY + 'active')
    win.clearProperty(SCROBBLE_SNAPSHOT_PROP)
    win.clearProperty('classy.playback.scrobble_snapshot')
    win.clearProperty(RESUME_APPLIED_PROP)
    win.clearProperty(POS_TRACKER_PROP)
    win.clearProperty(TEARDOWN_LOCK_PROP)
    win.clearProperty(STOPPING_SCROBBLE_SNAPSHOT_PROP)
    win.clearProperty(UPNEXT_COMPLETE_PROP)
    win.clearProperty(PLAY_SEQ_PROP)
    win.clearProperty('classy.playback.play_seq')
    win.setProperty(INTRO_RESET_PENDING_PROP, '1')
    _clear_persisted()
    try:
        from . import service_hooks
        win.clearProperty(service_hooks.AV_HOOKS_PENDING_PROP)
        win.clearProperty(service_hooks.AV_HOOKS_DONE_SEQ_PROP)
    except Exception:
        pass

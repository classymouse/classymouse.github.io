# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file outcome.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Central playback-outcome policy (pure decisions, no xbmc).

Separates:
  - actual position (what the user reached)
  - reported progress (what trackers receive)
  - watched / clear-resume flags
  - whether Kodi playback should stop (never implied by watched alone)
'''

from __future__ import annotations

from dataclasses import dataclass

# Near-end Stop with a reliable clock: treat as finished (credits / natural stop).
# Not a substitute for playback.watched_percent on mid-title Stop.
NEAR_END_REMAINING_SEC = 45.0
MIN_TOTAL_FOR_NEAR_END = 60.0


@dataclass(frozen=True)
class PlaybackOutcome:
    '''Result of interpreting a playback event for trackers / resume.'''

    action: str
    actual_current: float
    actual_total: float
    reported_current: float
    percent: float
    counts_as_watched: bool
    clear_resume: bool
    force_complete: bool
    reason: str
    # Watched never implies stopping local playback.
    stop_playback: bool = False

    def as_scrobble_times(self):
        return self.reported_current, self.actual_total


def _clamp_percent(current, total):
    try:
        current = float(current or 0)
        total = float(total or 0)
    except (TypeError, ValueError):
        return 0.0, 0.0, 0.0
    if total <= 0:
        return max(0.0, current), 0.0, 0.0
    current = max(0.0, min(current, total))
    percent = (current / total) * 100.0
    return current, total, max(0.0, min(100.0, percent))


def watched_threshold(watched_percent):
    try:
        value = float(watched_percent)
    except (TypeError, ValueError):
        value = 92.0
    return max(80.0, min(99.0, value))


def resolve_outcome(
    *,
    action,
    current,
    total,
    watched_percent=92.0,
    event='normal',
):
    '''
    Decide reported progress and watched/clear-resume flags.

    action: 'start' | 'pause' | 'stop'
    event (for stop):
      'normal'             - manual Stop / pause-driven stop
      'ended'              - Kodi onPlayBackEnded
      'upnext_handoff'     - Up Next accepted / autoplay started next
      'evening_transition' - TV Evening advancing to next slot
    '''
    action = (action or 'stop').lower()
    event = (event or 'normal').lower()
    threshold = watched_threshold(watched_percent)
    actual_current, actual_total, percent = _clamp_percent(current, total)

    force_complete = False
    reason = 'actual'

    if action == 'stop':
        if event in ('ended', 'upnext_handoff', 'evening_transition'):
            force_complete = True
            reason = event
        elif (
            actual_total >= MIN_TOTAL_FOR_NEAR_END
            and actual_current > 0
            and (actual_total - actual_current) <= NEAR_END_REMAINING_SEC
        ):
            # Reliable near-end Stop (credits / last seconds)  -  not the old 85% rule.
            force_complete = True
            reason = 'near_end'

    reported_current = actual_total if force_complete and actual_total > 0 else actual_current
    if force_complete and actual_total > 0:
        percent = 100.0

    counts_as_watched = False
    if action in ('pause', 'stop') and actual_total > 0:
        counts_as_watched = force_complete or percent >= threshold

    clear_resume = bool(counts_as_watched and action == 'stop')

    return PlaybackOutcome(
        action=action,
        actual_current=actual_current,
        actual_total=actual_total,
        reported_current=reported_current,
        percent=round(percent, 2),
        counts_as_watched=counts_as_watched,
        clear_resume=clear_resume,
        force_complete=force_complete,
        reason=reason,
        stop_playback=False,
    )


def salvage_position(live_current, live_total, last_current, last_total, *, min_keep_sec=15.0):
    '''
    Recover position when Kodi collapses getTime() on Stop/Pause.

    Returns (current, total). Does not decide watched status.
    '''
    try:
        live_current = float(live_current or 0)
    except (TypeError, ValueError):
        live_current = 0.0
    try:
        live_total = float(live_total or 0)
    except (TypeError, ValueError):
        live_total = 0.0
    try:
        last_current = float(last_current or 0)
    except (TypeError, ValueError):
        last_current = 0.0
    try:
        last_total = float(last_total or 0)
    except (TypeError, ValueError):
        last_total = 0.0

    total = live_total if live_total > 0 else last_total
    current = live_current
    if live_current < min_keep_sec and last_current >= min_keep_sec:
        current = last_current
    if current <= 0 and last_current > 0:
        current = last_current
    return current, total


def tracker_report_percent(outcome, *, trakt_complete_as_100=False):
    '''
    Percent body for a tracker adapter.

    Trakt often needs 100 on completion events because of its server threshold.
    Simkl/WeTrakr receive the policy percent; WeTrakr also gets min_progress query.
    '''
    if outcome is None:
        return 0.0
    if trakt_complete_as_100 and outcome.counts_as_watched and outcome.action == 'stop':
        return 100.0
    return float(outcome.percent)

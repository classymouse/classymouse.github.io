# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resume_prompt.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Auto-resume setting + yes/no resume dialog (Crew bookmarks.auto parity).'''

import threading

import xbmc
import xbmcgui

from ..modules.classy import c

# Ignore accidental early pauses (buffer / dialog)  -  not real mid-watch progress.
MIN_RESUME_SECONDS = 30.0


def autoresume_enabled():
    '''Default on  -  matches behaviour before this setting existed.'''
    value = c.get_setting('playback.autoresume')
    if value is None or value == '':
        return True
    return str(value).lower() != 'false'


def _format_offset(seconds):
    seconds = max(0.0, float(seconds or 0))
    mins, secs = divmod(int(seconds), 60)
    hours, mins = divmod(mins, 60)
    return f'{int(hours):02d}:{int(mins):02d}:{int(secs):02d}'


def _is_paused():
    try:
        return bool(xbmc.getCondVisibility('Player.Paused'))
    except Exception:
        return False


def _ensure_playing(player):
    '''Unpause only when actually paused  -  bare pause() toggles and can stick.'''
    if not _is_paused():
        return
    try:
        player.pause()
    except Exception:
        pass


def _ensure_paused(player):
    if _is_paused():
        return
    try:
        player.pause()
    except Exception:
        pass


def _prompt_resume(offset):
    time_label = _format_offset(offset)
    try:
        body = c.lang(90225) % time_label
    except Exception:
        body = f'Resume playback from {time_label}?'
    try:
        from .. import tracker
        from ..trakt import auth as trakt_auth
        from ..simkl import auth as simkl_auth
        from ..apis import wetrakr

        label = tracker.display_label()
        if tracker.is_trakt() and trakt_auth.scrobble_enabled() and trakt_auth.has_credentials():
            body += f'[CR][I]{label} scrobble is enabled[/I]'
        elif tracker.is_simkl() and simkl_auth.scrobble_enabled() and simkl_auth.has_credentials():
            body += f'[CR][I]{label} scrobble is enabled[/I]'
        elif tracker.is_wetrakr() and wetrakr.has_credentials():
            body += f'[CR][I]{label} scrobble is enabled[/I]'
        # Sidecar  -  not XOR; only alongside Trakt/Simkl (not when WeTrakr is home).
        if (
            not tracker.is_wetrakr()
            and wetrakr.scrobble_enabled()
            and wetrakr.has_credentials()
        ):
            body += '[CR][I]WeTrakr scrobble is enabled[/I]'
    except Exception:
        pass
    try:
        heading = c.lang(90226)
    except Exception:
        heading = 'Resume Playback'
    try:
        yeslabel = c.lang(90227)
    except Exception:
        yeslabel = 'Resume'
    try:
        nolabel = c.lang(90228)
    except Exception:
        nolabel = 'From Start'
    defaultbutton = getattr(xbmcgui, 'DLG_YESNO_YES_BTN', None)
    return c.yesnoDialog(
        body,
        heading=heading,
        yeslabel=yeslabel,
        nolabel=nolabel,
        defaultbutton=defaultbutton,
    )


def _wait_for_playable(player, max_wait=60):
    '''Crew parity  -  wait until Kodi reports active video before seeking.'''
    for _ in range(max_wait):
        try:
            if player.isPlayingVideo():
                xbmc.sleep(1000)
                return True
        except Exception:
            pass
        xbmc.sleep(1000)
    return False


def _seek_ok(current, target):
    '''True when getTime() landed near the resume target.

    Old floor of max(15, 5% target) made every sub-15s resume look like a miss
    (already-at-11s kept retrying, then the post-dialog pause stuck playback).
    '''
    current = float(current or 0)
    target = float(target or 0)
    if target <= 0:
        return current <= 2.0
    if abs(current - target) <= max(5.0, target * 0.05):
        return True
    # Overshoot past target still counts (CDN often lands a little late).
    if current >= target and current <= target + max(30.0, target * 0.1):
        return True
    return False


def _seek_to(player, offset):
    '''Seek with short retries  -  debrid CDN streams often ignore an immediate seek.'''
    target = max(0.0, float(offset or 0))
    for attempt in range(3):
        try:
            player.seekTime(target)
            xbmc.sleep(1500)
            current = float(player.getTime() or 0)
            if _seek_ok(current, target):
                c.log(f'[Playback] seek ok target={target:.0f}s at={current:.0f}s')
                return True
            if attempt < 2:
                c.log(
                    f'[Playback] seek retry {attempt + 1} '
                    f'target={target:.0f}s at={current:.0f}s',
                    1,
                )
        except Exception as exc:
            c.log(f'[Playback] resume seek failed: {exc}', 1)
        xbmc.sleep(2000)
    return False


def _prompt_evening_resume(offset, progress=0):
    """Ask on fresh evening slots that already have a mid-watch bookmark."""
    time_label = _format_offset(offset)
    try:
        pct = int(float(progress or 0))
    except (TypeError, ValueError):
        pct = 0
    if pct > 0:
        body = (
            f'This episode is {pct}% watched ({time_label}).\n\n'
            f'Resume where you left off, or start from the beginning?'
        )
    else:
        body = f'Resume from {time_label}, or start from the beginning?'
    return c.yesnoDialog(
        body,
        heading='TV Evening',
        yeslabel='Resume',
        nolabel='From Start',
        defaultbutton=getattr(xbmcgui, 'DLG_YESNO_NO_BTN', None),
    )


def _apply_resume_job(player, offset, *, evening_prompt=False, progress=0, force_auto=False):
    if not _wait_for_playable(player):
        c.log('[Playback] resume skipped  -  playback not ready in time', 1)
        return

    if evening_prompt:
        _ensure_paused(player)
        resume = _prompt_evening_resume(offset, progress=progress)
        try:
            if resume:
                c.log(f'[Playback] TV Evening user resume at {offset:.0f}s')
                _seek_to(player, offset)
            else:
                c.log('[Playback] TV Evening user chose start from beginning')
                _seek_to(player, 0.0)
        except Exception as exc:
            c.log(f'[Playback] TV Evening resume failed: {exc}', 1)
        xbmc.sleep(500)
        _ensure_playing(player)
        try:
            from ..modules import control
            control.window.clearProperty('thecrew.tvevening.resume_prompt')
        except Exception:
            pass
        return

    if force_auto or autoresume_enabled():
        c.log(f'[Playback] auto-resume at {offset:.0f}s')
        if not _seek_to(player, offset):
            c.log(f'[Playback] auto-resume failed at {offset:.0f}s', 1)
        return

    _ensure_paused(player)

    resume = _prompt_resume(offset)
    try:
        if resume:
            c.log(f'[Playback] user resume at {offset:.0f}s')
            _seek_to(player, offset)
        else:
            c.log('[Playback] user chose start from beginning')
            _seek_to(player, 0.0)
    except Exception as exc:
        c.log(f'[Playback] resume seek failed: {exc}', 1)

    xbmc.sleep(500)
    _ensure_playing(player)


def apply_resume_offset(player, offset, *, evening_prompt=False, progress=0, force_auto=False):
    '''Seek once after playback is running  -  auto or prompt per settings.'''
    try:
        offset = float(offset or 0)
    except (TypeError, ValueError):
        offset = 0.0
    if offset < MIN_RESUME_SECONDS:
        if offset > 0:
            c.log(f'[Playback] resume skipped  -  offset {offset:.0f}s below {MIN_RESUME_SECONDS:.0f}s floor')
        return

    threading.Thread(
        target=_apply_resume_job,
        args=(player, offset),
        kwargs={
            'evening_prompt': evening_prompt,
            'progress': progress,
            'force_auto': force_auto,
        },
        daemon=True,
        name='classy-resume',
    ).start()

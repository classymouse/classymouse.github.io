# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file intro_skip_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Netflix-style Skip Intro prompt (service-thread doModal).'''

import json
import threading

import xbmc

from ..kodi.dialog_base import ClassyDialogBase
from ..modules import control
from ..modules.classy import c
from . import intro_skip as intro_skip_mod

PENDING_PROP = intro_skip_mod.PENDING_PROP
PARAMS_PROP = intro_skip_mod.PARAMS_PROP
RESULT_PROP = intro_skip_mod.RESULT_PROP


class IntroSkipDialog(ClassyDialogBase):
    XML_FILE = 'IntroSkip.xml'

    def __init__(self, *args, **kwargs):
        countdown_seconds = int(kwargs.pop('countdown_seconds', 15) or 15)
        super().__init__(*args, **kwargs)
        self.countdown_seconds = countdown_seconds
        self.action_taken = None
        self.cancelled = False
        self._button_clicked = False
        self._countdown_thread = None

    def onInit(self):
        try:
            self.setProperty('introskip.countdown', str(self.countdown_seconds))
            self._countdown_thread = threading.Thread(
                target=self._countdown_loop,
                daemon=True,
            )
            self._countdown_thread.start()
        except Exception as exc:
            c.log(f'[IntroSkip] dialog onInit failed: {exc}', 1)

    def _countdown_loop(self):
        try:
            for remaining in range(self.countdown_seconds, 0, -1):
                if self.cancelled or self.action_taken is not None:
                    return
                self.setProperty('introskip.countdown', str(remaining))
                xbmc.sleep(1000)
            if not self.cancelled and self.action_taken is None:
                self.action_taken = 'timeout'
                self.close()
        except Exception as exc:
            c.log(f'[IntroSkip] countdown failed: {exc}', 1)

    def onClick(self, control_id):
        if self._button_clicked:
            return
        self._button_clicked = True
        self.cancelled = True
        if control_id == 100:
            self.action_taken = 'skip'
        else:
            self.action_taken = 'dismiss'
        self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            if self._button_clicked:
                return
            self._button_clicked = True
            self.cancelled = True
            self.action_taken = 'dismiss'
            self.close()


def dispatch_pending_dialog():
    win = control.homeWindow
    if win.getProperty(PENDING_PROP) != 'true':
        return False
    raw = win.getProperty(PARAMS_PROP) or '{}'
    try:
        params = json.loads(raw)
    except Exception:
        params = {}
    win.clearProperty(PENDING_PROP)
    countdown = int(params.get('countdown') or 15)
    try:
        dialog = IntroSkipDialog.create(countdown_seconds=countdown)
        dialog.doModal()
        action = dialog.action_taken or 'dismiss'
        try:
            dialog.close()
        except Exception:
            pass
        del dialog
        if action == 'skip':
            win.setProperty(RESULT_PROP, 'skip')
        elif action == 'timeout':
            win.setProperty(RESULT_PROP, 'timeout')
        else:
            win.setProperty(RESULT_PROP, 'dismiss')
        c.log(f'[IntroSkip] prompt result={action!r}')
        return True
    except Exception as exc:
        c.log(f'[IntroSkip] dialog failed: {exc}', 1)
        win.setProperty(RESULT_PROP, 'dismiss')
        return False

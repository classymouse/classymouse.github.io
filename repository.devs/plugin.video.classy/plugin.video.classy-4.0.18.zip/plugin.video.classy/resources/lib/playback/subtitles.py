# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file subtitles.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

OpenSubtitles.com REST v1 subtitle fetch + load on play.'''

import gzip
import json
import os
import re
import time
import traceback
from io import BytesIO

import requests
import xbmc

from ..kodi import kodi_locale
from ..modules import control
from ..modules.classy import c

API_URL = 'https://api.opensubtitles.com/api/v1'
USER_AGENT = 'The Crew'

# subtitles.mode: 0=Follow Kodi, 1=Always on, 2=Off
MODE_FOLLOW_KODI = 0
MODE_ALWAYS_ON = 1
MODE_OFF = 2

LANG_DICT = {
    'Afrikaans': 'af', 'Albanian': 'sq', 'Arabic': 'ar', 'Armenian': 'hy', 'Basque': 'eu',
    'Bengali': 'bn', 'Bosnian': 'bs', 'Breton': 'br', 'Bulgarian': 'bg', 'Burmese': 'my',
    'Catalan': 'ca', 'Chinese': 'zh', 'Croatian': 'hr', 'Czech': 'cs', 'Danish': 'da', 'Dutch': 'nl',
    'English': 'en', 'Esperanto': 'eo', 'Estonian': 'et', 'Finnish': 'fi', 'French': 'fr',
    'Galician': 'gl', 'Georgian': 'ka', 'German': 'de', 'Greek': 'el', 'Hebrew': 'he', 'Hindi': 'hi',
    'Hungarian': 'hu', 'Icelandic': 'is', 'Indonesian': 'id', 'Italian': 'it', 'Japanese': 'ja',
    'Kazakh': 'kk', 'Khmer': 'km', 'Korean': 'ko', 'Latvian': 'lv', 'Lithuanian': 'lt',
    'Luxembourgish': 'lb', 'Macedonian': 'mk', 'Malay': 'ms', 'Malayalam': 'ml', 'Manipuri': 'mni',
    'Mongolian': 'mn', 'Montenegrin': 'me', 'Norwegian': 'no', 'Occitan': 'oc', 'Persian': 'fa',
    'Polish': 'pl', 'Portuguese': 'pt', 'Portuguese(Brazil)': 'pb', 'Romanian': 'ro',
    'Russian': 'ru', 'Serbian': 'sr', 'Sinhalese': 'si', 'Slovak': 'sk', 'Slovenian': 'sl',
    'Spanish': 'es', 'Swahili': 'sw', 'Swedish': 'sv', 'Syriac': 'syr', 'Tagalog': 'tl', 'Tamil': 'ta',
    'Telugu': 'te', 'Thai': 'th', 'Turkish': 'tr', 'Ukrainian': 'uk', 'Urdu': 'ur',
}

LANG_CODE_MAP = {
    'dut': 'nl', 'eng': 'en', 'fre': 'fr', 'ger': 'de', 'spa': 'es',
    'por': 'pt', 'ita': 'it', 'rus': 'ru', 'ara': 'ar', 'heb': 'he',
    'nld': 'nl', 'deu': 'de', 'fra': 'fr',
}

# Kodi locale.subtitlelanguage (ISO 639-2) -> settings picklist name
KODI_LANG_TO_NAME = {
    'eng': 'English', 'dut': 'Dutch', 'nld': 'Dutch', 'deu': 'German', 'ger': 'German',
    'fre': 'French', 'fra': 'French', 'spa': 'Spanish', 'ita': 'Italian', 'por': 'Portuguese',
    'rus': 'Russian', 'ara': 'Arabic', 'heb': 'Hebrew', 'pol': 'Polish', 'tur': 'Turkish',
    'swe': 'Swedish', 'nor': 'Norwegian', 'dan': 'Danish', 'fin': 'Finnish', 'cze': 'Czech',
    'ces': 'Czech', 'hun': 'Hungarian', 'rum': 'Romanian', 'ron': 'Romanian', 'bul': 'Bulgarian',
    'hrv': 'Croatian', 'srp': 'Serbian', 'slv': 'Slovenian', 'slk': 'Slovak', 'ukr': 'Ukrainian',
    'jpn': 'Japanese', 'kor': 'Korean', 'zho': 'Chinese', 'chi': 'Chinese',
}

SUBTITLE_LANG_OPTIONS = [
    'English', 'Dutch', 'German', 'French', 'Spanish', 'Italian', 'Portuguese',
    'Portuguese(Brazil)', 'Russian', 'Polish', 'Arabic', 'Chinese', 'Japanese', 'Korean', 'Turkish',
]

PLAYBACK_SETTLE_SEC = 3
PLAYBACK_READY_MAX_WAIT = 22


def _wait_for_playback_ready():
    '''CDN / Up Next handoff: wait until duration and playhead are stable before subs.'''
    deadline = time.time() + PLAYBACK_READY_MAX_WAIT
    last_time = -1.0
    stable_reads = 0
    while time.time() < deadline:
        player = xbmc.Player()
        try:
            if not player.isPlayingVideo():
                stable_reads = 0
                time.sleep(0.4)
                continue
            total = float(player.getTotalTime() or 0)
            curr = float(player.getTime() or 0)
        except Exception:
            stable_reads = 0
            time.sleep(0.4)
            continue
        if total < 30 or curr < 0:
            stable_reads = 0
            time.sleep(0.4)
            continue
        if last_time >= 0 and abs(curr - last_time) < 0.75:
            stable_reads += 1
        else:
            stable_reads = 0
        last_time = curr
        if stable_reads >= PLAYBACK_SETTLE_SEC:
            return player
        time.sleep(0.5)
    try:
        return xbmc.Player()
    except Exception:
        return None


def _lang_name_from_index(setting_id, default_idx=0):
    try:
        idx = int(control.setting(setting_id) or default_idx)
    except (TypeError, ValueError):
        idx = default_idx
    if 0 <= idx < len(SUBTITLE_LANG_OPTIONS):
        return SUBTITLE_LANG_OPTIONS[idx]
    return SUBTITLE_LANG_OPTIONS[default_idx]


LANG_NAME_MAP = {
    'dut': 'Dutch', 'nl': 'Dutch', 'nld': 'Dutch', 'eng': 'English', 'en': 'English',
    'rus': 'Russian', 'ru': 'Russian', 'fre': 'French', 'fr': 'French', 'fra': 'French',
    'deu': 'German', 'de': 'German', 'ger': 'German', 'spa': 'Spanish', 'es': 'Spanish',
    'ita': 'Italian', 'it': 'Italian', 'por': 'Portuguese', 'pt': 'Portuguese',
}


def get_subtitle_mode():
    try:
        return int(c.get_setting('subtitles.mode') or MODE_FOLLOW_KODI)
    except (TypeError, ValueError):
        return MODE_FOLLOW_KODI


def _opensubtitles_fetch_allowed():
    mode = get_subtitle_mode()
    if mode == MODE_OFF:
        return False
    if mode == MODE_ALWAYS_ON:
        return True
    kodi_lang = kodi_locale.get_subtitle_language().lower()
    if kodi_lang in ('none', 'forced_only'):
        return False
    return bool(kodi_lang)


def _embedded_only_mode():
    '''Follow Kodi forced_only: use embedded tracks only, no OpenSubtitles.'''
    if get_subtitle_mode() != MODE_FOLLOW_KODI:
        return False
    return kodi_locale.get_subtitle_language().lower() == 'forced_only'


class Subtitles:
    def __init__(self):
        self.os_user = (c.get_setting('OSuser') or '').strip()
        self.os_pass = (c.get_setting('OSpass') or '').strip()
        self.os_apikey = (c.get_setting('OSapikey') or '').strip()
        self.token = None

    def _get_language_codes(self):
        langs = []
        mode = get_subtitle_mode()

        if mode == MODE_FOLLOW_KODI:
            kodi_lang = kodi_locale.get_subtitle_language().lower()
            if kodi_lang and kodi_lang not in ('none', 'forced_only', 'mediadefault'):
                name = KODI_LANG_TO_NAME.get(kodi_lang)
                if name and name in LANG_DICT:
                    langs.extend(LANG_DICT[name].split(','))

        lang1 = _lang_name_from_index('subtitles.lang.1', 0)
        if lang1 in LANG_DICT:
            for code in LANG_DICT[lang1].split(','):
                if code not in langs:
                    langs.append(code)

        lang2 = _lang_name_from_index('subtitles.lang.2', 0)
        if lang2 in LANG_DICT:
            for code in LANG_DICT[lang2].split(','):
                if code not in langs:
                    langs.append(code)

        return langs

    def _language_name(self, lang_code):
        lang_lower = (lang_code or '').lower().strip()
        if lang_lower in LANG_NAME_MAP:
            return LANG_NAME_MAP[lang_lower]
        for code, name in LANG_NAME_MAP.items():
            if code in lang_lower or lang_lower in code:
                return name
        return (lang_code or 'Subtitles').upper()

    def _authenticate(self):
        if not self.os_user or not self.os_pass or not self.os_apikey:
            return False
        try:
            headers = {
                'Content-Type': 'application/json',
                'Api-Key': self.os_apikey,
                'User-Agent': f'{USER_AGENT} {c.version}',
            }
            response = requests.post(
                f'{API_URL}/login',
                data=json.dumps({'username': self.os_user, 'password': self.os_pass}),
                headers=headers,
                timeout=30,
            )
            if response.status_code != 200:
                c.log(f'[Subtitles] auth HTTP {response.status_code}', 1)
                return False
            result = json.loads(response.text)
            self.token = result.get('token')
            if not self.token:
                return False
            allowed = result.get('user', {}).get('allowed_downloads', 0)
            if allowed == 0:
                c.log('[Subtitles] no OpenSubtitles downloads remaining today', 1)
                return False
            return True
        except Exception as exc:
            c.log(f'[Subtitles] auth failed: {exc}', 1)
            return False

    def _normalize_imdb(self, imdb):
        imdb_str = str(imdb or '').strip()
        if not imdb_str:
            return ''
        if imdb_str.startswith('tt'):
            return imdb_str
        numeric_id = re.sub('[^0-9]', '', imdb_str)
        if not numeric_id:
            return ''
        return f'tt{numeric_id}'

    def _search_subtitles(self, langs, imdb, season=None, episode=None, tmdb=None):
        if not self.token:
            return []

        params_base = {'languages': ','.join(langs)}
        if season is not None and episode is not None:
            params_base['type'] = 'episode'
            params_base['season_number'] = str(int(season or 0))
            params_base['episode_number'] = str(int(episode or 0))
        else:
            params_base['type'] = 'movie'

        queries = []
        imdbid = self._normalize_imdb(imdb)
        if imdbid:
            queries.append({**params_base, 'imdb_id': imdbid})
        tmdb_str = str(tmdb or '').strip()
        if tmdb_str and tmdb_str not in ('0', 'None'):
            queries.append({**params_base, 'tmdb_id': tmdb_str})

        for params in queries:
            results = self._search_subtitles_request(params)
            if results:
                return results
        return []

    def _search_subtitles_request(self, params):
        try:
            headers = {
                'Api-Key': self.os_apikey,
                'Authorization': f'Bearer {self.token}',
                'User-Agent': f'{USER_AGENT} {c.version}',
            }
            response = requests.get(f'{API_URL}/subtitles', params=params, headers=headers, timeout=30)
            if not response or response.status_code != 200:
                return []
            data = json.loads(response.text).get('data', [])
            subtitles = []
            for item in data:
                attrs = item.get('attributes', {})
                files = attrs.get('files') or []
                if not files:
                    continue
                file_info = files[0]
                file_id = file_info.get('file_id')
                if file_id:
                    subtitles.append({
                        'file_id': file_id,
                        'filename': file_info.get('file_name', ''),
                        'language': attrs.get('language', ''),
                    })
            return subtitles
        except Exception as exc:
            c.log(f'[Subtitles] search failed: {exc}', 1)
            return []

    def _select_best_subtitle(self, subtitles, preferred_langs):
        for lang in preferred_langs:
            for subtitle in subtitles:
                if subtitle['language'].lower() == lang.lower():
                    return subtitle
        return subtitles[0] if subtitles else None

    def _download_subtitle(self, file_id):
        if not self.token:
            return None
        try:
            headers = {
                'Content-Type': 'application/json',
                'Api-Key': self.os_apikey,
                'Authorization': f'Bearer {self.token}',
                'User-Agent': f'{USER_AGENT} {c.version}',
            }
            response = requests.post(
                f'{API_URL}/download',
                data=json.dumps({'file_id': file_id}),
                headers=headers,
                timeout=30,
            )
            if not response or response.status_code != 200:
                return None
            result = json.loads(response.text)
            download_link = result.get('link')
            if not download_link:
                return None
            subtitle_response = requests.get(download_link, timeout=45)
            if not subtitle_response or subtitle_response.status_code != 200:
                return None
            content = subtitle_response.content
            if isinstance(content, bytes) and content.startswith(b'\x1f\x8b'):
                content = gzip.GzipFile(fileobj=BytesIO(content)).read()
            return content
        except Exception as exc:
            c.log(f'[Subtitles] download failed: {exc}', 1)
            return None

    def _save_and_load_subtitle(self, content, lang, season=None, episode=None):
        suffix = ''
        if season and episode:
            try:
                suffix = f'.S{int(season):02d}E{int(episode):02d}'
            except (TypeError, ValueError):
                suffix = ''
        subtitle_path = os.path.join(
            control.transPath('special://temp/'),
            f'TemporarySubs{suffix}.{lang}.srt',
        )
        handle = control.openFile(subtitle_path, 'w')
        try:
            if isinstance(content, bytes):
                handle.write(content.decode('utf-8', errors='replace'))
            else:
                handle.write(content)
        finally:
            handle.close()
        if not self._apply_external_subtitle(subtitle_path):
            c.log(f'[Subtitles] apply failed after retries ({subtitle_path})', 1)
            return False
        label = self._language_name(lang)
        c.infoDialog(f'Subtitles: {label}', heading='The Crew', time=2500, sound=False)
        return True

    def _apply_external_subtitle(self, subtitle_path):
        for attempt in range(3):
            try:
                player = xbmc.Player()
                if not player.isPlayingVideo():
                    time.sleep(0.8)
                    continue
                player.setSubtitles(subtitle_path)
                player.showSubtitles(True)
                return True
            except Exception as exc:
                c.log(f'[Subtitles] apply attempt {attempt + 1} failed: {exc}', 1)
                time.sleep(1.0)
        return False

    def _try_embedded_primary(self, langs_old, player):
        if not langs_old:
            return False
        try:
            available_subs = player.getAvailableSubtitleStreams() or []
            first_lang = langs_old[0]
            for idx, sub_lang in enumerate(available_subs):
                sub_lower = (sub_lang or '').lower()
                if first_lang.lower() in sub_lower or sub_lower in first_lang.lower():
                    player.setSubtitleStream(idx)
                    player.showSubtitles(True)
                    label = self._language_name(sub_lang)
                    c.infoDialog(f'Subtitles: {label}', heading='The Crew', time=2000, sound=False)
                    return True
        except Exception as exc:
            c.log(f'[Subtitles] embedded check failed: {exc}', 1)
        return False

    def _try_podnapisi_fallback(self, langs_old, langs_api, season, episode):
        try:
            from ..apis import podnapisi as podnapisi_api
            from ..playback import session as playback_session

            if not podnapisi_api.fallback_enabled():
                return False

            sess = playback_session.load() or {}
            mediatype = (sess.get('mediatype') or 'movie').lower()
            hit = podnapisi_api.fetch_best(
                langs_old or langs_api,
                mediatype=mediatype,
                title=sess.get('title') or '',
                tvshowtitle=sess.get('tvshowtitle') or '',
                year=sess.get('year') or '',
                season=season,
                episode=episode,
            )
            if not hit:
                return False
            content, lang = hit
            if not self._save_and_load_subtitle(content, lang, season, episode):
                return False
            c.log(f'[Subtitles] loaded via Podnapisi ({lang})')
            return True
        except Exception as exc:
            c.log(f'[Subtitles] Podnapisi fallback failed: {exc}', 1)
            return False

    def _try_opensubtitles(self, langs, imdb, season=None, episode=None, tmdb=None):
        if not self.os_user or not self.os_pass or not self.os_apikey:
            return False
        if not self._authenticate():
            return False
        subtitles = self._search_subtitles(langs, imdb, season, episode, tmdb=tmdb)
        if not subtitles:
            return False
        best = self._select_best_subtitle(subtitles, langs)
        if not best:
            return False
        content = self._download_subtitle(best['file_id'])
        if not content:
            return False
        if not self._save_and_load_subtitle(content, best['language'], season, episode):
            return False
        c.log(f'[Subtitles] loaded {best.get("filename")} ({best.get("language")})')
        return True

    def fetch_and_load(self, name, imdb, season=None, episode=None, tmdb=None):
        del name
        try:
            if get_subtitle_mode() == MODE_OFF:
                return False
            if (not imdb or str(imdb) == '0') and (not tmdb or str(tmdb) == '0'):
                return False

            player = _wait_for_playback_ready()
            if player is None:
                c.log('[Subtitles] playback not ready  -  skip fetch', 1)
                return False

            langs_old = self._get_language_codes()
            if not langs_old:
                c.log('[Subtitles] no languages configured')
                return False

            langs = []
            for old_code in langs_old:
                new_code = LANG_CODE_MAP.get(old_code, old_code[:2] if len(old_code) >= 2 else old_code)
                langs.append(new_code)

            if self._try_embedded_primary(langs_old, player):
                return True

            if _embedded_only_mode() or not _opensubtitles_fetch_allowed():
                c.log('[Subtitles] OpenSubtitles fetch skipped by mode/Kodi locale')
                if self._try_podnapisi_fallback(langs_old, langs, season, episode):
                    return True
                return False

            if self._try_opensubtitles(langs, imdb, season, episode, tmdb=tmdb):
                return True

            if not (self.os_user and self.os_pass and self.os_apikey):
                c.log('[Subtitles] OpenSubtitles credentials incomplete  -  trying Podnapisi')
            else:
                c.log('[Subtitles] no OpenSubtitles match  -  trying Podnapisi')
            if self._try_podnapisi_fallback(langs_old, langs, season, episode):
                return True
            return False
        except Exception as exc:
            c.log(f'[Subtitles] fetch_and_load failed: {exc}', 1)
            c.log(f'[Subtitles] {traceback.format_exc()}', 1)
            return False


def fetch_for_session(session):
    '''Background entry from onAVStarted.'''
    if not session:
        return
    mediatype = (session.get('mediatype') or '').lower()
    season = episode = None
    if mediatype == 'episode':
        try:
            season = int(session.get('season') or 0)
            episode = int(session.get('episode') or 0)
        except (TypeError, ValueError):
            season = episode = 0
        if season <= 0 or episode <= 0:
            return
    imdb = session.get('imdb') or ''
    tmdb = session.get('tmdb') or ''
    title = session.get('title') or session.get('tvshowtitle') or ''
    if mediatype == 'episode':
        c.log(f'[Subtitles] fetch queued S{season:02d}E{episode:02d} imdb={imdb} tmdb={tmdb}')
    Subtitles().fetch_and_load(title, imdb, season, episode, tmdb=tmdb)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file monitor.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Playback monitor  -  ClassyPlayer owns resume seek + tracker/WeTrakr scrobble callbacks.'''

import threading

import xbmc

from ..modules.classy import c
from .. import tracker
from ..progress import filters as slot_filters
from . import outcome as playback_outcome
from . import session as playback_session
from .resume_prompt import apply_resume_offset


_player_lock = threading.Lock()
_local_player = None


def get_playback_player():
    '''Singleton ClassyPlayer for this interpreter  -  callbacks fire here.'''
    global _local_player
    with _player_lock:
        if _local_player is None:
            _local_player = ClassyPlayer()
            c.log(f'[Playback] player ready id={id(_local_player)}')
        return _local_player


def boot_service_player():
    '''Warm the player in the service interpreter (optional; plugin creates its own).'''
    return get_playback_player()


class ClassyPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._last_time = 0.0
        self._total_time = 0.0
        self._pos_stop = threading.Event()
        self._pos_thread = None

    def play(self, url, listitem=None, windowed=False, startpos=-1):
        self._stop_position_tracker()
        self._last_time = 0.0
        self._total_time = 0.0
        return super().play(url, listitem, windowed, startpos)

    def _session_active(self):
        return bool(playback_session.load())

    def _kodi_video_playing(self):
        try:
            return bool(xbmc.Player().isPlayingVideo())
        except Exception:
            return False

    def _should_defer_teardown(self):
        '''Up Next handoff or next stream already playing  -  do not wipe session/hooks.'''
        try:
            from ..modules import control
            if control.window.getProperty(playback_session.UPNEXT_HANDOFF_PROP) == '1':
                return True
        except Exception:
            pass
        if self._kodi_video_playing():
            return True
        return False

    def _prior_play_stop_snapshot(self):
        '''Up Next: Stop callback for the episode we already replaced via handoff.'''
        try:
            from ..modules import control
            import json as _json

            raw = control.window.getProperty(playback_session.STOPPING_SCROBBLE_SNAPSHOT_PROP) or ''
            if not raw:
                return None
            stop_snap = _json.loads(raw)
            if not isinstance(stop_snap, dict):
                return None
            stop_seq = str(stop_snap.get('play_seq') or '')
            cur_seq = playback_session.current_play_seq()
            if not stop_seq or not cur_seq or stop_seq == cur_seq:
                control.window.clearProperty(playback_session.STOPPING_SCROBBLE_SNAPSHOT_PROP)
                return None
            return stop_snap
        except Exception:
            return None

    def _try_teardown_lock(self):
        try:
            from ..modules import control
            win = control.window
            if win.getProperty(playback_session.TEARDOWN_LOCK_PROP) == '1':
                return False
            win.setProperty(playback_session.TEARDOWN_LOCK_PROP, '1')
            return True
        except Exception:
            return True

    def _playback_teardown(self, ended=False):
        playback_session.clear()
        self._upnext_cleanup(ended=ended)
        try:
            from ..apis import wetrakr
            wetrakr.reset_playback_flags()
        except Exception:
            pass

    def onPlayBackStarted(self):
        if not self._session_active():
            return
        self._apply_resume_once()

    def onAVStarted(self):
        '''Later than Started  -  CDN streams may not be seekable on first callback.'''
        if not self._session_active():
            return
        self._apply_resume_once()
        # Scrobble times only  -  subs/intro skip run on service PlaybackHooksMonitor.
        self._start_position_tracker()
        try:
            from . import service_hooks
            service_hooks.signal_av_started()
        except Exception:
            pass
        try:
            from ..tvevening.monitor import evening_is_live, signal_av_started
            if evening_is_live():
                signal_av_started()
        except Exception as exc:
            c.log(f'[Playback] TV Evening AV signal failed: {exc}', 1)

    def onPlayBackResumed(self):
        if not self._session_active():
            return
        self._apply_resume_once()
        self._start_position_tracker()
        try:
            from ..tvevening import session as evening_session
            from ..tvevening.monitor import evening_is_live
            if evening_is_live() and evening_session.get_state() != evening_session.STATE_PAUSESCREEN:
                evening_session.set_state(evening_session.STATE_PLAYING)
        except Exception:
            pass
        try:
            from ..apis import wetrakr
            sess = playback_session.scrobble_snapshot()
            if sess:
                current, total = self._read_times('resume')
                wetrakr.handle_playback_scrobble('resume', sess, current, total)
        except Exception as exc:
            c.log(f'[Playback] WeTrakr resume failed: {exc}')

    def onPlayBackPaused(self):
        if not self._session_active():
            return
        # Snapshot while getTime() is still valid  -  pause+stop used to be the only
        # path that saved correct progress because Stop teardown reports ~0 - 2s.
        pos, total = self._stable_playback_times()
        if pos > 0:
            self._last_time = pos
        if total > 0:
            self._total_time = total
        self._scrobble('pause')
        try:
            from ..tvevening import session as evening_session
            from ..tvevening.monitor import evening_is_live
            if evening_is_live() and evening_session.get_state() != evening_session.STATE_PAUSESCREEN:
                evening_session.set_state(evening_session.STATE_PAUSED)
                try:
                    evening_session.save_playback_bookmark(pos, total)
                except Exception:
                    pass
        except Exception:
            pass

    def _is_stale_stop(self):
        snap = playback_session.scrobble_snapshot()
        snap_seq = str(snap.get('play_seq') or '')
        cur_seq = playback_session.current_play_seq()
        return bool(snap_seq and cur_seq and snap_seq != cur_seq)

    def onPlayBackStopped(self):
        if not self._session_active():
            return
        defer = self._should_defer_teardown()
        if not defer:
            self._stop_position_tracker()
        # Capture BEFORE scrobble  -  getTime() often collapses to ~0 - 2s on Stop.
        # Position tracker keeps _last_time current so Stop-without-Pause still
        # saves the real offset (not the stale start/resume point).
        pos, total = self._stable_playback_times()
        if pos > 0:
            self._last_time = pos
        if total > 0:
            self._total_time = total

        stop_event = self._stop_event_kind()
        outcome = self._build_outcome('stop', pos, total, event=stop_event)
        force_complete = bool(outcome.force_complete)

        prior_snap = self._prior_play_stop_snapshot()
        if prior_snap:
            self._scrobble('stop', outcome=outcome, session=prior_snap)
            try:
                from ..modules import control
                control.window.clearProperty(playback_session.STOPPING_SCROBBLE_SNAPSHOT_PROP)
                control.window.clearProperty(playback_session.UPNEXT_COMPLETE_PROP)
            except Exception:
                pass
            c.log('[Playback] Up Next prior-episode stop  -  scrobble only, skip teardown')
            return

        self._scrobble('stop', outcome=outcome)
        if not defer and not prior_snap:
            try:
                from ..play.fallback_queue import schedule_if_needed
                if schedule_if_needed(pos, total):
                    return
            except Exception:
                pass
        if self._is_stale_stop():
            c.log('[Playback] stale stop  -  scrobble only, skip teardown')
            return
        if defer:
            c.log('[Playback] stop teardown deferred (Up Next handoff or active playback)')
            self._evening_raise_bridge(force_complete=force_complete)
            return

        if not self._try_teardown_lock():
            return

        self._playback_teardown(ended=False)
        self._evening_raise_bridge(force_complete=force_complete)
        try:
            from ..modules import control
            from ..tvevening import session as evening_session
            from ..tvevening import monitor as evening_monitor
            if not evening_monitor.evening_is_live():
                return
            if control.window.getProperty('thecrew.tvevening.transitioning') == 'true':
                return
            if evening_session.get_state() == evening_session.STATE_PAUSESCREEN:
                return
            # Mid-episode Stop only  -  do not soft-pause on brief stream/audio glitches
            # while still near the start; monitor owns end-of-episode transitions.
            near_end = total > 0 and (total - pos) <= 30
            if near_end:
                return
            if pos < 15:
                # Early Stop during buffer / audio switch  -  ignore
                c.log('[Playback] TV Evening early Stop ignored (pos<15s)')
                return
            evening_session.save_playback_bookmark(pos, total)
            control.window.setProperty(evening_session.PROP_USER_STOPPED, 'true')
            c.log(f'[Playback] TV Evening Stop  -  soft pause at {pos:.0f}s')
            # Always soft-pause via session props  -  monitor thread may live in another
            # (already dead) plugin process, so _monitor_instance is often None here.
            try:
                from ..tvevening import bridge_dialog
                bridge_dialog.dismiss_bridge()
            except Exception:
                pass
            try:
                if evening_monitor._monitor_instance is not None:
                    evening_monitor._monitor_instance.stop(soft=True)
                else:
                    evening_session.soft_pause_session()
            except Exception as exc:
                c.log(f'[Playback] TV Evening soft-pause failed: {exc}', 1)
                evening_session.soft_pause_session()
        except Exception as exc:
            c.log(f'[Playback] TV Evening Stop handling failed: {exc}', 1)

    def onPlayBackEnded(self):
        if not self._session_active():
            return
        defer = self._should_defer_teardown()
        if not defer:
            self._stop_position_tracker()
        pos, total = self._stable_playback_times()
        if pos > 0:
            self._last_time = pos
        if total > 0:
            self._total_time = total
        outcome = self._build_outcome('stop', pos, total, event='ended')
        self._scrobble('stop', outcome=outcome)
        if self._is_stale_stop():
            c.log('[Playback] stale end  -  scrobble only, skip teardown')
            return
        if defer:
            c.log('[Playback] end teardown deferred (Up Next handoff or active playback)')
            self._evening_raise_bridge(force_complete=True)
            return

        if not self._try_teardown_lock():
            return

        self._playback_teardown(ended=True)
        self._evening_raise_bridge(force_complete=True)
        # Evening monitor watches idle after end and advances; no extra work here.

    def onPlayBackSeek(self, _time, _seek_offset):
        if not self._session_active():
            return
        try:
            current = self.getTime()
            total = self.getTotalTime()
            if current > 0:
                self._last_time = current
            if total > 0:
                self._total_time = total
        except Exception:
            pass
        try:
            from ..apis import wetrakr
            sess = playback_session.scrobble_snapshot()
            if sess:
                current, total = self._read_times('seek')
                wetrakr.handle_playback_scrobble('seek', sess, current, total)
        except Exception as exc:
            c.log(f'[Playback] WeTrakr seek failed: {exc}')

    def _evening_raise_bridge(self, force_complete=False):
        '''Cover home menu during the idle -> countdown/complete handoff.'''
        try:
            from ..modules import control
            from ..tvevening.monitor import evening_is_live
            from ..tvevening import bridge_dialog

            if not evening_is_live():
                return
            transitioning = (
                control.window.getProperty('thecrew.tvevening.transitioning') == 'true'
            )
            if not (force_complete or transitioning):
                return
            bridge_dialog.request_bridge(message='One moment...')
        except Exception as exc:
            c.log(f'[Playback] TV Evening bridge failed: {exc}', 1)

    def _start_position_tracker(self):
        '''Poll getTime() while playing  -  Stop teardown is not trustworthy.'''
        if not self._session_active():
            return
        try:
            from ..modules import control
            if control.window.getProperty(playback_session.POS_TRACKER_PROP) == '1':
                return
            control.window.setProperty(playback_session.POS_TRACKER_PROP, '1')
        except Exception:
            pass
        self._stop_position_tracker(local_only=True)
        self._pos_stop = threading.Event()
        thread = threading.Thread(
            target=self._position_tracker_loop,
            name='classy-pos-tracker',
            daemon=True,
        )
        self._pos_thread = thread
        thread.start()

    def _stop_position_tracker(self, local_only=False):
        ev = getattr(self, '_pos_stop', None)
        if ev is not None:
            ev.set()
        self._pos_thread = None
        if local_only:
            return
        try:
            from ..modules import control
            control.window.clearProperty(playback_session.POS_TRACKER_PROP)
        except Exception:
            pass

    def _position_tracker_loop(self):
        while not self._pos_stop.wait(1.0):
            try:
                if not self.isPlayingVideo():
                    continue
                current = float(self.getTime() or 0)
                total = float(self.getTotalTime() or 0)
                if current > 0:
                    self._last_time = current
                if total > 0:
                    self._total_time = total
            except Exception:
                pass

    def _stable_playback_times(self):
        '''Prefer last known mid-watch position over teardown getTime()~0 - 2s.'''
        last = float(self._last_time or 0)
        total = float(self._total_time or 0)
        live_pos = 0.0
        live_total = 0.0
        try:
            live_pos = float(self.getTime() or 0)
            live_total = float(self.getTotalTime() or 0)
        except Exception:
            pass
        if live_total > 0:
            total = live_total
        if live_pos >= 15:
            pos = live_pos
        elif last >= 15:
            pos = last
        else:
            pos = max(live_pos, last)
        return pos, total

    def _apply_resume_once(self):
        try:
            from ..modules import control
            if control.window.getProperty(playback_session.RESUME_APPLIED_PROP) == '1':
                return
        except Exception:
            pass
        sess = playback_session.load()
        try:
            offset = float(sess.get('resume_offset') or 0)
        except (TypeError, ValueError):
            offset = 0.0
        if offset <= 0:
            return

        try:
            from ..modules import control
            control.window.setProperty(playback_session.RESUME_APPLIED_PROP, '1')
        except Exception:
            pass

        evening_prompt = False
        force_auto = False
        progress = 0.0
        try:
            from ..modules import control
            from ..tvevening.monitor import evening_is_live, evening_blocks_upnext
            if evening_is_live() or evening_blocks_upnext():
                if control.window.getProperty('thecrew.tvevening.resume_prompt') == 'true':
                    evening_prompt = True
                    try:
                        progress = float(sess.get('resume_progress') or 0)
                    except (TypeError, ValueError):
                        progress = 0.0
                elif offset > 0:
                    # Recovery Continue (paused/playing)  -  quiet seek, no dialog.
                    force_auto = True
                    c.log(f'[Playback] TV Evening  -  auto-resume at {offset:.0f}s')
                else:
                    c.log('[Playback] TV Evening  -  no mid-watch resume, start 00:00')
                    return
        except Exception:
            pass

        apply_resume_offset(
            self,
            offset,
            evening_prompt=evening_prompt,
            progress=progress,
            force_auto=force_auto,
        )

    def _stop_event_kind(self):
        '''Map Stop context to outcome event (not watched heuristics).'''
        try:
            from ..modules import control
            if control.window.getProperty(playback_session.UPNEXT_COMPLETE_PROP) == '1':
                return 'upnext_handoff'
        except Exception:
            pass
        try:
            from ..modules import control
            from ..tvevening.monitor import evening_is_live
            if (
                evening_is_live()
                and control.window.getProperty('thecrew.tvevening.transitioning') == 'true'
            ):
                return 'evening_transition'
        except Exception:
            pass
        return 'normal'

    def _build_outcome(self, state, current, total, event='normal'):
        return playback_outcome.resolve_outcome(
            action=state,
            current=current,
            total=total,
            watched_percent=slot_filters.resume_progress_max(),
            event=event,
        )

    def _read_times(self, state):
        live_current = 0.0
        live_total = 0.0
        try:
            live_current = float(self.getTime() or 0)
            live_total = float(self.getTotalTime() or 0)
        except Exception:
            pass
        current, total = playback_outcome.salvage_position(
            live_current,
            live_total,
            self._last_time,
            self._total_time,
        )
        if total > 0:
            self._last_time = current
            self._total_time = total
        return current, total

    def _scrobble(self, state, force_complete=False, session=None, outcome=None):
        sess = session or playback_session.scrobble_snapshot()
        if not sess:
            c.log(f'[Playback] scrobble {state} skipped  -  no session', 1)
            return
        if not sess.get('imdb') and not sess.get('tmdb'):
            c.log(f'[Playback] scrobble {state} skipped  -  no ids', 1)
            return
        current, total = self._read_times(state)
        if outcome is None:
            event = 'normal'
            if state == 'stop' and force_complete:
                event = 'ended'
            outcome = self._build_outcome(state, current, total, event=event)
        current, total = outcome.as_scrobble_times()
        note = ''
        if outcome.force_complete:
            note = f' (force complete:{outcome.reason})'
        elif outcome.counts_as_watched:
            note = ' (watched threshold)'
        c.log(
            f'[Playback] scrobble {state} tmdb={sess.get("tmdb")} '
            f'at {current:.0f}/{total:.0f}s{note}'
        )
        # Attach outcome for tracker adapters (min_progress / clear_resume).
        try:
            sess = dict(sess)
            sess['_outcome_percent'] = outcome.percent
            sess['_outcome_watched'] = bool(outcome.counts_as_watched)
            sess['_outcome_clear_resume'] = bool(outcome.clear_resume)
            sess['_outcome_reason'] = outcome.reason
        except Exception:
            pass
        try:
            if state == 'start':
                tracker.scrobble_start(sess, current, total)
            elif state == 'pause':
                tracker.scrobble_pause(sess, current, total)
            else:
                tracker.scrobble_stop(sess, current, total)
        except Exception as exc:
            c.log(f'[Playback] scrobble {state} failed: {exc}', 1)
        # R1 dual-write: local bookmarks always on pause/stop (when enabled).
        if state in ('pause', 'stop'):
            try:
                from ..modules import bookmarks as local_bookmarks
                local_bookmarks.write_from_session(sess, current, total)
                if not tracker.live():
                    from ..progress.widget_signals import notify_progress_changed
                    notify_progress_changed('local_bookmark_%s' % state)
            except Exception as exc:
                c.log(f'[Playback] local bookmark {state} failed: {exc}', 1)
        try:
            from ..apis import wetrakr
            wetrakr.handle_playback_scrobble(state, sess, current, total)
        except Exception as exc:
            c.log(f'[Playback] WeTrakr scrobble {state} failed: {exc}')

    def _upnext_cleanup(self, ended=False):
        '''Plugin-thread cleanup; service monitor owns dialog dispatch.'''
        try:
            from . import upnext as upnext_mod

            if ended:
                upnext_mod.service_on_playback_ended()
            else:
                upnext_mod.disarm()
        except Exception as exc:
            c.log(f'[Playback] UpNext cleanup failed: {exc}', 1)

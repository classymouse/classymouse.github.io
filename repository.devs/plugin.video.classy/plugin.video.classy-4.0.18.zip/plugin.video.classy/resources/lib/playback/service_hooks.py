# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file service_hooks.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Service-thread playback hooks  -  subs, intro skip, WeTrakr progress, intro tick.

Plugin and service are separate Python interpreters. play() runs in the plugin
process; ClassyMonitor (never reloaded) owns hook state like TV Evening.

Plugin: session.store() + arm_after_play() + optional AV timestamp signal.
Service: PlaybackHooksMonitor.tick() each poll.'''

import threading
import time

import xbmc

from ..modules import control
from ..modules.classy import c
from . import session as playback_session

AV_HOOKS_PENDING_PROP = 'thecrew.playback.av_hooks_pending'
AV_HOOKS_DONE_SEQ_PROP = 'thecrew.playback.av_hooks_done_seq'
AV_STARTED_TS_PROP = 'thecrew.playback.av_started_ts'

_hooks_lock = threading.Lock()
_monitor_instance = None


def get_hooks_monitor():
    global _monitor_instance
    if _monitor_instance is None:
        _monitor_instance = PlaybackHooksMonitor()
        c.log('[Playback] hooks monitor ready (service)')
    return _monitor_instance


def signal_av_started():
    '''Plugin AV callback  -  write prop only; service monitor does the work.'''
    try:
        control.window.setProperty(AV_STARTED_TS_PROP, str(time.time()))
    except Exception:
        pass


def mark_hooks_complete():
    get_hooks_monitor().mark_done()


def arm_after_play():
    '''Call from play_stream immediately after playback_session.store().'''
    try:
        seq = playback_session.current_play_seq()
        win = control.window
        win.setProperty(AV_HOOKS_PENDING_PROP, '1')
        win.setProperty(AV_HOOKS_DONE_SEQ_PROP, '')
        c.log(f'[Playback] AV hooks armed seq={seq}')
    except Exception as exc:
        c.log(f'[Playback] AV hooks arm failed: {exc}', 1)


def service_tick():
    get_hooks_monitor().tick()


class PlaybackHooksMonitor:
    '''Persistent service-side worker  -  same lifetime as ClassyMonitor.'''

    def __init__(self):
        self._handled_seq = ''
        self._last_av_ts = 0.0
        self._active_seq = ''
        # Sports / foreign AV often have no Classy session and no IMDb/TMDB on the
        # InfoTag  -  one failed rehydrate is enough; do not retry every poll.
        self._rehydrate_done = False
        self._rehydrate_fail_logged = False

    def mark_done(self):
        try:
            seq = playback_session.current_play_seq()
            control.window.setProperty(AV_HOOKS_DONE_SEQ_PROP, seq)
            control.window.clearProperty(AV_HOOKS_PENDING_PROP)
            control.window.clearProperty(playback_session.UPNEXT_HANDOFF_PROP)
            self._handled_seq = seq
            try:
                from ..play.fallback_queue import clear as clear_play_fallback
                clear_play_fallback()
            except Exception:
                pass
        except Exception:
            pass

    def _hooks_done_for(self, seq):
        if not seq:
            return False
        if self._handled_seq == seq:
            return True
        done = control.window.getProperty(AV_HOOKS_DONE_SEQ_PROP) or ''
        return done == seq

    def _read_av_ts(self):
        try:
            return float(control.window.getProperty(AV_STARTED_TS_PROP) or 0)
        except (TypeError, ValueError):
            return 0.0

    def _run_hooks(self, player, sess):
        c.log(
            f'[Playback] service AV hooks firing S{sess.get("season")}E{sess.get("episode")} '
            f'seq={playback_session.current_play_seq()}',
        )
        try:
            from . import av_hooks
            av_hooks.on_av_started(player)
        except Exception as exc:
            c.log(f'[Playback] service AV hooks failed: {exc}', 1)
        try:
            from . import intro_skip as intro_skip_mod
            intro_skip_mod.on_av_started(player)
        except Exception as exc:
            c.log(f'[Playback] service IntroSkip start failed: {exc}', 1)
        self.mark_done()
        try:
            from .monitor import get_playback_player
            get_playback_player()._scrobble('start')
        except Exception as exc:
            c.log(f'[Playback] service scrobble start failed: {exc}', 1)

    def _playback_ticks(self, player):
        try:
            from . import intro_skip as intro_skip_mod
            intro_skip_mod.tick(player)
        except Exception:
            pass
        try:
            from ..apis import wetrakr
            wetrakr.tick_progress(player)
        except Exception:
            pass

    def tick(self):
        try:
            if control.window.getProperty(playback_session.INTRO_RESET_PENDING_PROP) == '1':
                from . import intro_skip as intro_skip_mod
                intro_skip_mod.reset_playback_state()
                control.window.clearProperty(playback_session.INTRO_RESET_PENDING_PROP)
                self._handled_seq = ''
        except Exception:
            pass

        player = xbmc.Player()
        try:
            playing = player.isPlayingVideo()
        except Exception:
            playing = False
        if not playing:
            self._rehydrate_done = False
            self._rehydrate_fail_logged = False
            return

        sess = playback_session.load()
        if not sess and not self._rehydrate_done:
            try:
                if playback_session.restore_if_needed(player):
                    sess = playback_session.load()
                    seq = playback_session.current_play_seq()
                    if seq:
                        control.window.setProperty(AV_HOOKS_DONE_SEQ_PROP, seq)
                        self._handled_seq = seq
                        self._active_seq = seq
                        c.log(
                            f'[Playback] session rehydrated after restart '
                            f'S{sess.get("season")}E{sess.get("episode")} seq={seq}',
                        )
                        try:
                            from ..apis import wetrakr
                            wetrakr.reset_playback_flags()
                            current = float(player.getTime() or 0)
                            total = float(player.getTotalTime() or 0)
                            wetrakr.handle_playback_scrobble('start', sess, current, total)
                        except Exception as exc:
                            c.log(f'[Playback] WeTrakr rehydrate start failed: {exc}', 1)
                self._rehydrate_done = True
            except Exception as exc:
                self._rehydrate_done = True
                if not self._rehydrate_fail_logged:
                    self._rehydrate_fail_logged = True
                    c.log(f'[Playback] session rehydrate failed: {exc}', 1)
        if not sess:
            return

        seq = playback_session.current_play_seq()
        if seq and seq != self._active_seq:
            self._active_seq = seq
            self._handled_seq = ''
            try:
                from ..apis import wetrakr
                wetrakr.reset_playback_flags()
            except Exception:
                pass
        av_ts = self._read_av_ts()
        if av_ts > self._last_av_ts:
            self._last_av_ts = av_ts

        if self._hooks_done_for(seq):
            self._playback_ticks(player)
            return

        with _hooks_lock:
            if self._hooks_done_for(seq):
                return
            try:
                total = float(player.getTotalTime() or 0)
            except Exception:
                total = 0.0
            if total <= 0:
                return
            self._run_hooks(player, sess)

        if self._hooks_done_for(seq):
            self._playback_ticks(player)

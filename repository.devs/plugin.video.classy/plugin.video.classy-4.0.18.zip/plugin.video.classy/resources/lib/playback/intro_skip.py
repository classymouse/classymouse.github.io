# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file intro_skip.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Intro / recap skip via TheIntroDB + chapter fallback (episodes only).'''

import json
import threading
import time

import xbmc

from ..apis import introdb as introdb_api
from ..modules import control
from ..modules.classy import c
from . import session as playback_session

# introdb.skip_mode: 0=Off, 1=Prompt, 2=Auto
SKIP_OFF = 0
SKIP_PROMPT = 1
SKIP_AUTO = 2

PROMPT_COUNTDOWN_SEC = 15
PROMPT_EARLY_SEC = 15
SETTLE_SEC = 4
SETTLE_MAX_WAIT_SEC = 12
SETTLE_JUMP_SEC = 20
POST_END_GRACE_SEC = 20
CHAPTER_MIN_START_SEC = 5
CHAPTER_MIN_SEGMENT_SEC = 10
CHAPTER_MIN_END_SEC = 15

_PREFIX = 'thecrew.introskip.'
PENDING_PROP = _PREFIX + 'pending'
PARAMS_PROP = _PREFIX + 'params'
RESULT_PROP = _PREFIX + 'result'
CREDITS_START_PROP = 'thecrew.introdb.credits_start'

_state_lock = threading.Lock()
_playback_state = {}


def _window():
    return control.homeWindow


def get_skip_mode():
    try:
        return int(c.get_setting('introdb.skip_mode') or SKIP_OFF)
    except (TypeError, ValueError):
        return SKIP_OFF


def is_introdb_enabled():
    return str(c.get_setting('introdb.enabled') or 'true').lower() in ('true', '1')


def _need_introdb_fetch():
    '''Fetch when intro-skip or Up Next can use IntroDB data (not merely because enabled).'''
    if not is_introdb_enabled():
        return False
    if get_skip_mode() != SKIP_OFF:
        return True
    try:
        from . import upnext as upnext_mod
        return bool(upnext_mod.is_enabled())
    except Exception:
        return False


def _playback_key(session):
    return '|'.join([
        session.get('imdb') or '',
        session.get('tmdb') or '',
        session.get('season') or '',
        session.get('episode') or '',
    ])


def _build_segments(data):
    '''Recap and intro as separate segments, chronological order.'''
    segments = []
    for key in ('recap', 'intro'):
        segment = data.get(key)
        if segment:
            segments.append(segment)
    if not segments:
        skip = data.get('skip')
        if skip:
            segments.append(skip)
    segments.sort(key=lambda s: float(s.get('start_sec') or 0))
    return segments


def _current_segment(state):
    segments = state.get('segments') or []
    try:
        index = int(state.get('segment_index') or 0)
    except (TypeError, ValueError):
        index = 0
    if index < 0 or index >= len(segments):
        return None
    return segments[index]


def _advance_segment(key):
    with _state_lock:
        st = _playback_state.get(key)
        if st is None:
            return
        index = int(st.get('segment_index') or 0) + 1
        segments = st.get('segments') or []
        if index >= len(segments):
            st['done'] = True
            return
        st['segment_index'] = index
        st['prompt_answered'] = False
        st['approved'] = get_skip_mode() == SKIP_AUTO
        st['last_curr'] = None
        st['settle_ready'] = False


def reset_playback_state():
    with _state_lock:
        _playback_state.clear()
    win = _window()
    win.clearProperty(PENDING_PROP)
    win.clearProperty(PARAMS_PROP)
    win.clearProperty(RESULT_PROP)
    win.clearProperty(CREDITS_START_PROP)


def on_av_started(player):
    reset_playback_state()
    sess = playback_session.load()
    if not sess or (sess.get('mediatype') or '').lower() != 'episode':
        return
    if not _need_introdb_fetch():
        return

    key = _playback_key(sess)
    with _state_lock:
        _playback_state[key] = {
            'session': dict(sess),
            'segments': [],
            'segment_index': 0,
            'fetch_done': False,
            'done': False,
            'prompt_answered': False,
            'approved': get_skip_mode() == SKIP_AUTO,
            'skip_enabled': get_skip_mode() != SKIP_OFF,
            'started_at': time.time(),
            'last_curr': None,
            'settle_ready': False,
            'no_timing_logged': False,
        }

    thread = threading.Thread(
        target=_fetch_segments,
        args=(key, dict(sess), player),
        name='classy-introdb-fetch',
        daemon=True,
    )
    thread.start()


def _fetch_segments(key, session, player):
    try:
        duration_sec = None
        try:
            total = float(player.getTotalTime() or 0)
            if total > 0:
                duration_sec = total
        except Exception:
            pass
        duration_ms = int(duration_sec * 1000) if duration_sec else None
        data = introdb_api.get_media(
            tmdb_id=session.get('tmdb'),
            imdb_id=session.get('imdb'),
            season=session.get('season'),
            episode=session.get('episode'),
            duration_ms=duration_ms,
        )
        segments = _build_segments(data)
        credits = data.get('credits')
        if credits and credits.get('start_sec') is not None:
            _window().setProperty(CREDITS_START_PROP, str(credits['start_sec']))
        with _state_lock:
            st = _playback_state.get(key)
            if st is not None:
                st['segments'] = segments
                st['fetch_done'] = True
        if segments:
            parts = []
            for seg in segments:
                parts.append(
                    f'{seg.get("start_sec", 0):.1f}-{seg.get("end_sec", 0):.1f}s'
                )
            c.log(f'[IntroSkip] segments queued ({len(segments)}): {", ".join(parts)}')
    except Exception as exc:
        c.log(f'[IntroSkip] fetch failed: {exc}', 1)
        with _state_lock:
            st = _playback_state.get(key)
            if st is not None:
                st['fetch_done'] = True


def _try_chapter_fallback(player, state, key):
    if _current_segment(state):
        return False
    if not state.get('fetch_done'):
        return False
    try:
        total = float(player.getTotalTime() or 0)
        if total < 60:
            return False
        raw = xbmc.getInfoLabel('Player.Chapters')
        if not raw:
            return False
        marks = [float(x) for x in raw.split(',') if x.strip()]
        if len(marks) < 2:
            return False
        start_pct, end_pct = marks[0], marks[1]
        if start_pct > 5 or end_pct > 30 or end_pct <= start_pct:
            return False
        start_sec = total * start_pct / 100.0
        end_sec = total * end_pct / 100.0
        if start_sec < CHAPTER_MIN_START_SEC:
            return False
        if end_sec - start_sec < CHAPTER_MIN_SEGMENT_SEC or end_sec < CHAPTER_MIN_END_SEC:
            return False
        segments = [{
            'start_sec': start_sec,
            'end_sec': end_sec,
            'source': 'chapters',
        }]
        with _state_lock:
            st = _playback_state.get(key)
            if st is not None and not st.get('segments'):
                st['segments'] = segments
                st['segment_index'] = 0
        state['segments'] = segments
        state['segment_index'] = 0
        c.log(f'[IntroSkip] chapter fallback {start_sec:.1f}-{end_sec:.1f}s')
        return True
    except Exception as exc:
        c.log(f'[IntroSkip] chapter parse failed: {exc}', 1)
    return False


def _resume_sec(session):
    try:
        offset = float(session.get('resume_offset') or 0)
        progress = float(session.get('resume_progress') or 0)
        if progress > 0 and offset <= 0:
            return None
        return offset if offset > 0 else None
    except (TypeError, ValueError):
        return None


def _effective_playhead(player, session):
    try:
        curr = float(player.getTime() or 0)
    except Exception:
        curr = 0.0
    resume = _resume_sec(session)
    if resume is not None:
        return max(curr, resume)
    return curr


def _position_settled(player, state):
    if state.get('settle_ready'):
        return True
    started = state.get('started_at') or time.time()
    elapsed = time.time() - started
    try:
        curr = float(player.getTime() or 0)
    except Exception:
        return False
    last = state.get('last_curr')
    if last is not None and abs(curr - last) >= SETTLE_JUMP_SEC:
        state['last_curr'] = curr
        return False
    session = state.get('session') or {}
    resume = _resume_sec(session)
    if resume is not None and resume > PROMPT_EARLY_SEC:
        state['settle_ready'] = True
        return True
    if elapsed < SETTLE_SEC:
        state['last_curr'] = curr
        return False
    if last is not None and abs(curr - last) <= 3:
        state['settle_ready'] = True
        return True
    if elapsed >= SETTLE_MAX_WAIT_SEC:
        state['settle_ready'] = True
        return True
    state['last_curr'] = curr
    return False


def _past_segment(player, session, segment, approved):
    try:
        end_sec = float(segment['end_sec'])
        curr = _effective_playhead(player, session)
        if approved and curr < end_sec + POST_END_GRACE_SEC:
            return False
        return curr >= end_sec
    except Exception:
        return False


def _execute_seek(player, start_sec, end_sec, source):
    try:
        if not player.isPlayingVideo():
            return False
        player.seekTime(end_sec)
        time.sleep(0.4)
        actual = float(player.getTime() or 0)
        if abs(actual - end_sec) > 8:
            player.seekTime(end_sec)
            time.sleep(0.4)
            actual = float(player.getTime() or 0)
            if abs(actual - end_sec) > 8:
                c.log(f'[IntroSkip] seek stuck at {actual:.1f}s wanted {end_sec:.1f}s', 1)
                return False
        c.log(f'[IntroSkip] skipped ({source}) {start_sec:.1f} -> {end_sec:.1f}s')
        return True
    except Exception as exc:
        c.log(f'[IntroSkip] seek failed: {exc}', 1)
        return False


def _queue_prompt():
    win = _window()
    if win.getProperty(PENDING_PROP) == 'true':
        return
    win.setProperty(PARAMS_PROP, json.dumps({'countdown': PROMPT_COUNTDOWN_SEC}))
    win.setProperty(PENDING_PROP, 'true')
    win.clearProperty(RESULT_PROP)


def _read_prompt_result():
    win = _window()
    result = win.getProperty(RESULT_PROP) or ''
    if not result:
        return None
    win.clearProperty(RESULT_PROP)
    win.clearProperty(PENDING_PROP)
    win.clearProperty(PARAMS_PROP)
    return result


def tick(player):
    '''Called from ClassyPlayer position tracker (~1s).'''
    if not player.isPlayingVideo():
        return
    sess = playback_session.load()
    if not sess or (sess.get('mediatype') or '').lower() != 'episode':
        return
    if not is_introdb_enabled() or get_skip_mode() == SKIP_OFF:
        return

    key = _playback_key(sess)
    with _state_lock:
        state = _playback_state.get(key)
        if state is None or state.get('done'):
            return
        state = dict(state)

    _try_chapter_fallback(player, state, key)
    with _state_lock:
        live = _playback_state.get(key)
        if live is not None:
            state = dict(live)
    segment = _current_segment(state)
    if not segment:
        if state.get('fetch_done') and not state.get('no_timing_logged'):
            with _state_lock:
                st = _playback_state.get(key)
                if st is not None:
                    st['no_timing_logged'] = True
                    st['done'] = True
            c.log('[IntroSkip] no timing available')
        return

    session = state.get('session') or dict(sess)
    if _past_segment(player, session, segment, state.get('approved')):
        _advance_segment(key)
        return

    try:
        start_sec = float(segment['start_sec'])
        end_sec = float(segment['end_sec'])
        curr = float(player.getTime() or 0)
    except Exception:
        return

    mode = get_skip_mode()
    approved = state.get('approved')

    if mode == SKIP_PROMPT and not state.get('prompt_answered'):
        if not _position_settled(player, state):
            with _state_lock:
                st = _playback_state.get(key)
                if st is not None:
                    st['last_curr'] = state.get('last_curr')
                    st['settle_ready'] = state.get('settle_ready')
            return
        effective = _effective_playhead(player, session)
        should_prompt = effective >= start_sec and effective < end_sec
        if should_prompt:
            _queue_prompt()
            with _state_lock:
                st = _playback_state.get(key)
                if st is not None:
                    st['prompt_answered'] = True
            return

    if mode == SKIP_PROMPT and state.get('prompt_answered') and not approved:
        result = _read_prompt_result()
        if result is None:
            return
        if result == 'skip':
            approved = True
            with _state_lock:
                st = _playback_state.get(key)
                if st is not None:
                    st['approved'] = True
        else:
            _advance_segment(key)
            return

    if mode == SKIP_AUTO:
        approved = True

    if not approved:
        return

    if curr < start_sec - 1:
        return
    if curr >= end_sec:
        _advance_segment(key)
        return

    if _execute_seek(player, start_sec, end_sec, segment.get('source', 'introdb')):
        with _state_lock:
            st = _playback_state.get(key)
            if st is not None:
                st['approved'] = True
        _advance_segment(key)

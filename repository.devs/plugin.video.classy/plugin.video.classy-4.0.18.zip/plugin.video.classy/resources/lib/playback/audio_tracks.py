# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file audio_tracks.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Prefer audio track when multiple streams exist (Kodi locale or English fallback).'''

import xbmc

from ..kodi import kodi_locale
from ..modules.classy import c

_ENGLISH_TOKENS = ('eng', 'en', 'english')


def _preference_tokens():
    pref = kodi_locale.get_audio_language().lower()
    if not pref or pref == 'mediadefault':
        return list(_ENGLISH_TOKENS)
    tokens = [pref]
    if pref == 'eng':
        tokens.extend(('en', 'english'))
    elif pref == 'dut' or pref == 'nld':
        tokens.extend(('dut', 'nl', 'dutch', 'nld'))
    elif len(pref) == 2:
        tokens.append(pref)
    elif len(pref) == 3:
        tokens.append(pref[:2])
    return tokens


def _track_matches(track_label, tokens):
    label = (track_label or '').lower()
    for token in tokens:
        if token and token in label:
            return True
    return False


def select_preferred_audio(player=None):
    '''
    Switch audio only when multiple tracks exist and current is not preferred.

    Returns True when a switch was made.
    '''
    player = player or xbmc.Player()
    try:
        available = player.getAvailableAudioStreams() or []
    except Exception as exc:
        c.log(f'[Audio] list tracks failed: {exc}', 1)
        return False

    if len(available) <= 1:
        return False

    tokens = _preference_tokens()
    try:
        current_idx = int(player.getAudioStream())
    except Exception:
        current_idx = -1

    if 0 <= current_idx < len(available):
        if _track_matches(available[current_idx], tokens):
            return False

    for idx, track in enumerate(available):
        if _track_matches(track, tokens):
            try:
                player.setAudioStream(idx)
                c.log(f'[Audio] selected track {idx}: {track!r}')
                return True
            except Exception as exc:
                c.log(f'[Audio] setAudioStream failed: {exc}', 1)
                return False

    if c.devmode:
        c.log(f'[Audio] no preferred track in {available!r}; keeping default')
    return False

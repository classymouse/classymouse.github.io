# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file upnext_prescrape.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Silent mid-play scrape for the next episode (Up Next binge).

Started when Up Next arms the dialog for the current episode; results land in
upnext_cache for the next play route to consume before a full scrape overlay.'''

from __future__ import annotations

import threading

from ..modules.classy import c
from ..play.models import PlayRequest
from ..sources import upnext_cache
from ..sources.orchestrator import scrape_streams

_lock = threading.Lock()
_active_key = ''
_threads = []


def _request_from_next_ep(next_ep):
    if not isinstance(next_ep, dict):
        return None
    try:
        season = int(next_ep.get('season') or 0)
        episode = int(next_ep.get('episode') or 0)
    except (TypeError, ValueError):
        return None
    if season <= 0 or episode <= 0:
        return None
    imdb = next_ep.get('imdb') or ''
    tmdb = next_ep.get('tmdb') or ''
    if not imdb and not tmdb:
        return None
    return PlayRequest(
        mediatype='episode',
        title=next_ep.get('title') or '',
        year=next_ep.get('year') or '',
        imdb=imdb,
        tmdb=tmdb,
        season=season,
        episode=episode,
        tvshowtitle=next_ep.get('tvshowtitle') or next_ep.get('title') or '',
        premiered=next_ep.get('premiered') or '',
    )


def start(next_ep):
    '''Fire-and-forget silent scrape for next_ep. Dedupes in-flight keys.'''
    global _active_key
    try:
        from . import upnext as upnext_mod
        if not upnext_mod._owns_upnext():
            return False
        if not upnext_mod.is_enabled():
            return False
    except Exception:
        pass

    request = _request_from_next_ep(next_ep)
    if request is None:
        return False

    key = upnext_cache.cache_key_for_request(request)
    if not key:
        return False

    with _lock:
        global _threads
        _threads = [t for t in _threads if t.is_alive()]
        if _active_key == key and _threads:
            c.log(f'[UpNextPrescrape] already running {key}')
            return False
        _active_key = key

    def _worker():
        global _active_key
        try:
            c.log(
                f'[UpNextPrescrape] start '
                f'{request.tvshowtitle} S{request.season:02d}E{request.episode:02d}',
            )
            candidates, cancelled = scrape_streams(
                request, timeout=30, show_dialog=False,
            )
            if cancelled:
                c.log('[UpNextPrescrape] cancelled')
                return
            if not candidates:
                c.log('[UpNextPrescrape] 0 sources')
                return
            upnext_cache.put_candidates(
                request.imdb,
                request.tmdb,
                request.season,
                request.episode,
                candidates,
            )
            c.log(f'[UpNextPrescrape] done ({len(candidates)} streams)')
        except Exception as exc:
            c.log(f'[UpNextPrescrape] failed: {exc}', 1)
        finally:
            with _lock:
                if _active_key == key:
                    _active_key = ''

    thread = threading.Thread(target=_worker, name='UpNextPrescrape')
    thread.daemon = True
    with _lock:
        _threads.append(thread)
    thread.start()
    return True

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resume.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Playback resume lookup  -  Trakt or Simkl /sync/playback cache.'''

from .. import tracker
from ..progress import filters as slot_filters


def _norm_imdb(value):
    text = str(value or '').strip()
    if not text or text in ('0', 'None', 'null'):
        return ''
    if text.startswith('tt'):
        return text
    if text.isdigit():
        return f'tt{text}'
    return text


def _imdb_match(a, b):
    left = _norm_imdb(a)
    right = _norm_imdb(b)
    return bool(left and right and left == right)


def _duration_seconds(request, runtime_min=0):
    if runtime_min and int(runtime_min) > 0:
        return int(runtime_min) * 60
    meta = getattr(request, 'meta', None) or {}
    for key in ('duration', 'runtime'):
        raw = meta.get(key)
        if raw in (None, '', 0):
            continue
        try:
            value = int(float(raw))
        except (TypeError, ValueError):
            continue
        if value <= 0:
            continue
        # TMDB movie runtime is minutes; list rows often store seconds.
        if value > 500:
            return value
        return value * 60
    return 0


def _resume_entry(progress, duration, playback_id):
    if duration <= 0 or progress <= 0:
        return None
    resume_seconds = (duration * float(progress)) / 100.0
    if resume_seconds <= 0:
        return None
    return {
        'progress': float(progress),
        'duration': int(duration),
        'resume_seconds': float(resume_seconds),
        'playback_id': playback_id,
    }


def _match_episode_item(item, request):
    episode_data = item.get('episode') if isinstance(item.get('episode'), dict) else {}
    show_data = item.get('show') if isinstance(item.get('show'), dict) else {}
    try:
        season = int(episode_data.get('season') or 0)
        episode = int(episode_data.get('number') or 0)
    except (TypeError, ValueError):
        return False
    if season != int(request.season or 0) or episode != int(request.episode or 0):
        return False

    show_ids = show_data.get('ids') if isinstance(show_data.get('ids'), dict) else {}
    item_tmdb = str(show_ids.get('tmdb') or '').strip()
    item_imdb = show_ids.get('imdb') or ''
    req_tmdb = str(request.tmdb or '').strip()
    req_imdb = request.imdb or ''

    if req_tmdb and item_tmdb and req_tmdb == item_tmdb:
        return True
    if req_imdb and _imdb_match(req_imdb, item_imdb):
        return True
    return False


def _match_movie_item(item, request):
    movie_data = item.get('movie') if isinstance(item.get('movie'), dict) else {}
    ids = movie_data.get('ids') if isinstance(movie_data.get('ids'), dict) else {}
    item_tmdb = str(ids.get('tmdb') or '').strip()
    item_imdb = ids.get('imdb') or ''
    req_tmdb = str(request.tmdb or '').strip()
    req_imdb = request.imdb or ''

    if req_tmdb and item_tmdb and req_tmdb == item_tmdb:
        return True
    if req_imdb and _imdb_match(req_imdb, item_imdb):
        return True
    return False


def _scan_episode(items, request):
    pmin = slot_filters.resume_progress_min()
    pmax = slot_filters.resume_progress_max()
    for item in items or []:
        if not isinstance(item, dict) or not _match_episode_item(item, request):
            continue
        try:
            progress = float(item.get('progress', 0) or 0)
        except (TypeError, ValueError):
            continue
        if progress <= pmin or progress >= pmax:
            continue
        episode_data = item.get('episode') if isinstance(item.get('episode'), dict) else {}
        duration = _duration_seconds(request, episode_data.get('runtime') or 0)
        entry = _resume_entry(progress, duration, item.get('id'))
        if entry:
            return entry
    return None


def _scan_movie(items, request):
    pmin = slot_filters.resume_progress_min()
    pmax = slot_filters.resume_progress_max()
    for item in items or []:
        if not isinstance(item, dict) or not _match_movie_item(item, request):
            continue
        try:
            progress = float(item.get('progress', 0) or 0)
        except (TypeError, ValueError):
            continue
        if progress <= pmin or progress >= pmax:
            continue
        movie_data = item.get('movie') if isinstance(item.get('movie'), dict) else {}
        duration = _duration_seconds(request, movie_data.get('runtime') or 0)
        if duration <= 0:
            duration = _duration_seconds(request, 0)
        entry = _resume_entry(progress, duration, item.get('id'))
        if entry:
            return entry
        if progress > pmin and progress < pmax:
            meta_entry = from_row_meta(request)
            if meta_entry:
                meta_entry['progress'] = progress
                if item.get('id'):
                    meta_entry['playback_id'] = item.get('id')
                return meta_entry
    return None


def _playback_items(request, *, force=False):
    '''Resume rows from the active tracker backend (Trakt / Simkl / WeTrakr).'''
    if getattr(request, 'is_episode', False):
        mediatype = 'episode'
    elif getattr(request, 'is_movie', False):
        mediatype = 'movie'
    else:
        return []
    return tracker.playback_items(mediatype, force=force) or []


def lookup(request, *, force=False):
    '''
    Return resume dict for a PlayRequest or None.

    force=True drops playback caches first (clear-resume / post-scrobble).
    '''
    items = _playback_items(request, force=force)
    if getattr(request, 'is_episode', False):
        return _scan_episode(items, request)
    if getattr(request, 'is_movie', False):
        return _scan_movie(items, request)
    return None


def from_row_meta(request):
    '''Fallback when playback row lacks runtime  -  use embedded browse meta.'''
    meta = getattr(request, 'meta', None) or {}
    try:
        progress = float(meta.get('resume_point') or 0)
    except (TypeError, ValueError):
        progress = 0.0
    pmin = slot_filters.resume_progress_min()
    pmax = slot_filters.resume_progress_max()
    if progress <= pmin or progress >= pmax:
        return None
    duration = int(meta.get('duration') or 0)
    if duration <= 0:
        duration = _duration_seconds(request, meta.get('runtime') or 0)
    entry = _resume_entry(progress, duration, meta.get('playback_id') or '')
    if not entry:
        return None
    try:
        from .resume_prompt import MIN_RESUME_SECONDS
        if float(entry.get('resume_seconds') or 0) < float(MIN_RESUME_SECONDS):
            return None
    except Exception:
        pass
    return entry


def lookup_for_play(request):
    '''Tracker /sync/playback first, then row meta, then local bookmarks.db.

    Local never beats an online tracker resume hit (R1).
    '''
    info = lookup(request)
    if info:
        return info
    info = from_row_meta(request)
    if info:
        return info
    try:
        from ..modules import bookmarks as local_bookmarks
        return local_bookmarks.resume_entry_for_request(request)
    except Exception:
        return None


def clear_resume(request):
    '''Delete active tracker playback row and invalidate local caches.

    Dispatches to the active tracker backend (Trakt / Simkl / WeTrakr), which
    owns its per-service clear + local cache / session reset. Always clears
    the matching local bookmarks.db row when enabled (R1).
    '''
    removed = False
    if tracker.live():
        removed = bool(tracker.clear_resume(request))
    try:
        from ..modules import bookmarks as local_bookmarks
        imdb = getattr(request, 'imdb', '') or ''
        if getattr(request, 'is_episode', False):
            media = 'episode'
            season = getattr(request, 'season', 0) or 0
            episode = getattr(request, 'episode', 0) or 0
        else:
            media = 'movie'
            season = 0
            episode = 0
        had_local = local_bookmarks.get_record(imdb, media, season, episode) is not None
        local_bookmarks.clear_resume_point(media, imdb, season, episode)
        if had_local:
            removed = True
    except Exception:
        pass
    return removed

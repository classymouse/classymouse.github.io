# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file movies.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Movie browse routes  -  discovery lists.'''

import sys

from ..indexers import movie_discover
from ..indexers import movie_genres
from ..indexers import movie_progress
from ..indexers import movie_userlists
from ..indexers import movie_years
from ..modules.router import register_route


def _movies(params):
    handle = int(sys.argv[1])
    movie_discover.directory(handle, params)


def _movies_calendar(params):
    '''Theatrical / DVD release calendars  -  same discover path as movies&url=.'''
    handle = int(sys.argv[1])
    movie_discover.directory(handle, params)


_MOVIE_WIDGET_PRESETS = (
    'tmdb_movie_featured',
    'trending',
    'popular',
    'theaters',
    'tmdb_movie_latest_releases',
)


def _movie_widget(_params):
    '''New Movies  -  ``movie.widget`` picks discover preset (default Featured).'''
    handle = int(sys.argv[1])
    try:
        from ..modules.classy import c
        idx = int(c.get_setting('movie.widget') or 0)
    except Exception:
        idx = 0
    if idx < 0 or idx >= len(_MOVIE_WIDGET_PRESETS):
        idx = 0
    movie_discover.directory(handle, {'url': _MOVIE_WIDGET_PRESETS[idx]})


def _movie_years(_params):
    handle = int(sys.argv[1])
    movie_years.years_directory(handle)


def _movie_genres(_params):
    handle = int(sys.argv[1])
    movie_genres.genres_directory(handle)


def _movie_progress(_params):
    handle = int(sys.argv[1])
    movie_progress.directory(handle, _params)


register_route('movies', _movies)
register_route('movies_calendar', _movies_calendar)
register_route('movieWidget', _movie_widget)
register_route('movieYears', _movie_years)
register_route('movieGenres', _movie_genres)
register_route('movieProgress', _movie_progress)


def _movie_userlists(_params):
    handle = int(sys.argv[1])
    movie_userlists.directory(handle, _params)


register_route('movieUserlists', _movie_userlists)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file downloads.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Offline download action (sourceList CM). Folder browse is Tools -> Downloads.'''

from ..modules import kodi
from ..modules.classy import c
from ..modules.downloader import download, downloads_ready
from ..modules.router import register_route
from ..play.models import PlayRequest
from ..play.smart_resolve import _resolve_one
from ..sources.directory import load_session


def _download_handler(params):
    if not downloads_ready():
        kodi.notification(c.addon_id, c.lang(30895))
        return

    try:
        index = int((params or {}).get('index', -1))
    except (TypeError, ValueError):
        index = -1

    candidates, request = load_session()
    if not candidates:
        c.log('[Download] empty source session', 1)
        kodi.notification(c.addon_id, c.lang(30896))
        return
    if index < 0 or index >= len(candidates):
        c.log(f'[Download] invalid index={index}', 1)
        return

    if not request:
        request = PlayRequest()

    cand = candidates[index]
    c.log(
        f'[Download] start index={index} provider={cand.provider!r} '
        f'quality={cand.quality!r}'
    )
    play_url = _resolve_one(cand, request=request, quiet=False)
    if not play_url:
        kodi.notification(c.addon_id, c.lang(30896))
        return

    meta = (request.meta if request else None) or {}
    image = meta.get('poster') or meta.get('thumb') or ''
    name = request.display_title if request else (cand.name or 'Download')
    download(name, image, play_url, request=request)


register_route('download', _download_handler)

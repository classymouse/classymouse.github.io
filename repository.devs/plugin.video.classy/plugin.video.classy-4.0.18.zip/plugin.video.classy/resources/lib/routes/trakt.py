# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file trakt.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt routes  -  auth and future tracker actions.'''

from ..trakt import ui
from ..trakt.manager import manager
from ..modules.router import register_route


def _auth_trakt(_params):
    ui.auth_trakt()


def _open_resolveurl_settings(params):
    import xbmc

    from ..modules import control, kodi
    from ..tools import debrid_manager

    try:
        if not xbmc.getCondVisibility('System.HasAddon(script.module.resolveurl)'):
            kodi.notification(c.addon_id, 'Install script.module.resolveurl')
            return
        # Optional provider=alldebrid|premiumize|realdebrid|torbox lands on that tab.
        provider = (params or {}).get('provider') or ''
        debrid_manager.open_resolveurl_settings(provider)
    finally:
        control.finish_dialog_route()


def _trakt_manager(params):
    manager(
        (params or {}).get('name') or '',
        (params or {}).get('imdb') or '',
        (params or {}).get('tmdb') or '',
        (params or {}).get('content') or 'movie',
    )


register_route('authTrakt', _auth_trakt)
register_route('openResolveUrlSettings', _open_resolveurl_settings)
register_route('traktManager', _trakt_manager)

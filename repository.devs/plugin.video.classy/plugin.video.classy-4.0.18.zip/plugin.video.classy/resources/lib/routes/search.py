# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file search.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Movie / TV search  -  Crew-compatible action names.'''

import sys
from urllib.parse import unquote_plus

from ..modules.router import register_route
from ..search import browse
from ..search import person


def _handle():
    return int(sys.argv[1])


def _page(params):
    return (params or {}).get('page') or 1


def _movie_search(_params):
    browse.history_directory(_handle(), 'movie')


def _tv_search(_params):
    browse.history_directory(_handle(), 'tvshow')


def _movie_search_new(_params):
    browse.search_new('movie')


def _tv_search_new(_params):
    browse.search_new('tvshow')


def _movie_search_term(params):
    name = unquote_plus(str((params or {}).get('name') or ''))
    page = (params or {}).get('page') or 1
    browse.search_term('movie', name, page=page)


def _tv_search_term(params):
    name = unquote_plus(str((params or {}).get('name') or ''))
    page = (params or {}).get('page') or 1
    browse.search_term('tvshow', name, page=page)


def _movie_delete_term(params):
    browse.delete_search_term('movie', (params or {}).get('id'))


def _tv_delete_term(params):
    browse.delete_search_term('tvshow', (params or {}).get('id'))


def _clear_cache_search(_params):
    browse.clear_search_history()


def _movie_person(_params):
    person.search_new('movie')


def _tv_person(_params):
    person.search_new('tvshow')


def _movie_person_term(params):
    name = unquote_plus(str((params or {}).get('name') or ''))
    person.search_term('movie', name, page=_page(params))


def _tv_person_term(params):
    name = unquote_plus(str((params or {}).get('name') or ''))
    person.search_term('tvshow', name, page=_page(params))


def _movie_person_credits(params):
    person.credits_directory(
        _handle(),
        'movie',
        (params or {}).get('person_id'),
        name=unquote_plus(str((params or {}).get('name') or '')),
    )


def _tv_person_credits(params):
    person.credits_directory(
        _handle(),
        'tvshow',
        (params or {}).get('person_id'),
        name=unquote_plus(str((params or {}).get('name') or '')),
    )


def _movie_persons(_params):
    person.browse_directory(_handle(), 'movie')


register_route('movieSearch', _movie_search)
register_route('tvSearch', _tv_search)
register_route('movieSearchnew', _movie_search_new)
register_route('tvSearchnew', _tv_search_new)
register_route('movieSearchterm', _movie_search_term)
register_route('tvSearchterm', _tv_search_term)
register_route('movieDeleteTerm', _movie_delete_term)
register_route('tvDeleteTerm', _tv_delete_term)
register_route('clearCacheSearch', _clear_cache_search)
register_route('moviePerson', _movie_person)
register_route('tvPerson', _tv_person)
register_route('moviePersonterm', _movie_person_term)
register_route('tvPersonterm', _tv_person_term)
register_route('moviePersonCredits', _movie_person_credits)
register_route('tvPersonCredits', _tv_person_credits)
register_route('moviePersons', _movie_persons)

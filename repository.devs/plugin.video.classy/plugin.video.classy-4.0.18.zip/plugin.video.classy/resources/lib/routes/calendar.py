# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file calendar.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Calendar routes  -  What's On (TV) + future movie release calendar.'''

import sys

from ..indexers import tv_calendar
from ..modules.router import register_route


def _calendar(params):
    handle = int(sys.argv[1])
    tv_calendar.directory(handle, params)


register_route('calendar', _calendar)

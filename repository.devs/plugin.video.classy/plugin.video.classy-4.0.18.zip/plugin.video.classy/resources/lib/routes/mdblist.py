# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file mdblist.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

MDBList list-provider routes.'''

import sys

from ..indexers import mdb_lists
from ..modules.router import register_route


def _mdb_lists(params):
    handle = int(sys.argv[1])
    mdb_lists.directory(handle, params)


register_route('mdbLists', _mdb_lists)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file views.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

View mode routes  -  Tools picker, save folder, addView handler.'''

from ..indexers.navigator import n
from ..kodi import views
from ..modules.router import register_route


def _views_navigator(_params):
    n.navViews()


def _views_save_menu(params):
    n.navViewsSaveMenu((params or {}).get('content'))


def _add_view(params):
    views.add_view((params or {}).get('content'))


register_route('viewsNavigator', _views_navigator)
register_route('viewsSaveMenu', _views_save_menu)
register_route('addView', _add_view)

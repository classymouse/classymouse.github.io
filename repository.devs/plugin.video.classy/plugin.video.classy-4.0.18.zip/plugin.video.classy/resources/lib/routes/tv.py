# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tv.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV browse routes  -  seasons and episodes.'''

import sys

from ..indexers import documentaries
from ..indexers import tv_browse
from ..indexers import tv_genres
from ..indexers import tv_networks
from ..modules.router import register_route


def _seasons(params):
    handle = int(sys.argv[1])
    tv_browse.seasons_directory(handle, params)


def _episodes(params):
    handle = int(sys.argv[1])
    tv_browse.episodes_directory(handle, params)


def _tvshows(params):
    handle = int(sys.argv[1])
    from ..indexers import tv_discover
    tv_discover.directory(handle, params)


def _tv_genres(_params):
    handle = int(sys.argv[1])
    tv_genres.genres_directory(handle)


def _tv_networks(_params):
    handle = int(sys.argv[1])
    tv_networks.networks_directory(handle)


def _documentaries(_params):
    handle = int(sys.argv[1])
    documentaries.documentaries_directory(handle)


def _tv_widget(params):
    '''Skin / home TV widget  -  ``tv.widget`` picks Next / Resume / New Shows.'''
    handle = int(sys.argv[1])
    try:
        from ..modules.classy import c
        idx = int(c.get_setting('tv.widget') or 0)
    except Exception:
        idx = 0
    if idx == 1:
        from ..indexers import progress as progress_indexer
        progress_indexer.in_progress_episodes(handle, params or {})
        return
    if idx == 2:
        from ..indexers import tv_discover
        tv_discover.directory(handle, {'url': 'premiere'})
        return
    from ..indexers import progress as progress_indexer
    progress_indexer.next_episodes(handle, params or {})


register_route('seasons', _seasons)
register_route('episodes', _episodes)
register_route('tvshows', _tvshows)
register_route('tvGenres', _tv_genres)
register_route('tvNetworks', _tv_networks)
register_route('docuNavigator', _documentaries)
register_route('tvWidget', _tv_widget)

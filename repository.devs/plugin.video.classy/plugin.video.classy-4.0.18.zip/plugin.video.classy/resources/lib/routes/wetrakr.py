# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file wetrakr.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr routes  -  authorize / revoke / about / lists / public / search / manager.'''

import sys

import xbmcgui

from ..apis import wetrakr
from ..indexers import movie_discover
from ..indexers import tv_discover
from ..indexers import wetrakr_publiclists
from ..indexers import wetrakr_userlists
from ..modules.router import register_route
from ..wetrakr import manager as wetrakr_manager


def _auth_wetrakr(_params):
    wetrakr.authenticate()


def _revoke_wetrakr(_params):
    wetrakr.revoke()


def _about_wetrakr(_params):
    wetrakr.about()


def _wetrakr_userlists(params):
    handle = int(sys.argv[1])
    wetrakr_userlists.directory(handle, params)


def _wetrakr_publiclists(params):
    handle = int(sys.argv[1])
    wetrakr_publiclists.directory(handle, params)


def _wetrakr_search(params):
    '''Prompt then open movies|tvshows&url=wetrakrsearch&query=.'''
    media = str((params or {}).get('media') or 'movie').strip().lower()
    is_show = media in ('show', 'shows', 'tv', 'tvshow')
    query = str((params or {}).get('query') or '').strip()
    if not query:
        heading = 'Search WeTrakr TV' if is_show else 'Search WeTrakr Movies'
        query = (xbmcgui.Dialog().input(heading, type=xbmcgui.INPUT_ALPHANUM) or '').strip()
    if not query:
        return
    handle = int(sys.argv[1])
    payload = {'url': 'wetrakrsearch', 'query': query, 'page': '1'}
    if is_show:
        tv_discover.directory(handle, payload)
    else:
        movie_discover.directory(handle, payload)


def _wetrakr_manager(params):
    wetrakr_manager.manager(
        (params or {}).get('name') or '',
        (params or {}).get('imdb') or '',
        (params or {}).get('tmdb') or '',
        (params or {}).get('content') or 'movie',
    )


register_route('authWetrakr', _auth_wetrakr)
register_route('revokeWetrakr', _revoke_wetrakr)
register_route('aboutWetrakr', _about_wetrakr)
register_route('wetrakrUserlists', _wetrakr_userlists)
register_route('wetrakrPubliclists', _wetrakr_publiclists)
register_route('wetrakrSearch', _wetrakr_search)
register_route('wetrakrManager', _wetrakr_manager)

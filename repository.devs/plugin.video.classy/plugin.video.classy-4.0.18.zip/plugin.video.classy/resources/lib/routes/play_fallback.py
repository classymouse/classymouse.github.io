# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file play_fallback.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

from ..modules.router import register_route
from ..play.fallback_queue import continue_fallback


def _play_fallback_handler(params):
    del params
    continue_fallback()


register_route('playFallback', _play_fallback_handler)

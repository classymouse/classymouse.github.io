# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tools.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Tools routes  -  cache, logs, changelog (+ Crew action aliases).'''

from ..indexers.navigator import n
from ..modules.router import register_route
from ..tools import (
    cache_tools,
    changelog,
    debrid_manager,
    device_info,
    log_upload,
    scraper_packs_dialog,
)
from ..wetrakr import maintenance as wetrakr_maintenance


def _clear_caches_menu(_params):
    n.navClearCaches()


def _upload_logs_menu(_params):
    n.navUploadLogs()


def _changelog(_params):
    changelog.show()


def _upload_kodi(_params):
    log_upload.LogUploader.upload_kodi_log()


def _upload_classy(_params):
    log_upload.LogUploader.upload_classy_log()


def _debrid_management(_params):
    n.navDebridManagement()


def _debrid_service(params):
    debrid_manager.open_service_menu((params or {}).get('provider') or '')


def _scraper_packs(_params):
    scraper_packs_dialog.open_dialog()


def _device_info(_params):
    device_info.show()


register_route('clearCaches', _clear_caches_menu)
register_route('cachingTools', _clear_caches_menu)
register_route('uploadLogs', _upload_logs_menu)
register_route('changelog', _changelog)
register_route('uploadKodiLog', _upload_kodi)
register_route('uploadClassyLog', _upload_classy)
register_route('uploadCrewLog', _upload_classy)
register_route('debridManagement', _debrid_management)
register_route('debridService', _debrid_service)
register_route('scraperPacks', _scraper_packs)
register_route('deviceInfo', _device_info)

register_route('clearSources', lambda _p: cache_tools.confirm_and_clear('providers'))
register_route('clearCacheSearch', lambda _p: cache_tools.confirm_and_clear('search'))
register_route('clearCache', lambda _p: cache_tools.confirm_and_clear('main'))
register_route('clearMetaCache', lambda _p: cache_tools.confirm_and_clear('meta'))
register_route('clearCacheDebrid', lambda _p: cache_tools.confirm_and_clear('debrid'))
register_route('clearAllCache', lambda _p: cache_tools.confirm_and_clear('all'))
register_route('clearCacheWetrakr', lambda _p: cache_tools.confirm_and_clear('wetrakr'))
register_route('wetrakrForceSync', lambda _p: wetrakr_maintenance.confirm_and_force_sync())

# Legacy aliases from first 4.0.5 cache scaffold
register_route('clearCacheScrape', lambda _p: cache_tools.confirm_and_clear('providers'))
register_route('clearCacheMetadata', lambda _p: cache_tools.confirm_and_clear('meta'))
register_route('clearCacheAll', lambda _p: cache_tools.confirm_and_clear('all'))

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file alter_sources.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Alter sources  -  re-run scrape/play with flipped picker mode (Crew parity).'''

from ..modules.classy import c
from ..modules.router import register_route, register_route_alias
from ..play.alter import params_for_alter_play
from .play import play_handler


def alter_sources_handler(params):
    play_params = params_for_alter_play(params)
    if not play_params.get('imdb') and not play_params.get('tmdb'):
        c.log(f'[Alter] rejected sparse params: {params!r}', 1)
        return
    c.log(f'[Alter] select={play_params.get("select")} imdb={play_params.get("imdb")} tmdb={play_params.get("tmdb")}')
    play_handler(play_params)


register_route('alter_sources', alter_sources_handler)
register_route_alias('alterSources', 'alter_sources')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file navigator.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Navigator / settings routes  -  Crew action names map to show_menu or existing nav.'''

from ..indexers.navigator import n
from ..modules import kodi
from ..modules.classy import c
from ..modules.router import register_route


def _root(_params):
    n.root()


def _nav_movies(_params):
    n.navMovies()


def _nav_tvshows(_params):
    n.navTVShows()


def _nav_movie_discover(_params):
    n.navMovieDiscover()


def _nav_tv_progress(_params):
    n.navTVProgress()


def _nav_tv_discover(_params):
    n.navTVDiscover()


def _nav_tools(_params):
    n.navTools()


def _nav_devs(_params):
    if not c.is_devmode():
        kodi.notification('The Crew', 'Developers menu requires dev password')
        n.root()
        return
    n.navDevs()


def _nav_dev_lists(_params):
    if not c.is_devmode():
        kodi.notification('The Crew', 'Developers menu requires dev password')
        n.root()
        return
    n.navDevLists()


def _trakt_movies(_params):
    n.traktMovies()


def _trakt_shows(_params):
    n.traktTVShows()


def _open_settings(params):
    kodi.open_settings(query=params.get('query', ''))


def _developers(_params):
    _nav_devs(_params)


def _movie_navigator(_params):
    n.navMovies()


def _tv_navigator(_params):
    n.navTVShows()


def _tool_navigator(_params):
    n.navTools()


def _library_navigator(_params):
    n.navLibrary()


def _my_movies_lite(_params):
    n.mymovies(lite=True)


def _my_tv_lite(_params):
    n.mytvshows(lite=True)


def _submenu(menu_key):
    def _handler(_params):
        n.show_menu(menu_key)
    return _handler


register_route('', _root)
register_route('navMovies', _nav_movies)
register_route('navMovieDiscover', _nav_movie_discover)
register_route('navTVShows', _nav_tvshows)
register_route('navTVProgress', _nav_tv_progress)
register_route('navTVDiscover', _nav_tv_discover)
register_route('navTools', _nav_tools)
register_route('navDevs', _nav_devs)
register_route('navDevLists', _nav_dev_lists)
register_route('traktmovies', _trakt_movies)
register_route('traktshows', _trakt_shows)
register_route('opensettings', _open_settings)

# Crew-compatible root action names (widgets / shortcuts / parity).
register_route('developers', _developers)
register_route('movieNavigator', _movie_navigator)
register_route('tvNavigator', _tv_navigator)
register_route('toolNavigator', _tool_navigator)
register_route('libraryNavigator', _library_navigator)
register_route('bluehat', _submenu('bluehat'))
register_route('kidsNavigator', _submenu('kids'))
register_route('searchNavigator', _submenu('search'))

# Movies / TV  -  Crew-shaped submenus (menus.py).
register_route('mymovieliteNavigator', _my_movies_lite)
register_route('mytvliteNavigator', _my_tv_lite)
register_route('tmdbmovieslist', _submenu('tmdbmovieslist'))
register_route('tmdbtvlist', _submenu('tmdbtvlist'))
register_route('calendars_menu', _submenu('calendars_menu'))
register_route('calendarsAllNavigator', _submenu('calendars_menu'))


def _whats_on_section(_params):
    '''Section divider row inside What's On  -  no action.'''
    pass


register_route('whatsOnSection', _whats_on_section)
register_route('movies_calendars_menu', _submenu('movies_calendars_menu'))
register_route('wetrakrDiscoverMovies', _submenu('wetrakr_discover_movies'))
register_route('wetrakrDiscoverTV', _submenu('wetrakr_discover_tv'))
register_route('halloweenNavigator', _submenu('halloween'))
register_route('holidaysNavigator', _submenu('holidays'))
register_route('tvliteNavigator', _tv_navigator)
register_route('tvCertificates', _submenu('tv_certificates_menu'))
register_route('tvLanguages', _submenu('tv_languages_menu'))
register_route('movieliteNavigator', _movie_navigator)
register_route('traktlist', _submenu('traktlist'))
register_route('movieCertificates', _submenu('movie_certificates_menu'))
register_route('movieLanguages', _submenu('movie_languages_menu'))

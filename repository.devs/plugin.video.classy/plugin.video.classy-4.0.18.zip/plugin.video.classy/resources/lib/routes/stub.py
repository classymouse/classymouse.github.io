# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file stub.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Placeholder routes for menu / CM items marked ** (not wired yet).'''

from ..modules.classy import c
from ..modules.router import register_route


def notify_not_implemented(params, heading='The Crew'):
    action = str((params or {}).get('action') or '')
    url = str((params or {}).get('url') or '')
    detail = action
    if url:
        detail = f'{action}&url={url}' if action else url
    c.log(f'[Stub] not implemented: {detail}')
    c.infoDialog(
        'Marked ** in the menu  -  not wired yet.',
        heading=heading,
        sound=True,
        icon='INFO',
    )


def _stub_handler(params):
    notify_not_implemented(params)
    try:
        import sys
        from ..modules import kodi
        handle = int(sys.argv[1])
        kodi.content(handle, 'videos')
        kodi.directory(handle, cacheToDisc=False)
    except Exception:
        pass


# Navigator / search / TV browse stubs (Crew parity).
_NAV_STUB_ACTIONS = (
)

# Context-menu / playcount actions (Crew parity  -  stub until shipped).
_CM_STUB_ACTIONS = (
    'queueItem',
    'clearSources',
    'random',
    'traktMyRatings',
    'traktMyStatistics',
)

for _action in _NAV_STUB_ACTIONS:
    register_route(_action, _stub_handler)

for _action in _CM_STUB_ACTIONS:
    register_route(_action, _stub_handler)

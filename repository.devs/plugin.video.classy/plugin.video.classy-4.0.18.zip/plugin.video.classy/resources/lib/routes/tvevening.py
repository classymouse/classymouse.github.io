# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file tvevening.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TV Evening route  -  dialog-only entry (no directory listing).'''

from ..modules.router import register_route
from ..tvevening import start_tv_evening


def _tvevening(_params):
    start_tv_evening()


register_route('tvevening', _tvevening)

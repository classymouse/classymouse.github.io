# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file orion.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Orion Tools routes  -  install, authorize, settings (Crew parity).'''

from ..indexers.navigator import n
from ..modules.router import register_route
from ..orion.api import api


def _orion_nav(_params):
    n.navOrion()


register_route('OrionNavigator', _orion_nav)
register_route('installOrion', lambda _p: api.install_orion())
register_route('authorizeOrion', lambda _p: api.authorize_orion())
register_route('registerOrion', lambda _p: api.register_orion())
register_route('userInfoOrion', lambda _p: api.user_info_orion())
register_route('settingsOrion', lambda _p: api.settings_orion())
register_route('filtersOrion', lambda _p: api.settings_orion_filters())
register_route('globalFiltersOrion', lambda _p: api.global_filters_orion())
register_route('serverOrion', lambda _p: api.server_orion())

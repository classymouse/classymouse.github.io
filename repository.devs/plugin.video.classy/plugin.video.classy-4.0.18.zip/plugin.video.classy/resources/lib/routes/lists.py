# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file lists.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

XML list routes  -  fetch, parse, directory.'''

import sys
from urllib.parse import unquote_plus

from ..lists.bridge import install_lists_ecosystem_shims
from ..lists.directory import show_directory
from ..lists.fetch import fetch_list
from ..lists.parse import parse_list
from ..lists.registry import ROOT_URLS, url_for_action
from ..lists.resolver import expand_regex_url, payload_for_fetch
from ..modules.classy import c
from ..modules.router import register_route

LIST_ROOT_ACTIONS = frozenset({
    '247movies', '247tvshows', 'yss', 'weak',
    'sportsbay', 'sports24', 'gratis', 'base', 'waste', 'arconai', 'stratus', 'distro',
    'xumo', 'bumble', 'pluto', 'tubi', 'spanish', 'spanish2', 'bp', 'arabic', 'arabic2',
    'india', 'chile', 'colombia', 'argentina', 'spain', 'cctv', 'titan', 'porn', 'faith',
    'lust', 'greyhat', 'absolution', 'eyecandy', 'purplehat', 'retribution', 'kiddo',
    'redhat', 'yellowhat', 'blackhat', 'food', 'ncaa', 'ncaab', 'lfl', 'xfl', 'boxing',
    'tennis', 'mlb', 'nfl', 'nhl', 'nba', 'ufc', 'fifa', 'wwe', 'motogp', 'f1', 'pga',
    'nascar', 'cricket', 'sports_channels', 'sreplays', 'greenhat',
    'misc_sports', 'fullsites',
    'classy', 'git',
})

LIST_FLOW_ACTIONS = frozenset({
    'directory', 'qdirectory', 'plist',
})

LIST_REGEX_ACTIONS = frozenset({
    'xdirectory', 'tvtuner',
})


def _load_list_items(feed_url):
    feed_url = expand_regex_url(feed_url)
    fetch_url, inline = payload_for_fetch(feed_url)
    if inline:
        raw = inline
        source = feed_url[:80]
    elif fetch_url:
        raw = fetch_list(fetch_url)
        source = fetch_url[:80]
    else:
        return [], ''

    if not raw:
        return [], source

    items, _regex = parse_list(raw, source_url=source)
    return items, source


def _resolve_feed_url(params):
    action = (params.get('action') or '').strip()
    if action == 'plist':
        return (c.get_setting('personal.list') or '').strip()
    if action in LIST_FLOW_ACTIONS:
        return unquote_plus(params.get('url') or '')
    return url_for_action(action) or ''


def _list_route(params):
    install_lists_ecosystem_shims()
    action = params.get('action') or ''
    feed_url = _resolve_feed_url(params)
    handle = int(sys.argv[1])

    if not feed_url:
        c.log(f'[Lists] no feed url for action={action!r}')
        show_directory(handle, [])
        return

    items, source = _load_list_items(feed_url)
    if not items and source:
        c.log(f'[Lists] fetch/parse empty action={action!r} url={source}', 1)
    else:
        c.log(f'[Lists] action={action!r} items={len(items)} url={source}')
    show_directory(handle, items)


def _regex_list_route(params):
    install_lists_ecosystem_shims()
    action = params.get('action') or ''
    handle = int(sys.argv[1])
    raw_url = unquote_plus(params.get('url') or '')
    if not raw_url:
        c.log(f'[Lists] {action} empty url', 1)
        show_directory(handle, [])
        return

    items, source = _load_list_items(raw_url)
    c.log(f'[Lists] {action} items={len(items)} url={source or raw_url[:80]}')
    show_directory(handle, items)


def _register(action):
    register_route(action, _list_route)


_LIST_ACTIONS = set(LIST_ROOT_ACTIONS) | set(ROOT_URLS.keys())

for _action in _LIST_ACTIONS:
    _register(_action)

for _action in LIST_FLOW_ACTIONS:
    _register(_action)

for _action in LIST_REGEX_ACTIONS:
    register_route(_action, _regex_list_route)


def open_list_action(action):
    '''Shared entry for navigator routes (direct root feed actions).'''
    _list_route({'action': action})


def _test_white_streams(params):
    '''Dev  -  local test_local.xml from addon root (Whitehat sample streams).'''
    del params
    path = f'special://home/addons/{c.addon_id}/test_local.xml'
    _list_route({'action': 'directory', 'url': path})


def _testings_route(params):
    '''
    Profile testings.xml cheat (Crew 3.x developer action).
    Root menu row appears only when the file exists  -  no adult PIN.
    '''
    del params
    from ..lists.testings import load_testings_items

    install_lists_ecosystem_shims()
    handle = int(sys.argv[1])
    items = load_testings_items()
    if not items:
        c.log('[Lists] testings.xml empty or missing', 1)
    show_directory(handle, items)


register_route('testWhiteStreams', _test_white_streams, dev_only=True)
# Crew action name `developer` kept for XML / favourites parity.
register_route('testings', _testings_route)
register_route('developer', _testings_route)

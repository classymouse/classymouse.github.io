# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Developer-only routes.'''

from ..dev import dev_client_test
from ..dev import dev_apis_test
from ..dev import dev_trakt_test
from ..tools import dev_tools
from ..modules import kodi
from ..modules.classy import c
from ..modules.router import register_route


def _test_threads(_params):
    workers = c.get_max_threads(100)
    msg = f'cpu={c.cpu_count} workers(100)={workers}'
    c.log(f'[Dev] threads {msg}')
    kodi.notification('Threads', msg)


def _test_client(_params):
    summary = dev_client_test.run()
    kodi.notification('Client test', summary[:160] if summary else 'done')


def _test3(_params):
    summary = dev_apis_test.run()
    kodi.notification('APIs test', summary[:160] if summary else 'done')


def _test_trakt(_params):
    summary = dev_trakt_test.run()
    kodi.notification('Trakt test', summary[:160] if summary else 'done')


def _test4(_params):
    c.log('Test4 action triggered')
    kodi.notification('Test4', 'Test4 action executed')


def _test_metadata(_params):
    from ..dev import dev_metadata_test
    summary = dev_metadata_test.run()
    kodi.notification('Metadata test', summary[:160] if summary else 'done')


def _test_progress(_params):
    from ..dev import dev_progress_test
    summary = dev_progress_test.run()
    kodi.notification('Progress test', summary[:160] if summary else 'done')


def _test_lists_bridge(_params):
    from ..dev import dev_lists_bridge_test
    summary = dev_lists_bridge_test.run()
    kodi.notification('Lists bridge', summary[:160] if summary else 'done')


def _test_search(_params):
    from ..dev import dev_search_test
    summary = dev_search_test.run()
    kodi.notification('Search test', summary[:160] if summary else 'done')


def _test_videolibrary(params):
    from ..dev import dev_videolibrary_test
    summary = dev_videolibrary_test.run(params)
    kodi.notification('VideoLibrary probe', summary[:200] if summary else 'done')


register_route('test1', _test_threads, dev_only=True)
register_route('test2', _test_client, dev_only=True)
register_route('test3', _test3, dev_only=True)
register_route('test4', _test_trakt, dev_only=True)
register_route('test5', _test4, dev_only=True)
register_route('test6', _test_metadata, dev_only=True)
register_route('test7', _test_progress, dev_only=True)
register_route('test8', _test_lists_bridge, dev_only=True)
register_route('testSearch', _test_search, dev_only=True)
register_route('testVideoLibrary', _test_videolibrary, dev_only=True)

register_route('copyOsCreds', lambda _p: dev_tools.copy_os_creds(), dev_only=True)
register_route('checkUserAscii', lambda _p: dev_tools.check_user_ascii(), dev_only=True)
register_route('fixUserAscii', lambda _p: dev_tools.fix_user_ascii(), dev_only=True)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file my_crew.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

My Crew routes  -  pinboard navigator + pin/remove/rename/manage.'''

from urllib.parse import unquote_plus

import xbmc
import xbmcgui

from ..indexers.my_crew import directory as my_crew_directory
from ..modules import kodi
from ..modules.classy import c
from ..modules.router import register_route
from ..pinboard import store as pinboard_store


def _pinboard_navigator(_params):
    my_crew_directory()


def _pin_to_my_crew(params):
    target = unquote_plus(params.get('target') or '')
    label = unquote_plus(params.get('label') or '')
    icon = unquote_plus(params.get('icon') or '')

    if not target:
        kodi.notification(c.addon_id, 'Cannot pin  -  missing action')
        return

    if not label:
        label = target

    custom = xbmcgui.Dialog().input(
        _lang(90234, 'Shortcut label'),
        defaultt=pinboard_store.strip_label_markup(label),
    )
    if custom is None:
        return
    custom = pinboard_store.strip_label_markup(custom)
    if not custom:
        kodi.notification(c.addon_id, 'Pin cancelled')
        return

    ok, reason = pinboard_store.add_item(custom, target, icon=icon)
    if ok:
        kodi.notification(c.addon_id, f'Pinned: {custom}')
        c.log(f'[MyCrew] user pinned {custom!r}')
    elif reason == 'already pinned':
        kodi.notification(c.addon_id, 'Already in My Crew')
    else:
        kodi.notification(c.addon_id, 'Could not pin shortcut')


def _remove_from_my_crew(params):
    item_id = params.get('item_id')
    if item_id not in (None, ''):
        ok = pinboard_store.remove_item(int(item_id))
    else:
        target = unquote_plus(params.get('target') or '')
        ok = pinboard_store.remove_by_action(target)

    if ok:
        kodi.notification(c.addon_id, 'Removed from My Crew')
        xbmc.executebuiltin('Container.Refresh')
    else:
        kodi.notification(c.addon_id, 'Shortcut not found')


def _rename_my_crew_item(params):
    try:
        item_id = int(params.get('item_id') or 0)
    except (TypeError, ValueError):
        return
    if item_id <= 0:
        return

    rows = pinboard_store.list_items()
    current = next((r for r in rows if int(r['id']) == item_id), None)
    if not current:
        return

    new_label = xbmcgui.Dialog().input(
        _lang(90234, 'Shortcut label'),
        defaultt=current.get('label') or '',
    )
    if new_label is None:
        return
    new_label = pinboard_store.strip_label_markup(new_label)
    if not new_label:
        return

    if pinboard_store.rename_item(item_id, new_label):
        kodi.notification(c.addon_id, 'Shortcut renamed')
        xbmc.executebuiltin('Container.Refresh')


def _move_my_crew_item(params):
    try:
        item_id = int(params.get('item_id') or 0)
        direction = int(params.get('direction') or 0)
    except (TypeError, ValueError):
        return
    if item_id <= 0 or direction not in (-1, 1):
        return
    if pinboard_store.move_item(item_id, direction):
        xbmc.executebuiltin('Container.Refresh')


def _my_crew_manage(_params):
    body = (
        'Long-press any menu row and choose Pin to My Crew.[CR]'
        'Inside My Crew, long-press a shortcut to rename, reorder, or remove.'
    )
    try:
        body = c.lang(90235)
    except Exception:
        pass
    xbmcgui.Dialog().ok(_lang(90236, 'My Crew'), body)


def _lang(string_id, fallback):
    try:
        text = c.lang(string_id)
        if text and str(text) != str(string_id):
            return text
    except Exception:
        pass
    return fallback


register_route('pinboardNavigator', _pinboard_navigator)
register_route('pinToMyCrew', _pin_to_my_crew)
register_route('removeFromMyCrew', _remove_from_my_crew)
register_route('renameMyCrewItem', _rename_my_crew_item)
register_route('moveMyCrewItem', _move_my_crew_item)
register_route('myCrewManage', _my_crew_manage)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Route tables  -  register actions here or in domain route modules.

Add new files under routes/ (progress.py, movies.py, ...) and import
them from routes/__init__.py.'''

from . import navigator
from . import dev
from . import trakt
from . import simkl
from . import wetrakr
from . import mdblist
from . import progress
from . import tv
from . import movies
from . import play
from . import play_fallback
from . import sources
from . import downloads
from . import lists
from . import adult
from . import search
from . import advanced_search
from . import calendar
from . import bookmarks
from . import my_crew
from . import playcount
from . import alter_sources
from . import library
from . import tvevening
from . import tools
from . import views
from . import orion
from . import trailer
from . import stub

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file adult.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Adult section routes  -  PIN settings actions and gated menu entry.'''

from ..indexers.adult import Adult
from ..modules import adult_pin
from ..modules.classy import c
from ..modules.router import register_route


def _porn_check_pin(_params):
    if adult_pin.AdultPIN.check_access():
        Adult().root()
    else:
        c.log('[Adult] access denied by PIN gate')


def _enable_adult_pin(_params):
    adult_pin.AdultPIN.enable_protection()


def _disable_adult_pin(_params):
    adult_pin.AdultPIN.disable_protection()


def _setup_adult_pin(_params):
    adult_pin.AdultPIN.setup_pin()


def _reset_adult_pin(_params):
    adult_pin.AdultPIN.reset_pin()


def _remove_adult_pin(_params):
    adult_pin.AdultPIN.remove_pin()


def _adult_site_handler(params):
    Adult().site_handler(params.get('site') or '')


def _adult_videos(params):
    Adult().videos(
        params.get('site') or '',
        url=params.get('url'),
        page=params.get('page') or '1',
    )


def _adult_search(params):
    Adult().search(params.get('site') or '')


def _adult_play(params):
    Adult().play(params.get('site') or '', params.get('url') or '')


register_route('porn_check_pin', _porn_check_pin)
register_route('enable_adult_pin', _enable_adult_pin)
register_route('disable_adult_pin', _disable_adult_pin)
register_route('setup_adult_pin', _setup_adult_pin)
register_route('reset_adult_pin', _reset_adult_pin)
register_route('remove_adult_pin', _remove_adult_pin)
register_route('adult_site_handler', _adult_site_handler)
register_route('adult_videos', _adult_videos)
register_route('adult_search', _adult_search)
register_route('adult_play', _adult_play)

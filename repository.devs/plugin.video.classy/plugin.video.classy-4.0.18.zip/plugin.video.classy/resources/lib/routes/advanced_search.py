# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file advanced_search.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Advanced Search + Saved Filters routes.'''

import sys

from ..modules.classy import c
from ..modules.router import register_route
from ..search import advanced


def _handle():
    return int(sys.argv[1])


def _movie_advanced_search(params):
    p = params or {}
    advanced.run_dialog_flow(
        'movie',
        p.get('filter_id'),
        from_cm=str(p.get('from_cm') or '') in ('1', 'true', 'True'),
    )


def _tv_advanced_search(params):
    p = params or {}
    advanced.run_dialog_flow(
        'tv',
        p.get('filter_id'),
        from_cm=str(p.get('from_cm') or '') in ('1', 'true', 'True'),
    )


def _movie_results(params):
    advanced.results_directory(
        _handle(),
        'movie',
        advanced.decode_filter(params),
        page=(params or {}).get('page') or 1,
    )


def _tv_results(params):
    advanced.results_directory(
        _handle(),
        'tv',
        advanced.decode_filter(params),
        page=(params or {}).get('page') or 1,
    )


def _movie_saved_filters(_params):
    advanced.saved_filters_directory(_handle(), 'movie')


def _tv_saved_filters(_params):
    advanced.saved_filters_directory(_handle(), 'tv')


def _movie_execute_filter(params):
    advanced.execute_saved_filter('movie', (params or {}).get('id'))


def _tv_execute_filter(params):
    advanced.execute_saved_filter('tv', (params or {}).get('id'))


def _movie_delete_filter(params):
    advanced.FilterManager().delete_filter((params or {}).get('id'))


def _tv_delete_filter(params):
    advanced.FilterManager().delete_filter((params or {}).get('id'))


def _movie_clear_all(_params):
    if not c.yesnoDialog('Delete all saved movie filters?', 'This cannot be undone.'):
        return
    count = advanced.FilterManager().delete_all_filters('movie')
    c.infoDialog(f'Deleted {count} filter(s)', icon='INFO')
    try:
        import xbmc
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def _tv_clear_all(_params):
    if not c.yesnoDialog('Delete all saved TV filters?', 'This cannot be undone.'):
        return
    count = advanced.FilterManager().delete_all_filters('tv')
    c.infoDialog(f'Deleted {count} filter(s)', icon='INFO')
    try:
        import xbmc
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


register_route('movieAdvancedSearch', _movie_advanced_search)
register_route('tvAdvancedSearch', _tv_advanced_search)
register_route('movieAdvancedResults', _movie_results)
register_route('tvAdvancedResults', _tv_results)
register_route('movieSavedFilters', _movie_saved_filters)
register_route('tvSavedFilters', _tv_saved_filters)
register_route('movieExecuteFilter', _movie_execute_filter)
register_route('tvExecuteFilter', _tv_execute_filter)
register_route('movieDeleteFilter', _movie_delete_filter)
register_route('tvDeleteFilter', _tv_delete_filter)
register_route('movieClearAllFilters', _movie_clear_all)
register_route('tvClearAllFilters', _tv_clear_all)

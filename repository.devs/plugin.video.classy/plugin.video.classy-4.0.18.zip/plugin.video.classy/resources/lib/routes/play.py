# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file play.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Play action  -  scrape, pick source, start playback.'''

from urllib.parse import unquote_plus

from ..modules import kodi
from ..modules.classy import c
from ..lists.play import play_list_url
from ..play.metadata import enrich_request
from ..play.mode import MODE_DIALOG, MODE_DIRECTORY, resolve_play_mode
from ..play.models import PlayRequest
from ..play.picker import pick_stream
from ..play.player import play_stream
from ..play.fallback_queue import stash_after_resolve
from ..play.smart_resolve import resolve_stream_queue
from ..play.upnext_autoplay import LAST_MAGNET_PROP, pick_autoplay_candidate
from ..sources.directory import open_source_directory
from ..sources.orchestrator import scrape_streams
from ..sources.scrape_timeout import resolve_timeout
from ..modules.router import register_route


def play_handler(params):
    content = (params.get('content') or '').strip()
    url = unquote_plus(params.get('url') or '')
    if play_list_url(url, content=content):
        return

    request = PlayRequest.from_params(params)
    if not request.tmdb and not request.imdb:
        kodi.notification(c.addon_id, 'Missing title IDs  -  cannot scrape sources')
        c.log(f'[Play] rejected sparse params: {params}', 1)
        return

    # Movies / non-evening episodes: soft-pause or clear stale evening so
    # ClassyPlayer AV cannot arm the evening monitor for foreign content.
    if not request.is_episode:
        try:
            from ..tvevening import session as evening_session
            evening_session.release_for_foreign_play('movie play')
        except Exception as exc:
            c.log(f'[Play] TV Evening release failed: {exc}', 1)

    # TV Evening play gate  -  block rogue / stale episode plays while monitor owns session
    if request.is_episode:
        try:
            from ..tvevening import session as evening_session
            if evening_session.should_block_play(
                request.season,
                request.episode,
                tmdb=request.tmdb,
                imdb=request.imdb,
            ):
                c.log(
                    f'[Play] TV Evening blocked '
                    f'S{request.season:02d}E{request.episode:02d}',
                    1,
                )
                try:
                    from ..modules import control as ctrl
                    ctrl.window.setProperty('thecrew.tvevening.source_failure', 'blocked')
                except Exception:
                    pass
                return
        except Exception as exc:
            c.log(f'[Play] TV Evening gate error: {exc}', 1)

    enrich_request(request)
    if not request.title and not request.tvshowtitle:
        kodi.notification(c.addon_id, 'Could not resolve title for scraping')
        return

    mode = resolve_play_mode(params)
    c.log(f'[Play] route {request.display_title!r} mode={mode} tmdb={request.tmdb} imdb={request.imdb}')
    candidates, scrape_cancelled = scrape_streams(request, timeout=resolve_timeout(params))

    if scrape_cancelled:
        c.log('[Play] scrape aborted  -  returning to browse')
        _evening_source_failure('cancelled')
        _close_experience_overlay()
        return

    if not candidates:
        kodi.notification(c.addon_id, 'No streams found')
        _evening_source_failure('filtered')
        _close_experience_overlay()
        return

    if mode == MODE_DIRECTORY:
        _close_experience_overlay()
        open_source_directory(candidates, request)
        return

    if mode == MODE_DIALOG:
        _close_experience_overlay()
        chosen, start = pick_stream(candidates, heading=request.display_title)
    elif str(params.get('upnext') or '') == '1' and request.is_episode:
        try:
            from ..modules import control

            skip_hash = control.window.getProperty(LAST_MAGNET_PROP) or ''
        except Exception:
            skip_hash = ''
        start, chosen = pick_autoplay_candidate(candidates, request, skip_hash=skip_hash)
        if chosen is None:
            chosen, start = candidates[0], 0
    else:
        chosen, start = candidates[0], 0

    if not chosen:
        c.log('[Play] user cancelled source picker')
        _evening_source_failure('cancelled')
        _close_experience_overlay()
        return

    # Re-gate after scrape (gap / completing may have armed)
    if request.is_episode:
        try:
            from ..tvevening import session as evening_session
            if evening_session.should_block_play(
                request.season,
                request.episode,
                tmdb=request.tmdb,
                imdb=request.imdb,
            ):
                c.log('[Play] TV Evening blocked after scrape', 1)
                _evening_source_failure('blocked')
                _close_experience_overlay()
                return
        except Exception:
            pass

    play_url, winner = resolve_stream_queue(
        candidates, start, request, primary=chosen,
    )
    if not play_url:
        kodi.notification(c.addon_id, 'No working stream found')
        _evening_source_failure('exception')
        return

    stash_after_resolve(
        candidates, start, winner or chosen, request, primary=chosen,
    )
    play_stream(winner or chosen, request, resolved_url=play_url)


def _close_experience_overlay():
    '''Drop a scrape-opened ResolveStatus if play exits before smart resolve.'''
    try:
        from ..kodi.resolve_status import get_active_overlay, clear_active_overlay
        overlay = get_active_overlay()
        if overlay is None:
            return
        try:
            overlay.close()
        except Exception:
            pass
        clear_active_overlay()
    except Exception:
        pass


def _evening_source_failure(kind):
    try:
        from ..modules import control
        from ..tvevening import session as evening_session
        from ..tvevening.monitor import evening_is_live
        if evening_is_live():
            control.window.setProperty('thecrew.tvevening.source_failure', kind)
            evening_session.record_scrape_failure()
    except Exception:
        pass


register_route('play', play_handler)

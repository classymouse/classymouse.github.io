# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file library.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Library routes  -  CM actions, tools submenu, Kodi scan.'''

from ..library import bulk, movies, scan, sources, tvshows
from ..modules import kodi
from ..modules.classy import c
from ..modules.router import register_route


def _movie_to_library(params):
    movies.add_from_params(params)


def _tvshow_to_library(params):
    tvshows.add_from_params(params)


def _movies_to_library(params):
    url = (params or {}).get('url') or ''
    bulk.import_movies(url)


def _tvshows_to_library(params):
    url = (params or {}).get('url') or ''
    bulk.import_tvshows(url)


def _setup_library_sources(_params):
    sources.setup_library_sources()


def _update_library(params):
    query = (params or {}).get('query') or ''
    if query == 'tool':
        kodi.idle
    if scan.trigger_video_library_update(force=True):
        c.infoDialog(c.lang(33513) or 'Library update started', time=3000)
    else:
        c.infoDialog('Library update skipped (disabled or already scanning)', time=3000)


register_route('movieToLibrary', _movie_to_library)
register_route('tvshowToLibrary', _tvshow_to_library)
register_route('moviesToLibrary', _movies_to_library)
register_route('tvshowsToLibrary', _tvshows_to_library)
register_route('setupLibrarySources', _setup_library_sources)
register_route('updateLibrary', _update_library)

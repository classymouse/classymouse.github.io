# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file trailer.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Play trailer route (CM + InfoTag).'''

from ..modules.router import register_route
from ..play.trailer import play_from_params


def trailer_handler(params):
    play_from_params(params)


register_route('trailer', trailer_handler)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file simkl.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl routes  -  authorize / revoke / manager.'''

from ..modules.router import register_route
from ..simkl import manager as simkl_manager
from ..simkl import ui


def _auth_simkl(_params):
    ui.auth_simkl()


def _revoke_simkl(_params):
    ui.revoke_simkl()


def _simkl_manager(params):
    simkl_manager.manager(
        (params or {}).get('name') or '',
        (params or {}).get('imdb') or '',
        (params or {}).get('tmdb') or '',
        (params or {}).get('content') or 'movie',
    )


register_route('authSimkl', _auth_simkl)
register_route('revokeSimkl', _revoke_simkl)
register_route('simklManager', _simkl_manager)

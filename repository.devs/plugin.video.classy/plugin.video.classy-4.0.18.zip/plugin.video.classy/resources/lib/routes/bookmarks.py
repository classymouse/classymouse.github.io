# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file bookmarks.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Clear resume points from context menu  -  local bookmarks.db + tracker when live.'''

import xbmc

from .. import tracker
from ..modules import kodi
from ..modules.classy import c
from ..modules.router import register_route
from ..play.models import PlayRequest
from ..playback import resume as playback_resume
from ..playback import session as playback_session


def _clear_handler(params, mediatype):
    request = PlayRequest.from_params({**(params or {}), 'mediatype': mediatype})
    if not request.tmdb and not request.imdb:
        kodi.notification(c.addon_id, 'Missing title IDs  -  cannot clear resume')
        return

    removed = playback_resume.clear_resume(request)
    playback_session.clear()
    if removed:
        try:
            from ..progress.widget_signals import notify_progress_changed
            notify_progress_changed('clear_resume')
        except Exception:
            pass
        kodi.notification(c.addon_id, 'Resume point cleared')
    elif tracker.live():
        kodi.notification(
            c.addon_id,
            f'No {tracker.display_label()} resume point found',
        )
    else:
        kodi.notification(c.addon_id, 'No local resume point found')

    redirect = str((params or {}).get('redirect') or '').strip()
    if redirect:
        xbmc.executebuiltin(f'Container.Update({redirect})')
    else:
        xbmc.executebuiltin('Container.Refresh')


def movie_clear_bookmark(params):
    _clear_handler(params, 'movie')


def episode_clear_bookmark(params):
    _clear_handler(params, 'episode')


register_route('movieClearBookmark', movie_clear_bookmark)
register_route('episodeClearBookmark', episode_clear_bookmark)

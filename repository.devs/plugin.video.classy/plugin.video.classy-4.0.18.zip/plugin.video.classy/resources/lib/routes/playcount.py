# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file playcount.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Context menu playcount routes  -  local bookmarks dual-write + tracker when live.'''

from .. import tracker
from ..modules import kodi
from ..modules.classy import c
from ..modules.router import register_route


def _parse_watched(params):
    raw = (params or {}).get('query')
    if raw is None:
        raw = (params or {}).get('watched')
    text = str(raw or '').strip().lower()
    if text in ('1', 'true', 'yes', 'watched'):
        return True
    if text in ('0', 'false', 'no', 'unwatched'):
        return False
    try:
        return bool(int(text))
    except (TypeError, ValueError):
        return None


def _local_playcount(params, mediatype, watched):
    '''Episode / movie only  -  season/show stay tracker-owned for v1.'''
    media = (mediatype or '').lower()
    if media not in ('movie', 'episode'):
        return False
    if watched is None:
        return False
    try:
        from ..modules import bookmarks as local_bookmarks
        return local_bookmarks.mark_watched_local(
            (params or {}).get('imdb') or '',
            media,
            season=(params or {}).get('season') or 0,
            episode=(params or {}).get('episode') or 0,
            watched=watched,
        )
    except Exception as exc:
        c.log(f'[Playcount] local bookmark failed: {exc}', 1)
        return False


def _handler(params, mediatype):
    watched = _parse_watched(params)
    local_ok = _local_playcount(params, mediatype, watched)

    if tracker.live():
        ok, message = tracker.apply_playcount(params, mediatype=mediatype)
        if message:
            kodi.notification(c.addon_id, message)
        elif local_ok and ok is False:
            kodi.notification(
                c.addon_id,
                'Marked as watched' if watched else 'Marked as unwatched',
            )
        return

    if local_ok:
        kodi.notification(
            c.addon_id,
            'Marked as watched' if watched else 'Marked as unwatched',
        )
        try:
            from ..progress.widget_signals import notify_progress_changed
            notify_progress_changed('local_playcount')
        except Exception:
            pass
        return

    if (mediatype or '').lower() in ('tvshow', 'season'):
        kodi.notification(
            c.addon_id,
            f'Connect {tracker.display_label()} to mark whole seasons/shows',
        )
        return

    kodi.notification(
        c.addon_id,
        f'Connect {tracker.display_label()} or enable local bookmarks',
    )


def movie_playcount(params):
    _handler(params, 'movie')


def episode_playcount(params):
    _handler(params, 'episode')


def tv_playcount(params):
    _handler(params, 'tvshow')


def season_playcount(params):
    _handler(params, 'season')


register_route('moviePlaycount', movie_playcount)
register_route('episodePlaycount', episode_playcount)
register_route('tvPlaycount', tv_playcount)
register_route('seasonPlaycount', season_playcount)

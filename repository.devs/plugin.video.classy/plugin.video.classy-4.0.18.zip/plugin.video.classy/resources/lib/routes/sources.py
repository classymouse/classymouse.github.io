# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file sources.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Source list directory + playItem click handler.'''

from ..modules.classy import c
from ..modules.router import register_route
from ..play.models import PlayRequest
from ..play.fallback_queue import stash_after_resolve
from ..play.player import play_stream
from ..play.smart_resolve import resolve_stream_queue
from ..sources.directory import load_session, show_source_directory


def _source_list_handler(params):
    show_source_directory(params)


def _play_item_handler(params):
    try:
        index = int((params or {}).get('index', -1))
    except (TypeError, ValueError):
        index = -1

    candidates, request = load_session()
    if not candidates:
        c.log('[Play] playItem: empty source session', 1)
        return
    if index < 0 or index >= len(candidates):
        c.log(f'[Play] playItem invalid index={index} count={len(candidates)}', 1)
        return

    if not request:
        request = PlayRequest()

    primary = candidates[index]
    c.log(
        f'[Play] playItem start index={index}/{len(candidates)} '
        f'provider={primary.provider!r} quality={primary.quality!r}'
    )
    play_url, winner = resolve_stream_queue(
        candidates, index, request, primary=primary,
    )
    if not play_url:
        from ..modules import kodi
        kodi.notification(c.addon_id, 'No working stream found')
        return
    stash_after_resolve(
        candidates, index, winner or primary, request, primary=primary,
    )
    play_stream(winner or primary, request, resolved_url=play_url)


register_route('sourceList', _source_list_handler)
register_route('playItem', _play_item_handler)

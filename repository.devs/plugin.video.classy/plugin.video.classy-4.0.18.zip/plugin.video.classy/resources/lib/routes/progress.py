# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file progress.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Progress routes  -  widget + browse actions.'''

import sys

from ..indexers import progress as progress_indexer
from ..modules.router import register_route


def _progress_next_episodes(params):
    handle = int(sys.argv[1])
    progress_indexer.next_episodes(handle, params)


def _progress_shows(params):
    handle = int(sys.argv[1])
    progress_indexer.in_progress_shows(handle, params)


def _progress_in_progress_episodes(params):
    handle = int(sys.argv[1])
    progress_indexer.in_progress_episodes(handle, params)


register_route('progress_next_episodes', _progress_next_episodes)
register_route('progress_shows', _progress_shows)
register_route('progress_in_progress_episodes', _progress_in_progress_episodes)

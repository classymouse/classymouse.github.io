# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file account_cache.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

SQLite last-good cache for thin debrid account rows (username / email / expiry).

Keep prior row until a successful rewrite. Clear only on explicit logout or
when the live token is gone at refresh time.
'''

from __future__ import annotations

import os
import sqlite3
import time

import xbmcaddon
import xbmcvfs

from ..modules.classy import c

_DB_NAME = 'debrid_account.db'


def _db_path():
    profile = xbmcaddon.Addon().getAddonInfo('profile')
    return os.path.join(xbmcvfs.translatePath(profile), _DB_NAME)


def _connect():
    path = _db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure(cur):
    cur.execute(
        '''
        CREATE TABLE IF NOT EXISTS debrid_account (
            provider TEXT PRIMARY KEY,
            username TEXT,
            email TEXT,
            expires_at INTEGER,
            plan TEXT,
            fetched_at INTEGER NOT NULL
        )
        '''
    )


def get(provider):
    '''Return one cached row dict or None.'''
    key = str(provider or '').strip().lower()
    if not key:
        return None
    try:
        with _connect() as conn:
            cur = conn.cursor()
            _ensure(cur)
            cur.execute(
                'SELECT provider, username, email, expires_at, plan, fetched_at '
                'FROM debrid_account WHERE provider = ?',
                (key,),
            )
            row = cur.fetchone()
            return dict(row) if row else None
    except Exception as exc:
        c.log(f'[DebridAccount] get {key} failed: {exc}', 1)
        return None


def get_all():
    '''Return {provider: row_dict}.'''
    out = {}
    try:
        with _connect() as conn:
            cur = conn.cursor()
            _ensure(cur)
            cur.execute(
                'SELECT provider, username, email, expires_at, plan, fetched_at '
                'FROM debrid_account'
            )
            for row in cur.fetchall():
                out[row['provider']] = dict(row)
    except Exception as exc:
        c.log(f'[DebridAccount] get_all failed: {exc}', 1)
    return out


def upsert(row):
    '''Write/replace one provider row. Missing keys become empty/None.'''
    if not isinstance(row, dict):
        return False
    key = str(row.get('provider') or '').strip().lower()
    if not key:
        return False
    username = str(row.get('username') or '').strip() or None
    email = str(row.get('email') or '').strip() or None
    plan = str(row.get('plan') or '').strip() or None
    expires_at = row.get('expires_at')
    try:
        expires_at = int(expires_at) if expires_at not in (None, '') else None
    except (TypeError, ValueError):
        expires_at = None
    fetched_at = int(row.get('fetched_at') or time.time())
    try:
        with _connect() as conn:
            cur = conn.cursor()
            _ensure(cur)
            cur.execute(
                '''
                INSERT INTO debrid_account
                    (provider, username, email, expires_at, plan, fetched_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(provider) DO UPDATE SET
                    username = excluded.username,
                    email = excluded.email,
                    expires_at = excluded.expires_at,
                    plan = excluded.plan,
                    fetched_at = excluded.fetched_at
                ''',
                (key, username, email, expires_at, plan, fetched_at),
            )
            conn.commit()
        return True
    except Exception as exc:
        c.log(f'[DebridAccount] upsert {key} failed: {exc}', 1)
        return False


def clear_provider(provider):
    key = str(provider or '').strip().lower()
    if not key:
        return False
    try:
        with _connect() as conn:
            cur = conn.cursor()
            _ensure(cur)
            cur.execute('DELETE FROM debrid_account WHERE provider = ?', (key,))
            conn.commit()
        return True
    except Exception as exc:
        c.log(f'[DebridAccount] clear {key} failed: {exc}', 1)
        return False

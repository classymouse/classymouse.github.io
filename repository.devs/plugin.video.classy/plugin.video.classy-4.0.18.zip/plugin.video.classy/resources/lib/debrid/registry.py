# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file registry.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Single registry for ResolveURL-backed debrid services.

Adding a provider (e.g. OffCloud) = one entry here + a thin fetch_* in
account_fetch.py. Manager, cache worker, scrub, and settings focus all
read from this list.
'''

from __future__ import annotations

from typing import NamedTuple, Optional, Tuple


class ProviderSpec(NamedTuple):
    key: str
    label: str
    enabled_setting: str
    primary_secret: str
    secrets: Tuple[str, ...]
    settings_query: str  # ResolveURL category.field (0-based)
    auth_mode: str       # ResolveURL ?mode=


# Order = Tools Debrid management directory order.
PROVIDERS: Tuple[ProviderSpec, ...] = (
    ProviderSpec(
        key='realdebrid',
        label='Real-Debrid',
        enabled_setting='RealDebridResolver_enabled',
        primary_secret='RealDebridResolver_token',
        secrets=(
            'RealDebridResolver_auth',
            'RealDebridResolver_token',
            'RealDebridResolver_refresh',
            'RealDebridResolver_client_id',
            'RealDebridResolver_client_secret',
        ),
        settings_query='2.34',
        auth_mode='auth_rd',
    ),
    ProviderSpec(
        key='alldebrid',
        label='AllDebrid',
        enabled_setting='AllDebridResolver_enabled',
        primary_secret='AllDebridResolver_token',
        secrets=(
            'AllDebridResolver_auth',
            'AllDebridResolver_token',
        ),
        settings_query='1.6',
        auth_mode='auth_ad',
    ),
    ProviderSpec(
        key='premiumize',
        label='Premiumize',
        enabled_setting='PremiumizeMeResolver_enabled',
        primary_secret='PremiumizeMeResolver_token',
        secrets=(
            'PremiumizeMeResolver_auth',
            'PremiumizeMeResolver_token',
        ),
        settings_query='2.24',
        auth_mode='auth_pm',
    ),
    ProviderSpec(
        key='torbox',
        label='TorBox',
        enabled_setting='TorBoxResolver_enabled',
        primary_secret='TorBoxResolver_apikey',
        secrets=(
            'TorBoxResolver_auth',
            'TorBoxResolver_user',
            'TorBoxResolver_apikey',
        ),
        settings_query='3.14',
        auth_mode='auth_tb',
    ),
)


def get(key: str) -> Optional[ProviderSpec]:
    want = str(key or '').strip().lower()
    for spec in PROVIDERS:
        if spec.key == want:
            return spec
    return None


def keys():
    return tuple(p.key for p in PROVIDERS)

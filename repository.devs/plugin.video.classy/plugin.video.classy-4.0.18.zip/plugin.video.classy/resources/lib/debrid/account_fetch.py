# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file account_fetch.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Thin user-info pulls for debrid providers (username / email / expiry only).

Tokens come from ResolveURL settings. Soft-fail + short timeout. Do not log
email or full payloads.
'''

from __future__ import annotations

import time
from datetime import datetime

import requests
import xbmc
import xbmcaddon

from ..modules.classy import c
from . import account_cache
from .registry import PROVIDERS, ProviderSpec, get as get_provider

_RESOLVEURL_ID = 'script.module.resolveurl'
_TIMEOUT = 10
_UA = 'TheCrew-Debrid/1.0'


def _ru_addon():
    try:
        if not xbmc.getCondVisibility(f'System.HasAddon({_RESOLVEURL_ID})'):
            return None
        return xbmcaddon.Addon(_RESOLVEURL_ID)
    except Exception:
        return None


def _token(addon, setting_id):
    try:
        return (addon.getSetting(setting_id) or '').strip()
    except Exception:
        return ''


def _parse_expires(value):
    '''Normalize provider expiry to unix seconds, or None.'''
    if value in (None, '', 0, '0', 'N/A'):
        return None
    if isinstance(value, (int, float)):
        ts = int(value)
        # ms vs s
        if ts > 10_000_000_000:
            ts //= 1000
        return ts if ts > 0 else None
    text = str(value).strip()
    if not text:
        return None
    if text.isdigit():
        return _parse_expires(int(text))
    for fmt in (
        '%Y-%m-%dT%H:%M:%S.%fZ',
        '%Y-%m-%dT%H:%M:%SZ',
        '%Y-%m-%dT%H:%M:%S',
        '%Y-%m-%d %H:%M:%S',
        '%Y-%m-%d',
    ):
        try:
            return int(datetime.strptime(text.replace('+0000', ''), fmt).timestamp())
        except Exception:
            continue
    return None


def _row(provider, username='', email='', expires=None, plan=''):
    return {
        'provider': provider,
        'username': (username or '').strip() or None,
        'email': (email or '').strip() or None,
        'expires_at': _parse_expires(expires),
        'plan': (plan or '').strip() or None,
        'fetched_at': int(time.time()),
    }


def _fetch_realdebrid(token):
    # ResolveURL OAuth tokens expect Bearer  -  query auth_token fails silently.
    url = 'https://api.real-debrid.com/rest/1.0/user'
    data = requests.get(
        url,
        timeout=_TIMEOUT,
        headers={
            'User-Agent': _UA,
            'Authorization': f'Bearer {token}',
        },
    ).json()
    if not isinstance(data, dict) or data.get('error'):
        return None
    return _row(
        'realdebrid',
        username=data.get('username') or '',
        email=data.get('email') or '',
        expires=data.get('expiration'),
        plan=data.get('type') or '',
    )


def _fetch_alldebrid(token):
    url = 'https://api.alldebrid.com/v4/user'
    data = requests.get(
        url,
        params={'agent': 'TheCrew', 'apikey': token},
        timeout=_TIMEOUT,
        headers={'User-Agent': _UA},
    ).json()
    if not isinstance(data, dict) or data.get('status') != 'success':
        return None
    user = (data.get('data') or {}).get('user') or {}
    if not isinstance(user, dict):
        return None
    plan = 'Premium' if user.get('isPremium') else 'Free'
    return _row(
        'alldebrid',
        username=user.get('username') or '',
        email=user.get('email') or '',
        expires=user.get('premiumUntil'),
        plan=plan,
    )


def _fetch_premiumize(token):
    url = 'https://www.premiumize.me/api/account/info'
    data = requests.get(
        url,
        headers={'Authorization': f'Bearer {token}', 'User-Agent': _UA},
        timeout=_TIMEOUT,
    ).json()
    if not isinstance(data, dict) or data.get('status') != 'success':
        return None
    customer = data.get('customer_id')
    username = f'id {customer}' if customer not in (None, '') else ''
    plan = 'Premium' if data.get('premium_until') else 'Free'
    return _row(
        'premiumize',
        username=username,
        email='',
        expires=data.get('premium_until'),
        plan=plan,
    )


def _fetch_torbox(token):
    url = 'https://api.torbox.app/v1/api/user/me'
    data = requests.get(
        url,
        params={'settings': 'false'},
        headers={'Authorization': f'Bearer {token}', 'User-Agent': _UA},
        timeout=_TIMEOUT,
    ).json()
    if not isinstance(data, dict):
        return None
    body = data.get('data') if data.get('success') else data
    if not isinstance(body, dict):
        return None
    plan_map = {0: 'Free', 1: 'Essential', 2: 'Standard', 3: 'Pro'}
    plan = plan_map.get(body.get('plan'), '')
    expires = (
        body.get('premium_expires_at')
        or body.get('expiration')
        or body.get('premium_until')
    )
    return _row(
        'torbox',
        username='',
        email=body.get('email') or '',
        expires=expires,
        plan=plan,
    )


_FETCHERS = {
    'realdebrid': _fetch_realdebrid,
    'alldebrid': _fetch_alldebrid,
    'premiumize': _fetch_premiumize,
    'torbox': _fetch_torbox,
}


def fetch_provider(spec: ProviderSpec, token: str):
    '''Network fetch for one provider. Returns row dict or None.'''
    fn = _FETCHERS.get(spec.key)
    if not fn or not token:
        return None
    try:
        return fn(token)
    except Exception as exc:
        c.log(f'[DebridAccount] fetch {spec.key} failed: {exc}', 1)
        return None


def refresh_provider(key, abort_check=None):
    '''Fetch + upsert one provider when token present; clear cache if not.'''
    spec = get_provider(key)
    if spec is None:
        return False
    if abort_check and abort_check():
        return False
    addon = _ru_addon()
    if addon is None:
        return False
    token = _token(addon, spec.primary_secret)
    if not token:
        account_cache.clear_provider(spec.key)
        return False
    row = fetch_provider(spec, token)
    if abort_check and abort_check():
        return False
    if not row:
        return False
    return account_cache.upsert(row)


def refresh_all(abort_check=None):
    '''Refresh every registry provider that has a live token. Last-good kept on miss.'''
    addon = _ru_addon()
    if addon is None:
        return 0
    updated = 0
    for spec in PROVIDERS:
        if abort_check and abort_check():
            break
        token = _token(addon, spec.primary_secret)
        if not token:
            account_cache.clear_provider(spec.key)
            continue
        row = fetch_provider(spec, token)
        if abort_check and abort_check():
            break
        if row and account_cache.upsert(row):
            updated += 1
            c.log(f'[DebridAccount] cached {spec.key}')
    return updated


def _expiry_date(expires_at):
    '''UTC YYYY-MM-DD from unix expiry, or "".'''
    try:
        ts = int(expires_at)
    except (TypeError, ValueError):
        return ''
    if ts <= 0:
        return ''
    try:
        from datetime import timezone
        return datetime.fromtimestamp(ts, timezone.utc).strftime('%Y-%m-%d')
    except Exception:
        try:
            return datetime.utcfromtimestamp(ts).strftime('%Y-%m-%d')
        except Exception:
            return ''


def format_expiry(expires_at, now=None):
    '''Detail line for the service menu, e.g. "Expires 2026-03-15 (48d)".'''
    date_s = _expiry_date(expires_at)
    if not date_s:
        return ''
    try:
        ts = int(expires_at)
    except (TypeError, ValueError):
        return ''
    now = int(now if now is not None else time.time())
    days = int((ts - now) / 86400)
    if days < 0:
        return f'Expired {date_s}'
    if days == 0:
        return f'Expires today ({date_s})'
    return f'Expires {date_s} ({days}d)'


def status_suffix(cached):
    '''Directory label bit: " (YYYY-MM-DD)" only  -  no user / expires wording.'''
    if not cached:
        return ''
    date_s = _expiry_date(cached.get('expires_at'))
    if not date_s:
        return ''
    try:
        ts = int(cached.get('expires_at'))
        if ts < int(time.time()):
            return f' (expired {date_s})'
    except (TypeError, ValueError):
        pass
    return f' ({date_s})'

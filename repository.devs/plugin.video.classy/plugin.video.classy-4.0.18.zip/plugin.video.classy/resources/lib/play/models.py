# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file models.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Play path data models.'''

from __future__ import annotations

import json
from urllib.parse import unquote_plus


def _parse_meta_param(raw):
    if not raw:
        return {}
    text = unquote_plus(str(raw))
    try:
        data = json.loads(text)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


class PlayRequest:
    __slots__ = (
        'mediatype', 'title', 'year', 'imdb', 'tmdb', 'tvdb', 'trakt',
        'season', 'episode', 'tvshowtitle', 'localtvshowtitle', 'premiered',
        'aliases', 'meta',
    )

    def __init__(self, mediatype='movie', **kwargs):
        self.mediatype = mediatype or 'movie'
        self.title = ''
        self.year = ''
        self.imdb = ''
        self.tmdb = ''
        self.tvdb = ''
        self.trakt = ''
        self.season = 0
        self.episode = 0
        self.tvshowtitle = ''
        self.localtvshowtitle = ''
        self.premiered = ''
        self.aliases = []
        self.meta = {}
        for key in self.__slots__:
            if key in kwargs and kwargs[key] is not None:
                setattr(self, key, kwargs[key])
        self._normalize_ids()

    def _normalize_ids(self):
        for attr in ('imdb', 'tmdb', 'tvdb', 'trakt'):
            value = getattr(self, attr)
            if value is None:
                setattr(self, attr, '')
            else:
                setattr(self, attr, str(value).strip())
        if self.imdb and str(self.imdb).startswith('tt'):
            self.imdb = str(self.imdb)[2:]
        try:
            self.season = int(self.season or 0)
        except (TypeError, ValueError):
            self.season = 0
        try:
            self.episode = int(self.episode or 0)
        except (TypeError, ValueError):
            self.episode = 0
        if (self.mediatype or '').lower() == 'movie':
            self.season = 0
            self.episode = 0
        if self.mediatype == 'episode' and not self.tvshowtitle:
            self.tvshowtitle = self.title

    @property
    def is_episode(self):
        if (self.mediatype or '').lower() == 'movie':
            return False
        if (self.mediatype or '').lower() in ('tvshow', 'show', 'tvshows'):
            return False
        return bool(self.season and self.episode)

    @property
    def is_movie(self):
        return not self.is_episode

    @property
    def display_title(self):
        if self.is_episode and self.season and self.episode:
            ep = self.title or f'Episode {self.episode}'
            show = self.tvshowtitle or 'Show'
            return f'{show}  -  S{self.season:02d}E{self.episode:02d}  -  {ep}'
        return self.title or self.tvshowtitle or 'Item'

    def imdb_for_scrape(self):
        '''IMDB id with tt prefix  -  required by Torrentio and most pack scrapers.'''
        text = str(self.imdb or '').strip()
        if not text:
            return ''
        if text.startswith('tt'):
            return text
        if text.isdigit():
            return f'tt{text}'
        return text

    def to_scrape_data(self):
        data = {
            'title': self.title,
            'year': self.year,
            'imdb': self.imdb_for_scrape(),
            'tmdb': self.tmdb,
            'tvdb': self.tvdb,
            'aliases': list(self.aliases or []),
            'premiered': self.premiered,
        }
        if self.is_episode:
            data.update({
                'tvshowtitle': self.tvshowtitle or self.title,
                'localtvshowtitle': self.localtvshowtitle or self.tvshowtitle or self.title,
                'season': self.season,
                'episode': self.episode,
            })
        return data

    @classmethod
    def from_params(cls, params):
        params = dict(params or {})
        meta = _parse_meta_param(params.pop('meta', None))
        season = params.get('season') or meta.get('season') or ''
        episode = params.get('episode') or meta.get('episode') or ''
        mediatype = (
            params.get('mediatype') or params.get('content') or meta.get('mediatype') or ''
        ).strip().lower()
        if not mediatype:
            mediatype = 'episode' if (season and episode) else 'movie'
        if mediatype in ('tvshows', 'tvshow', 'show'):
            mediatype = 'episode' if (season and episode) else 'tvshow'
        if mediatype == 'tvshow' and (season and episode):
            mediatype = 'episode'

        def _field(name):
            value = params.get(name)
            if value in (None, ''):
                value = meta.get(name)
            return '' if value is None else str(value).strip()

        request = cls(
            mediatype=mediatype,
            title=_field('title'),
            year=_field('year'),
            imdb=_field('imdb'),
            tmdb=_field('tmdb'),
            tvdb=_field('tvdb'),
            trakt=_field('trakt'),
            season=season,
            episode=episode,
            tvshowtitle=_field('tvshowtitle'),
            localtvshowtitle=_field('localtvshowtitle'),
            premiered=_field('premiered'),
            meta=dict(meta) if meta else {},
        )
        request._normalize_ids()
        return request

    @classmethod
    def from_row(cls, row):
        from ..metadata.video_row import VideoRow

        row = row if isinstance(row, VideoRow) else VideoRow.from_dict(row)
        return cls(
            mediatype=row.mediatype,
            title=row.title,
            year=row.year,
            imdb=row.imdb,
            tmdb=row.tmdb,
            tvdb=row.tvdb,
            trakt=row.trakt,
            season=row.season,
            episode=row.episode,
            tvshowtitle=row.tvshowtitle,
            premiered=row.premiered,
            meta=row.to_dict(),
        )


class StreamCandidate:
    __slots__ = (
        'provider', 'source', 'quality', 'language', 'url', 'name', 'info',
        'direct', 'debridonly', 'size', 'seeders', 'hash', 'raw',
    )

    def __init__(self, **kwargs):
        self.provider = ''
        self.source = ''
        self.quality = ''
        self.language = ''
        self.url = ''
        self.name = ''
        self.info = ''
        self.direct = False
        self.debridonly = False
        self.size = 0.0
        self.seeders = 0
        self.hash = ''
        self.raw = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    @classmethod
    def from_raw(cls, raw, provider=''):
        if not isinstance(raw, dict):
            return None
        url = raw.get('url') or ''
        if not url:
            return None
        try:
            seeders = int(raw.get('seeders') or 0)
        except (TypeError, ValueError):
            seeders = 0
        try:
            size = float(raw.get('size') or 0)
        except (TypeError, ValueError):
            size = 0.0
        return cls(
            provider=str(raw.get('provider') or provider or ''),
            source=str(raw.get('source') or ''),
            quality=str(raw.get('quality') or ''),
            language=str(raw.get('language') or ''),
            url=str(url),
            name=str(raw.get('name') or raw.get('name_info') or ''),
            info=str(raw.get('info') or ''),
            direct=bool(raw.get('direct')),
            debridonly=bool(raw.get('debridonly')),
            size=size,
            seeders=seeders,
            hash=str(raw.get('hash') or ''),
            raw=dict(raw),
        )

    def label(self, index=0):
        from ..sources.labels import build_list_label
        return build_list_label(self, index)

    def to_dict(self):
        return {
            'provider': self.provider,
            'source': self.source,
            'quality': self.quality,
            'language': self.language,
            'url': self.url,
            'name': self.name,
            'info': self.info,
            'direct': self.direct,
            'debridonly': self.debridonly,
            'size': self.size,
            'seeders': self.seeders,
            'hash': self.hash,
            'raw': dict(self.raw or {}),
        }

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            return None
        return cls(**{k: data.get(k) for k in cls.__slots__ if k in data})

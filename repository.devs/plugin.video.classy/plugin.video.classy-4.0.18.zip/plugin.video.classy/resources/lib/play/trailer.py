# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file trailer.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

TMDB trailer fetch + YouTube play (RunPlugin / resolve).'''

from __future__ import annotations

import sys
from urllib.parse import unquote_plus, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from ..apis.tmdb import tmdb
from ..metadata.ids import valid_id
from ..modules import control
from ..modules.classy import c

YOUTUBE_PLAY = 'plugin://plugin.video.youtube/play/?video_id='


def trailer_plugin_url(*, name='', imdb='', tmdb_id='', mediatype='movie', url=''):
    '''Crew parity: InfoTag + CM share this resolver URL.'''
    query = {'action': 'trailer'}
    title = (name or '').strip()
    if title:
        query['name'] = title
    if valid_id(imdb):
        query['imdb'] = str(imdb)
    if valid_id(tmdb_id):
        query['tmdb'] = str(tmdb_id)
    if mediatype:
        query['mediatype'] = mediatype
    direct = (url or '').strip()
    if direct and direct not in ('0', 'None'):
        query['url'] = direct
    return f'plugin://{c.addon_id}/?{urlencode(query)}'


def trailer_url_for_row(row):
    '''Info dialog Play Trailer + CM should hit the same route.'''
    mediatype = (row.mediatype or '').strip()
    if mediatype not in ('movie', 'tvshow', 'episode'):
        return ''
    if not valid_id(row.imdb) and not valid_id(row.tmdb):
        return ''
    # Episodes resolve trailers as the parent show (TMDB videos live there).
    resolve_type = 'tvshow' if mediatype == 'episode' else mediatype
    name = (row.tvshowtitle or row.title or '').strip() if mediatype == 'episode' else (
        (row.title or row.tvshowtitle or '').strip()
    )
    direct = (row.trailer or '').strip()
    if direct and direct.startswith('plugin://'):
        return direct
    return trailer_plugin_url(
        name=name,
        imdb=row.imdb or '',
        tmdb_id=row.tmdb or '',
        mediatype=resolve_type,
        url=direct,
    )


def _normalize_mediatype(mediatype):
    mt = (mediatype or 'movie').strip().lower()
    if mt in ('tvshow', 'episode', 'tv', 'season'):
        return 'tv'
    return 'movie'


def _normalize_youtube_plugin_url(url):
    text = (url or '').strip()
    if not text:
        return ''
    if 'youtube' in text.lower() and 'video_id=' in text:
        video_id = text.split('video_id=')[-1].split('&')[0].strip()
        if video_id:
            return f'{YOUTUBE_PLAY}{video_id}'
    if 'youtube' in text.lower() and 'videoid=' in text:
        video_id = text.split('videoid=')[-1].split('&')[0].strip()
        if video_id:
            return f'{YOUTUBE_PLAY}{video_id}'
    return text


def _normalize_url(url):
    text = unquote_plus((url or '').strip())
    if not text or text in ('0', 'None'):
        return ''
    return text


def _trailer_candidates_from_videos(videos):
    items = []
    if not isinstance(videos, dict):
        return items
    for video in videos.get('results') or []:
        if not isinstance(video, dict):
            continue
        if str(video.get('site') or '').lower() != 'youtube':
            continue
        if str(video.get('type') or '').lower() != 'trailer':
            continue
        key = (video.get('key') or '').strip()
        if not key:
            continue
        name = (video.get('name') or 'Trailer').strip()
        items.append({
            'title': name,
            'url': f'{YOUTUBE_PLAY}{key}',
            'official': bool(video.get('official')),
        })
    items.sort(key=lambda row: (0 if row['official'] else 1, row['title'].casefold()))
    return items


def resolve_tmdb_id(tmdb_id, imdb_id, mediatype):
    tid = valid_id(tmdb_id)
    if tid:
        return tid
    imdb = valid_id(imdb_id)
    if not imdb:
        return ''
    kind = _normalize_mediatype(mediatype)
    data = tmdb.find_external(imdb, source='imdb_id')
    if not isinstance(data, dict):
        return ''
    key = 'tv_results' if kind == 'tv' else 'movie_results'
    results = data.get(key) or []
    if results and isinstance(results[0], dict):
        return valid_id(results[0].get('id'))
    return ''


def fetch_trailers(tmdb_id, imdb_id, mediatype):
    tid = resolve_tmdb_id(tmdb_id, imdb_id, mediatype)
    if not tid:
        return []
    kind = _normalize_mediatype(mediatype)
    if kind == 'tv':
        data = tmdb.get_tv(tid, append='videos')
    else:
        data = tmdb.get_movie(tid, append='videos')
    if not isinstance(data, dict):
        return []
    return _trailer_candidates_from_videos(data.get('videos'))


def pick_trailer(candidates):
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    labels = [row['title'] for row in candidates]
    idx = control.selectDialog(labels, heading='Trailers')
    if idx < 0:
        return 'canceled'
    return candidates[idx]


def play_trailer_url(url, *, title='', imdb='', tmdb_id='', poster=''):
    url = _normalize_youtube_plugin_url(_normalize_url(url))
    if not url:
        control.infoDialog('No trailer URL.', sound=True)
        return

    try:
        from ..playback.upnext import clear_session
        clear_session()
    except Exception as exc:
        c.log(f'[Trailer] upnext clear failed: {exc}', 1)

    c.log(f'[Trailer] play {url[:120]}')

    label = (title or 'Trailer').strip()
    li = xbmcgui.ListItem(label=label, path=url)
    li.setProperty('IsPlayable', 'true')
    info = li.getVideoInfoTag()
    info.setTitle(label)
    info.setMediaType('video')
    unique = {}
    if valid_id(imdb):
        unique['imdb'] = str(imdb)
    if valid_id(tmdb_id):
        unique['tmdb'] = str(tmdb_id)
    if unique:
        info.setUniqueIDs(unique)
    if poster:
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})

    try:
        handle = int(sys.argv[1])
    except (IndexError, ValueError, TypeError):
        handle = -1

    if url.startswith('plugin://') or url.startswith('http'):
        xbmc.executebuiltin(f'PlayMedia({url})')
    elif handle == -1:
        xbmc.Player().play(url, li)
    else:
        xbmcplugin.setResolvedUrl(handle, True, li)
    control.idle()


def play_from_params(params):
    params = params or {}
    url = _normalize_url(params.get('url'))
    name = unquote_plus(params.get('name') or '')
    imdb = params.get('imdb') or ''
    tmdb_id = params.get('tmdb') or ''
    mediatype = params.get('mediatype') or 'movie'

    c.log(
        f'[Trailer] route mediatype={mediatype} tmdb={tmdb_id or "-"} '
        f'imdb={imdb or "-"} url={"yes" if url else "fetch"}',
    )

    if url:
        play_trailer_url(url, title=name, imdb=imdb, tmdb_id=tmdb_id)
        return

    candidates = fetch_trailers(tmdb_id, imdb, mediatype)
    if not candidates:
        kind = 'TV show' if _normalize_mediatype(mediatype) == 'tv' else 'movie'
        control.infoDialog(f'No trailers available for this {kind}.', sound=True)
        return

    picked = pick_trailer(candidates)
    if picked in (None, 'canceled'):
        return
    play_trailer_url(
        picked['url'],
        title=picked.get('title') or name,
        imdb=imdb,
        tmdb_id=tmdb_id,
    )

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file smart_resolve.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Walk ranked sources until one resolves (Crew SmartResolve-lite).'''

import re
from contextlib import nullcontext

import xbmc

from ..kodi.resolve_status import capture_progress_dialogs, open_resolve_status
from ..modules import debrid
from ..modules import debrid_names
from ..modules.classy import c
from ..sources.labels import build_select_rows
from .models import PlayRequest


def _plain_label(text):
    return re.sub(r'\[/?[^\]]+\]', '', str(text or '')).strip()


def _candidate_key(candidate):
    raw = candidate.raw or {}
    return (
        (candidate.url or '').strip(),
        str(raw.get('debrid') or '').strip().lower(),
        str(candidate.provider or '').strip().lower(),
    )


def find_start_index(candidates, start_index=0, primary=None):
    '''
    Resolve the list index to start from.

    Prefer an explicit primary candidate (dialog click), then a numeric index
    (directory playItem), with bounds checks.
    '''
    items = list(candidates or [])
    if not items:
        return 0

    if primary is not None:
        try:
            return items.index(primary)
        except ValueError:
            # Reconstructed objects  -  match by URL/debrid key.
            want = _candidate_key(primary)
            for idx, cand in enumerate(items):
                if _candidate_key(cand) == want:
                    return idx

    try:
        index = int(start_index)
    except (TypeError, ValueError):
        index = 0
    if index < 0:
        index = 0
    if index >= len(items):
        index = 0
    return index


def _build_queue(candidates, start_index):
    '''
    Selected row first, then the rest of the list after it, then rows above.

    Matches Crew intent: honour the click, then keep walking the visible list.
    Returns (queue, list_indices) where list_indices[i] is the original row #.
    '''
    items = list(candidates or [])
    if not items:
        return [], []

    start_index = find_start_index(items, start_index)
    ordered_indexes = (
        [start_index]
        + list(range(start_index + 1, len(items)))
        + list(range(0, start_index))
    )

    seen = set()
    queue = []
    list_indices = []
    for idx in ordered_indexes:
        cand = items[idx]
        key = _candidate_key(cand)
        if not key[0] or key in seen:
            continue
        seen.add(key)
        queue.append(cand)
        list_indices.append(idx)
    return queue, list_indices


def _resolve_one(candidate, request=None, quiet=True):
    url = (candidate.url or '').strip()
    if not url:
        return None

    season = episode = None
    if isinstance(request, PlayRequest) and request.is_episode:
        season = request.season or None
        episode = request.episode or None

    raw = candidate.raw or {}
    tagged_debrid = raw.get('debrid') or ''

    needs_debrid = bool(candidate.debridonly) or url.startswith('magnet:')
    if needs_debrid:
        if debrid.is_torbox_resolve_blocked() and debrid_names.is_torbox(tagged_debrid):
            c.log('[SmartResolve] skipping TorBox row  -  session backoff')
            return None
        if not debrid.status(torrent=url.startswith('magnet:')):
            return None
        return debrid.resolve_for_play(
            url,
            season=season,
            episode=episode,
            quiet=quiet,
            debrid=tagged_debrid,
        )

    try:
        import resolveurl

        hmf = resolveurl.HostedMediaFile(url=url)
        if hmf.valid_url():
            resolved = hmf.resolve()
            if isinstance(resolved, dict):
                resolved = resolved.get('url') or ''
            if resolved:
                resolved = str(resolved).strip()
                from ..lists.hoster_process import _ensure_hls_pipe_headers

                return _ensure_hls_pipe_headers(resolved, url)
    except Exception as exc:
        c.log(f'[SmartResolve] resolveurl failed: {exc}', 1)

    if url.startswith(('http://', 'https://', 'rtmp')):
        return url
    return None


def _status_lines(candidate, list_index, try_offset, try_total, list_total, quiet=False):
    '''Overlay text  -  list row number stays aligned with the source directory.'''
    if quiet:
        # Couch mode: one line morphs; header already shows the episode.
        main = f'Resolving... {try_offset + 1} of {try_total}'
        return main, '', ''

    head, detail = build_select_rows(candidate, list_index)
    quality = _plain_label(candidate.quality or '') or 'link'
    raw = candidate.raw or {}
    debrid_tag = str(raw.get('debrid') or '').strip()
    provider = _plain_label(candidate.provider or '')
    # Prefer pack-prefixed display when provider is a registry key.
    try:
        from ..sources.labels import provider_display
        provider = _plain_label(provider_display(candidate.provider)) or provider
    except Exception:
        pass
    service = debrid_tag or provider or 'Direct'
    main = f'Trying {quality}'
    if service:
        main = f'{main}  |  {service}'
    sub = _plain_label(head)
    if detail:
        sub = f'{sub}  -  {_plain_label(detail)}' if sub else _plain_label(detail)
    attempt = (
        f'Source {list_index + 1} of {list_total}'
        f'  |  try {try_offset + 1}/{try_total}'
    )
    return main, sub[:120], attempt


def resolve_stream_queue(candidates, start_index, request=None, show_progress=True, primary=None):
    '''
    Try sources starting at the clicked/selected row until one resolves.

    Returns (play_url, winning_candidate) or (None, None).
    '''
    items = list(candidates or [])
    start = find_start_index(items, start_index, primary=primary)
    queue, list_indices = _build_queue(items, start)
    if not queue:
        return None, None

    total = len(queue)
    list_total = len(items)
    c.log(
        f'[SmartResolve] queue {total} links from list index {start} '
        f'(list size {list_total})'
    )

    from ..kodi.resolve_status import (
        get_active_overlay,
        clear_active_overlay,
        experience_overlay_wanted,
    )

    quiet = experience_overlay_wanted()
    overlay = None
    try:
        if show_progress:
            # Reuse scrape-opened ResolveStatus during TV Evening (one surface).
            overlay = get_active_overlay() or open_resolve_status(request)
            xbmc.sleep(100)

        progress_ctx = capture_progress_dialogs(overlay) if overlay else nullcontext()
        with progress_ctx:
            for offset, candidate in enumerate(queue):
                if overlay and overlay.is_cancelled():
                    c.log('[SmartResolve] cancelled by user')
                    return None, None

                list_index = list_indices[offset]
                main, sub, attempt = _status_lines(
                    candidate, list_index, offset, total, list_total, quiet=quiet,
                )
                if overlay:
                    try:
                        overlay.update_status(main, sub, attempt)
                        xbmc.sleep(50)
                    except Exception:
                        pass

                c.log(
                    f'[SmartResolve] attempt {offset + 1}/{total} '
                    f'list=#{list_index + 1} quality={candidate.quality!r} '
                    f'provider={candidate.provider!r}',
                )
                play_url = _resolve_one(candidate, request=request, quiet=True)
                if overlay and overlay.is_cancelled():
                    c.log('[SmartResolve] cancelled by user')
                    return None, None
                if play_url:
                    if overlay:
                        try:
                            overlay.update_status(
                                'Starting playback...' if quiet else 'Stream found  -  starting playback...',
                                '',
                                '' if quiet else attempt,
                            )
                            xbmc.sleep(300)
                        except Exception:
                            pass
                    c.log(
                        f'[SmartResolve] success on attempt {offset + 1}/{total} '
                        f'(list #{list_index + 1})'
                    )
                    return play_url, candidate

            c.log(f'[SmartResolve] queue exhausted ({total} links)')
            return None, None
    finally:
        if overlay:
            try:
                overlay.close()
            except Exception:
                pass
            try:
                clear_active_overlay()
            except Exception:
                pass
            try:
                del overlay
            except Exception:
                pass

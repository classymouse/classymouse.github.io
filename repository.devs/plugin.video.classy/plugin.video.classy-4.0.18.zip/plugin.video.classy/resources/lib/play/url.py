# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file url.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Play URLs from browse rows  -  embed meta so play skips TMDB re-fetch.'''

import json
import sys
from urllib.parse import quote_plus, urlencode

from ..metadata.video_row import VideoRow

# Compact row  ->  meta for action=play (Crew-style sysmeta, smaller key set).
_PLAY_META_KEYS = (
    'mediatype', 'title', 'originaltitle', 'year', 'imdb', 'tmdb', 'tvdb', 'trakt',
    'tvshowtitle', 'localtvshowtitle', 'season', 'episode', 'premiered', 'plot',
    'poster', 'fanart', 'thumb',
    'tmdb_poster_path', 'tmdb_backdrop_path', 'tmdb_still_path',
    'resume_point', 'duration',
)


def meta_from_row(row):
    '''Build JSON-serializable meta dict from a VideoRow (or dict).'''
    if isinstance(row, VideoRow):
        data = row.to_dict()
    elif isinstance(row, dict):
        data = row
    else:
        return {}

    meta = {}
    mediatype = (data.get('mediatype') or 'movie').lower()
    for key in _PLAY_META_KEYS:
        value = data.get(key)
        if value in (None, '', [], {}):
            continue
        if key in ('season', 'episode'):
            if mediatype == 'movie' or int(value or 0) <= 0:
                continue
        meta[key] = value
    if not meta.get('mediatype'):
        meta['mediatype'] = data.get('mediatype') or 'movie'
    return meta


def play_url(row, *, select=None):
    '''Folder-safe play URL with optional embedded meta blob.

    ``select`` stamps hosts.mode override (0=Dialog, 1=Directory, 2=Autoplay).
    Home widgets need select=2  -  Directory mode cannot hand off from a
    resolve click (IsPlayable) on the Home screen.
    '''
    if isinstance(row, VideoRow):
        data = row
    else:
        data = VideoRow.from_dict(row) if isinstance(row, dict) else VideoRow()

    mediatype = data.mediatype or 'movie'
    params = {
        'action': 'play',
        'title': data.title,
        'year': data.year,
        'imdb': data.imdb,
        'tmdb': data.tmdb,
        'tvdb': data.tvdb,
        'trakt': data.trakt,
        'mediatype': mediatype,
    }
    if mediatype == 'episode' and data.season and data.episode:
        params.update({
            'tvshowtitle': data.tvshowtitle or data.title,
            'season': data.season,
            'episode': data.episode,
            'premiered': data.premiered,
        })
    if select is not None and str(select).strip() != '':
        params['select'] = int(select)

    clean = {k: v for k, v in params.items() if v not in (None, '', 0)}
    query = urlencode(clean)

    meta = meta_from_row(data)
    if meta:
        blob = quote_plus(json.dumps(meta, separators=(',', ':')))
        query = f'{query}&meta={blob}' if query else f'meta={blob}'

    return f'{sys.argv[0]}?{query}'

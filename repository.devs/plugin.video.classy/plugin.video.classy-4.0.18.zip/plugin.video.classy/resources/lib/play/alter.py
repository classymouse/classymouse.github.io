# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file alter.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Parse alter_sources route params  ->  play handler input.'''

from urllib.parse import parse_qsl, unquote_plus

from .mode import alter_select_override


def params_for_alter_play(params):
    '''
    Crew passes a quoted plugin play URL in ``url``; episodes may add ``meta`` separately.
    Returns a param dict for play_handler with ``select`` forced per hosts.mode flip.
    '''
    raw = dict(params or {})
    url = unquote_plus(str(raw.pop('url', '') or ''))

    merged = {}
    if url:
        query = url.split('?', 1)[1] if '?' in url else url
        merged = dict(parse_qsl(query, keep_blank_values=True))

    if not merged:
        merged = dict(raw)
        merged.pop('action', None)

    extra_meta = raw.get('meta')
    if extra_meta and not merged.get('meta'):
        merged['meta'] = extra_meta

    merged['select'] = str(alter_select_override())
    return merged

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file player.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Playback entry  -  resolve debrid/ResolveURL then start ClassyPlayer.'''

import sys

import xbmcgui
import xbmcplugin

from ..modules import debrid
from ..modules.classy import c
from ..modules import kodi
from ..playback.monitor import get_playback_player
from ..playback import resume as playback_resume
from ..playback import session as playback_session
from ..playback.resume_prompt import autoresume_enabled
from ..progress import filters as slot_filters
from .models import PlayRequest, StreamCandidate


def _resolve_handle():
    '''Plugin resolve handle when Kodi waits for setResolvedUrl (IsPlayable).'''
    try:
        handle = int(sys.argv[1])
    except (TypeError, ValueError, IndexError):
        return -1
    return handle


def _apply_video_info(li, request, resume=None):
    meta = dict(getattr(request, 'meta', None) or {})
    mediatype = 'episode' if request.is_episode else 'movie'
    info_tag = li.getVideoInfoTag()
    info_tag.setMediaType(mediatype)

    title = request.title or request.tvshowtitle or request.display_title
    if request.is_episode:
        info_tag.setTitle(str(title or f'Episode {request.episode}'))
        if request.tvshowtitle:
            info_tag.setTvShowTitle(str(request.tvshowtitle))
        if request.season:
            info_tag.setSeason(int(request.season))
        if request.episode:
            info_tag.setEpisode(int(request.episode))
    else:
        info_tag.setTitle(str(title or 'Movie'))

    if request.year and str(request.year).isdigit():
        info_tag.setYear(int(request.year))
    if meta.get('plot'):
        info_tag.setPlot(str(meta.get('plot')))
    if meta.get('premiered'):
        info_tag.setPremiered(str(meta.get('premiered')))

    duration = int((resume or {}).get('duration') or 0)
    if not duration:
        duration = int(meta.get('duration') or 0)
    if duration > 0:
        try:
            info_tag.setDuration(duration)
        except Exception:
            pass

    unique = {}
    if request.imdb:
        unique['imdb'] = request.imdb_for_scrape()
    if request.tmdb:
        unique['tmdb'] = str(request.tmdb)
    if request.tvdb:
        unique['tvdb'] = str(request.tvdb)
    if unique:
        try:
            info_tag.setUniqueIDs(unique)
        except Exception:
            pass

    resume = resume or {}
    progress = float(resume.get('progress') or 0)
    resume_secs = float(resume.get('resume_seconds') or 0)
    if resume_secs > 0 and duration > 0 and autoresume_enabled():
        try:
            info_tag.setResumePoint(resume_secs, duration)
        except Exception:
            try:
                info_tag.setResumePoint(resume_secs)
            except Exception:
                pass
    elif progress > 0 and c.devmode:
        c.log(f'[Play] resume progress={progress:.1f}% but no duration  -  seek via player only')


def play_stream(candidate, request=None, resolved_url=None):
    if not isinstance(candidate, StreamCandidate):
        kodi.notification(c.addon_id, 'No stream selected')
        return False

    url = (resolved_url or candidate.url or '').strip()
    if not url:
        kodi.notification(c.addon_id, 'Invalid stream URL')
        return False

    season = episode = None
    if isinstance(request, PlayRequest) and request.is_episode:
        season = request.season or None
        episode = request.episode or None

    needs_debrid = not resolved_url and (bool(candidate.debridonly) or url.startswith('magnet:'))
    if needs_debrid:
        if not debrid.status(torrent=True):
            kodi.notification(
                c.addon_id,
                'Enable a debrid service in ResolveURL settings (Real-Debrid, AllDebrid, ...).',
            )
            return False
        resolved = debrid.resolve_for_play(
            url,
            season=season,
            episode=episode,
            debrid=(candidate.raw or {}).get('debrid'),
        )
        if not resolved:
            kodi.notification(c.addon_id, 'Could not resolve debrid link')
            return False
        url = resolved

    label = candidate.label()
    if isinstance(request, PlayRequest):
        label = request.display_title

    li = xbmcgui.ListItem(path=url, label=label)
    li.setProperty('IsPlayable', 'true')

    art = {}
    if isinstance(request, PlayRequest) and request.meta:
        poster = request.meta.get('poster') or request.meta.get('thumb')
        fanart = request.meta.get('fanart')
        if poster:
            art['thumb'] = poster
            art['icon'] = poster
        if fanart:
            art['fanart'] = fanart
    if art:
        li.setArt(art)

    resume_info = None
    if isinstance(request, PlayRequest):
        evening_live = False
        try:
            from ..tvevening.monitor import evening_is_live, evening_blocks_upnext
            evening_live = bool(evening_is_live() or evening_blocks_upnext())
        except Exception:
            evening_live = False

        resume_info = playback_resume.lookup_for_play(request)
        resume_mode = ''
        evening_bookmark = None
        try:
            from ..modules import control as ctrl
            resume_mode = (ctrl.window.getProperty('thecrew.tvevening.resume_mode') or '').lower()
            if resume_mode == 'auto':
                try:
                    secs = float(ctrl.window.getProperty('thecrew.tvevening.resume_seconds') or 0)
                    prog = float(ctrl.window.getProperty('thecrew.tvevening.resume_progress') or 0)
                except (TypeError, ValueError):
                    secs, prog = 0.0, 0.0
                if secs >= 2.0 and prog < slot_filters.resume_progress_max():
                    evening_bookmark = {
                        'resume_seconds': secs,
                        'progress': prog,
                        'duration': int(secs / (prog / 100.0)) if prog > 0 else 0,
                        'playback_id': '',
                    }
        except Exception:
            resume_mode = ''

        # Local evening bookmark wins  -  tracker sync often lags behind a dinner pause.
        if evening_bookmark:
            resume_info = evening_bookmark
            c.log(
                f'[Play] TV Evening  -  local bookmark {evening_bookmark["progress"]:.0f}% '
                f'offset={evening_bookmark["resume_seconds"]:.0f}s'
            )

        if evening_live and resume_info:
            try:
                progress = float(resume_info.get('progress') or 0)
            except (TypeError, ValueError):
                progress = 0.0
            # Near-complete bookmarks would finish the slot instantly  -  start fresh.
            if progress >= slot_filters.resume_progress_max():
                c.log(
                    f'[Play] TV Evening  -  resume {progress:.0f}% near complete, '
                    f'starting from 00:00'
                )
                resume_info = None
            elif progress < 2.0:
                resume_info = None
            elif resume_mode == 'auto':
                c.log(
                    f'[Play] TV Evening  -  recovery auto-resume {progress:.0f}% '
                    f'(Continue Playing)'
                )
            else:
                c.log(
                    f'[Play] TV Evening  -  mid-watch resume {progress:.0f}% '
                    f'(will prompt Resume / From Start)'
                )
        elif evening_live:
            c.log('[Play] TV Evening  -  no resume bookmark available, start 00:00')

        # Apply ListItem resume for recovery auto so Kodi helps seek; still strip for prompts.
        apply_li_resume = (not evening_live) or (resume_mode == 'auto' and resume_info)
        _apply_video_info(li, request, resume=resume_info if apply_li_resume else None)
        playback_session.store(request, resume=resume_info)
        try:
            from ..playback import service_hooks
            service_hooks.arm_after_play()
        except Exception as exc:
            c.log(f'[Play] AV hooks arm failed: {exc}', 1)
        try:
            from ..modules import control as ctrl
            # Prompt only for mid-watch on a fresh slot; recovery Continue uses auto seek.
            if evening_live and resume_info and resume_mode != 'auto':
                ctrl.window.setProperty('thecrew.tvevening.resume_prompt', 'true')
            else:
                ctrl.window.clearProperty('thecrew.tvevening.resume_prompt')
            if resume_mode == 'auto':
                ctrl.window.clearProperty('thecrew.tvevening.resume_mode')
        except Exception:
            pass
        if resume_info and not evening_live:
            c.log(
                f'[Play] resume {resume_info.get("progress", 0):.1f}% '
                f'offset={resume_info.get("resume_seconds", 0):.0f}s'
            )
        elif float((request.meta or {}).get('resume_point') or 0) > 0 and not evening_live:
            c.log('[Play] resume meta present but could not compute seek offset', 1)

    c.log(f'[Play] starting playback url={url[:120]}')
    try:
        from .fallback_queue import mark_play_started

        mark_play_started()
    except Exception:
        pass
    if isinstance(request, PlayRequest) and request.is_episode:
        try:
            from .upnext_autoplay import remember_magnet

            remember_magnet(candidate)
        except Exception:
            pass

    # Home widgets (IsPlayable): Kodi waits for setResolvedUrl. Player.play alone
    # leaves the resolve hanging. Prefer resolve handoff; never both.
    handle = _resolve_handle()
    if handle >= 0:
        try:
            li.setPath(url)
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(handle, True, li)
        c.log(f'[Play] setResolvedUrl handle={handle}')
    else:
        get_playback_player().play(url, li)

    if isinstance(request, PlayRequest) and request.is_episode:
        try:
            from ..tvevening.monitor import evening_blocks_upnext
            if evening_blocks_upnext():
                c.log('[Play] UpNext arm skipped  -  TV Evening owns transitions')
            else:
                from ..playback import upnext as upnext_mod
                upnext_mod.arm(request)
        except Exception as exc:
            c.log(f'[Play] UpNext arm failed: {exc}', 1)

    return True

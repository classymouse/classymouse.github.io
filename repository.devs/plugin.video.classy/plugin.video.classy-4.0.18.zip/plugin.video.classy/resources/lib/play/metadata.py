# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file metadata.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Fill sparse PlayRequest fields and artwork from TMDB before scraping.'''

from ..apis.tmdb import tmdb
from ..metadata import ids as idmap
from ..metadata import extract
from ..modules.classy import c
from .models import PlayRequest


def enrich_request(request):
    if not isinstance(request, PlayRequest):
        return request

    try:
        _apply_meta_art(request)
    except Exception:
        pass

    if not request.tmdb and not request.imdb:
        try:
            _enrich_scrape_metadata(request)
        except Exception:
            pass
        return request

    try:
        _enrich_scrape_metadata(request)
        if request.is_episode and request.season and request.episode:
            _enrich_episode(request)
        elif request.is_movie:
            _enrich_movie(request)
    except Exception as exc:
        c.log(f'[Play] metadata enrich failed: {exc}', 1)
    return request


def _ensure_meta(request):
    if request.meta is None:
        request.meta = {}
    return request.meta


def _apply_tmdb_art(meta, poster_path=None, backdrop_path=None, still_path=None):
    if poster_path:
        poster = extract.poster_url(poster_path)
        if poster:
            meta['poster'] = poster
            meta.setdefault('thumb', poster)
    if still_path:
        still = extract.still_url(still_path)
        if still:
            meta['thumb'] = still
            meta.setdefault('poster', still)
    if backdrop_path:
        fanart = extract.fanart_url(backdrop_path)
        if fanart:
            meta['fanart'] = fanart


def _apply_meta_art(request):
    '''Use poster/path fields from list meta  -  no HTTP.'''
    meta = request.meta or {}
    if not meta:
        return
    out = _ensure_meta(request)
    for key in ('poster', 'fanart', 'thumb', 'plot'):
        if meta.get(key) and not out.get(key):
            out[key] = meta[key]
    if not out.get('poster') or not out.get('fanart'):
        _apply_tmdb_art(
            out,
            meta.get('tmdb_poster_path'),
            meta.get('tmdb_backdrop_path'),
            meta.get('tmdb_still_path'),
        )


def _normalize_imdb(value):
    text = str(value or '').strip()
    if text.startswith('tt'):
        text = text[2:]
    return text


def _movie_needs_fetch(request):
    '''True when scrape cannot run without TMDB (missing title/year/imdb).'''
    if not request.title or not request.year:
        return True
    if not request.imdb:
        return True
    return False


def _resolve_movie_imdb(request):
    if request.imdb or not request.tmdb:
        return False
    resolved = idmap.resolve_movie_ids(tmdb=request.tmdb)
    imdb = idmap.valid_id((resolved or {}).get('imdb'))
    if imdb:
        request.imdb = _normalize_imdb(imdb)
        return True
    return False


def _enrich_movie(request):
    meta = _ensure_meta(request)
    try:
        resume_progress = float(meta.get('resume_point') or 0)
    except (TypeError, ValueError):
        resume_progress = 0.0
    needs_runtime = resume_progress > 0 and not int(meta.get('duration') or 0)

    if _resolve_movie_imdb(request) and not _movie_needs_fetch(request) and not needs_runtime:
        return
    if not _movie_needs_fetch(request) and not needs_runtime:
        return

    data = tmdb.get_movie(request.tmdb)
    if not isinstance(data, dict):
        return
    if not request.title:
        request.title = (data.get('title') or '').strip()
    release = (data.get('release_date') or '')[:10]
    if not request.year and release:
        request.year = release[:4]
    if not request.premiered:
        request.premiered = release
    imdb = (data.get('imdb_id') or '').strip()
    if imdb and not request.imdb:
        request.imdb = _normalize_imdb(imdb)

    _apply_tmdb_art(meta, data.get('poster_path'), data.get('backdrop_path'))
    if data.get('overview') and not meta.get('plot'):
        meta['plot'] = (data.get('overview') or '').strip()
    if needs_runtime and data.get('runtime'):
        meta['duration'] = int(data['runtime']) * 60
    meta.setdefault('mediatype', 'movie')
    meta.setdefault('title', request.title)


def _episode_needs_fetch(request):
    if not request.tvshowtitle or not request.title:
        return True
    if not request.imdb and not request.tmdb:
        return True
    return False


def _resolve_show_imdb(request):
    if request.imdb or not request.tmdb:
        return False
    resolved = idmap.resolve_show_ids(tmdb=request.tmdb)
    imdb = idmap.valid_id((resolved or {}).get('imdb'))
    if imdb:
        request.imdb = _normalize_imdb(imdb)
        return True
    return False


def _enrich_episode(request):
    if _resolve_show_imdb(request) and not _episode_needs_fetch(request):
        return
    if not _episode_needs_fetch(request):
        return

    show = tmdb.get_tv(request.tmdb)
    if isinstance(show, dict):
        if not request.tvshowtitle:
            request.tvshowtitle = (show.get('name') or '').strip()
        first = (show.get('first_air_date') or '')[:10]
        if not request.year and first:
            request.year = first[:4]
        meta = _ensure_meta(request)
        _apply_tmdb_art(meta, show.get('poster_path'), show.get('backdrop_path'))

    ep = tmdb.get_tv_episode(request.tmdb, request.season, request.episode)
    if not isinstance(ep, dict):
        return
    if not request.title:
        request.title = (ep.get('name') or '').strip()
    aired = (ep.get('air_date') or '')[:10]
    if not request.premiered:
        request.premiered = aired
    if not request.localtvshowtitle:
        request.localtvshowtitle = request.tvshowtitle

    meta = _ensure_meta(request)
    _apply_tmdb_art(meta, still_path=ep.get('still_path'))
    if not meta.get('fanart') and isinstance(show, dict):
        _apply_tmdb_art(meta, backdrop_path=show.get('backdrop_path'))
    if ep.get('overview') and not meta.get('plot'):
        meta['plot'] = (ep.get('overview') or '').strip()
    meta.setdefault('mediatype', 'episode')
    meta.setdefault('title', request.title)
    meta.setdefault('tvshowtitle', request.tvshowtitle)
    meta.setdefault('season', request.season)
    meta.setdefault('episode', request.episode)


def _alias_titles(rows):
    titles = []
    for row in rows or []:
        if isinstance(row, dict):
            text = (row.get('title') or '').strip()
        else:
            text = str(row or '').strip()
        if text:
            titles.append(text)
    return titles


def _enrich_scrape_metadata(request):
    '''Aliases and ids pack scrapers expect (Crew parity).'''
    if request.aliases:
        return
    imdb = request.imdb
    if not imdb:
        return
    try:
        from ..trakt import aliases as trakt_aliases

        content = 'episode' if request.is_episode else 'movie'
        local = request.localtvshowtitle or request.tvshowtitle or request.title
        rows = trakt_aliases.fetch_aliases(imdb, content=content, localtitle=local)
        titles = _alias_titles(rows)
        if titles:
            request.aliases = titles
    except Exception as exc:
        if getattr(c, 'devmode', False):
            c.log(f'[Play] alias fetch skipped: {exc}', 1)

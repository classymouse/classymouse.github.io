# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file picker.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Source picker dialog.'''

import xbmcgui

from ..modules.classy import c
from ..sources.labels import build_select_rows


def pick_stream(candidates, heading=None):
    '''
    Show source picker.

    Returns (candidate, index) or (None, -1) if cancelled / empty.
    '''
    if not candidates:
        return None, -1
    if len(candidates) == 1:
        return candidates[0], 0

    rows = [build_select_rows(cand, i) for i, cand in enumerate(candidates)]
    title = heading or c.addon_id
    use_details = (
        c.get_setting('sourcelist.multiline') == 'true'
        and any(detail for _, detail in rows)
    )

    try:
        if use_details:
            items = []
            for head, detail in rows:
                li = xbmcgui.ListItem(label=head)
                try:
                    li.setLabel2(detail or '')
                except Exception:
                    pass
                items.append(li)
            index = xbmcgui.Dialog().select(title, items, useDetails=True)
        else:
            index = xbmcgui.Dialog().select(title, [head for head, _ in rows])
    except TypeError:
        # Older Kodi: no useDetails kwarg  -  fall back to one line per row.
        labels = [f'{head}  -  {detail}' if detail else head for head, detail in rows]
        index = xbmcgui.Dialog().select(title, labels)

    if index is None or index < 0 or index >= len(candidates):
        return None, -1
    return candidates[index], int(index)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file mode.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Play mode  -  matches Crew ``hosts.mode`` enum indices.'''

from ..modules import kodi
from ..modules.classy import c

# Kodi settings enum index = play mode (same as Crew 3.x).
MODE_DIALOG = 0
MODE_DIRECTORY = 1
MODE_AUTOPLAY = 2

_DEFAULT = MODE_DIRECTORY


def alter_select_override():
    '''Crew alter_sources: directory picker when default is autoplay, else autoplay.'''
    try:
        hosts_mode = int(c.get_setting('hosts.mode') or _DEFAULT)
    except (TypeError, ValueError):
        hosts_mode = _DEFAULT
    if hosts_mode == MODE_AUTOPLAY:
        return MODE_DIRECTORY
    return MODE_AUTOPLAY


def resolve_play_mode(params=None):
    '''Return mode int. URL ``select`` overrides ``hosts.mode`` when present.'''
    params = params or {}
    override = params.get('select')
    if override is not None and str(override).strip() != '':
        try:
            return int(str(override).strip())
        except (TypeError, ValueError):
            pass
    # Home widgets: directory mode is unreliable; default to top-source autoplay.
    if kodi.is_widget_listing():
        return MODE_AUTOPLAY
    try:
        return int(c.get_setting('hosts.mode') or _DEFAULT)
    except (TypeError, ValueError):
        return _DEFAULT

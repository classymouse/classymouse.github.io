# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file fallback_queue.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Auto-try next scraped source when Kodi playback dies before AV starts.'''

from __future__ import annotations

import json
import time

import xbmc

from ..modules import control
from ..modules.classy import c
from ..play.models import PlayRequest, StreamCandidate
from .smart_resolve import _build_queue, _candidate_key, find_start_index

PROP_STASH = 'thecrew.playback.fallback_stash'
PROP_STARTED_AT = 'thecrew.playback.play_started_at'
PROP_LOCK = 'thecrew.playback.fallback_lock'
# Legacy dual-read cleared on write (cutover from classy.*).
_LEGACY_STASH = 'classy.playback.fallback_stash'
_LEGACY_STARTED = 'classy.playback.play_started_at'
_LEGACY_LOCK = 'classy.playback.fallback_lock'

MAX_AUTO_TRIES = 5
FAIL_WINDOW_SEC = 45
MIN_PLAYABLE_TOTAL = 30


def _win():
    return control.window


def clear():
    win = _win()
    win.clearProperty(PROP_STASH)
    win.clearProperty(PROP_STARTED_AT)
    win.clearProperty(PROP_LOCK)
    win.clearProperty(_LEGACY_STASH)
    win.clearProperty(_LEGACY_STARTED)
    win.clearProperty(_LEGACY_LOCK)


def mark_play_started():
    try:
        win = _win()
        win.setProperty(PROP_STARTED_AT, str(time.time()))
        win.clearProperty(_LEGACY_STARTED)
    except Exception:
        pass


def stash_after_resolve(candidates, start_index, winner, request, primary=None):
    '''Keep unresolved queue tail so a dead CDN link can auto-advance.'''
    items = list(candidates or [])
    if not items or not isinstance(request, PlayRequest):
        clear()
        return

    start = find_start_index(items, start_index, primary=primary or winner)
    queue, list_indices = _build_queue(items, start)
    if not queue or winner is None:
        clear()
        return

    win_key = _candidate_key(winner)
    next_offset = 0
    for idx, cand in enumerate(queue):
        if _candidate_key(cand) == win_key:
            next_offset = idx + 1
            break

    remaining = queue[next_offset:]
    rem_indices = list_indices[next_offset:]
    if not remaining:
        clear()
        return

    payload = {
        'request': _request_dict(request),
        'candidates': [c.to_dict() for c in remaining],
        'list_indices': rem_indices,
        'attempts': 0,
    }
    try:
        win = _win()
        win.setProperty(PROP_STASH, json.dumps(payload, separators=(',', ':')))
        win.clearProperty(_LEGACY_STASH)
        c.log(
            f'[PlayFallback] stashed {len(remaining)} alternate source(s) '
            f'after list #{list_indices[next_offset - 1] + 1 if next_offset else start + 1}',
        )
    except Exception as exc:
        c.log(f'[PlayFallback] stash failed: {exc}', 1)


def _request_dict(request):
    return {
        'mediatype': request.mediatype,
        'title': request.title,
        'year': request.year,
        'imdb': request.imdb,
        'tmdb': request.tmdb,
        'tvdb': request.tvdb,
        'trakt': request.trakt,
        'season': request.season,
        'episode': request.episode,
        'tvshowtitle': request.tvshowtitle,
        'localtvshowtitle': request.localtvshowtitle,
        'premiered': request.premiered,
        'meta': request.meta or {},
    }


def _load_stash():
    raw = _win().getProperty(PROP_STASH) or _win().getProperty(_LEGACY_STASH) or ''
    if not raw:
        return None
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _save_stash(data):
    if not data:
        clear()
        return
    try:
        _win().setProperty(PROP_STASH, json.dumps(data, separators=(',', ':')))
    except Exception:
        clear()


def _hooks_completed():
    try:
        from ..playback import session as playback_session
        from ..playback import service_hooks

        seq = playback_session.current_play_seq()
        if not seq:
            return False
        done = control.window.getProperty(service_hooks.AV_HOOKS_DONE_SEQ_PROP) or ''
        return done == seq
    except Exception:
        return False


def _play_age_sec():
    try:
        started = float(
            _win().getProperty(PROP_STARTED_AT)
            or _win().getProperty(_LEGACY_STARTED)
            or 0
        )
    except (TypeError, ValueError):
        started = 0.0
    if started <= 0:
        return 9999.0
    return max(0.0, time.time() - started)


def should_fallback_on_stop(pos, total):
    if _load_stash() is None:
        return False
    if _hooks_completed():
        clear()
        return False
    try:
        from ..playback import session as playback_session

        if control.window.getProperty(playback_session.UPNEXT_HANDOFF_PROP) == '1':
            return False
    except Exception:
        pass
    if _play_age_sec() > FAIL_WINDOW_SEC:
        return False
    if total >= MIN_PLAYABLE_TOTAL or pos >= 5:
        return False
    return True


def schedule_if_needed(pos, total):
    if not should_fallback_on_stop(pos, total):
        return False
    win = _win()
    if win.getProperty(PROP_LOCK) == '1' or win.getProperty(_LEGACY_LOCK) == '1':
        return False
    try:
        win.setProperty(PROP_LOCK, '1')
        win.clearProperty(_LEGACY_LOCK)
        c.log(
            f'[PlayFallback] playback died early ({pos:.0f}/{total:.0f}s) '
            f'- scheduling next source',
        )
        xbmc.executebuiltin(
            f'RunPlugin(plugin://{c.addon_id}/?action=playFallback)',
        )
        return True
    except Exception as exc:
        win.clearProperty(PROP_LOCK)
        c.log(f'[PlayFallback] schedule failed: {exc}', 1)
        return False


def continue_fallback():
    '''Plugin route: resolve and play the next stashed candidate.'''
    win = _win()
    win.clearProperty(PROP_LOCK)

    data = _load_stash()
    if not data:
        return False

    attempts = int(data.get('attempts') or 0)
    if attempts >= MAX_AUTO_TRIES:
        c.log(f'[PlayFallback] gave up after {attempts} auto tries', 1)
        clear()
        from ..modules import kodi
        kodi.notification(c.addon_id, 'No working stream found (auto-fallback limit)')
        return False

    raw_candidates = data.get('candidates') or []
    if not raw_candidates:
        clear()
        return False

    cand = StreamCandidate.from_dict(raw_candidates[0])
    if not cand:
        data['candidates'] = raw_candidates[1:]
        data['list_indices'] = (data.get('list_indices') or [])[1:]
        data['attempts'] = attempts + 1
        _save_stash(data)
        return continue_fallback()

    list_index = 0
    indices = data.get('list_indices') or []
    if indices:
        try:
            list_index = int(indices[0])
        except (TypeError, ValueError):
            list_index = 0

    try:
        request = PlayRequest(**(data.get('request') or {}))
    except Exception:
        request = PlayRequest()

    from .smart_resolve import _resolve_one

    c.log(
        f'[PlayFallback] auto try {attempts + 1}/{MAX_AUTO_TRIES} '
        f'list #{list_index + 1} provider={cand.provider!r} quality={cand.quality!r}',
    )
    play_url = _resolve_one(cand, request=request, quiet=True)
    if not play_url:
        c.log('[PlayFallback] resolve failed  -  trying next row', 1)
        data['candidates'] = raw_candidates[1:]
        data['list_indices'] = indices[1:]
        data['attempts'] = attempts + 1
        _save_stash(data)
        return continue_fallback()

    data['candidates'] = raw_candidates[1:]
    data['list_indices'] = indices[1:]
    data['attempts'] = attempts + 1
    _save_stash(data)

    from .player import play_stream

    return bool(play_stream(cand, request, resolved_url=play_url))

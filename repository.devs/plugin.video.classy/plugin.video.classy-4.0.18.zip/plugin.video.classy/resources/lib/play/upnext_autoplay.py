# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file upnext_autoplay.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Up Next zero-click autoplay: prefer exact-episode sources over season packs.'''

from __future__ import annotations

import re
from urllib.parse import parse_qs, urlparse

from ..modules.classy import c
from ..sources.title_match import (
    _RANGE_PATTERNS,
    episode_hdlr,
    release_name_from_candidate,
)

LAST_MAGNET_PROP = 'thecrew.upnext.last_magnet'


def infohash_from_candidate(candidate):
    raw_hash = (getattr(candidate, 'hash', None) or '').strip().lower()
    if raw_hash:
        return raw_hash
    url = (getattr(candidate, 'url', None) or '').strip()
    if not url.lower().startswith('magnet:'):
        return ''
    try:
        query = parse_qs(urlparse(url).query)
        xt = (query.get('xt') or [''])[0]
    except Exception:
        xt = url
    match = re.search(r'btih:([a-f0-9]{40})', xt, re.I)
    if match:
        return match.group(1).lower()
    return ''


def remember_magnet(candidate):
    infohash = infohash_from_candidate(candidate)
    if not infohash:
        return
    try:
        from ..modules import control

        control.window.setProperty(LAST_MAGNET_PROP, infohash)
    except Exception:
        pass


def _is_exact_episode_release(candidate, request):
    release = release_name_from_candidate(candidate)
    if not release:
        return False
    hdlr = episode_hdlr(request.season, request.episode)
    if not hdlr or not re.search(re.escape(hdlr), release, re.I):
        return False
    for pattern in _RANGE_PATTERNS:
        if re.search(pattern, release, re.I):
            return False
    return True


def _is_season_pack_release(release_name):
    if not release_name:
        return False
    for pattern in _RANGE_PATTERNS:
        if re.search(pattern, release_name, re.I):
            return True
    return False


def _hash_allowed(candidate, skip_hash):
    if not skip_hash:
        return True
    infohash = infohash_from_candidate(candidate)
    return not infohash or infohash != skip_hash


def pick_autoplay_candidate(candidates, request, skip_hash=''):
    '''
    Pick list index + candidate for Up Next autoplay.

    Prefer exact SxEy releases, skip the prior episode's torrent hash, and
    deprioritize season packs that replay the wrong file from debrid cache.
    '''
    items = list(candidates or [])
    if not items:
        return 0, None

    skip_hash = str(skip_hash or '').strip().lower()
    season = int(request.season or 0)
    episode = int(request.episode or 0)

    for idx, cand in enumerate(items):
        if _is_exact_episode_release(cand, request) and _hash_allowed(cand, skip_hash):
            c.log(
                f'[Play] UpNext autoplay pick list #{idx + 1} '
                f'exact S{season:02d}E{episode:02d}',
            )
            return idx, cand

    for idx, cand in enumerate(items):
        if not _hash_allowed(cand, skip_hash):
            continue
        release = release_name_from_candidate(cand)
        if release and not _is_season_pack_release(release):
            c.log(
                f'[Play] UpNext autoplay pick list #{idx + 1} '
                f'non-pack (no exact S{season:02d}E{episode:02d} in name)',
            )
            return idx, cand

    for idx, cand in enumerate(items):
        if _hash_allowed(cand, skip_hash):
            c.log(
                f'[Play] UpNext autoplay pick list #{idx + 1} fallback '
                f'(only packs / hash-skipped rows above)',
                1,
            )
            return idx, cand

    c.log('[Play] UpNext autoplay pick list #1 last resort (all rows matched skip hash)', 1)
    return 0, items[0]

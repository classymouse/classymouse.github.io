# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file gate.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Exclusive watch-tracker gate: one active backend at a time (XOR).

Menus / monitor / playcount / progress / calendars ask this module  - 
not scrape tracker.service or call trakt.auth directly for live checks.'''

from ..modules.classy import c
from .backends import REGISTRY
from .types import (
    NAME_SIMKL,
    NAME_TRAKT,
    NAME_WETRAKR,
    SIMKL_STATUS_PLANTOWATCH,
    TRACKER_SIMKL,
    TRACKER_TRAKT,
    TRACKER_WETRAKR,
)


def active_service() -> int:
    """Return TRACKER_TRAKT, TRACKER_SIMKL or TRACKER_WETRAKR."""
    try:
        raw = int(c.get_setting('tracker.service') or 0)
    except Exception:
        return TRACKER_TRAKT
    if raw == TRACKER_SIMKL:
        return TRACKER_SIMKL
    if raw == TRACKER_WETRAKR:
        return TRACKER_WETRAKR
    return TRACKER_TRAKT


def active_name() -> str:
    """'trakt', 'simkl' or 'wetrakr'  -  stable id for logs / conditionals."""
    service = active_service()
    if service == TRACKER_SIMKL:
        return NAME_SIMKL
    if service == TRACKER_WETRAKR:
        return NAME_WETRAKR
    return NAME_TRAKT


def is_simkl() -> bool:
    return active_service() == TRACKER_SIMKL


def is_trakt() -> bool:
    return active_service() == TRACKER_TRAKT


def is_wetrakr() -> bool:
    return active_service() == TRACKER_WETRAKR


def _backend():
    mod = REGISTRY.get(active_name())
    if mod is None:
        return REGISTRY[NAME_TRAKT]
    return mod


def live() -> bool:
    """Active backend is authorized and usable."""
    return bool(_backend().live())


def trakt_live() -> bool:
    if not is_trakt():
        return False
    return bool(REGISTRY[NAME_TRAKT].live())


def simkl_live() -> bool:
    if not is_simkl():

        return False
    return bool(REGISTRY[NAME_SIMKL].live())


def wetrakr_live() -> bool:
    if not is_wetrakr():
        return False
    return bool(REGISTRY[NAME_WETRAKR].live())


def supports_collection() -> bool:
    return bool(_backend().supports_collection())


def supports_watchlist() -> bool:
    return bool(_backend().supports_watchlist())


def supports_progress() -> bool:
    return bool(_backend().supports_progress())


def supports_calendars() -> bool:
    return bool(_backend().supports_calendars())


def display_label() -> str:
    """Short brand for menu / CM titles (Trakt / Simkl)."""
    return str(getattr(_backend(), 'display_label', None) or active_name().title())


def watchlist_status_for_active() -> str:
    return SIMKL_STATUS_PLANTOWATCH


def _dispatch(name, *args, **kwargs):
    fn = getattr(_backend(), name, None)
    if fn is None:
        raise AttributeError(f'tracker backend {active_name()!r} missing {name}')
    return fn(*args, **kwargs)


def scrobble_session(session, current_sec, total_sec, action):
    return _dispatch('scrobble_session', session, current_sec, total_sec, action)


def scrobble_start(session, current_sec, total_sec):
    return _dispatch('scrobble_start', session, current_sec, total_sec)


def scrobble_pause(session, current_sec, total_sec):
    return _dispatch('scrobble_pause', session, current_sec, total_sec)


def scrobble_stop(session, current_sec, total_sec):
    return _dispatch('scrobble_stop', session, current_sec, total_sec)


def playback_items(mediatype, *, force=False):
    return _dispatch('playback_items', mediatype, force=force)


def clear_resume(request_or_meta):
    return _dispatch('clear_resume', request_or_meta)


def mark_watched_movie(imdb, tmdb=''):
    return _dispatch('mark_watched_movie', imdb, tmdb)


def mark_unwatched_movie(imdb, tmdb=''):
    return _dispatch('mark_unwatched_movie', imdb, tmdb)


def mark_watched_episode(imdb, tmdb, season, episode):
    return _dispatch('mark_watched_episode', imdb, tmdb, season, episode)


def mark_unwatched_episode(imdb, tmdb, season, episode):
    return _dispatch('mark_unwatched_episode', imdb, tmdb, season, episode)


def mark_watched_show(imdb, tmdb=''):
    return _dispatch('mark_watched_show', imdb, tmdb)


def mark_unwatched_show(imdb, tmdb=''):
    return _dispatch('mark_unwatched_show', imdb, tmdb)


def apply_playcount(params, *, mediatype):
    return _dispatch('apply_playcount', params, mediatype=mediatype)


def next_episode_sessions(**kwargs):
    return _dispatch('next_episode_sessions', **kwargs)


def calendar_episodes(window, **kwargs):
    return _dispatch('calendar_episodes', window, **kwargs)


def watching_shows():
    return _dispatch('watching_shows')


def watchlist_items(**kwargs):
    return _dispatch('watchlist_items', **kwargs)

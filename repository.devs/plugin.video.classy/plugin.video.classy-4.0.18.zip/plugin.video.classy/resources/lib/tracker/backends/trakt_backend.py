# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file trakt_backend.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Trakt tracker backend  -  thin wrappers over resources.lib.trakt.*.'''

from ...progress import slots as progress_slots
from ...trakt import auth
from ...trakt import calendar_lists
from ...trakt import scrobble
from ...trakt import watched_actions

name = 'trakt'
display_label = 'Trakt'


def live():
    return bool(auth.has_credentials())


def supports_collection():
    return True


def supports_watchlist():
    return True


def supports_progress():
    return True


def supports_calendars():
    return True


def scrobble_session(session, current_sec, total_sec, action):
    return scrobble.scrobble_session(session, current_sec, total_sec, action)


def scrobble_start(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'start')


def scrobble_pause(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'pause')


def scrobble_stop(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'stop')


def playback_items(mediatype, *, force=False):
    '''Trakt /sync/playback rows for the resume scan.'''
    from ...trakt import sync
    if force:
        sync.invalidate_playback_caches()
    mt = (mediatype or '').lower()
    if mt == 'episode':
        return sync.get_playback_episodes_extended(log_label='resume')
    if mt == 'movie':
        return sync.get_playback_movies_extended(log_label='resume')
    return []


def clear_resume(request_or_meta):
    '''Delete the Trakt playback row for this request and drop caches.'''
    from ...playback import resume as playback_resume
    from ...playback import session as playback_session
    from ...trakt import sync
    info = playback_resume.lookup(request_or_meta, force=True)
    playback_id = (info or {}).get('playback_id')
    if not playback_id:
        sess = playback_session.load()
        playback_id = sess.get('playback_id') or ''
    if playback_id:
        scrobble.delete_playback(playback_id)
    sync.invalidate_playback_caches()
    playback_session.clear()
    return bool(playback_id)


def mark_watched_movie(imdb, tmdb=''):
    return watched_actions.mark_movie(imdb, tmdb, watched=True)


def mark_unwatched_movie(imdb, tmdb=''):
    return watched_actions.mark_movie(imdb, tmdb, watched=False)


def mark_watched_episode(imdb, tmdb, season, episode):
    return watched_actions.mark_episode(imdb, tmdb, season, episode, watched=True)


def mark_unwatched_episode(imdb, tmdb, season, episode):
    return watched_actions.mark_episode(imdb, tmdb, season, episode, watched=False)


def mark_watched_show(imdb, tmdb=''):
    return watched_actions.mark_show(imdb, tmdb, watched=True)


def mark_unwatched_show(imdb, tmdb=''):
    return watched_actions.mark_show(imdb, tmdb, watched=False)


def apply_playcount(params, *, mediatype):
    return watched_actions.apply_playcount(params, mediatype=mediatype)


def next_episode_sessions(**kwargs):
    '''Delegate to progress slots (Trakt watched  ->  next S/E).'''
    return progress_slots.next_episode_slots(**kwargs)


def calendar_episodes(window, **kwargs):
    '''window is a calendar preset id (calendar_today, trakthistory, ...).'''
    return calendar_lists.fetch_page(window, **kwargs)


def watching_shows():
    '''Not used by Classy menus yet  -  hook for future list routers.'''
    return []


def watchlist_items(**kwargs):
    return []

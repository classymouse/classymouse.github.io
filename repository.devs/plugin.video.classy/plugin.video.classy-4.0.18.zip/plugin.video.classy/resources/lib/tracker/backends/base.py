# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file base.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Backend protocol  -  each tracker package implements these names.

Gate dispatches via getattr(_backend(), name). New backends: implement this
surface, register in backends/__init__.py, add a settings enum value.'''

from __future__ import annotations


class TrackerBackend:
    '''Documentation / NotImplemented scaffold  -  not required to subclass.'''

    name = ''
    display_label = ''

    def live(self):
        raise NotImplementedError

    def supports_collection(self):
        raise NotImplementedError

    def supports_watchlist(self):
        raise NotImplementedError

    def supports_progress(self):
        raise NotImplementedError

    def supports_calendars(self):
        raise NotImplementedError

    def scrobble_session(self, session, current_sec, total_sec, action):
        raise NotImplementedError

    def scrobble_start(self, session, current_sec, total_sec):
        raise NotImplementedError

    def scrobble_pause(self, session, current_sec, total_sec):
        raise NotImplementedError

    def scrobble_stop(self, session, current_sec, total_sec):
        raise NotImplementedError

    def playback_items(self, mediatype, *, force=False):
        '''Resume playback rows (Trakt-shaped) for mediatype movie|episode.'''
        raise NotImplementedError

    def clear_resume(self, request_or_meta):
        '''Clear the active resume point for a PlayRequest (server + local).'''
        raise NotImplementedError

    def mark_watched_movie(self, imdb, tmdb=''):
        raise NotImplementedError

    def mark_unwatched_movie(self, imdb, tmdb=''):
        raise NotImplementedError

    def mark_watched_episode(self, imdb, tmdb, season, episode):
        raise NotImplementedError

    def mark_unwatched_episode(self, imdb, tmdb, season, episode):
        raise NotImplementedError

    def mark_watched_show(self, imdb, tmdb=''):
        raise NotImplementedError

    def mark_unwatched_show(self, imdb, tmdb=''):
        raise NotImplementedError

    def apply_playcount(self, params, *, mediatype):
        raise NotImplementedError

    def next_episode_sessions(self, **kwargs):
        raise NotImplementedError

    def calendar_episodes(self, window, **kwargs):
        raise NotImplementedError

    def watching_shows(self):
        raise NotImplementedError

    def watchlist_items(self, **kwargs):
        raise NotImplementedError

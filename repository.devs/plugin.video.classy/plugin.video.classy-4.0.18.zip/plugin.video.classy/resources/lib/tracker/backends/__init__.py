# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Backend registry  -  name  ->  module. Add future trackers here.'''

from . import simkl_backend
from . import trakt_backend
from . import wetrakr_backend

REGISTRY = {
    trakt_backend.name: trakt_backend,
    simkl_backend.name: simkl_backend,
    wetrakr_backend.name: wetrakr_backend,
}

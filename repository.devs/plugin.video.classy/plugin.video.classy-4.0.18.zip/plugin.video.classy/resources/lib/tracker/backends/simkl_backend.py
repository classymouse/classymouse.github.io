# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file simkl_backend.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Simkl tracker backend  -  thin wrappers over resources.lib.simkl.*.'''

from ...progress import slots as progress_slots
from ...simkl import auth
from ...simkl import calendars as simkl_calendars
from ...simkl import lists as simkl_lists
from ...simkl import scrobble
from ...simkl import watched_actions

name = 'simkl'
display_label = 'Simkl'


def live():
    return bool(auth.has_credentials())


def supports_collection():
    return False


def supports_watchlist():
    return True


def supports_progress():
    return True


def supports_calendars():
    return True


def scrobble_session(session, current_sec, total_sec, action):
    return scrobble.scrobble_session(session, current_sec, total_sec, action)


def scrobble_start(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'start')


def scrobble_pause(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'pause')


def scrobble_stop(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'stop')


def playback_items(mediatype, *, force=False):
    '''Simkl playback rows for the resume scan.'''
    from ...simkl import progress as simkl_progress
    from ...simkl import sync as simkl_sync
    if force:
        simkl_sync.invalidate()
    mt = (mediatype or '').lower()
    if mt == 'episode':
        return simkl_progress.episode_playback_items()
    if mt == 'movie':
        return simkl_progress.movie_playback_items()
    return []


def clear_resume(request_or_meta):
    '''Delete the Simkl playback session for this request and drop caches.'''
    from ...playback import session as playback_session
    from ...simkl import scrobble as simkl_scrobble
    from ...simkl import sync as simkl_sync
    mediatype = 'episode' if getattr(request_or_meta, 'is_episode', False) else 'movie'
    removed = simkl_scrobble.clear_playback_session(
        mediatype,
        imdb=getattr(request_or_meta, 'imdb', '') or '',
        tmdb=getattr(request_or_meta, 'tmdb', '') or '',
        season=getattr(request_or_meta, 'season', 0) or 0,
        episode=getattr(request_or_meta, 'episode', 0) or 0,
    )
    simkl_sync.invalidate()
    playback_session.clear()
    return bool(removed)


def mark_watched_movie(imdb, tmdb=''):
    return watched_actions.mark_movie(imdb, tmdb, watched=True)


def mark_unwatched_movie(imdb, tmdb=''):
    return watched_actions.mark_movie(imdb, tmdb, watched=False)


def mark_watched_episode(imdb, tmdb, season, episode):
    ok, _detail = watched_actions.mark_episode(imdb, tmdb, season, episode, watched=True)
    return ok


def mark_unwatched_episode(imdb, tmdb, season, episode):
    ok, _detail = watched_actions.mark_episode(imdb, tmdb, season, episode, watched=False)
    return ok


def mark_watched_show(imdb, tmdb=''):
    return watched_actions.mark_show(imdb, tmdb, watched=True)


def mark_unwatched_show(imdb, tmdb=''):
    return watched_actions.mark_show(imdb, tmdb, watched=False)


def apply_playcount(params, *, mediatype):
    return watched_actions.apply_playcount(params, mediatype=mediatype)


def next_episode_sessions(**kwargs):
    return progress_slots.next_episode_slots(**kwargs)


def calendar_episodes(window, **kwargs):
    return simkl_calendars.fetch_page(window, **kwargs)


def watching_shows():
    return simkl_lists.show_items('watching')


def watchlist_items(**kwargs):
    media = (kwargs.get('media') or kwargs.get('mediatype') or 'movie').lower()
    if media in ('tv', 'show', 'shows', 'tvshow'):
        return simkl_lists.show_items('plantowatch')
    return simkl_lists.movie_items('plantowatch')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file wetrakr_backend.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

WeTrakr tracker backend  -  thin wrappers over resources.lib.wetrakr.*.

XOR watch tracker (option 2). Playback scrobbles via /scrobble/* here; the
apis.wetrakr sidecar suppresses itself when WeTrakr is the home tracker.'''

from ...modules.classy import c
from ...progress import slots as progress_slots
from ...wetrakr import auth
from ...wetrakr import calendars as wetrakr_calendars
from ...wetrakr import lists as wetrakr_lists
from ...wetrakr import progress as wetrakr_progress
from ...wetrakr import scrobble
from ...wetrakr import sync as wetrakr_sync
from ...wetrakr import watched_actions

name = 'wetrakr'
display_label = 'WeTrakr'


def live():
    return bool(auth.live())


def supports_collection():
    return False


def supports_watchlist():
    return True


def supports_progress():
    return True


def supports_calendars():
    return True


def scrobble_session(session, current_sec, total_sec, action):
    return scrobble.scrobble_session(session, current_sec, total_sec, action)


def scrobble_start(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'start')


def scrobble_pause(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'pause')


def scrobble_stop(session, current_sec, total_sec):
    return scrobble_session(session, current_sec, total_sec, 'stop')


def playback_items(mediatype, *, force=False):
    '''WeTrakr playing rows for the resume scan.'''
    if force:
        wetrakr_sync.invalidate()
    mt = (mediatype or '').lower()
    if mt == 'episode':
        return wetrakr_progress.episode_playback_items()
    if mt == 'movie':
        return wetrakr_progress.movie_playback_items()
    return []


def clear_resume(request_or_meta):
    '''Clear WeTrakr playing / resume for this title (DELETE /scrobble/playing).

    Matches Red Light clear_progress: cancel the playing session for the
    episode/movie identity. tracking/remove would delete a logged play  -  do
    not use that for Clear Resume Point.'''
    from ...apis import wetrakr as api
    from ...playback import session as playback_session

    mediatype = 'episode' if getattr(request_or_meta, 'is_episode', False) else 'movie'
    tmdb = getattr(request_or_meta, 'tmdb', '') or ''
    imdb = getattr(request_or_meta, 'imdb', '') or ''
    season = getattr(request_or_meta, 'season', 0) or 0
    episode = getattr(request_or_meta, 'episode', 0) or 0
    title = (
        getattr(request_or_meta, 'tvshowtitle', '')
        or getattr(request_or_meta, 'title', '')
        or ''
    )
    year = getattr(request_or_meta, 'year', '') or ''
    if not tmdb and not imdb:
        wetrakr_sync.invalidate()
        playback_session.clear()
        return False

    ok = api.cancel_playing(
        media_type=mediatype,
        tmdb_id=tmdb,
        season=season if mediatype == 'episode' else None,
        episode=episode if mediatype == 'episode' else None,
        title=title,
        year=year,
    )
    # Soft: clear playing/lists only  -  keep watched overlays (A1e).
    wetrakr_sync.invalidate_tracking()
    try:
        wetrakr_progress.invalidate_next_episodes()
    except Exception:
        pass
    playback_session.clear()
    if ok:
        try:
            from ...progress.widget_signals import notify_progress_changed
            notify_progress_changed('wetrakr_clear_resume')
        except Exception:
            pass
        if mediatype == 'episode':
            c.log(
                f'[WeTrakr] clear_resume S{int(season):02d}E{int(episode):02d} '
                f'tmdb={tmdb}',
            )
        else:
            c.log(f'[WeTrakr] clear_resume movie tmdb={tmdb}')
    return bool(ok)


def mark_watched_movie(imdb, tmdb=''):
    return watched_actions.mark_movie(imdb, tmdb, watched=True)


def mark_unwatched_movie(imdb, tmdb=''):
    return watched_actions.mark_movie(imdb, tmdb, watched=False)


def mark_watched_episode(imdb, tmdb, season, episode):
    ok, _detail = watched_actions.mark_episode(imdb, tmdb, season, episode, watched=True)
    return ok


def mark_unwatched_episode(imdb, tmdb, season, episode):
    ok, _detail = watched_actions.mark_episode(imdb, tmdb, season, episode, watched=False)
    return ok


def mark_watched_show(imdb, tmdb=''):
    return watched_actions.mark_show(imdb, tmdb, watched=True)


def mark_unwatched_show(imdb, tmdb=''):
    return watched_actions.mark_show(imdb, tmdb, watched=False)


def apply_playcount(params, *, mediatype):
    return watched_actions.apply_playcount(params, mediatype=mediatype)


def next_episode_sessions(**kwargs):
    return progress_slots.next_episode_slots(**kwargs)


def calendar_episodes(window, **kwargs):
    return wetrakr_calendars.fetch_page(window, **kwargs)


def watching_shows():
    return wetrakr_progress.watching_show_items()


def watchlist_items(**kwargs):
    media = (kwargs.get('media') or kwargs.get('mediatype') or 'movie').lower()
    if media in ('tv', 'show', 'shows', 'tvshow'):
        return wetrakr_lists.show_items('planning')
    return wetrakr_lists.movie_items('planning')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Public tracker gate  -  re-export for `from resources.lib import tracker`.'''

from .gate import (
    TRACKER_SIMKL,
    TRACKER_TRAKT,
    TRACKER_WETRAKR,
    active_name,
    active_service,
    apply_playcount,
    calendar_episodes,
    clear_resume,
    display_label,
    is_simkl,
    is_trakt,
    is_wetrakr,
    live,
    mark_unwatched_episode,
    mark_unwatched_movie,
    mark_unwatched_show,
    mark_watched_episode,
    mark_watched_movie,
    mark_watched_show,
    next_episode_sessions,
    playback_items,
    scrobble_pause,
    scrobble_session,
    scrobble_start,
    scrobble_stop,
    simkl_live,
    supports_calendars,
    supports_collection,
    supports_progress,
    supports_watchlist,
    trakt_live,
    watching_shows,
    watchlist_items,
    watchlist_status_for_active,
    wetrakr_live,
)
from .types import (
    NAME_SIMKL,
    NAME_TRAKT,
    NAME_WETRAKR,
    SIMKL_STATUS_COMPLETED,
    SIMKL_STATUS_DROPPED,
    SIMKL_STATUS_HOLD,
    SIMKL_STATUS_PLANTOWATCH,
    SIMKL_STATUS_WATCHING,
)

__all__ = [
    'TRACKER_SIMKL',
    'TRACKER_TRAKT',
    'TRACKER_WETRAKR',
    'NAME_SIMKL',
    'NAME_TRAKT',
    'NAME_WETRAKR',
    'SIMKL_STATUS_COMPLETED',
    'SIMKL_STATUS_DROPPED',
    'SIMKL_STATUS_HOLD',
    'SIMKL_STATUS_PLANTOWATCH',
    'SIMKL_STATUS_WATCHING',
    'active_name',
    'active_service',
    'apply_playcount',
    'calendar_episodes',
    'clear_resume',
    'display_label',
    'is_simkl',
    'is_trakt',
    'is_wetrakr',
    'live',
    'mark_unwatched_episode',
    'mark_unwatched_movie',
    'mark_unwatched_show',
    'mark_watched_episode',
    'mark_watched_movie',
    'mark_watched_show',
    'next_episode_sessions',
    'playback_items',
    'scrobble_pause',
    'scrobble_session',
    'scrobble_start',
    'scrobble_stop',
    'simkl_live',
    'supports_calendars',
    'supports_collection',
    'supports_progress',
    'supports_watchlist',
    'trakt_live',
    'watching_shows',
    'watchlist_items',
    'watchlist_status_for_active',
    'wetrakr_live',
]

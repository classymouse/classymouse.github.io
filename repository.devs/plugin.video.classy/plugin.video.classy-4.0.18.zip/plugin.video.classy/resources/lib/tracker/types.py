# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file types.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Tracker constants  -  XOR service ids and capability names.'''

# Setting enum values (tracker.service)  -  Trakt=0, Simkl=1, WeTrakr=2. No "both".
TRACKER_TRAKT = 0
TRACKER_SIMKL = 1
TRACKER_WETRAKR = 2

NAME_TRAKT = 'trakt'
NAME_SIMKL = 'simkl'
NAME_WETRAKR = 'wetrakr'

# Simkl library status buckets (no Trakt-style collection)
SIMKL_STATUS_WATCHING = 'watching'
SIMKL_STATUS_PLANTOWATCH = 'plantowatch'
SIMKL_STATUS_HOLD = 'hold'
SIMKL_STATUS_DROPPED = 'dropped'
SIMKL_STATUS_COMPLETED = 'completed'

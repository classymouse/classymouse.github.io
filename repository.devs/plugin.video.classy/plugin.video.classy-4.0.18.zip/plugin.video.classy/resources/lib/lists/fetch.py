# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file fetch.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

The Crew 3.x sometimes bundled local XML because randomagent() sent legacy MSIE
strings that some hosts reject (403). Classy uses current browser UAs and retries
once on 403  -  remote feeds stay fresh without shipping XML in-addon.

Fetch remote list XML  -  remote-first, modern User-Agent.'''

import os

import xbmcvfs

from ..modules import client
from ..modules.classy import c
from ..modules.scraper_client import agent as browser_agent

# Retry UA if host returns 403 (legacy MSIE-style blocks, etc.).
_FALLBACK_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
)


def list_overrides_dir():
    path = os.path.join(client.addon_data_path(), 'list_overrides')
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def _override_path(url):
    '''Optional dev override: addon_data/list_overrides/<basename>.'''
    if not url or not isinstance(url, str):
        return None
    if url.startswith(('http://', 'https://')):
        name = url.rstrip('/').split('/')[-1]
        if not name.endswith('.xml'):
            name = f'{name}.xml'
        path = os.path.join(list_overrides_dir(), name)
        if os.path.isfile(path):
            return path
    return None


def _read_local(path):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as handle:
            return handle.read()
    except Exception as exc:
        c.log(f'[Lists fetch] local read failed {path}: {exc}', 1)
        return None


def _read_special(url):
    try:
        path = xbmcvfs.translatePath(url)
        if path and os.path.isfile(path):
            return _read_local(path)
    except Exception as exc:
        c.log(f'[Lists fetch] special path failed {url}: {exc}', 1)
    return None


def _http_fetch(url, user_agent=None):
    headers = {
        'User-Agent': user_agent or browser_agent(),
        'Accept': 'text/plain,text/xml,application/xml,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    try:
        parsed = url.split('/', 3)
        if len(parsed) >= 3:
            headers.setdefault('Referer', f'{parsed[0]}//{parsed[2]}/')
    except Exception:
        pass

    resp = client.fetch(url, headers=headers, timeout=45)
    if resp.ok and resp.body:
        return resp.body

    if resp.status == 403 and headers.get('User-Agent') != _FALLBACK_UA:
        c.log(f'[Lists fetch] HTTP 403 for {url[:80]}  -  retry with fallback UA')
        resp = client.fetch(url, headers={**headers, 'User-Agent': _FALLBACK_UA}, timeout=45)
        if resp.ok and resp.body:
            return resp.body

    c.log(
        f'[Lists fetch] HTTP failed url={url[:80]} status={resp.status} err={resp.error}',
        1,
    )
    return None


def fetch_list(url):
    '''
    Return list XML/text for a feed URL.

    Order: dev override (addon_data)  ->  special:// local path  ->  HTTP remote.
    '''
    url = str(url or '').strip()
    if not url:
        return None

    override = _override_path(url)
    if override:
        c.log(f'[Lists fetch] using override {override}')
        return _read_local(override)

    if url.startswith('special://'):
        return _read_special(url)

    if url.startswith(('http://', 'https://')):
        return _http_fetch(url)

    c.log(f'[Lists fetch] unsupported url scheme: {url[:80]}', 1)
    return None

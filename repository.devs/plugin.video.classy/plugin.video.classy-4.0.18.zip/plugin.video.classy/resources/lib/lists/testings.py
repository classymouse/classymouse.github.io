# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file testings.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Local testings.xml cheat  -  profile root, outside adult PIN.
Drop testings.xml into addon_data/<addon_id>/ to show a root menu row.'''

import os

from ..modules import control
from ..modules.classy import c
from .parse import parse_list

FILENAME = 'testings.xml'


def testings_path():
    return os.path.join(control.dataPath, FILENAME)


def testings_present():
    '''True when profile root has testings.xml (Crew 3.x cheat location).'''
    path = testings_path()
    try:
        if os.path.isfile(path):
            return True
    except OSError:
        pass
    try:
        _dirs, files = control.listDir(control.dataPath)
        return FILENAME in (files or [])
    except Exception:
        return False


def load_testings_items():
    '''
    Parse profile testings.xml and stamp rows for simple list play
    (content=videos  -  no scrape / tracker path).
    '''
    path = testings_path()
    if not testings_present():
        c.log(f'[Testings] missing file: {path}', 1)
        return []

    try:
        handle = control.openFile(path, 'r')
        try:
            raw = handle.read()
        finally:
            handle.close()
    except Exception as exc:
        c.log(f'[Testings] read failed: {exc}', 1)
        return []

    if isinstance(raw, bytes):
        raw = c.to_str(raw, errors='replace')
    items, _regex = parse_list(raw or '', source_url=path)
    for row in items:
        row['content'] = 'videos'
    c.log(f'[Testings] loaded {len(items)} items from {path}')
    return items

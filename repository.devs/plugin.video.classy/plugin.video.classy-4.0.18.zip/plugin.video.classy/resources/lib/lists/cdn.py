# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cdn.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

CDN module URIs  -  remote Python sources for sports / IPTV resolvers.'''

CDN_MODULES = {
    'crewstreamer': 'https://raw.githubusercontent.com/posadka/xmls2/main/crewstreamer.xml',
    'crewschedule': 'https://raw.githubusercontent.com/posadka/xmls2/main/crewschedule.xml',
    'crewreplays': 'https://raw.githubusercontent.com/posadka/xmls2/main/crewreplays.xml',
}


def cdn_uri_for(name):
    return CDN_MODULES.get(str(name or '').strip())

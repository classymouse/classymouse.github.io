# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file bridge.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Interim ecosystem bridge  -  XML/CDN list code written for Crew module layout.

TEMPORARY: remove when plugin id is plugin.video.thecrew (see 4.0-BASELINE rebrand checklist).
Permanent pieces live in lists/fetch, parse, directory, ...  -  not here.'''

from ..modules.classy import c

_INSTALLED = False


def install_lists_ecosystem_shims(force=False):
    '''
    Prepare Classy to run upstream CDN modules and XML pyFunctions.

    - Ensures pack HTTP shims (pyFunctions may import scraper clients).
    - control.py already exposes Crew-shaped APIs + interim plugin-id bridge.
    '''
    global _INSTALLED
    if _INSTALLED and not force:
        return True

    try:
        from ..modules.pack_client import install_pack_client_shims
        install_pack_client_shims()
    except Exception as exc:
        c.log(f'[Lists bridge] pack client shims failed: {exc}', 1)

    try:
        # Pin Classy client/control for remote XML pyFunctions (Crew PluginName guards).
        from .regex.engine import _ensure_lists_pyfunction_bridge
        _ensure_lists_pyfunction_bridge()
    except Exception as exc:
        c.log(f'[Lists bridge] pyFunction PluginName bridge failed: {exc}', 1)

    try:
        import requests  # noqa: F401  -  crewschedule CDN module
    except ImportError:
        c.log(
            '[Lists bridge] script.module.requests missing  -  install it for sports/replay lists',
            1,
        )

    _INSTALLED = True
    c.log('[Lists bridge] ecosystem shims active (interim until rebrand)')
    return True


def bridge_active():
    return _INSTALLED

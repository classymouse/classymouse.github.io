# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file regex_store.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

SQLite regex payload cache  -  Crew-compatible (regex.db).'''

import os
from sqlite3 import dbapi2 as database

from ..modules import control
from ..modules.classy import c

_DB_NAME = 'regex.db'


def _db_path():
    return os.path.join(control.dataPath, _DB_NAME)


def _connect():
    control.makeFile(control.dataPath)
    dbcon = database.connect(_db_path())
    dbcur = dbcon.cursor()
    dbcur.execute(
        'CREATE TABLE IF NOT EXISTS regex ('
        'regex TEXT, response TEXT, UNIQUE(regex)'
        ');'
    )
    return dbcon, dbcur


def insert(entries):
    '''Store quoted regex XML blocks keyed by md5 hash.'''
    if not entries:
        return
    try:
        dbcon, dbcur = _connect()
        for entry in entries:
            key = entry.get('regex')
            if not key:
                continue
            try:
                dbcur.execute(
                    'INSERT INTO regex VALUES (?, ?)',
                    (str(key), entry.get('response') or ''),
                )
            except Exception:
                pass
        dbcon.commit()
        dbcon.close()
    except Exception as exc:
        c.log(f'[Lists regex_store] insert error: {exc}', 1)


def fetch(regex_id):
    '''Return stored regex XML (quote_plus payload) for hash id.'''
    if not regex_id:
        return None
    try:
        dbcon, dbcur = _connect()
        dbcur.execute('SELECT response FROM regex WHERE regex = ?', (str(regex_id),))
        row = dbcur.fetchone()
        dbcon.close()
        return row[0] if row else None
    except Exception as exc:
        c.log(f'[Lists regex_store] fetch error: {exc}', 1)
        return None


def clear():
    '''Drop regex cache table (dev / troubleshooting).'''
    try:
        dbcon, dbcur = _connect()
        dbcur.execute('DROP TABLE IF EXISTS regex')
        dbcur.execute('VACUUM')
        dbcon.commit()
        dbcon.close()
    except Exception as exc:
        c.log(f'[Lists regex_store] clear error: {exc}', 1)

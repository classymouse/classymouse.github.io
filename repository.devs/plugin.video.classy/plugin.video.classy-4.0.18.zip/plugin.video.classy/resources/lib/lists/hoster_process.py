# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file hoster_process.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Crew lists.resolver.process() port  -  Greenhat / XML direct-play hosters.'''

import os
import re
from urllib.parse import quote_plus, urljoin

import xbmc
import xbmcvfs

from ..modules.classy import c
from .resolver import expand_regex_url

_RTMP_TIMEOUT = re.compile(r'\s*timeout=(\d*)')
_XML_TAG = re.compile(r'<(\w+)>(.*?)</\1>', re.DOTALL | re.IGNORECASE)


def _xml_tags(text):
    '''Extract Crew list preset/meta tags regardless of element order.'''
    return {name.lower(): value.strip() for name, value in _XML_TAG.findall(str(text or ''))}


def _parse_preset_search(url):
    tags = _xml_tags(url)
    preset = tags.get('preset', '')
    if not preset or 'search' not in preset:
        return None
    return {
        'preset': preset,
        'title': tags.get('title', ''),
        'year': tags.get('year', ''),
        'imdb': tags.get('imdb', ''),
        'tmdb': tags.get('tmdb', ''),
        'tvdb': tags.get('tvdb', ''),
        'tvshowtitle': tags.get('tvshowtitle', ''),
        'premiered': tags.get('premiered', ''),
        'season': tags.get('season', ''),
        'episode': tags.get('episode', ''),
        'content': tags.get('content', ''),
    }


def _stream_extension(url):
    try:
        return url.split('?')[0].split('&')[0].split('|')[0].rsplit('.', 1)[-1].replace('/', '').lower()
    except Exception:
        return ''


def _default_play_headers():
    try:
        import resolveurl

        return {'User-Agent': resolveurl.common.RAND_UA}
    except Exception:
        return {
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            ),
        }


def _append_pipe_headers(play_url, headers):
    text = str(play_url or '').strip()
    if not text or '|' in text:
        return text
    parts = [text]
    for key, value in headers.items():
        if value:
            parts.append(f'{key}={quote_plus(str(value))}')
    return '|'.join(parts)


def _ensure_hls_pipe_headers(play_url, source_url):
    '''tnmr/luluvdo CDNs 403 without Referer; ResolveURL sometimes returns bare m3u8.'''
    text = str(play_url or '').strip()
    lower = text.lower()
    if '|' in text or '.m3u8' not in lower:
        return text

    source = str(source_url or '').strip()
    if not source.startswith(('http://', 'https://')):
        return text

    referer = urljoin(source, '/')
    headers = _default_play_headers()
    headers['Referer'] = referer
    headers['Origin'] = referer.rstrip('/')
    patched = _append_pipe_headers(text, headers)
    c.log(f'[Lists process] injected HLS pipe headers for {source[:80]}')
    return patched


def _try_resolveurl(url):
    try:
        import resolveurl

        xxx_plugins_path = 'special://home/addons/script.module.resolveurl.xxx/resources/plugins/'
        translated_path = xbmcvfs.translatePath(xxx_plugins_path)
        if xbmcvfs.exists(translated_path):
            resolveurl.add_plugin_dirs(translated_path)

        hmf = resolveurl.HostedMediaFile(url=url)
        if hmf.valid_url():
            resolved = hmf.resolve()
            if isinstance(resolved, dict):
                resolved = resolved.get('url') or ''
            if resolved:
                resolved = _ensure_hls_pipe_headers(str(resolved).strip(), url)
                c.log(f'[Lists process] resolveurl OK: {resolved[:120]}')
                return resolved
    except Exception as exc:
        c.log(f'[Lists process] resolveurl failed: {exc}', 1)
    return None


def _try_google(url):
    try:
        from ..modules import directstream

        result = directstream.google(url)
        if isinstance(result, list) and result:
            first = result[0]
            if isinstance(first, dict):
                return first.get('url') or first.get('link')
            return str(first)
        if isinstance(result, str) and result:
            return result
    except Exception as exc:
        c.log(f'[Lists process] google directstream failed: {exc}', 1)
    return None


def _show_image(url):
    try:
        from ..modules import client

        profile = xbmcvfs.translatePath(f'addon://{c.addon_id}/')
        image_path = os.path.join(profile, 'list_preview.jpg')
        if os.path.exists(image_path):
            os.remove(image_path)
        payload = client.request(url)
        if not payload:
            return False
        with open(image_path, 'wb') as handle:
            if isinstance(payload, str):
                handle.write(payload.encode('utf-8', errors='replace'))
            else:
                handle.write(payload)
        xbmc.executebuiltin(f'ShowPicture("{image_path}")')
        return False
    except Exception as exc:
        c.log(f'[Lists process] image preview failed: {exc}', 1)
        return False


def _play_preset_search(url):
    data = _parse_preset_search(url)
    if not data:
        return None

    from ..play.metadata import enrich_request
    from ..play.models import PlayRequest
    from ..play.picker import pick_stream
    from ..sources.orchestrator import scrape_streams
    from ..sources.quality_tiers import quality_tier

    season = data.get('season') or ''
    episode = data.get('episode') or ''
    content = (data.get('content') or '').strip().lower()
    if season or episode:
        mediatype = 'episode'
    elif content in ('movie', 'movies'):
        mediatype = 'movie'
    elif content in ('tvshow', 'tvshows', 'episode', 'episodes'):
        mediatype = 'episode' if season or episode else 'movie'
    else:
        mediatype = 'episode' if data.get('tvshowtitle') else 'movie'

    imdb = (data.get('imdb') or '').strip()
    if imdb and not imdb.startswith('tt'):
        imdb = f'tt{imdb}'

    request = PlayRequest(
        mediatype=mediatype,
        title=(data.get('title') or '').strip(),
        year=(data.get('year') or '').strip(),
        imdb=imdb,
        tmdb=(data.get('tmdb') or '').strip(),
        tvdb=(data.get('tvdb') or '').strip(),
        season=season,
        episode=episode,
        tvshowtitle=(data.get('tvshowtitle') or '').strip(),
        premiered=(data.get('premiered') or '').strip(),
    )
    enrich_request(request)
    if not request.title and not request.tvshowtitle:
        c.log('[Lists process] preset search missing title metadata', 1)
        return None

    c.log(
        f'[Lists process] preset search scrape: {request.display_title!r} '
        f'preset={data.get("preset")!r} imdb={request.imdb!r}',
    )
    candidates, cancelled = scrape_streams(request)
    if cancelled or not candidates:
        return None

    if data.get('preset') == 'searchsd':
        sd_candidates = [row for row in candidates if quality_tier(row.quality) >= 4]
        if sd_candidates:
            candidates = sd_candidates

    chosen, start = pick_stream(candidates, heading=request.display_title)
    if not chosen:
        return None

    from ..play.smart_resolve import resolve_stream_queue

    play_url, _winner = resolve_stream_queue(
        candidates, start, request, primary=chosen,
    )
    if not play_url:
        return None

    c.log(f'[Lists process] preset search resolved url={play_url[:120]}')
    return play_url


def process_list_play_url(url):
    '''
    Second resolver pass after sublink pick (Crew resolver.process).

    Returns a playable URL string, None on failure, or False when handled without
    playback (image preview / plugin handoff).
    '''
    if url is None:
        return None

    text = str(url).strip()
    if not text:
        return None

    if text.startswith('plugin://'):
        xbmc.executebuiltin(f'RunPlugin({text})')
        return False

    if any(token in text for token in ('.jpg', '.png', '.gif')):
        ext = _stream_extension(text)
        if ext in ('jpg', 'png', 'gif'):
            _show_image(text)
            return False

    if '|regex=' in text or '$doregex' in text:
        expanded = expand_regex_url(text)
        if expanded:
            text = str(expanded).strip()

    if '<preset>' in text and 'search' in text:
        preset_url = _play_preset_search(text)
        if preset_url:
            return preset_url

    if text.startswith('rtmp'):
        if not _RTMP_TIMEOUT.search(text):
            text += ' timeout=10'
        return text

    if any(token in text for token in ('.m3u8', '.f4m', '.ts')):
        ext = _stream_extension(text)
        if ext in ('m3u8', 'f4m', 'ts'):
            return text

    if '.google.com' in text:
        google_url = _try_google(text)
        if google_url:
            return google_url

    resolved = _try_resolveurl(text)
    if resolved:
        return resolved

    if text.startswith(('http://', 'https://', 'rtmp')):
        return text

    return None

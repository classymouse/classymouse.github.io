# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resolver.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Minimal regex URL expansion for xdirectory (full regex engine later).'''

import re
from urllib.parse import unquote_plus

from ..modules.classy import c
from . import regex_store
from .regex import resolve as regex_resolve

_REGEX_SUFFIX = re.compile(r'(.+?)\|regex=(.+?)$')
_NAME_TAG = re.compile(r'<name>([^<]+)</name>')


def _prepend_doregex(combined):
    '''Add $doregex[name] only for get_x_url-style bodies (Crew getx keeps existing prefix).'''
    head = combined.split('<regex>', 1)[0]
    if '$doregex[' in head:
        return combined
    try:
        name = _NAME_TAG.findall(combined)[0]
        return f'$doregex[{name}]' + combined
    except (IndexError, TypeError):
        return combined


def _run_regex_resolve(body):
    if not body:
        return ''
    try:
        resolved = regex_resolve(body)
        if resolved:
            text = str(resolved)
            c.log(f'[Lists resolver] regex resolved len={len(text)}')
            return text
    except Exception as exc:
        c.log(f'[Lists resolver] regex resolve failed: {exc}', 1)
    return ''


def expand_regex_url(url):
    '''
    Expand base_url|regex=hash, then execute $doregex chain.

    Returns resolved URL/XML string, or original url when no regex suffix.
    '''
    text = str(url or '').strip()
    if not text:
        return ''

    # listrepeat output from makelist  -  nested $doregex[makelist2] is for play clicks
    if '<item>' in text:
        return text

    match = _REGEX_SUFFIX.search(text)
    if not match:
        if '$doregex' in text or '</regex>' in text:
            return _run_regex_resolve(text) or text
        return text

    base, regex_id = match.group(1), match.group(2)
    payload = regex_store.fetch(regex_id)
    if not payload:
        c.log(f'[Lists resolver] missing regex payload id={regex_id!r}', 1)
        return base

    combined = base + unquote_plus(payload)
    c.log(f'[Lists resolver] expanded regex payload len={len(combined)}')
    combined = _prepend_doregex(combined)
    resolved = _run_regex_resolve(combined)
    if resolved:
        return resolved
    if '$doregex[' in combined or '</regex>' in combined:
        c.log('[Lists resolver] regex chain unresolved after resolve()', 1)
        return ''
    return combined


def payload_for_fetch(resolved):
    '''Return (fetch_url, inline_body)  -  inline when resolved text is XML, not HTTP.'''
    text = str(resolved or '').strip()
    if not text:
        return '', ''

    if text.startswith('$doregex'):
        c.log(f'[Lists resolver] unresolved $doregex url: {text[:80]}', 1)
        return '', ''

    if text.startswith(('http://', 'https://')):
        return text, ''

    if text.startswith('<?xml') or '<item>' in text or '<dir>' in text:
        return '', text

    return text, ''

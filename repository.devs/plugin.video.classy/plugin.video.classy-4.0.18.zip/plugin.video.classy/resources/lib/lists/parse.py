# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file parse.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Parse Crew-style list XML into row dicts (the_crew_list format).'''

import base64
import gzip
import hashlib
import html
import io
import re
import zipfile
from urllib.parse import quote_plus

from ..modules.classy import c
from . import regex_store

_ITEM_PATTERN = re.compile(
    r'((?:<item>.+?</item>|<dir>.+?</dir>|<plugin>.+?</plugin>|<info>.+?</info>|'
    r'<name>[^<]+</name><link>[^<]+</link><thumbnail>[^<]+</thumbnail><mode>[^<]+</mode>|'
    r'<name>[^<]+</name><link>[^<]+</link><thumbnail>[^<]+</thumbnail><date>[^<]+</date>))',
    re.MULTILINE | re.DOTALL,
)
_REGEX_BLOCK = re.compile(r'<regex>.+?</regex>', re.DOTALL)
_SUBLINK_EMPTY = re.compile(
    r'<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>|<sublink></sublink>',
    re.DOTALL,
)
_LINK_EMPTY = re.compile(r'<link></link>', re.DOTALL)
_M3U_INF = re.compile(r'#EXTINF:.+?,(.+?)\n(.+?)\n', re.MULTILINE | re.DOTALL)


_CDATA_WRAP = re.compile(r'^<!\[CDATA\[(.*)\]\]>$', re.DOTALL)


def _clean_link_value(link):
    '''Strip CDATA wrapper and XML entities from list link text.'''
    if not link or link == '0':
        return link
    text = html.unescape(str(link).strip())
    match = _CDATA_WRAP.match(text)
    if match:
        return match.group(1).strip()
    if text.startswith('<![CDATA['):
        text = text[9:]
        if text.endswith(']]>'):
            text = text[:-3]
        return text.strip()
    return text


def _extract_tag(content, tag, default='0'):
    try:
        return re.findall(rf'<{tag}>(.+?)</{tag}>', content)[0]
    except (IndexError, TypeError):
        return default


def _normalize_payload(raw):
    text = str(raw or '')
    if not text.strip():
        return ''

    if text.strip().startswith('#EXTM3U') and '#EXTINF' in text:
        try:
            chunks = _M3U_INF.findall(text)
            return ''.join(
                f'<item><title>{title}</title><link>{link}</link></item>'
                for title, link in chunks
            )
        except ValueError:
            pass

    decoded = _try_base64_or_compress(text)
    if decoded and '</link>' in decoded:
        return decoded
    if '<item>' in text or '<dir>' in text or '<plugin>' in text:
        return text
    return decoded or text


def _try_base64_or_compress(text):
    try:
        clean = re.sub(r'[^A-Za-z0-9+/=]', '', text)
        if not clean:
            raise ValueError('no base64')
        raw = base64.b64decode(clean)
        out = c.to_str(raw, errors='replace')
        if out.strip():
            return out
    except Exception:
        pass

    try:
        blob = text.encode('latin-1', errors='ignore')
        if blob.startswith(b'\x1f\x8b'):
            return c.to_str(gzip.decompress(blob), errors='replace')
        if blob.startswith(b'PK'):
            with zipfile.ZipFile(io.BytesIO(blob)) as zf:
                names = zf.namelist()
                if names:
                    return c.to_str(zf.read(names[0]), errors='replace')
    except Exception:
        pass
    return ''


def parse_list(raw, source_url=''):
    '''
    Parse list XML/text into row dicts compatible with Crew list items.

    Returns (items, regex_entries) where regex_entries feed regex_store.insert().
    '''
    del source_url
    items = []
    regex_entries = []

    try:
        payload = _normalize_payload(raw)
        if not payload:
            return items, regex_entries

        header = re.split(r'<item>|<dir>', payload)[0]
        default_thumb = _extract_tag(header, 'thumbnail')
        default_fanart = _extract_tag(header, 'fanart')
        default_vip = _extract_tag(header, 'poster')

        for block in _ITEM_PATTERN.findall(payload):
            reg_blocks = re.findall(r'(<regex>.+?</regex>)', block, re.MULTILINE | re.DOTALL)
            regdata = ''.join(reg_blocks)
            reglist = re.findall(r'(<listrepeat>.+?</listrepeat>)', regdata, re.MULTILINE | re.DOTALL)
            regdata_q = quote_plus(regdata)
            reghash = hashlib.md5(regdata_q.encode('utf-8')).hexdigest() if regdata_q else ''

            block = block.replace('\r', '').replace('\n', '').replace('\t', '').replace('&nbsp;', '')
            block = _REGEX_BLOCK.sub('', block)
            block = _SUBLINK_EMPTY.sub('', block)
            block = _LINK_EMPTY.sub('', block)

            name_block = re.sub(r'<meta>.+?</meta>', '', block, flags=re.DOTALL)
            name = _extract_tag(name_block, 'title')
            if name == '0':
                name = _extract_tag(name_block, 'name')

            date = _extract_tag(block, 'date', '')
            if date and re.search(r'\d+', date):
                name = f'{name} [COLOR red] Updated {date}[/COLOR]'

            poster = _extract_tag(block, 'thumbnail', default_thumb)
            fanart = _extract_tag(block, 'fanart', default_fanart)
            meta = _extract_tag(block, 'meta')
            link = _extract_tag(block, 'link')
            if link and link != '0':
                link = _clean_link_value(link)

            link = link.replace('>search<', f'><preset>search</preset>{meta}<')
            if link == 'search':
                link = f'<preset>search</preset>{meta}'
            link = link.replace('>searchsd<', f'><preset>searchsd</preset>{meta}<')
            if link == 'searchsd':
                link = f'<preset>searchsd</preset>{meta}'
            link = _SUBLINK_EMPTY.sub('', link)

            if regdata:
                regex_entries.append({'regex': reghash, 'response': regdata_q})
                link = f'{link}|regex={reghash}'

            tag = block.lstrip()
            if tag.startswith('<item'):
                action = 'play'
            elif tag.startswith('<plugin'):
                action = 'plugin'
            elif tag.startswith('<info>') or link == '0':
                action = '0'
            else:
                action = 'directory'

            if action == 'play' and reglist:
                action = 'xdirectory'

            folder = action in ('directory', 'xdirectory', 'plugin')

            content = _extract_tag(meta, 'content')
            if content == '0':
                content = _extract_tag(block, 'content')

            imdb = _extract_tag(meta, 'imdb')
            tvdb = _extract_tag(meta, 'tvdb')
            tvshowtitle = _extract_tag(meta, 'tvshowtitle')
            title = _extract_tag(meta, 'title')
            season = _extract_tag(meta, 'season')
            episode = _extract_tag(meta, 'episode')

            if content == '0':
                if tvdb != '0' or tvshowtitle != '0' or (season != '0' and episode != '0'):
                    content = 'tvshow'
                elif imdb != '0':
                    content = 'movie'

            if content != '0' and not content.endswith('s'):
                content = f'{content}s'

            if 'tvshow' in content and not link.strip().endswith('.xml'):
                link = (
                    f'<preset>tvindexer</preset><url>{link}</url>'
                    f'<thumbnail>{poster}</thumbnail><fanart>{fanart}</fanart>{meta}'
                )
                action = 'tvtuner'

            if 'tvtuner' in content and not link.strip().endswith('.xml'):
                link = (
                    f'<preset>tvtuner</preset><url>{link}</url>'
                    f'<thumbnail>{poster}</thumbnail><fanart>{fanart}</fanart>{meta}'
                )
                action = 'tvtuner'

            if title == '0' and tvshowtitle != '0':
                title = tvshowtitle

            if action == '0':
                continue

            items.append({
                'name': name,
                'vip': default_vip,
                'url': link,
                'action': action,
                'folder': folder,
                'poster': poster,
                'banner': '0',
                'fanart': fanart,
                'content': content,
                'imdb': imdb,
                'tvdb': tvdb,
                'tmdb': '0',
                'title': title,
                'originaltitle': title,
                'tvshowtitle': tvshowtitle,
                'year': _extract_tag(meta, 'year'),
                'premiered': _extract_tag(meta, 'premiered'),
                'season': season,
                'episode': episode,
            })

        if regex_entries:
            regex_store.insert(regex_entries)

        c.log(f'[Lists parse] {len(items)} items, {len(regex_entries)} regex blocks')
        return items, regex_entries

    except Exception as exc:
        c.log(f'[Lists parse] error: {exc}', 1)
        return [], []

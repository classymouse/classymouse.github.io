# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file directory.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Render parsed list rows as a Kodi plugin directory.'''

import os
import re
import sys
from urllib.parse import quote_plus, urlparse

import xbmcvfs

from ..modules import kodi
from ..modules.classy import c
from ..kodi import listing
from .play import decorate_schedule_label, is_upcoming_schedule_row

_SYSADDON = sys.argv[0]

# White XML thumbs often hardcode script.thecrew.artwork. Prefer Classy in-addon
# artwork so Classy-only installs (and theme switches) still get sport icons.
_ARTWORK_MEDIA = re.compile(
    r'special://home/addons/script\.thecrew\.artwork/resources/media/[^/]+/([^"\'<\s]+)',
    re.I,
)
_ARTWORK_FANART = re.compile(
    r'special://home/addons/script\.thecrew\.artwork/resources/fanart/([^"\'<\s]+)',
    re.I,
)
_SEARCH_LABEL = re.compile(r'\bSEARCH\b', re.I)
# White replays.xml: AEW has aew.png; IMPACT/ROH/INDY/NJPW/PPV/TRENDING often have no thumb.
_REPLAYS_LABEL = re.compile(
    r'\bREPLAYS?\b|\bSCRAPER\b|\bTRENDING WRESTLING\b',
    re.I,
)
# White fullsites.xml: many FULL SITE LIVE rows ship with no thumbnail.
_LIVE_LABEL = re.compile(
    r'\bFULL SITE LIVE\b|\bFULL LIVE\b',
    re.I,
)


def _clean_url_title(name):
    if not name or not isinstance(name, str):
        return name
    if not (name.startswith('http://') or name.startswith('https://')):
        return name
    try:
        path = urlparse(name).path.strip('/').split('/')
        slug = path[-1].split('#')[0].split('?')[0] if path else ''
        cleaned = slug.replace('-', ' ').replace('_', ' ').title()
        return cleaned or name
    except Exception:
        return name


def _local_art_file(filename):
    name = str(filename or '').strip().lstrip('/')
    if not name:
        return ''
    try:
        art_root = c.get_art_path()
    except Exception:
        return ''
    candidate = os.path.join(art_root, name)
    if xbmcvfs.exists(candidate) or os.path.isfile(candidate):
        return candidate
    # Theme fallbacks when active appearance is missing the PNG.
    try:
        base = os.path.join(c.path, 'resources', 'lib', 'artwork')
    except Exception:
        return ''
    for theme in ('thecrew', 'modern'):
        path = os.path.join(base, theme, name)
        if xbmcvfs.exists(path) or os.path.isfile(path):
            return path
    return ''


def _rewrite_list_art(value):
    text = str(value or '').strip()
    if not text or text in ('0',):
        return ''
    norm = text.replace('\\', '/')
    match = _ARTWORK_MEDIA.search(norm)
    if match:
        local = _local_art_file(match.group(1))
        if local:
            return local
    match = _ARTWORK_FANART.search(norm)
    if match:
        # Fanart pack lives on script.thecrew.artwork; keep remote path if present.
        return text
    return text


def _poster_url(value, fallback, *, label=''):
    rewritten = _rewrite_list_art(value)
    # Ignore listrepeat placeholders that leaked into parsed thumbs.
    if rewritten and '[makelist.' in rewritten.lower():
        rewritten = ''
    if rewritten:
        return rewritten
    text = str(label or '')
    if text and _SEARCH_LABEL.search(text):
        search_icon = _local_art_file('search.png')
        if search_icon:
            return search_icon
    if text and _REPLAYS_LABEL.search(text):
        replays_icon = _local_art_file('replays.png')
        if replays_icon:
            return replays_icon
    if text and _LIVE_LABEL.search(text):
        live_icon = _local_art_file('live.png')
        if live_icon:
            return live_icon
    return fallback


def _build_item_url(row):
    action = row.get('action') or 'directory'
    if action == 'plugin':
        return row.get('url') or ''

    url = f'{_SYSADDON}?action={action}'
    payload = row.get('url') or ''
    if payload:
        url += f'&url={quote_plus(str(payload))}'
    content = row.get('content') or 'addons'
    if content and content != '0':
        url += f'&content={quote_plus(str(content))}'
    return url


def _content_type(items):
    for row in items:
        key = row.get('content')
        if key:
            return key
    return 'addons'


def _mode_for_content(content_type):
    return {
        'movies': 'movies',
        'tvshows': 'tvshows',
        'seasons': 'seasons',
        'episodes': 'episodes',
        'videos': 'videos',
    }.get(content_type, 'addons')


def _empty_placeholder(handle):
    label = c.lang(32500) if hasattr(c, 'lang') else 'No results found'
    if not label or label == 32500:
        label = 'No results found'
    display = f'[COLOR gray]{label}[/COLOR]'
    li = kodi.item(label=display)
    icon = c.addon_icon()
    li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
    kodi.addItem(handle=handle, url='', listitem=li, isFolder=False)


def _decorate_schedule_label(name):
    '''Prefix embedhd-style scheduled rows with a red UPCOMING badge.'''
    if not name or not is_upcoming_schedule_row(name):
        return name
    if '[COLOR red]UPCOMING[/COLOR]' in name:
        return name
    return f'[COLOR red]UPCOMING[/COLOR] {name}'


def _is_developer_row(row):
    '''White feeds often append a Testings -> action=developer plugin row.'''
    action = str(row.get('action') or '').strip().lower()
    if action in ('developer', 'testings'):
        return True
    url = str(row.get('url') or '')
    if 'action=developer' in url or 'action=testings' in url:
        return True
    return False


def _testings_allowed():
    '''Crew parity  -  only show Testings rows when profile has testings.xml.'''
    try:
        from .testings import testings_present
        return testings_present()
    except Exception:
        return False


def show_directory(handle, items):
    '''Add list rows to Kodi directory and end listing.'''
    ctx = listing.listing_context()
    items = listing.slice_rows(items or [], ctx)
    if not items:
        _empty_placeholder(handle)
        kodi.content(handle, 'addons')
        kodi.directory(handle, cacheToDisc=False)
        return

    icon = c.addon_icon()
    fanart = c.addon_fanart()
    content_type = _content_type(items)
    allow_testings = _testings_allowed()

    for row in items:
        if _is_developer_row(row) and not allow_testings:
            continue
        name = row.get('name') or row.get('title') or 'Item'
        name = _clean_url_title(name)
        name = decorate_schedule_label(name)

        poster = _poster_url(row.get('poster'), icon, label=name)
        item_fanart = _poster_url(row.get('fanart'), fanart or '', label='')

        li = kodi.item(label=name)
        li.setArt({
            'icon': poster,
            'thumb': poster,

            'poster': poster,
            'tvshow.poster': poster,
            'fanart': item_fanart or fanart or poster,
        })
        if item_fanart or fanart:
            li.setProperty('Fanart_Image', item_fanart or fanart)

        item_url = _build_item_url(row)
        is_folder = bool(row.get('folder', True))
        # Always mark playable rows so Kodi waits for setResolvedUrl (widgets + in-addon).
        # Without this, sys.argv[1] is -1 and we fall back to Player.play.
        if not is_folder and not is_upcoming_schedule_row(name):
            li.setProperty('IsPlayable', 'true')
        kodi.addItem(handle=handle, url=item_url, listitem=li, isFolder=is_folder)

    kodi.content(handle, _mode_for_content(content_type))
    kodi.directory(handle, cacheToDisc=True)

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file registry.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Remote list feed URLs  -  registry only (no bundled XML in the addon).

Classy policy: listings stay remote so feeds can update without a release.
Dev-only override: addon_data/.../list_overrides/<filename> (see fetch.py).'''

# Mirrors Crew lists.ROOT_URLS  -  remote sources only (no special:// bundled paths).
ROOT_URLS = {
    'greyhat': 'https://raw.githubusercontent.com/posadka/xmls2/main/kids/greyhat_main.xml',
    'greenhat': 'http://thechains24.com/GREENHAT/green.xml',
    'ncaa': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ncaa/ncaa.xml',
    'ncaab': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ncaa/ncaab.xml',
    'mlb': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/mlb/mlb.xml',
    'nfl': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nfl/nfl.xml',
    'nhl': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nhl/nhl.xml',
    'nba': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nba/nba.xml',
    'ufc': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/ufc_mma/ufc.xml',
    'motogp': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/motor/motogp.xml',
    'boxing': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/boxing/boxing.xml',
    'fifa': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/fifa/fifa.xml',
    'wwe': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/wwe/wwe.xml',
    'sports_channels': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/channels/channels.xml',
    'sreplays': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/replays/replays.xml',
    'tennis': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/tennis/tennis.xml',
    'f1': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/motor/f1.xml',
    'pga': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/pga/pga.xml',
    'purplehat': 'https://raw.githubusercontent.com/classymouse/cc/main/CCcinema.xml',
    'classy': 'https://raw.githubusercontent.com/classymouse/cc/main/main.xml',

    'nascar': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/nascar/nascar.xml',
    'misc_sports': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/misc/misc_sports.xml',
    # Crew 3.2.23+ FULL LIVE SITES (White)  -  first Sports row in navigator.
    'fullsites': 'https://raw.githubusercontent.com/posadka/xmls2/main/sports/fullsites/fullsites.xml',
}


def url_for_action(action):
    '''Map router action name to list feed URL (or None).'''
    key = str(action or '').strip().lower()
    if not key:
        return None
    return ROOT_URLS.get(key)

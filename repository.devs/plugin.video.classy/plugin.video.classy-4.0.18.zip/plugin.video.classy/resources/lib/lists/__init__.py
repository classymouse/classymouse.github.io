# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file __init__.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

XML list pipeline  -  remote feeds, CDN sports, directory + resolve.'''

from .bridge import install_lists_ecosystem_shims, bridge_active
from .cdn import CDN_MODULES, cdn_uri_for
from .directory import show_directory
from .fetch import fetch_list
from .parse import parse_list
from .registry import ROOT_URLS, url_for_action

__all__ = [
    'CDN_MODULES',
    'ROOT_URLS',
    'bridge_active',
    'cdn_uri_for',
    'fetch_list',
    'install_lists_ecosystem_shims',
    'parse_list',
    'show_directory',
    'url_for_action',
]

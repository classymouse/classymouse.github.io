# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file play.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Direct play for XML list rows (sports, IPTV)  -  no TMDB scrape.'''

import re
import sys
import html
from datetime import datetime, timedelta
from urllib.parse import quote, unquote_plus
import json

import xbmc
import xbmcgui
import xbmcplugin

from ..modules.classy import c
from .bridge import install_lists_ecosystem_shims
from .hoster_process import process_list_play_url
from .resolver import expand_regex_url

_PLAYER = xbmc.Player()
_RESOLVE_BUSY = False


class _ListsPlayerMonitor(xbmc.Player):
    '''Singleton monitor  -  close busy/play dialogs once Kodi starts playback.'''

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        super().__init__()

    def onPlayBackStarted(self):
        c.log('[Lists play] onPlayBackStarted - closing busy dialogs')
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        except Exception:
            pass


def _normalize_list_url(url):
    '''XML list links: unwrap CDATA and convert &amp;  ->  & for Kodi pipe URLs.'''
    text = html.unescape(str(url or '').strip())
    if text.startswith('<![CDATA['):
        if text.endswith(']]>'):
            text = text[9:-3].strip()
        else:
            text = text[9:].strip()
    return _normalize_pipe_separators(text)


# White / crewschedule XML often chains pipe options with & (Referer&Origin); Kodi wants |.
_PIPE_OPTION_KEYS = ('Referer', 'Origin', 'User-Agent', 'Cookie', 'Connection')


def _normalize_pipe_separators(url):
    text = str(url or '')
    pipe_idx = text.find('|')
    if pipe_idx < 0:
        return text
    base, suffix = text[:pipe_idx], text[pipe_idx + 1:]
    for key in _PIPE_OPTION_KEYS:
        suffix = re.sub(rf'&{key}=', f'|{key}=', suffix, flags=re.IGNORECASE)
    return f'{base}|{suffix}'


def _parse_pipe_url(url):
    '''
    Split url|Key=Value|Key2=Value2 into base URL, header dict, and Kodi pipe form.
    Query-string & in the base URL is left intact; only options after the first | are parsed.
    '''
    text = _normalize_pipe_separators(_normalize_list_url(url))
    if '|' not in text:
        return text, {}, text

    base, suffix = text.split('|', 1)
    headers = {}
    for part in suffix.split('|'):
        if '=' not in part:
            continue
        key, _, value = part.partition('=')
        key = key.strip()
        if key:
            headers[key] = value

    kodi_pipe = base
    if headers:
        kodi_pipe = base + '|' + '|'.join(f'{k}={v}' for k, v in headers.items())
    return base, headers, kodi_pipe


def _isa_headers_prop(headers):
    '''ISA wants url-encoded key=value pairs joined with &.'''
    parts = []
    for key, value in headers.items():
        text = unquote_plus(str(value))
        parts.append(f'{key}={quote(text, safe="")}')
    return '&'.join(parts)


def _ffmpegdirect_available():
    return bool(xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.ffmpegdirect)'))


def _kodi_amp_pipe(base, headers):
    '''DaddyLive-style pipe: url|Key=val&Key2=val2 (ffmpegdirect + Curl).'''
    if not headers:
        return base
    joined = '&'.join(f'{k}={v}' for k, v in headers.items())
    return f'{base}|{joined}'


def _apply_live_hls(listitem, base, headers, kodi_pipe):
    '''
    Sports CDN live HLS is junk (TS/media-sequence quirks). ISA stalls ~20s.
    Prefer ffmpegdirect + pipe headers (DaddyLive pattern); ISA is fallback.
    '''
    try:
        listitem.setContentLookup(False)
    except Exception:
        pass
    listitem.setMimeType('application/x-mpegURL')

    if headers and _ffmpegdirect_available():
        listitem.setPath(_kodi_amp_pipe(base, headers))
        listitem.setProperty('inputstream', 'inputstream.ffmpegdirect')
        listitem.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        listitem.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        listitem.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        return 'ffmpegdirect'

    if headers:
        header_prop = _isa_headers_prop(headers)
        listitem.setPath(base)
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_headers', header_prop)
        listitem.setProperty('inputstream.adaptive.stream_headers', header_prop)
        listitem.setProperty('inputstream.adaptive.common_headers', header_prop)
        listitem.setProperty(
            'inputstream.adaptive.manifest_config',
            json.dumps({'hls_ignore_endlist': True, 'live_delay': 16}),
        )
        listitem.setProperty(
            'inputstream.adaptive.config',
            json.dumps({'internal_cookies': True}),
        )
        return 'adaptive'

    listitem.setPath(kodi_pipe)
    return 'pipe'


def strip_list_label(label):
    '''Remove Kodi colour tags for dialogs / logs.'''
    return re.sub(r'\[/?[^\]]+\]', '', str(label or '')).strip()


def _localized(string_id, fallback):
    text = c.lang(string_id)
    if not text or text == string_id:
        return fallback
    return text


# crewschedule embedhd time in labels, e.g. "MLB 7/04 06:00 PM"
_SCHEDULE_TIME = re.compile(
    r'(\d{1,2}/\d{1,2})\s+(\d{1,2}:\d{2}\s*(?:AM|PM))',
    re.IGNORECASE,
)
_SUBLINK = re.compile(
    r'<sublink(?:\s+name=|)(?:\'|\"|)(.*?)(?:\'|\"|)>(.+?)</sublink>',
    re.DOTALL,
)


def _schedule_start_datetime(label):
    '''Parse m/d + time from a crewschedule row label (local wall time).'''
    plain = strip_list_label(label)
    match = _SCHEDULE_TIME.search(plain)
    if not match:
        return None

    date_part, time_part = match.group(1), match.group(2)
    now = datetime.now()
    candidates = []
    for year in (now.year - 1, now.year, now.year + 1):
        try:
            candidates.append(
                datetime.strptime(f'{date_part}/{year} {time_part}', '%m/%d/%Y %I:%M %p')
            )
        except ValueError:
            continue
    if not candidates:
        return None
    return min(candidates, key=lambda dt: abs((dt - now).total_seconds()))


def _is_future_schedule_row(label, grace_minutes=10):
    '''True only when the labelled start time is still ahead (not replays).'''
    start = _schedule_start_datetime(label)
    if start is None:
        return False
    return start > datetime.now() - timedelta(minutes=grace_minutes)


def is_live_schedule_row(label):
    '''crewschedule embedhd marks live rows with a LIVE colour tag.'''
    text = str(label or '')
    return '[COLOR green]LIVE[/COLOR]' in text or '[COLOR red]LIVE[/COLOR]' in text


def is_upcoming_schedule_row(label):
    '''
    crewschedule embedhd: scheduled rows use dodgerblue time; live rows use LIVE.
    Only treat as upcoming when the parsed start time is still in the future.
    '''
    text = str(label or '')
    if is_live_schedule_row(text):
        return False
    if '[COLOR dodgerblue]' not in text or '[COLOR orange]' not in text:
        return False
    return _is_future_schedule_row(text)


def decorate_schedule_label(label):
    '''Classy status badges  -  green LIVE, red UPCOMING (future embedhd rows only).'''
    text = str(label or '')
    if not text:
        return text

    # Drop stale UPCOMING on replays / past events.
    if '[COLOR red]UPCOMING[/COLOR]' in text and not _is_future_schedule_row(text):
        text = text.replace('[COLOR red]UPCOMING[/COLOR]', '', 1).strip()

    live_tag = re.compile(r'\[COLOR\s+\w+\]LIVE\[/COLOR\]', re.IGNORECASE)
    if live_tag.search(text):
        return live_tag.sub('[COLOR green]LIVE[/COLOR]', text, count=1)
    if is_upcoming_schedule_row(text) and '[COLOR red]UPCOMING[/COLOR]' not in text:
        return f'[COLOR red]UPCOMING[/COLOR] {text}'
    return text


def pick_sublink_url(url):
    '''Crew lists.resolver.get  -  one link passes through, many open a picker.'''
    text = str(url or '').strip()
    items = _SUBLINK.findall(text)
    if not items:
        return text
    if len(items) == 1:
        return items[0][1].strip()

    labels_urls = []
    for idx, (name, link) in enumerate(items):
        label = (name or '').strip()
        if not label:
            if '<preset>searchsd</preset>' in link:
                label = 'SD'
            elif '<preset>search</preset>' in link:
                label = 'HD'
            else:
                label = f'Link {idx + 1}'
        labels_urls.append((label, link.strip()))
    heading = strip_list_label(xbmc.getInfoLabel('ListItem.Label')) or c.addon_id
    picked = xbmcgui.Dialog().select(heading, [label for label, _ in labels_urls])
    if picked < 0:
        return False
    return labels_urls[picked][1]


def _has_sublink_markup(text):
    '''True for <sublink>, <sublink name="...">, and <sublink LABEL> (sports/WWE rows).'''
    if '<sublink' in str(text or '').lower():
        return True
    return bool(_SUBLINK.search(text or ''))


def _is_list_play_url(url, content):
    text = _normalize_list_url(url)
    # videos = testings.xml / IPTV-style direct rows (Crew 3.x lists.player lane)
    if content in ('addons', '0', 'videos'):
        return True
    if _has_sublink_markup(text) or text.startswith('magnet:'):
        return True
    if '<preset>' in text:
        return True
    if '|regex=' in text or '$doregex' in text:
        return True
    if '.m3u8' in text or '.f4m' in text:
        return True
    if text.startswith(('http://', 'https://', 'rtmp', 'plugin://')):
        return True
    return False


def _plugin_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, TypeError, ValueError):
        return None


def _is_live_stream_url(base, headers):
    '''True for HLS manifests and sports playlist endpoints that need ffmpegdirect.'''
    lower = (base or '').lower()
    if '.m3u8' in lower or '.f4m' in lower:
        return True
    # streameast / hereisman style  -  no extension, headers required or Curl 403s
    if headers and lower.startswith('http') and (
        'load-playlist' in lower or '/playlist/' in lower or 'm3u8' in lower
    ):
        return True
    return False


def _build_listitem(play_url, label):
    '''
    Live HLS / sports playlist + headers  ->  ffmpegdirect (or ISA fallback).
    Everything else  ->  pipe string on the path.
    '''
    base, headers, kodi_pipe = _parse_pipe_url(play_url)

    listitem = xbmcgui.ListItem(label=label)
    if _is_live_stream_url(base, headers):
        mode = _apply_live_hls(listitem, base, headers, kodi_pipe)
        c.log(f'[Lists play] live stream via {mode}')
    else:
        try:
            listitem.setContentLookup(False)
        except Exception:
            pass
        listitem.setPath(kodi_pipe)

    listitem.setProperty('IsPlayable', 'true')

    icon = xbmc.getInfoLabel('ListItem.Icon') or ''
    if icon:
        listitem.setArt({'icon': icon, 'thumb': icon})

    try:
        listitem.setInfo('video', {'title': label})
    except Exception:
        pass
    return listitem


def _handoff_to_kodi(play_url, listitem, handle):
    '''
    Kodi plugin resolve: setResolvedUrl OR Player.play  -  never both (avoids crashes).
    Prefer setResolvedUrl so ISA listitem properties stick.
    '''
    _ListsPlayerMonitor()
    if handle is not None and handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, listitem)
        c.log(f'[Lists play] setResolvedUrl handle={handle}')
        return

    _PLAYER.play(item=listitem)
    c.log('[Lists play] Player.play (no resolve handle)')


def _play_magnet_url(magnet_url, label):
    '''WWE / replay rows  -  magnet sublinks resolve through debrid then play.'''
    from ..modules import debrid

    if not debrid.status(torrent=True):
        kodi_notify(_localized(32524, 'Enable debrid in ResolveURL settings'))
        return True

    resolved = debrid.resolve_for_play(magnet_url)
    if not resolved:
        kodi_notify(_localized(32525, 'Could not resolve debrid link'))
        return True

    listitem = _build_listitem(resolved, label or 'Stream')
    c.log(f'[Lists play] debrid handoff url={resolved[:200]}')
    handle = _plugin_handle()
    if handle is None:
        handle = -1
    _handoff_to_kodi(resolved, listitem, handle)
    return True


def play_list_url(url, content='addons'):
    '''
    Resolve list/sports URL (regex, CDN, m3u8) and hand off to Kodi.
    '''
    global _RESOLVE_BUSY

    url = _normalize_list_url(url)

    if not _is_list_play_url(url, content):
        return False

    # Greenhats / XML lists bypass the episode play gate  -  release evening first
    # so shared thecrew.tvevening.* cannot hijack after ~20s.
    try:
        from ..tvevening import session as evening_session
        evening_session.release_for_foreign_play('lists play')
    except Exception as exc:
        c.log(f'[Lists play] TV Evening release failed: {exc}', 1)

    text = _normalize_list_url(url)
    if _RESOLVE_BUSY and ('$doregex' in text or '|regex=' in text):
        kodi_notify(_localized(32520, 'Resolving stream  -  please wait'))
        return True

    label = xbmc.getInfoLabel('ListItem.Label') or ''
    if is_upcoming_schedule_row(label):
        plain = strip_list_label(label)
        c.log(f'[Lists play] blocked upcoming row: {plain[:80]}')
        upcoming = _localized(32521, 'This broadcast has not started yet.')
        try:
            xbmcgui.Dialog().ok(
                c.addon_id,
                f'{upcoming}\n\n{plain}',
            )
        except Exception:
            kodi_notify(upcoming)
        return True

    install_lists_ecosystem_shims()

    url = pick_sublink_url(_normalize_list_url(str(url or '').strip()))
    if url is False:
        c.log('[Lists play] user cancelled sublink picker')
        return True
    if not url:
        kodi_notify(_localized(32526, 'No stream URL'))
        return True

    if url.startswith('magnet:'):
        plain = strip_list_label(label) or 'Stream'
        return _play_magnet_url(url, plain)

    needs_resolve = '$doregex' in url or '|regex=' in url
    if needs_resolve:
        _RESOLVE_BUSY = True
    try:
        resolved = expand_regex_url(url)
    finally:
        if needs_resolve:
            _RESOLVE_BUSY = False

    if not resolved:
        plain = strip_list_label(label) or 'this event'
        c.log(f'[Lists play] resolve empty for {plain[:80]}')
        try:
            xbmcgui.Dialog().ok(
                c.addon_id,
                _localized(
                    32522,
                    'No stream found for:\n\n%s\n\nThe source is offline or this event is not live yet.',
                ) % plain,
            )
        except Exception:
            kodi_notify(_localized(32401, 'No stream available'))
        return True

    if '<item>' in resolved or '$doregex' in resolved:
        c.log(f'[Lists play] unresolved list url: {resolved[:80]}', 1)
        kodi_notify(_localized(32401, 'No stream available'))
        return True

    play_url = _normalize_list_url(resolved)
    if not play_url:
        kodi_notify(_localized(32526, 'No stream URL'))
        return True

    if play_url.startswith('magnet:'):
        plain = strip_list_label(label) or 'Stream'
        return _play_magnet_url(play_url, plain)

    xbmc.executebuiltin('ActivateWindow(busydialog)')
    try:
        processed = process_list_play_url(play_url)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialog)')

    if processed is False:
        c.log('[Lists play] hoster process handled without direct url')
        return True
    if not processed:
        plain = strip_list_label(label) or 'this item'
        c.log(f'[Lists play] hoster resolve empty for {plain[:80]}')
        try:
            xbmcgui.Dialog().ok(
                c.addon_id,
                _localized(32523, 'No working stream found for:\n\n%s') % plain,
            )
        except Exception:
            kodi_notify(_localized(32401, 'No stream available'))
        return True

    play_url = _normalize_list_url(processed)

    if not label:
        label = 'Stream'
    listitem = _build_listitem(play_url, label)
    c.log(f'[Lists play] handoff url={play_url[:200]}')

    handle = _plugin_handle()
    if handle is None:
        handle = -1
    _handoff_to_kodi(play_url, listitem, handle)

    return True


def kodi_notify(message):
    try:
        xbmcgui.Dialog().notification(c.addon_id, message, xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception:
        pass

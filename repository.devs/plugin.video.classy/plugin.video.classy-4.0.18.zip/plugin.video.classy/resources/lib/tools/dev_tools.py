# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dev_tools.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Tools menu dev helpers with on-screen report (Shield / Xbox friendly).'''

from ..modules.classy import c
from . import ascii_guard, changelog, os_creds_import


def _show_report(title, lines):
    body = '\n'.join(lines or ['(no output)'])
    changelog.show_text(title, body)
    return body


def copy_os_creds():
    if not c.yesnoDialog(c.lang(30834)):
        return

    merged, used = os_creds_import.find_creds()
    lines = os_creds_import.build_report(merged, used)
    if not merged:
        _show_report(c.lang(30831), lines)
        c.infoDialog(lines[0] if lines else 'No credentials found', icon='ERROR')
        return

    os_creds_import.apply_via_addon_settings(merged)
    _show_report(c.lang(30831), lines)
    c.infoDialog('OpenSubtitles credentials updated', icon='INFO')


def check_user_ascii():
    ok, lines = ascii_guard.run_check(c.path)
    _show_report(c.lang(30832), lines)
    if not ok:
        c.infoDialog('Non-ASCII text found - see report', icon='WARNING')


def fix_user_ascii():
    if not c.yesnoDialog(c.lang(30835)):
        return

    ok, lines = ascii_guard.run_fix(c.path)
    _show_report(c.lang(30833), lines)
    if ok:
        c.infoDialog('ASCII check passed', icon='INFO')
    else:
        c.infoDialog('See ASCII fix report', icon='WARNING')

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file cache_tools.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Clear-cache actions  -  Crew cachingTools parity (labels + split main/meta).'''

from .. import cache as classy_cache
from ..metadata import tmdb_cache
from ..modules import cache as legacy_cache
from ..modules.classy import c
from ..sources import source_cache

# bucket_id -> (confirm string id, success string id)
_BUCKETS = {
    'providers': (32076, 32077),
    'main': (32084, 32081),
    'meta': (32082, 32083),
    'search': (32078, 32079),
    'debrid': (90290, 90291),
    'wetrakr': (90418, 90419),
    'all': (32080, 32081),
}


def _clear_providers():
    source_cache.clear_all()
    legacy_cache.cache_clear_providers()


def _clear_main():
    legacy_cache.cache_clear()


def _clear_meta():
    legacy_cache.cache_clear_meta()
    tmdb_cache.clear()


def _clear_search():
    legacy_cache.cache_clear_search()


def _clear_debrid():
    legacy_cache.cache_clear_debrid()


def _clear_wetrakr():
    try:
        from ..wetrakr import maintenance as wetrakr_maintenance
        wetrakr_maintenance.clear_all_caches()
    except Exception as exc:
        c.log(f'[CacheTools] WeTrakr clear failed: {exc}', 1)


def _clear_all():
    _clear_providers()
    _clear_main()
    _clear_meta()
    _clear_search()
    _clear_debrid()
    _clear_wetrakr()
    classy_cache.clear_all()


_CLEAR_FN = {
    'providers': _clear_providers,
    'main': _clear_main,
    'meta': _clear_meta,
    'search': _clear_search,
    'debrid': _clear_debrid,
    'wetrakr': _clear_wetrakr,
    'all': _clear_all,
}


def clear_bucket(bucket_id):
    fn = _CLEAR_FN.get(bucket_id)
    if not bucket_id or not fn:
        c.log(f'[CacheTools] unknown bucket: {bucket_id!r}', 1)
        return False
    c.log(f'[CacheTools] clearing bucket {bucket_id!r}')
    fn()
    return True


def confirm_and_clear(bucket_id):
    labels = _BUCKETS.get(bucket_id)
    if not labels:
        c.infoDialog('Unknown cache action', icon='ERROR')
        return False
    confirm_id, success_id = labels
    if not c.yesnoDialog(c.lang(confirm_id)):
        return False
    clear_bucket(bucket_id)
    c.infoDialog(c.lang(success_id), sound=True, icon='INFO')
    return True

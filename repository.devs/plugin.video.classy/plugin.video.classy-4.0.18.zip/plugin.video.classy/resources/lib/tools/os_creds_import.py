# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file os_creds_import.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Copy OpenSubtitles creds into Classy from Crew / backup / a4k (no secrets in output).'''

from __future__ import annotations

import os
import xml.etree.ElementTree as ET

TARGET_IDS = ('OSuser', 'OSpass', 'OSapikey')
A4K_MAP = {
    'OSuser': 'opensubtitles.username',
    'OSpass': 'opensubtitles.password',
}

SOURCE_NAMES = (
    'thecrew_settings_backup/settings.xml',
    'addon_data/plugin.video.thecrew/settings.xml',
    'addon_data/service.subtitles.a4ksubtitles/settings.xml',
)


def _kodi_vfs():
    try:
        import xbmcvfs
        return xbmcvfs
    except ImportError:
        return None


def userdata_home(home=None):
    """Kodi userdata folder (PC, Shield, Xbox) or explicit override for CLI."""
    if home:
        return os.path.normpath(home)
    vfs = _kodi_vfs()
    if vfs:
        return vfs.translatePath('special://home/')
    return os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Kodi', 'userdata')


def classy_settings_path(home=None):
    home = userdata_home(home)
    return os.path.join(home, 'addon_data', 'plugin.video.classy', 'settings.xml')


def source_paths(home=None):
    home = userdata_home(home)
    return [os.path.join(home, *rel.split('/')) for rel in SOURCE_NAMES]


def _path_exists(path):
    vfs = _kodi_vfs()
    if vfs:
        return vfs.exists(path)
    return os.path.isfile(path)


def _read_text(path):
    vfs = _kodi_vfs()
    if vfs and vfs.exists(path):
        handle = vfs.File(path)
        try:
            data = handle.read()
        finally:
            handle.close()
        if isinstance(data, bytes):
            data = data.decode('utf-8', errors='ignore')
        return data
    with open(path, 'r', encoding='utf-8') as handle:
        return handle.read()


def _read_values_from_xml(root) -> dict[str, str]:
    vals = {}
    for sid in TARGET_IDS:
        el = root.find("setting[@id='%s']" % sid)
        if el is not None:
            text = (el.text or '').strip()
            if text and el.get('default') != 'true':
                vals[sid] = text
        if sid in vals:
            continue
        a4k_id = A4K_MAP.get(sid)
        if not a4k_id:
            continue
        el = root.find("setting[@id='%s']" % a4k_id)
        if el is None:
            continue
        text = (el.text or '').strip()
        if text and el.get('default') != 'true':
            vals[sid] = text
    return vals


def _load_settings_root(path):
    if not path or not _path_exists(path):
        return None
    try:
        return ET.fromstring(_read_text(path))
    except Exception:
        return None


def find_creds(home=None):
    """Return (merged values, source path per id relative to userdata)."""
    home = userdata_home(home)
    merged = {}
    used = {}
    for src in source_paths(home):
        root = _load_settings_root(src)
        if root is None:
            continue
        vals = _read_values_from_xml(root)
        for sid, text in vals.items():
            if sid not in merged and text:
                merged[sid] = text
                try:
                    used[sid] = os.path.relpath(src, home).replace('\\', '/')
                except ValueError:
                    used[sid] = os.path.basename(src)
    return merged, used


def build_report(merged, used) -> list[str]:
    lines = []
    if not merged:
        lines.append('No OpenSubtitles credentials found in Crew / backup / a4k.')
        return lines

    lines.append('Copied to Classy: %s' % ', '.join(sorted(merged.keys())))
    for sid in TARGET_IDS:
        if sid in used:
            lines.append('  %s from %s' % (sid, used[sid]))
        elif sid in merged:
            lines.append('  %s from merged source' % sid)
        else:
            lines.append('  %s still missing' % sid)
    return lines


def apply_via_addon_settings(merged):
    from ..modules.classy import c

    for sid in TARGET_IDS:
        if sid in merged:
            c.set_setting(sid, merged[sid])


def apply_via_settings_xml(dst_path, merged, used) -> list[str]:
    if not merged:
        return build_report(merged, used)
    if not _path_exists(dst_path):
        return ['Classy settings missing: %s' % dst_path]

    tree = ET.parse(dst_path)
    root = tree.getroot()
    for sid in TARGET_IDS:
        if sid not in merged:
            continue
        el = root.find("setting[@id='%s']" % sid)
        if el is None:
            el = ET.SubElement(root, 'setting', {'id': sid})
        el.text = merged[sid]
        if 'default' in el.attrib:
            del el.attrib['default']

    tree.write(dst_path, encoding='utf-8', xml_declaration=False)
    return build_report(merged, used)

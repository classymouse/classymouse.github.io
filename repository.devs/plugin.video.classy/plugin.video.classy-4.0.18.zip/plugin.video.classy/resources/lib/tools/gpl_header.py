# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file gpl_header.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Apply or refresh the standard Crew GPL file header (podnapisi.py template).'''

from __future__ import annotations

import os
import re

CM_LINE = '********************************************************cm*'
CODING_LINE = '# -*- coding: utf-8 -*-'

PACKAGE = 'plugin.video.thecrew'
COPYRIGHT = '(c) 2026, The Crew (cm)'

SKIP_DIR_NAMES = {'.git', '__pycache__', '.cursor', 'temp'}
SKIP_PATH_PARTS = {'docs'}

OLD_MARKERS = (
    'Classy Add-on',
    'plugin.video.classy',
    'Classy Mouse',
    '@copyright (c) 2025',
)

_CM_BLOCK_RE = re.compile(
    r"^(?:\n)?'''[\s\S]*?" + re.escape(CM_LINE) + r"[\s\S]*?" + re.escape(CM_LINE) + r"[\s\S]*?'''\n?",
    re.MULTILINE,
)
_MODULE_DOC_RE = re.compile(
    r"^\s*(?:'''|\"\"\")(.+?)(?:'''|\"\"\")\s*\n",
    re.DOTALL | re.MULTILINE,
)


def build_header(filename: str, description: str = '') -> str:
    if description.strip():
        desc_part = '\n\n' + description.strip()
    else:
        desc_part = '\n'
    return (
        "'''\n"
        f"{CM_LINE}\n"
        "* The Crew Add-on\n"
        "*\n"
        f"* @file {filename}\n"
        f"* @package {PACKAGE}\n"
        "*\n"
        f"* @copyright {COPYRIGHT}\n"
        "* @license GNU General Public License, version 3 (GPL-3.0)\n"
        "*\n"
        f"{CM_LINE}"
        f"{desc_part}'''"
    )


def _extract_cm_description(block: str) -> str:
    first = block.find(CM_LINE)
    if first < 0:
        return ''
    second = block.find(CM_LINE, first + len(CM_LINE))
    if second < 0:
        return ''
    tail = block[second + len(CM_LINE):]
    tail = tail.rstrip()
    if tail.endswith("'''"):
        tail = tail[:-3]
    elif tail.endswith('"""'):
        tail = tail[:-3]
    return tail.strip()


def _split_leading_parts(text: str):
    shebang = ''
    body = text
    if body.startswith('#!'):
        line, _, body = body.partition('\n')
        shebang = line + '\n'

    coding = ''
    body_stripped = body.lstrip('\n')
    if body_stripped.startswith('#') and 'coding' in body_stripped.split('\n', 1)[0]:
        line, _, body = body_stripped.partition('\n')
        coding = line + '\n'
        body = body.lstrip('\n')
    elif not coding:
        coding = CODING_LINE + '\n'

    return shebang, coding, body


def _strip_existing_header(body: str) -> tuple[str, str]:
    desc_parts = []
    rest = body.lstrip('\n')
    while True:
        match = _CM_BLOCK_RE.match(rest)
        if match:
            desc_parts.append(_extract_cm_description(match.group(0)))
            rest = rest[match.end():].lstrip('\n')
            continue
        break

    doc_match = _MODULE_DOC_RE.match(rest)
    if doc_match and CM_LINE not in doc_match.group(0):
        desc_parts.append(doc_match.group(1).strip())
        rest = rest[doc_match.end():].lstrip('\n')

    desc = '\n\n'.join(part for part in desc_parts if part.strip())
    return desc, rest


def header_status(text: str, filename: str) -> str:
    if CM_LINE not in text:
        return 'missing'
    if f'@file {filename}' not in text:
        return 'stale_file'
    if f'@package {PACKAGE}' not in text:
        return 'stale_package'
    if any(marker in text for marker in OLD_MARKERS):
        return 'stale_old'
    if COPYRIGHT not in text:
        return 'stale_copyright'
    return 'ok'


def transform_file_text(text: str, filename: str, *, force: bool = False) -> tuple[str, str | None]:
    """Return (new_text, action) where action is None if unchanged."""
    status = header_status(text, filename)
    if status == 'ok' and not force:
        return text, None

    shebang, coding, body = _split_leading_parts(text)
    desc, rest = _strip_existing_header(body)
    header = build_header(filename, desc)
    new_text = f'{shebang}{coding}\n{header}\n\n{rest}'
    if not new_text.endswith('\n'):
        new_text += '\n'
    if new_text == text:
        return text, None
    return new_text, status if status != 'ok' else 'refresh'


def iter_python_files(root: str):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIR_NAMES]
        rel_dir = os.path.relpath(dirpath, root)
        rel_parts = () if rel_dir == '.' else tuple(rel_dir.split(os.sep))
        if any(part in SKIP_PATH_PARTS for part in rel_parts):
            continue
        for name in filenames:
            if not name.endswith('.py'):
                continue
            rel = os.path.join(rel_dir, name) if rel_dir != '.' else name
            yield os.path.join(dirpath, name), rel.replace('\\', '/')


def default_targets(addon_root: str) -> list[str]:
    paths = []
    lib_root = os.path.join(addon_root, 'resources', 'lib')
    if os.path.isdir(lib_root):
        paths.append(lib_root)
    for name in ('default.py', 'service.py'):
        path = os.path.join(addon_root, name)
        if os.path.isfile(path):
            paths.append(path)
    return paths


def run_apply(addon_root: str, *, fix: bool = False, force: bool = False) -> tuple[list[str], list[str]]:
    """Return (changed_or_would_change paths, ok paths)."""
    changed = []
    ok = []
    targets = default_targets(addon_root)

    files: list[tuple[str, str]] = []
    for target in targets:
        if os.path.isfile(target):
            rel = os.path.relpath(target, addon_root).replace('\\', '/')
            files.append((target, os.path.basename(rel)))
        else:
            files.extend(iter_python_files(target))

    for abs_path, rel in sorted(set(files), key=lambda row: row[0].lower()):
        filename = os.path.basename(abs_path)
        try:
            with open(abs_path, 'r', encoding='utf-8') as handle:
                original = handle.read()
        except OSError as exc:
            changed.append(f'{rel}: read failed: {exc}')
            continue

        new_text, action = transform_file_text(original, filename, force=force)
        if action is None:
            ok.append(rel)
            continue

        label = f'{rel} ({action})'
        if fix:
            with open(abs_path, 'w', encoding='utf-8', newline='') as handle:
                handle.write(new_text)
        changed.append(label)

    return changed, ok

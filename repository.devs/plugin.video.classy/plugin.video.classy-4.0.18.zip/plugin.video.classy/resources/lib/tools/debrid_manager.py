# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file debrid_manager.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Tools -> Debrid management (lean).

Auth status from ResolveURL settings. Thin account card (user / expiry)
from debrid.account_cache (worker-filled, last-good). Clear authorization
wipes live secrets + backup scrub (B1). Cloud browse stays later.
'''

from __future__ import annotations

import xbmc
import xbmcaddon
import xbmcgui

from ..debrid import account_cache, account_fetch
from ..debrid.registry import PROVIDERS, get as get_provider
from ..modules import control, resolveurl_backup
from ..modules.classy import c

_RESOLVEURL_ID = 'script.module.resolveurl'


def _ru_addon():
    try:
        if not xbmc.getCondVisibility(f'System.HasAddon({_RESOLVEURL_ID})'):
            return None
        return xbmcaddon.Addon(_RESOLVEURL_ID)
    except Exception:
        return None


def _authorized(addon, primary_key):
    try:
        return bool((addon.getSetting(primary_key) or '').strip())
    except Exception:
        return False


def _enabled(addon, enabled_key):
    try:
        return addon.getSetting(enabled_key) == 'true'
    except Exception:
        return False


def _schedule_account_refresh():
    try:
        from ..modules.monitor import get_monitor
        mon = get_monitor()
        if mon is None:
            return
        worker = mon.worker('debrid_account')
        if worker is not None:
            worker.force_due()
    except Exception:
        pass


def _ensure_enabled(spec, addon=None):
    '''Clear sets enabled=false; ResolveURL auth often leaves that flag alone.'''
    addon = addon or _ru_addon()
    if addon is None or spec is None:
        return
    try:
        if addon.getSetting(spec.enabled_setting) != 'true':
            addon.setSetting(spec.enabled_setting, 'true')
            c.log(f'[DebridManager] re-enabled {spec.key}')
    except Exception as exc:
        c.log(f'[DebridManager] enable {spec.key} failed: {exc}', 1)


def service_rows():
    '''Return list of dicts for the Tools directory.'''
    addon = _ru_addon()
    cached = account_cache.get_all()
    rows = []
    for spec in PROVIDERS:
        if addon is None:
            status = 'ResolveURL missing'
            auth = False
        else:
            auth = _authorized(addon, spec.primary_secret)
            on = _enabled(addon, spec.enabled_setting)
            if auth and on:
                status = 'Authorized'
            elif auth and not on:
                status = 'Authorized (disabled)'
            else:
                status = 'Not authorized'
        if auth:
            status = status + account_fetch.status_suffix(cached.get(spec.key))
        rows.append({
            'provider': spec.key,
            'label': spec.label,
            'status': status,
            'authorized': auth,
        })
    return rows


def clear_authorization(provider):
    '''Wipe live secrets, disable resolver, scrub ResolveURL backup.'''
    spec = get_provider(provider)
    if spec is None:
        control.okDialog('Unknown debrid service.', heading='Debrid management')
        return False

    addon = _ru_addon()
    if addon is None:
        control.okDialog(
            'ResolveURL is not installed.',
            heading='Debrid management',
        )
        return False

    confirm = control.yesnoDialog(
        f'Clear {spec.label} authorization?[CR][CR]'
        f'This disables {spec.label} in ResolveURL and wipes the token.[CR]'
        f'The ResolveURL backup copy is scrubbed too so a restart '
        f'cannot put it back.[CR][CR]You will need to authorize again '
        f'to use {spec.label}.',
        heading='Debrid management',
        nolabel='Cancel',
        yeslabel='Clear',
    )
    if not confirm:
        return False

    try:
        for sid in spec.secrets:
            addon.setSetting(sid, '')
        addon.setSetting(spec.enabled_setting, 'false')
    except Exception as exc:
        c.log(f'[DebridManager] clear live {spec.key} failed: {exc}', 1)
        control.okDialog(
            f'Could not clear {spec.label} in ResolveURL settings.',
            heading='Debrid management',
        )
        return False

    try:
        resolveurl_backup.scrub_provider(spec.key, log_label='debrid_manager')
    except Exception as exc:
        c.log(f'[DebridManager] scrub backup {spec.key} failed: {exc}', 1)

    try:
        resolveurl_backup.reconcile_backup_with_live(log_label='debrid_manager')
    except Exception:
        pass

    try:
        account_cache.clear_provider(spec.key)
    except Exception:
        pass

    c.log(f'[DebridManager] cleared {spec.key}')
    control.okDialog(
        f'{spec.label} authorization cleared.[CR]Backup scrubbed.',
        heading='Debrid management',
    )
    return True


def open_resolveurl_settings(provider=''):
    '''Open ResolveURL settings on the provider category / auth row.'''
    from ..modules import kodi

    spec = get_provider(provider)
    query = spec.settings_query if spec else ''
    if not xbmc.getCondVisibility(f'System.HasAddon({_RESOLVEURL_ID})'):
        control.okDialog(
            'ResolveURL is not installed.',
            heading='Debrid management',
        )
        return
    kodi.open_settings(query=query, _id=_RESOLVEURL_ID)


def authorize_provider(provider):
    '''Kick ResolveURL device-auth for this provider (no settings hunt).'''
    spec = get_provider(provider)
    if spec is None:
        return False
    if not xbmc.getCondVisibility(f'System.HasAddon({_RESOLVEURL_ID})'):
        control.okDialog(
            'ResolveURL is not installed.',
            heading='Debrid management',
        )
        return False
    # Clear left enabled=false; auth_ad/etc. restores the token only.
    _ensure_enabled(spec)
    xbmc.executebuiltin(
        f'RunPlugin(plugin://{_RESOLVEURL_ID}/?mode={spec.auth_mode})'
    )
    # Auth is async in ResolveURL  -  worker will retry when forced.
    _schedule_account_refresh()
    return True


def refresh_account(provider):
    '''User-initiated thin account pull for one provider.'''
    spec = get_provider(provider)
    if spec is None:
        return False
    addon = _ru_addon()
    # Already has a token after Clear+reauth  -  flip enabled back on.
    if addon is not None and _authorized(addon, spec.primary_secret):
        _ensure_enabled(spec, addon)
    ok = account_fetch.refresh_provider(spec.key)
    if ok:
        control.infoDialog(f'{spec.label} account updated', icon='INFO')
    else:
        control.okDialog(
            f'Could not refresh {spec.label} account info.[CR]'
            f'Authorize first, or try again in a moment.',
            heading='Debrid management',
        )
    return ok


def _account_lines(spec, cached):
    lines = []
    if not cached:
        lines.append('Account: (not cached yet)')
        return lines
    user = (cached.get('username') or '').strip()
    email = (cached.get('email') or '').strip()
    plan = (cached.get('plan') or '').strip()
    if user:
        lines.append(f'User: {user}')
    if email:
        lines.append(f'Email: {email}')
    if plan:
        lines.append(f'Plan: {plan}')
    exp = account_fetch.format_expiry(cached.get('expires_at'))
    if exp:
        lines.append(exp)
    if not lines:
        lines.append('Account: cached (no detail)')
    return lines


def open_service_menu(provider):
    '''Dialog for one service: authorize, clear, open ResolveURL.'''
    spec = get_provider(provider)
    if spec is None:
        control.finish_dialog_route()
        return

    addon = _ru_addon()
    if addon is None:
        control.okDialog(
            'ResolveURL is not installed.',
            heading='Debrid management',
        )
        control.finish_dialog_route()
        return

    auth = _authorized(addon, spec.primary_secret)
    on = _enabled(addon, spec.enabled_setting)
    if auth and on:
        status = 'Authorized'
    elif auth:
        status = 'Authorized (disabled)'
    else:
        status = 'Not authorized'

    cached = account_cache.get(spec.key) if auth else None
    options = [f'Status: {status}']
    options.extend(_account_lines(spec, cached) if auth else ['Account: not authorized'])
    # Offset into action choices after the info block.
    info_count = len(options)
    options.extend([
        'Authorize / Re-authorize',
        'Refresh account info',
        'Clear authorization',
        'Open ResolveURL settings',
    ])
    try:
        choice = xbmcgui.Dialog().select(spec.label, options)
        if choice < info_count:
            return
        action = choice - info_count
        if action == 0:
            authorize_provider(spec.key)
        elif action == 1:
            if refresh_account(spec.key):
                try:
                    xbmc.executebuiltin('Container.Refresh')
                except Exception:
                    pass
        elif action == 2:
            if clear_authorization(spec.key):
                try:
                    xbmc.executebuiltin('Container.Refresh')
                except Exception:
                    pass
        elif action == 3:
            open_resolveurl_settings(spec.key)
    finally:
        control.finish_dialog_route()

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file log_upload.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Anonymous Kodi / The Crew log upload for support tickets.'''

import os
import platform
import re
from datetime import datetime

import requests
import xbmcgui
import xbmcvfs

from ..modules.classy import c


class LogUploader:
    @staticmethod
    def _sanitize_log(text):
        try:
            import getpass
            actual_username = getpass.getuser()
        except Exception:
            actual_username = None

        try:
            system_username = os.path.expanduser('~').split(os.sep)[-1]
        except Exception:
            system_username = None

        sanitized = text
        sanitized = re.sub(r'C:\\Users\\[^\\]+', r'C:\\Users\\[USER]', sanitized, flags=re.IGNORECASE)
        sanitized = re.sub(r'C:/Users/[^/]+', r'C:/Users/[USER]', sanitized, flags=re.IGNORECASE)
        sanitized = re.sub(r'/home/[^/]+', r'/home/[USER]', sanitized)
        sanitized = re.sub(r'/Users/[^/]+', r'/Users/[USER]', sanitized)

        if actual_username:
            sanitized = sanitized.replace(actual_username, '[USER]')
        if system_username and system_username != actual_username:
            sanitized = sanitized.replace(system_username, '[USER]')

        sanitized = re.sub(r'\b192\.168\.\d{1,3}\.\d{1,3}\b', '[IP-LOCAL]', sanitized)
        sanitized = re.sub(r'\b10\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP-LOCAL]', sanitized)
        sanitized = re.sub(r'\b172\.(1[6-9]|2[0-9]|3[01])\.\d{1,3}\.\d{1,3}\b', '[IP-LOCAL]', sanitized)
        sanitized = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP]', sanitized)
        sanitized = re.sub(r'\b[0-9A-Fa-f]{2}([-:])[0-9A-Fa-f]{2}(\1[0-9A-Fa-f]{2}){4}\b', '[MAC]', sanitized)
        sanitized = re.sub(r'\b[0-9a-f]{40,64}\b', '[TOKEN]', sanitized, flags=re.IGNORECASE)
        sanitized = re.sub(r'Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer [TOKEN]', sanitized, flags=re.IGNORECASE)
        sanitized = re.sub(
            r'Authorization:\s*[^\r\n]+', 'Authorization: [REDACTED]', sanitized, flags=re.IGNORECASE,
        )
        sanitized = re.sub(r'[?&](api_key|apikey|key|token)=[^&\s]+', r'\1=[KEY]', sanitized, flags=re.IGNORECASE)

        try:
            hostname = platform.node()
            if hostname:
                sanitized = sanitized.replace(hostname, '[DEVICE]')
        except Exception:
            pass

        return sanitized

    @staticmethod
    def _read_log(path):
        if xbmcvfs.exists(path):
            handle = xbmcvfs.File(path, 'r')
            try:
                return handle.read()
            finally:
                handle.close()
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8', errors='ignore') as handle:
                return handle.read()
        return None

    @staticmethod
    def _upload_to_paste(content, title='Log'):
        try:
            response = requests.post(
                'https://dpaste.com/api/v2/',
                data={
                    'content': content,
                    'title': title,
                    'syntax': 'text',
                    'expiry_days': 7,
                },
                timeout=30,
            )
            response.raise_for_status()
            result_url = (response.text or '').strip()
            if result_url.startswith('http'):
                return result_url
        except Exception as exc:
            c.log(f'[LogUploader] dpaste failed: {exc}', 1)

        try:
            response = requests.post(
                'https://paste.ubuntu.com/',
                data={
                    'content': content,
                    'poster': 'The Crew Addon',
                    'syntax': 'text',
                    'expiration': '604800',
                },
                timeout=30,
            )
            response.raise_for_status()
            if response.url and response.url != 'https://paste.ubuntu.com/':
                return response.url
        except Exception as exc:
            c.log(f'[LogUploader] ubuntu paste failed: {exc}', 1)
        return None

    @staticmethod
    def _show_result(url, header, message):
        xbmcgui.Dialog().textviewer(header, message)

    @staticmethod
    def _upload_file(log_path, title, label):
        content = LogUploader._read_log(log_path)
        if not content:
            c.infoDialog(f'{label} not found', icon='ERROR')
            return False

        sanitized = LogUploader._sanitize_log(content)
        header = (
            f'# The Crew  -  {label}\n'
            f'# Upload Date: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n'
            f'# Addon: {c.addon_id} v.{c.version}\n'
            f'# Kodi: {c.kodiversion}\n'
            f'# Platform: {c.platform}\n'
            f'# NOTE: ANONYMIZED  -  usernames, IPs, tokens redacted\n'
            f'# Original Size: {len(content):,} bytes\n'
            f'#\n'
            f'{"=" * 80}\n\n'
        )
        body = header + sanitized
        paste_url = LogUploader._upload_to_paste(body, title)
        if not paste_url:
            c.infoDialog('Failed to upload log', icon='ERROR')
            return False

        message = (
            f'Your {label} was uploaded anonymously.\n\n'
            f'Usernames, IPs, and tokens were removed.\n\n'
            f'Share this link with support:\n{paste_url}\n\n'
            f'Expires in 7 days | Size: {len(body):,} bytes'
        )
        LogUploader._show_result(paste_url, f'{label} uploaded', message)
        return True

    @staticmethod
    def upload_kodi_log():
        path = xbmcvfs.translatePath('special://logpath/kodi.log')
        return LogUploader._upload_file(path, 'Kodi Log', 'Kodi log')

    @staticmethod
    def upload_classy_log():
        path = os.path.join(xbmcvfs.translatePath('special://logpath'), 'classy.log')
        return LogUploader._upload_file(path, 'The Crew Log', 'The Crew log')

    @staticmethod
    def upload_crew_log():
        '''Alias  -  log file on disk is still classy.log until go-live rename.'''
        return LogUploader.upload_classy_log()

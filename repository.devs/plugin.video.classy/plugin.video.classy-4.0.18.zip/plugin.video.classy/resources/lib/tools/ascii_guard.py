# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file ascii_guard.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Scan/fix user-facing addon text for non-ASCII (Kodi font charset).'''

from __future__ import annotations

import os

ALLOWED_NON_ASCII = {'\u00a4'}

SKIP_DIR_NAMES = {'.git', '__pycache__', '.cursor', 'temp', 'tools'}
SKIP_PATH_PARTS = {'docs'}

REPLACEMENTS = (
    ('\u2026', '...'),
    ('\u2192', ' -> '),
    ('\u2190', ' <- '),
    ('\u2194', ' <-> '),
    ('\u2014', ' - '),
    ('\u2013', ' - '),
    ('\u00b7', ' | '),
    ('\u2022', '* '),
    ('\u2264', '<='),
    ('\u2265', '>='),
    ('\u2248', '~'),
    ('\u00b1', '+/-'),
    ('\u2261', '=='),
    ('\u2713', '(+)'),
    ('\u2717', '(-)'),
    ('\u2605', '*'),
)


def _should_skip(rel_parts: tuple[str, ...]) -> bool:
    return any(part in SKIP_PATH_PARTS for part in rel_parts)


def iter_source_files(root: str):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIR_NAMES]
        rel_dir = os.path.relpath(dirpath, root)
        rel_parts = () if rel_dir == '.' else tuple(rel_dir.split(os.sep))
        if _should_skip(rel_parts):
            continue
        for name in filenames:
            if name.endswith(('.py', '.xml', '.po', '.txt')) or name == 'addon.xml':
                rel = os.path.join(rel_dir, name) if rel_dir != '.' else name
                norm = rel.replace('\\', '/')
                if norm == 'scripts/check_user_ascii.py':
                    continue
                yield os.path.join(dirpath, name), rel


def _non_ascii_positions(text: str) -> list[tuple[int, int, str]]:
    hits = []
    for line_no, line in enumerate(text.splitlines(), 1):
        for col, ch in enumerate(line, 1):
            if ord(ch) > 127 and ch not in ALLOWED_NON_ASCII:
                hits.append((line_no, col, ch))
    return hits


def _is_scanned_file(rel_path: str) -> bool:
    norm = rel_path.replace('\\', '/')
    base = os.path.basename(norm)
    _, ext = os.path.splitext(base)
    return ext in {'.py', '.xml', '.po', '.txt'} or base == 'addon.xml'


def _check_file(abs_path: str, rel_path: str) -> list[str]:
    if not _is_scanned_file(rel_path):
        return []
    try:
        with open(abs_path, 'r', encoding='utf-8') as handle:
            text = handle.read()
    except OSError as exc:
        return [f'{rel_path}: read failed: {exc}']

    return [
        f'{rel_path}:{line_no}:{col} U+{ord(ch):04X}'
        for line_no, col, ch in _non_ascii_positions(text)
    ]


def _fix_file(abs_path: str, rel_path: str) -> bool:
    with open(abs_path, 'r', encoding='utf-8') as handle:
        original = handle.read()
    fixed = original
    for src, dst in REPLACEMENTS:
        fixed = fixed.replace(src, dst)
    if fixed == original:
        return False
    with open(abs_path, 'w', encoding='utf-8', newline='') as handle:
        handle.write(fixed)
    return True


def run_check(root: str) -> tuple[bool, list[str]]:
    """Return (ok, report_lines)."""
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        return False, [f'error: not a directory: {root}']

    issues = []
    for abs_path, rel_path in iter_source_files(root):
        issues.extend(_check_file(abs_path, rel_path))

    if not issues:
        return True, ['OK: user-facing text is ASCII-only']

    lines = [f'non-ASCII user-facing text: {len(issues)} issue(s)']
    lines.extend(issues[:200])
    if len(issues) > 200:
        lines.append(f'... and {len(issues) - 200} more')
    return False, lines


def run_fix(root: str) -> tuple[bool, list[str]]:
    """Apply common replacements, then re-check. Return (ok, report_lines)."""
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        return False, [f'error: not a directory: {root}']
    if not os.access(root, os.W_OK):
        return False, [
            'Addon folder is read-only on this device.',
            'Run fix on a dev PC (python scripts/check_user_ascii.py --fix).',
        ]

    fixed = []
    for abs_path, rel_path in iter_source_files(root):
        if _fix_file(abs_path, rel_path):
            fixed.append(rel_path)

    lines = []
    if fixed:
        lines.append(f'fixed {len(fixed)} file(s):')
        lines.extend(fixed[:100])
        if len(fixed) > 100:
            lines.append(f'... and {len(fixed) - 100} more')
        lines.append('')

    ok, check_lines = run_check(root)
    lines.extend(check_lines)
    return ok, lines

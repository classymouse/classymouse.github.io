# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file scraper_packs_dialog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Tools -> Scraper Packs: skinned multi-toggle (replaces settings clutter).'''

from __future__ import annotations

import xbmcgui

from ..kodi.dialog_base import ClassyDialogBase
from ..modules import control
from ..modules.classy import c
from ..sources import scraper_packs

LIST_ID = 9001
BTN_CLOSE = 9002

L_TITLE = 30856
L_HINT = 30857
L_ON = 30858
L_OFF = 30859
L_NOT_INSTALLED = 30860
L_CLOSE = 30861
L_NEED_INSTALL = 30862


def _status_label(pack):
    if not scraper_packs.is_installed(pack):
        return c.lang(L_NOT_INSTALLED)
    if scraper_packs.is_enabled(pack):
        return '[COLOR lawngreen]%s[/COLOR]' % c.lang(L_ON)
    return '[COLOR crimson]%s[/COLOR]' % c.lang(L_OFF)


def _row_label(pack):
    name = (pack.get('label') or pack.get('id') or '').strip() or 'Pack'
    return name


class ScraperPacksDialog(ClassyDialogBase):
    XML_FILE = 'ScraperPacks.xml'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._packs = []

    def onInit(self):
        icon = ''
        try:
            icon = control.addonInfo('icon') or ''
        except Exception:
            icon = ''
        self.set_properties({
            'title': c.lang(L_TITLE),
            'hint': c.lang(L_HINT),
            'close_label': c.lang(L_CLOSE),
            'fanart': c.addon_fanart() or '',
            'icon': icon,
        })
        self._reload_list()
        try:
            self.setFocusId(LIST_ID)
        except Exception:
            pass

    def _reload_list(self):
        ctrl = self.control(LIST_ID)
        if ctrl is None:
            return
        try:
            ctrl.reset()
        except Exception:
            pass
        self._packs = list(scraper_packs.list_packs())
        for pack in self._packs:
            item = xbmcgui.ListItem(label=_row_label(pack), label2=_status_label(pack))
            try:
                item.setProperty('pack_id', str(pack.get('id') or ''))
                item.setProperty('installed', '1' if scraper_packs.is_installed(pack) else '0')
                item.setProperty('enabled', '1' if scraper_packs.is_enabled(pack) else '0')
            except Exception:
                pass
            ctrl.addItem(item)

    def onClick(self, controlId):
        if controlId == BTN_CLOSE:
            self.close_with(controlId)
            return
        if controlId != LIST_ID:
            return
        ctrl = self.control(LIST_ID)
        if ctrl is None:
            return
        try:
            pos = int(ctrl.getSelectedPosition())
        except Exception:
            return
        if pos < 0 or pos >= len(self._packs):
            return
        pack = self._packs[pos]
        if not scraper_packs.is_installed(pack):
            control.infoDialog(c.lang(L_NEED_INSTALL), heading=c.lang(L_TITLE), sound=False)
            return
        new_state = not scraper_packs.is_enabled(pack)
        if scraper_packs.set_enabled(pack, new_state):
            c.log(
                '[ScraperPacks] %s -> %s'
                % (pack.get('id'), 'on' if new_state else 'off')
            )
        self._reload_list()
        try:
            ctrl.selectItem(pos)
            self.setFocusId(LIST_ID)
        except Exception:
            pass

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self.close_with(None)


def open_dialog():
    '''Tools / settings entry  -  show pack toggles then discard dialog.'''
    dialog = ScraperPacksDialog.run_modal()
    try:
        del dialog
    except Exception:
        pass

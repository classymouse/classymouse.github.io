# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file changelog.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import os

import xbmcgui

from ..modules.classy import c

CHANGELOG_FILE = os.path.join(c.path, 'changelog.txt')

_ACTION_BACK = (10, 92)
_ACTION_MOVE_UP = 3
_ACTION_MOVE_DOWN = 4
_ACTION_PAGE_UP = 5
_ACTION_PAGE_DOWN = 6
_ACTION_MOUSE_WHEEL_UP = 104
_ACTION_MOUSE_WHEEL_DOWN = 105
_ACTION_FIRST_PAGE = 159
_ACTION_LAST_PAGE = 160

_HEADER = 101
_TEXT = 102
_SCROLL_TRAP = 105
_CLOSE = 201


def show():
    title = f'[B]The Crew v.{c.version}[/B]'
    try:
        with open(CHANGELOG_FILE, 'r', encoding='utf-8') as handle:
            text = handle.read().strip()
    except Exception as exc:
        c.log(f'[Changelog] read failed: {exc}', 1)
        text = 'Changelog file not found.'

    show_text(title, text)


def show_text(title, text):
    '''Scrollable report dialog (changelog / dev tool output).'''
    xml_name, addon_path, skin = _resolve_dialog_xml()
    if xml_name and addon_path:
        _show_skinned(addon_path, skin, xml_name, title, text)
        return

    xbmcgui.Dialog().textviewer(c.addon_id, text)


def _resolve_dialog_xml():
    '''Prefer Changelog.xml (scroll trap); fall back to LogViewer.xml.'''
    candidates = ('Changelog.xml', 'LogViewer.xml')
    roots = []
    try:
        import xbmcaddon
        art_path = xbmcaddon.Addon('script.thecrew.artwork').getAddonInfo('path')
        if art_path:
            roots.append(art_path)
    except Exception:
        pass
    if c.path:
        roots.append(c.path)

    skin = c.appearance() or 'thecrew'
    fallbacks = [skin]
    for fb in ('thecrew', 'modern'):
        if fb not in fallbacks:
            fallbacks.append(fb)

    for xml_name in candidates:
        for root in roots:
            for candidate_skin in fallbacks:
                xml_path = os.path.join(
                    root, 'resources', 'skins', candidate_skin, '1080i', xml_name,
                )
                if os.path.isfile(xml_path):
                    return xml_name, root, candidate_skin
    return None, None, None


def _show_skinned(addon_path, skin, xml_name, title, text):
    class LogViewer(xbmcgui.WindowXMLDialog):
        _LINE_STEP = 1
        _WHEEL_STEP = 3
        _PAGE_STEP = 10

        def onInit(self):
            self._scroll_pos = 0
            try:
                self.getControl(_HEADER).setLabel(title)
            except Exception:
                pass
            try:
                self.getControl(_TEXT).setText(text)
            except Exception as exc:
                c.log(f'[Changelog] setText failed: {exc}', 1)
            try:
                self.getControl(_SCROLL_TRAP)
                self.setFocusId(_SCROLL_TRAP)
            except Exception:
                pass

        def _textbox(self):
            return self.getControl(_TEXT)

        def _max_scroll(self):
            try:
                ctrl = self._textbox()
                if hasattr(ctrl, 'maxScroll'):
                    return max(0, int(ctrl.maxScroll()))
            except Exception:
                pass
            return None

        def _apply_scroll(self):
            try:
                ctrl = self._textbox()
                max_pos = self._max_scroll()
                if max_pos is not None:
                    self._scroll_pos = min(self._scroll_pos, max_pos)
                ctrl.scroll(self._scroll_pos)
                if hasattr(ctrl, 'getScroll'):
                    self._scroll_pos = max(0, int(ctrl.getScroll()))
            except Exception as exc:
                c.log(f'[Changelog] scroll failed: {exc}', 1)

        def _scroll_by(self, delta):
            if not delta:
                return
            self._scroll_pos = max(0, self._scroll_pos + delta)
            self._apply_scroll()

        def _scroll_to(self, pos):
            self._scroll_pos = max(0, pos)
            self._apply_scroll()

        def onClick(self, controlId):
            # Mouse / select on Close  -  onAction alone never sees button clicks.
            if controlId == _CLOSE:
                self.close()

        def onAction(self, action):
            try:
                action_id = action.getId()
            except Exception:
                return

            if action_id in _ACTION_BACK:
                self.close()
                return

            # Kodi textbox.scroll() is an absolute line index, not a relative delta.
            if action_id == _ACTION_MOUSE_WHEEL_UP:
                self._scroll_by(-self._WHEEL_STEP)
                return

            if action_id == _ACTION_MOUSE_WHEEL_DOWN:
                self._scroll_by(self._WHEEL_STEP)
                return

            if action_id == _ACTION_MOVE_UP:
                self._scroll_by(-self._LINE_STEP)
                return

            if action_id == _ACTION_MOVE_DOWN:
                self._scroll_by(self._LINE_STEP)
                return

            if action_id == _ACTION_PAGE_UP:
                self._scroll_by(-self._PAGE_STEP)
                return

            if action_id == _ACTION_PAGE_DOWN:
                self._scroll_by(self._PAGE_STEP)
                return

            if action_id == _ACTION_FIRST_PAGE:
                self._scroll_to(0)
                return

            if action_id == _ACTION_LAST_PAGE:
                max_pos = self._max_scroll()
                if max_pos is not None:
                    self._scroll_to(max_pos)
                else:
                    self._scroll_to(self._scroll_pos + 10000)
                return

    dialog = LogViewer(xml_name, addon_path, skin, '1080i')
    dialog.doModal()
    del dialog

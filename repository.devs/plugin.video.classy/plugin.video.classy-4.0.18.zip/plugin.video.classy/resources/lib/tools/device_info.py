# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file device_info.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Debug -> Device info: read-only support blurb (no PII).'''

from __future__ import annotations

import os
import subprocess
import sys

import xbmc
import xbmcaddon

from ..modules import control
from ..modules.classy import c

L_TITLE = 30865
L_COPY_PROMPT = 30869
L_COPY_YES = 30870
L_COPY_NO = 30871
L_COPY_OK = 30872
L_COPY_FAIL = 30873


def _addon_present(addon_id):
    try:
        if xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
            return True
    except Exception:
        pass
    try:
        import xbmcvfs
        root = xbmcvfs.translatePath('special://home/addons')
        if root and os.path.isdir(os.path.join(root, addon_id)):
            return True
    except Exception:
        pass
    return False


def _addon_version(addon_id):
    '''Best-effort installed version; empty if missing.'''
    if not addon_id or not _addon_present(addon_id):
        return ''
    try:
        return (xbmcaddon.Addon(addon_id).getAddonInfo('version') or '').strip()
    except Exception:
        return ''


def _python_short():
    ver = (sys.version or '').strip().split()[0] if sys.version else ''
    return ver or 'unknown'


def _kodi_build():
    try:
        raw = (xbmc.getInfoLabel('System.BuildVersion') or '').strip()
        if raw:
            return raw
    except Exception:
        pass
    return getattr(c, 'kodiversion', None) or 'unknown'


def _tracker_line():
    try:
        from .. import tracker
        name = tracker.display_label() or tracker.active_name() or 'unknown'
        live = 'live' if tracker.live() else 'not authorized'
        return '%s (%s)' % (name, live)
    except Exception:
        return 'unknown'


def _debug_state():
    try:
        on = str(c.get_setting('addon_debug') or '').lower() == 'true'
    except Exception:
        on = False
    return 'On' if on else 'Off'


def build_blurb():
    '''Plain ASCII multi-line support text (no tokens / paths / passwords).'''
    lines = [
        'Addon: %s %s' % (c.addon_id or 'plugin.video.classy', c.version or ''),
        'Kodi: %s' % _kodi_build(),
        'Python: %s' % _python_short(),
        'Platform: %s' % (getattr(c, 'platform', None) or 'unknown'),
        'Tracker: %s' % _tracker_line(),
        'Debug: %s' % _debug_state(),
    ]
    resolve_ver = _addon_version('script.module.resolveurl')
    if resolve_ver:
        lines.append('ResolveURL: %s' % resolve_ver)
    classy_ver = _addon_version('script.module.classyscrapers')
    if classy_ver:
        lines.append('ClassyScrapers: %s' % classy_ver)
    return '\n'.join(lines)


def copy_to_clipboard(text):
    '''Best-effort clipboard; True on success.'''
    payload = (text or '').strip()
    if not payload:
        return False
    # Windows (primary soak host)
    try:
        if sys.platform.startswith('win'):
            completed = subprocess.run(
                ['clip'],
                input=payload,
                text=True,
                encoding='utf-8',
                errors='replace',
                check=False,
                timeout=5,
            )
            if completed.returncode == 0:
                return True
    except Exception:
        pass
    # Linux / some CoreELEC builds
    for cmd in (
        ['xclip', '-selection', 'clipboard'],
        ['xsel', '--clipboard', '--input'],
    ):
        try:
            completed = subprocess.run(
                cmd,
                input=payload,
                text=True,
                encoding='utf-8',
                errors='replace',
                check=False,
                timeout=5,
            )
            if completed.returncode == 0:
                return True
        except Exception:
            continue
    return False


def show():
    '''okDialog with blurb, then optional copy.'''
    blurb = build_blurb()
    heading = c.lang(L_TITLE) or 'Device info'
    # Dialogs use [CR]; clipboard keeps real newlines.
    control.okDialog(blurb.replace('\n', '[CR]'), heading=heading)
    try:
        want_copy = control.yesnoDialog(
            c.lang(L_COPY_PROMPT) or 'Copy to clipboard?',
            heading=heading,
            nolabel=c.lang(L_COPY_NO) or 'No',
            yeslabel=c.lang(L_COPY_YES) or 'Copy',
        )
    except Exception:
        want_copy = False
    if not want_copy:
        return
    if copy_to_clipboard(blurb):
        control.infoDialog(c.lang(L_COPY_OK) or 'Copied', heading=heading, sound=False)
    else:
        control.infoDialog(c.lang(L_COPY_FAIL) or 'Copy failed', heading=heading, sound=False)

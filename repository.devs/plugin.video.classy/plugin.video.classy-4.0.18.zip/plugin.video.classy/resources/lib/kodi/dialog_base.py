# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file dialog_base.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Thin base for skinned WindowXML dialogs  -  one XML per screen, shared plumbing only.

Subclasses set XML_FILE and implement onInit / onClick. Do not share one XML across
features; layouts differ too much (see 4.0-SKINS.md).

Kodi SWIG requires:
1. xml + addon path as positional args at construction time
2. WindowXMLDialog.__init__ before any self.* assignment

Use create() / run_modal()  -  never MyDialog(only_kwargs=...).'''

from __future__ import annotations

import xbmcgui

from ..modules.classy import c

_RESOLUTION = '1080i'


class ClassyDialogBase(xbmcgui.WindowXMLDialog):
    '''Resolve bundled skin path + small helpers; feature logic stays in subclass.'''

    XML_FILE = ''

    def __init__(self, *args, **kwargs):
        skin_preferred = kwargs.pop('skin_preferred', None)
        xml_file = kwargs.pop('xml_file', None)
        feature_kwargs = dict(kwargs)

        if len(args) >= 2:
            xbmcgui.WindowXMLDialog.__init__(self, *args)
        else:
            name = (xml_file or self.XML_FILE or '').strip()
            if not name:
                raise ValueError(f'{type(self).__name__} requires XML_FILE or xml_file')
            addon_path, skin = c.resolve_dialog_skin(name, preferred=skin_preferred)
            xbmcgui.WindowXMLDialog.__init__(self, name, addon_path, skin, _RESOLUTION)

        # Only touch self after C++ WindowXML is constructed
        self._dialog_kwargs = feature_kwargs
        self.button_id = None
        self.closing = False

    @classmethod
    def create(cls, **kwargs):
        '''Build dialog with required WindowXML positional args.'''
        skin_preferred = kwargs.pop('skin_preferred', None)
        name = (kwargs.pop('xml_file', None) or cls.XML_FILE or '').strip()
        if not name:
            raise ValueError(f'{cls.__name__} requires XML_FILE or xml_file')
        addon_path, skin = c.resolve_dialog_skin(name, preferred=skin_preferred)
        return cls(name, addon_path, skin, _RESOLUTION, **kwargs)

    def set_properties(self, mapping):
        '''Bulk window properties  -  values coerced to str; None skipped.'''
        if not mapping:
            return
        for key, value in mapping.items():
            if value is None:
                continue
            self.setProperty(str(key), str(value))

    def control(self, control_id):
        try:
            return self.getControl(int(control_id))
        except Exception:
            return None

    def set_label(self, control_id, label):
        ctrl = self.control(control_id)
        if ctrl is not None:
            ctrl.setLabel(str(label or ''))

    def close_with(self, button_id=None):
        if self.closing:
            return
        if button_id is not None:
            self.button_id = button_id
        self.closing = True
        self.close()

    @classmethod
    def run_modal(cls, **kwargs):
        '''Show dialog; return instance after close (caller should del when done).'''
        dialog = cls.create(**kwargs)
        dialog.doModal()
        return dialog

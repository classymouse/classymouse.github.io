# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file context_menus.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Central context menu hub - all surfaces join here.

Surfaces:
  video   - movie / tvshow / episode rows (VideoListItem)
  menu    - navigator folder rows (pin to My Crew)
  my_crew - shortcuts inside My Crew (rename / move / remove)

Product rules: docs/CM_AUDIT.md (score + trailer first; one screen @ 1080p).'''

from __future__ import annotations

import sys
from urllib.parse import quote_plus, urlencode

from ..metadata.video_row import VideoRow
from ..modules import kodi
from ..modules.classy import c
from ..pinboard import menu_cm as pinboard_cm
from ..play.mode import MODE_AUTOPLAY
from ..play.url import play_url
from .. import tracker
from .listing import widget_browse_url

SURFACE_VIDEO = 'video'
SURFACE_MENU = 'menu'
SURFACE_MY_CREW = 'my_crew'

# Classy reuses Crew IDs 32520 - 32522 for stream errors  -  use literals here.
L_BROWSE_SERIES = 32071
L_BROWSE_SEASON = 'Browse Season %s'
L_MARK_WATCHED = 'Mark Watched'
L_MARK_UNWATCHED = 'Mark Unwatched'
L_SOURCE_SELECT = 32063
L_AUTO_PLAY = 32064
L_OPEN_FULL_LIST = 32752
L_PLAY_TRAILER = 32062
L_FIND_SIMILAR = 32100
L_CLEAR_RESUME = 90237

_VIDEO_MEDIATYPES = frozenset({'movie', 'tvshow', 'episode', 'season'})


def _plugin_root():
    if len(sys.argv) > 0 and sys.argv[0]:
        return sys.argv[0]
    return f'plugin://{c.addon_id}/'


def plugin_url(action, **params):
    query = {'action': action}
    for key, value in params.items():
        if value is None or value == '':
            continue
        query[key] = str(value)
    return f'{_plugin_root()}?{urlencode(query)}'


def run_plugin(action, **params):
    return f'RunPlugin({plugin_url(action, **params)})'


def activate_videos(action, **params):
    return f'ActivateWindow(Videos,{plugin_url(action, **params)},return)'


def container_update(action, **params):
    return f'Container.Update({plugin_url(action, **params)})'


def _show_title(row):
    return (row.tvshowtitle or row.title or '').strip()


def _has_ids(row):
    return bool((row.imdb or '').strip() or (row.tmdb or '').strip())


def _tmdb_id(row):
    token = str(row.tmdb or '').strip()
    if not token or token == '0':
        return ''
    return token


def _trakt_content(row):
    return 'movie' if row.mediatype == 'movie' else 'tvshow'


def _trakt_name(row):
    if row.mediatype == 'movie':
        return (row.title or '').strip()
    return _show_title(row)


def _browse_params(row):
    return {
        'tmdb': row.tmdb,
        'tvdb': row.tvdb,
        'imdb': row.imdb,
        'tvshowtitle': _show_title(row),
        'year': row.year,
    }


def activate_videos_url(plugin_url):
    return f'ActivateWindow(Videos,{plugin_url},return)'


def _widget_items(row, *, is_widget):
    items = []
    if not is_widget:
        return items
    url = widget_browse_url()
    if url:
        label = c.lang(L_OPEN_FULL_LIST)
        if not label or str(label) == str(L_OPEN_FULL_LIST):
            label = 'Open full list'
        items.append((label, activate_videos_url(url)))
    return items


def _tv_browse_items(row, *, is_widget=False):
    '''Browse Series / Season  -  all episode rows; show widgets get Browse Series.'''
    if not _tmdb_id(row):
        return []

    mediatype = row.mediatype or ''
    params = _browse_params(row)
    items = []

    if mediatype == 'episode':
        items.append((
            _cm_lang(L_BROWSE_SERIES, 'Browse Series'),
            activate_videos('seasons', **params),
        ))
        season = int(row.season or 0)
        if season > 0:
            items.append((
                L_BROWSE_SEASON % season,
                activate_videos('episodes', **params, season=season),
            ))
    elif is_widget and mediatype == 'tvshow':
        items.append((
            _cm_lang(L_BROWSE_SERIES, 'Browse Series'),
            activate_videos('seasons', **params),
        ))
    return items


def _discovery_items(row):
    '''Trailer + find similar (docs/CM_AUDIT.md). Info dialog = Kodi system CM.'''
    mediatype = row.mediatype or ''
    if mediatype not in _VIDEO_MEDIATYPES:
        return []

    items = []
    tmdb_id = _tmdb_id(row)
    if mediatype in ('movie', 'tvshow') and _has_ids(row):
        title = _trakt_name(row)
        direct = (row.trailer or '').strip()
        items.append((
            _cm_lang(L_PLAY_TRAILER, 'Play Trailer'),
            run_plugin(
                'trailer',
                name=title,
                imdb=row.imdb or '',
                tmdb=row.tmdb or '',
                mediatype=mediatype,
                url=direct if direct and not direct.startswith('plugin://') else '',
            ),
        ))
        if tmdb_id:
            browse_action = 'movies' if mediatype == 'movie' else 'tvshows'
            items.append((
                _cm_lang(L_FIND_SIMILAR, 'Find similar'),
                container_update(browse_action, url='tmdb_similar', tid=tmdb_id),
            ))
    return items


def _tracker_items(row):
    items = []
    if tracker.live() and _has_ids(row):
        name = _trakt_name(row)
        if name:
            if tracker.is_simkl():
                action = 'simklManager'
            elif tracker.is_wetrakr():
                action = 'wetrakrManager'
            else:
                action = 'traktManager'
            items.append((
                f'{tracker.display_label()} Manager',
                run_plugin(
                    action,
                    name=name,
                    imdb=row.imdb,
                    tmdb=row.tmdb,
                    content=_trakt_content(row),
                ),
            ))
    items.extend(_playcount_items(row))
    return items


def _row_watched(row):
    if int(row.overlay or 0) == 7:
        return True
    if (row.mediatype or '') == 'movie' and int(row.playcount or 0) > 0:
        return True
    return False


def _cm_lang(string_id, fallback):
    try:
        text = c.lang(string_id)
        if text and str(text) != str(string_id):
            return text
    except Exception:
        pass
    return fallback


def _alter_sources_label():
    try:
        hosts_mode = int(c.get_setting('hosts.mode') or 1)
    except (TypeError, ValueError):
        hosts_mode = 1
    if hosts_mode == MODE_AUTOPLAY:
        return _cm_lang(L_SOURCE_SELECT, 'Source Select')
    return _cm_lang(L_AUTO_PLAY, 'Auto Play')


def _play_items(row):
    mediatype = (row.mediatype or '').strip()
    if mediatype not in ('movie', 'episode') or not _has_ids(row):
        return []
    return [(
        _alter_sources_label(),
        run_plugin('alter_sources', url=quote_plus(play_url(row))),
    )]


def _playcount_items(row):
    if not tracker.live() or not _has_ids(row):
        return []

    mediatype = row.mediatype or ''
    imdb = row.imdb or ''
    tmdb = row.tmdb or ''
    watched = _row_watched(row)
    label = L_MARK_UNWATCHED if watched else L_MARK_WATCHED
    query = 6 if watched else 7

    if mediatype == 'movie':
        return [(
            label,
            run_plugin('moviePlaycount', imdb=imdb, tmdb=tmdb, query=query),
        )]
    if mediatype == 'tvshow':
        return [(
            label,
            run_plugin('tvPlaycount', imdb=imdb, tmdb=tmdb, query=query),
        )]
    if mediatype == 'episode':
        return [(
            label,
            run_plugin(
                'episodePlaycount',
                imdb=imdb,
                tmdb=tmdb,
                season=row.season,
                episode=row.episode,
                query=query,
            ),
        )]
    if mediatype == 'season':
        return [(
            label,
            run_plugin(
                'seasonPlaycount',
                imdb=imdb,
                tmdb=tmdb,
                season=row.season,
                query=query,
            ),
        )]
    return []


def _resume_items(row):
    if float(row.resume_point or 0) <= 0:
        return []
    imdb = row.imdb or ''
    tmdb = row.tmdb or ''
    mediatype = row.mediatype or ''
    clear_label = _cm_lang(L_CLEAR_RESUME, 'Clear Resume Point')
    if mediatype == 'movie':
        return [(
            clear_label,
            run_plugin('movieClearBookmark', imdb=imdb, tmdb=tmdb),
        )]
    if mediatype == 'episode':
        return [(
            clear_label,
            run_plugin(
                'episodeClearBookmark',
                imdb=imdb, tmdb=tmdb, season=row.season, episode=row.episode,
            ),
        )]
    return []


def build_video_menu(row, *, is_widget=None, surface=None):
    '''Video row CM - movie / tvshow / episode (discovery -> play -> tracker).'''
    row = row if isinstance(row, VideoRow) else VideoRow.from_dict(row)
    mediatype = (row.mediatype or '').strip()
    if mediatype not in _VIDEO_MEDIATYPES:
        return []

    if is_widget is None:
        is_widget = kodi.is_widget_listing()

    items = []
    items.extend(_widget_items(row, is_widget=is_widget))
    items.extend(_tv_browse_items(row, is_widget=is_widget))
    items.extend(_discovery_items(row))
    items.extend(_play_items(row))
    items.extend(_tracker_items(row))
    items.extend(_resume_items(row))
    return items


def build_menu_pin_items(action, label='', icon=''):
    return pinboard_cm.pin_menu_items(action, label=label, icon=icon)


def build_my_crew_menu(item_id):
    return pinboard_cm.my_crew_row_items(item_id)


def build(surface, **kwargs):
    if surface == SURFACE_VIDEO:
        return build_video_menu(
            kwargs['row'],
            is_widget=kwargs.get('is_widget'),
            surface=kwargs.get('fork'),
        )
    if surface == SURFACE_MENU:
        return build_menu_pin_items(
            kwargs.get('action', ''),
            label=kwargs.get('label', ''),
            icon=kwargs.get('icon', ''),
        )
    if surface == SURFACE_MY_CREW:
        return build_my_crew_menu(kwargs['item_id'])
    return []


def apply_video_context_menu(listitem, row, *, is_widget=None, surface=None):
    items = build_video_menu(row, is_widget=is_widget, surface=surface)
    if not items:
        return False
    listitem.addContextMenuItems(items)
    return True


build_context_menu = build_video_menu
apply_context_menu = apply_video_context_menu

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file resolve_status.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

ResolveStatus overlay  -  trying source N of M during smart resolve.

While the overlay is active, ResolveURL / xbmcgui DialogProgress output is
redirected here so native progress dialogs do not sit on top of the fullscreen XML.'''

from __future__ import annotations

import re
from contextlib import contextmanager

import xbmc
import xbmcgui

from .dialog_base import ClassyDialogBase
from ..modules.classy import c

_ACTIVE = {'overlay': None}


def get_active_overlay():
    return _ACTIVE.get('overlay')


def set_active_overlay(overlay):
    _ACTIVE['overlay'] = overlay


def clear_active_overlay():
    _ACTIVE['overlay'] = None


def _plain(text):
    return re.sub(r'\[/?[^\]]+\]', '', str(text or '')).strip()


def _close_competing_dialogs():
    for dlg in (
        'busydialognocancel',
        'busy',
        'progressdialog',
        'extendedprogressdialog',
        'notification',
    ):
        try:
            xbmc.executebuiltin(f'Dialog.Close({dlg})')
        except Exception:
            pass


def _kodi_texture(path):
    '''Normalize local / remote paths so WindowXML image controls will load them.'''
    if not path:
        return ''
    p = str(path).strip().replace('\\', '/')
    if not p or p in ('0', 'None'):
        return ''
    if p.startswith(('http://', 'https://', 'special://', 'image://', 'plugin://')):
        return p
    try:
        import xbmcvfs
        home = xbmcvfs.translatePath('special://home').replace('\\', '/').rstrip('/')
        if home and p.lower().startswith(home.lower()):
            rel = p[len(home):].lstrip('/')
            return f'special://home/{rel}'
    except Exception:
        pass
    # Last resort  -  absolute path with forward slashes (desktop Kodi).
    return p


def _apply_backdrop(dialog, fanart, fill=''):
    '''Properties + setImage  -  non-modal overlays often need both.'''
    fill_t = _kodi_texture(fill or fanart or c.addon_fanart())
    art_t = _kodi_texture(fanart) or fill_t
    try:
        dialog.set_properties({
            'fanart.fill': fill_t or art_t,
            'fanart': art_t or fill_t,
        })
    except Exception:
        pass
    for control_id, texture in ((1, fill_t or art_t), (2, art_t or fill_t)):
        if not texture:
            continue
        try:
            ctrl = dialog.getControl(control_id)
            if ctrl is not None:
                ctrl.setImage(texture)
        except Exception:
            pass
    try:
        c.log(f'[ResolveStatus] backdrop fanart={art_t[:80]!r} fill={fill_t[:80]!r}')
    except Exception:
        pass


class ResolveStatusDialog(ClassyDialogBase):
    '''Non-modal WindowXML overlay; poll is_cancelled() from the resolve loop.'''

    XML_FILE = 'ResolveStatus.xml'
    CANCEL_BUTTON = 6

    def __init__(self, *args, **kwargs):
        title = kwargs.pop('title', '') or ''
        subtitle = kwargs.pop('subtitle', '') or ''
        fanart = kwargs.pop('fanart', '') or ''
        super().__init__(*args, **kwargs)
        self._cancelled = False
        self._title = title
        self._subtitle = subtitle
        self._fanart = fanart
        self._attempt_label = ''

    def onInit(self):
        try:
            fill = c.addon_fanart() or ''
            fanart = (self._fanart or '').strip()
            if not fanart or fanart in ('0', 'None'):
                fanart = fill
            self.set_properties({
                'title': self._title or c.addon_id,
                'subtitle': self._subtitle,
                'status.main': 'Finding your stream...',
                'status.sub': '',
                'status.attempt': '',
                'resolve.spinning': '1',
            })
            _apply_backdrop(self, fanart, fill)
            self.clearProperty('resolve.action')
        except Exception as exc:
            c.log(f'[ResolveStatus] onInit error: {exc}', 1)

    def set_backdrop(self, fanart, fill=''):
        _apply_backdrop(self, fanart, fill or c.addon_fanart())

    def update_status(self, main, sub='', attempt=''):
        try:
            if attempt:
                self._attempt_label = str(attempt)
            if main:
                self.setProperty('status.main', str(main))
            self.setProperty('status.sub', str(sub or ''))
            if attempt or self._attempt_label:
                self.setProperty('status.attempt', str(attempt or self._attempt_label))
            _close_competing_dialogs()
        except Exception as exc:
            c.log(f'[ResolveStatus] update_status error: {exc}', 1)

    def is_cancelled(self):
        if self._cancelled:
            return True
        try:
            if self.getProperty('resolve.action') == 'cancel':
                self._cancelled = True
        except Exception:
            pass
        return self._cancelled

    def onClick(self, control_id):
        if control_id == self.CANCEL_BUTTON:
            self._cancelled = True
            self.setProperty('resolve.action', 'cancel')
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
            self._cancelled = True
            self.setProperty('resolve.action', 'cancel')
            self.close()

    def close(self):
        self._cancelled = True
        try:
            self.clearProperty('resolve.spinning')
            self.clearProperty('resolve.action')
        except Exception:
            pass
        try:
            super().close()
        except Exception:
            pass


class OverlayBoundProgressDialog:
    '''resolveurl.lib.kodi.ProgressDialog stand-in  -  paints ResolveStatus.'''

    def __init__(self, heading, line1='', line2='', line3='', background=False, active=True, timer=0):
        self.heading = heading or ''
        self.line1 = line1 or ''
        self.line2 = line2 or ''
        self.line3 = line3 or ''
        self.background = background
        self.pd = self
        if active:
            self._paint()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def is_canceled(self):
        overlay = get_active_overlay()
        return bool(overlay and overlay.is_cancelled())

    def iscanceled(self):
        return self.is_canceled()

    def update(self, percent, line1='', line2='', line3=''):
        if line1:
            self.line1 = line1
        if line2:
            self.line2 = line2
        if line3:
            self.line3 = line3
        self._paint(percent)

    def close(self):
        pass

    def _paint(self, percent=-1):
        overlay = get_active_overlay()
        if not overlay:
            return
        main = _plain(self.heading) or 'Resolving...'
        parts = [_plain(p) for p in (self.line1, self.line2, self.line3) if _plain(p)]
        sub = '  |  '.join(parts)[:160]
        attempt = getattr(overlay, '_attempt_label', '') or ''
        try:
            pct = int(percent)
        except (TypeError, ValueError):
            pct = -1
        # ResolveURL often calls update(0) on create  -  skip noise until real progress
        if pct > 0:
            attempt = f'{attempt}  |  {pct}%'.strip('  | ') if attempt else f'{pct}%'
        overlay.update_status(main, sub, attempt)


class OverlayDialogProgress:
    '''xbmcgui.DialogProgress stand-in used while ResolveStatus is active.'''

    def __init__(self):
        self._heading = ''
        self._message = ''

    def create(self, heading, message=''):
        self._heading = heading or ''
        self._message = message or ''
        self._paint()

    def update(self, percent, message=''):
        if message:
            self._message = message
        self._paint(percent)

    def iscanceled(self):
        overlay = get_active_overlay()
        return bool(overlay and overlay.is_cancelled())

    def close(self):
        pass

    def _paint(self, percent=-1):
        overlay = get_active_overlay()
        if not overlay:
            return
        main = _plain(self._heading) or 'Resolving...'
        sub = _plain(self._message)[:160]
        attempt = getattr(overlay, '_attempt_label', '') or ''
        try:
            pct = int(percent)
        except (TypeError, ValueError):
            pct = -1
        if pct > 0:
            attempt = f'{attempt}  |  {pct}%'.strip('  | ') if attempt else f'{pct}%'
        overlay.update_status(main, sub, attempt)


@contextmanager
def capture_progress_dialogs(overlay):
    '''Redirect ResolveURL / DialogProgress UI into the ResolveStatus overlay.'''
    set_active_overlay(overlay)
    _close_competing_dialogs()

    orig_xbmc_dp = xbmcgui.DialogProgress
    ru_mod = None
    orig_ru_pd = None
    try:
        try:
            from resolveurl.lib import kodi as ru_mod
            orig_ru_pd = ru_mod.ProgressDialog
            ru_mod.ProgressDialog = OverlayBoundProgressDialog
        except Exception as exc:
            c.log(f'[ResolveStatus] could not patch resolveurl ProgressDialog: {exc}', 2)

        xbmcgui.DialogProgress = OverlayDialogProgress
        yield
    finally:
        try:
            if ru_mod is not None and orig_ru_pd is not None:
                ru_mod.ProgressDialog = orig_ru_pd
        except Exception:
            pass
        try:
            xbmcgui.DialogProgress = orig_xbmc_dp
        except Exception:
            pass
        clear_active_overlay()
        _close_competing_dialogs()


def _display_title(request, fallback=''):
    if request is None:
        return fallback or ''
    if getattr(request, 'is_episode', False):
        show = request.tvshowtitle or request.title or ''
        try:
            return f'{show} - S{int(request.season):02d}E{int(request.episode):02d}'
        except (TypeError, ValueError):
            return show or fallback or ''
    return request.title or getattr(request, 'display_title', None) or fallback or ''


def _display_subtitle(request):
    if request is None:
        return ''
    if getattr(request, 'is_episode', False):
        return str(request.title or '')
    year = getattr(request, 'year', None)
    return str(year) if year else ''


def _resolve_fanart(request):
    meta = (getattr(request, 'meta', None) or {}) if request else {}
    for key in ('fanart', 'fanart2', 'thumb', 'poster'):
        val = meta.get(key)
        if val and str(val) not in ('0', 'None', ''):
            return _kodi_texture(val)

    # TV Evening playlist rows already carry show fanart from build.
    try:
        from ..tvevening.monitor import evening_is_live
        if evening_is_live():
            from ..tvevening import playlist_db
            from ..tvevening import session as evening_session
            ep = playlist_db.get_playlist_db().get_episode_at_position(
                evening_session.get_current_position()
            ) or {}
            for key in ('fanart', 'poster', 'thumb'):
                val = ep.get(key)
                if val and str(val) not in ('0', 'None', ''):
                    return _kodi_texture(val)
            show_tmdb = ep.get('showtmdb') or ep.get('tmdb') or getattr(request, 'tmdb', None)
            if show_tmdb and str(show_tmdb) not in ('0', 'None', ''):
                from ..modules import cache as caching
                art = caching.get_show_artwork(show_tmdb)
                if art:
                    return _kodi_texture(art)
    except Exception:
        pass

    if request is not None:
        show_tmdb = getattr(request, 'tmdb', None)
        if show_tmdb and str(show_tmdb) not in ('0', 'None', '') and getattr(request, 'is_episode', False):
            try:
                from ..modules import cache as caching
                art = caching.get_show_artwork(show_tmdb)
                if art:
                    return _kodi_texture(art)
            except Exception:
                pass

    return _kodi_texture(c.addon_fanart() or '')


def experience_overlay_wanted():
    '''True during a live TV Evening session  -  one calm surface for scrape + resolve.'''
    try:
        from ..tvevening.monitor import evening_is_live
        return bool(evening_is_live())
    except Exception:
        return False


def open_resolve_status(request=None, title='', reuse=True):
    '''Create and show the overlay (non-modal). Caller must close().

    When ``reuse`` is True and an overlay is already active (e.g. scrape opened
    it for TV Evening), refresh copy and return that instance instead of stacking.
    '''
    _close_competing_dialogs()
    fanart = _resolve_fanart(request)
    fill = _kodi_texture(c.addon_fanart() or '')
    if reuse:
        existing = get_active_overlay()
        if existing is not None:
            try:
                if not existing.is_cancelled():
                    existing.set_properties({
                        'title': _display_title(request, title) or c.addon_id,
                        'subtitle': _display_subtitle(request),
                    })
                    if hasattr(existing, 'set_backdrop'):
                        existing.set_backdrop(fanart, fill)
                    else:
                        _apply_backdrop(existing, fanart, fill)
                    set_active_overlay(existing)
                    return existing
            except Exception as exc:
                c.log(f'[ResolveStatus] reuse failed, opening fresh: {exc}', 1)

    dialog = ResolveStatusDialog.create(
        title=_display_title(request, title),
        subtitle=_display_subtitle(request),
        fanart=fanart or fill,
    )
    dialog.show()
    # Non-modal: onInit may race  -  push backdrop again after show.
    try:
        dialog.set_backdrop(fanart or fill, fill)
    except Exception:
        pass
    set_active_overlay(dialog)
    return dialog

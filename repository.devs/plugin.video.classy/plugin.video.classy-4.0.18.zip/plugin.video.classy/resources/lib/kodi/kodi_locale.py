# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file kodi_locale.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Read Kodi core player locale settings via JSON-RPC.'''

import json

import xbmc

from ..modules.classy import c

_CACHE = {}


def get_core_setting(setting_id, default=''):
    '''Return a Kodi system setting value (e.g. locale.subtitlelanguage).'''
    if setting_id in _CACHE:
        return _CACHE[setting_id]
    value = default
    try:
        payload = {
            'jsonrpc': '2.0',
            'id': 1,
            'method': 'Settings.GetSettingValue',
            'params': {'setting': setting_id},
        }
        raw = xbmc.executeJSONRPC(json.dumps(payload))
        parsed = json.loads(raw or '{}')
        value = parsed.get('result', {}).get('value', default)
        if value is None:
            value = default
    except Exception as exc:
        c.log(f'[KodiLocale] read {setting_id} failed: {exc}', 1)
    _CACHE[setting_id] = value
    return value


def clear_cache():
    _CACHE.clear()


def get_subtitle_language():
    return str(get_core_setting('locale.subtitlelanguage', 'forced_only') or '').strip()


def get_audio_language():
    return str(get_core_setting('locale.audiolanguage', 'mediadefault') or '').strip()

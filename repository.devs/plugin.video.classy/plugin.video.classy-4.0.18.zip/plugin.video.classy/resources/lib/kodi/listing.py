# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file listing.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Unified browse vs home-widget listing policy for every video directory.'''

from __future__ import annotations

import os
import sys
from dataclasses import dataclass

from ..modules import kodi
from ..modules.classy import c

WIDGET_ITEM_LIMIT = 25
BROWSE_PAGE_SIZE = 25
_WIDGET_STRIP_PARAMS = frozenset({
    'widget', 'reload', 'reload_type', 'reloadorientation',
})


def widget_browse_url():
    '''Current list URL without widget skin flags  -  opens full paginated browse.'''
    try:
        if len(sys.argv) < 3 or not sys.argv[2]:
            return ''
        raw = str(sys.argv[2]).strip()
        if raw.startswith('?'):
            raw = raw[1:]
        from urllib.parse import parse_qsl, urlencode
        pairs = [
            (k, v) for k, v in parse_qsl(raw, keep_blank_values=True)
            if k.lower() not in _WIDGET_STRIP_PARAMS
        ]
        if not dict(pairs).get('action'):
            return ''
        return f'{sys.argv[0]}?{urlencode(pairs)}'
    except Exception:
        return ''


@dataclass(frozen=True)
class ListingContext:
    is_widget: bool
    limit: int = WIDGET_ITEM_LIMIT
    page_size: int = BROWSE_PAGE_SIZE

    @property
    def paginate(self):
        return not self.is_widget

    @property
    def enrich_widget(self):
        return self.is_widget

    @property
    def in_widget(self):
        '''Alias for kodi.in_widget() during GetDirectory (includes is_widget_listing).'''
        return kodi.in_widget()

    @property
    def playable_direct(self):
        '''Home-screen widgets mark playable rows (Crew parity).'''
        return self.is_widget


def listing_context():
    '''Resolve once per GetDirectory  -  widget vs in-addon browse.'''
    is_widget = kodi.is_widget_listing()
    return ListingContext(is_widget=is_widget)


def parse_page(params, ctx=None):
    ctx = ctx or listing_context()
    if ctx.is_widget:
        return 1
    try:
        return max(1, int((params or {}).get('page') or 1))
    except (TypeError, ValueError):
        return 1


def slice_rows(rows, ctx=None):
    ctx = ctx or listing_context()
    items = list(rows or [])
    if ctx.is_widget:
        return items[:ctx.limit]
    return items


def prepare_rows_for_widget(rows, ctx=None):
    '''Episode widgets: skins often prefer poster over still thumb.'''
    ctx = ctx or listing_context()
    if not ctx.is_widget:
        return rows
    for row in rows:
        if getattr(row, 'mediatype', '') == 'episode':
            row.thumb = ''
    return rows


def _stamp_widget_autoplay(url):
    '''Force Autoplay on playable Home widget rows (select=2).

    Widget GetDirectory marks IsPlayable; click is a resolve. Default
    hosts.mode=Directory then Container.Updates from Home and exits without
    setResolvedUrl  -  scrape succeeds, playback never starts.
    '''
    text = str(url or '')
    if not text or 'action=play' not in text.lower():
        return text
    if 'select=' in text.lower():
        return text
    return f'{text}&select=2' if '?' in text else f'{text}?select=2'


def emit_video_row(handle, row, url, ctx=None, *, is_folder=False):
    from .video_listitem import VideoListItem

    ctx = ctx or listing_context()
    if not is_folder and ctx.playable_direct:
        url = _stamp_widget_autoplay(url)
    li = VideoListItem(row, is_widget=ctx.is_widget).listitem()
    if not is_folder and ctx.playable_direct:
        li.setProperty('IsPlayable', 'true')
    kodi.addItem(handle=handle, url=url, listitem=li, isFolder=is_folder)


def emit_video_rows(handle, rows, url_for_row, ctx=None, *, is_folder=False):
    ctx = ctx or listing_context()
    for row in prepare_rows_for_widget(slice_rows(rows, ctx), ctx):
        try:
            emit_video_row(handle, row, url_for_row(row), ctx, is_folder=is_folder)
        except Exception as exc:
            title = getattr(row, 'title', None) or '?'
            c.log(f'[Listing] emit row failed title={title!r}: {exc}', 1)


def pagination_next(action, page, total, ctx=None, *, page_size=None, extra_query=None):
    ctx = ctx or listing_context()
    if not ctx.paginate:
        return None, None
    page_size = page_size or ctx.page_size
    total_pages = max(1, (total + page_size - 1) // page_size)
    if page >= total_pages:
        return None, None
    next_page = page + 1
    query = {'action': action, 'page': next_page}
    if extra_query:
        query.update(extra_query)
    from urllib.parse import urlencode
    url = f'{sys.argv[0]}?{urlencode(query)}'
    label = f'Next Page ({next_page}/{total_pages})'
    return url, label


def add_next_page(handle, url, label, ctx=None):
    ctx = ctx or listing_context()
    if not ctx.paginate or not url:
        return
    art = c.get_art_path()
    icon = os.path.join(art, 'next.png') if art else c.addon_poster()
    li = kodi.item(label=label or 'Next Page')
    li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
    kodi.addItem(handle=handle, url=url, listitem=li, isFolder=True)


def emit_empty(handle, label, content_type, ctx=None, *, cache=False):
    li = kodi.item(label=label)
    poster = c.addon_poster()
    li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
    kodi.addItem(handle=handle, url=sys.argv[0], listitem=li, isFolder=False)
    finish_directory(handle, content_type, ctx, cache=cache)


_VIEW_CONTENT = frozenset({'movies', 'tvshows', 'seasons', 'episodes'})


def finish_directory(handle, content_type, ctx=None, *, cache=True):
    ctx = ctx or listing_context()
    if ctx.is_widget:
        kodi.touch_widget_active()
    kodi.content(handle, content_type)
    kodi.directory(handle, cacheToDisc=cache)
    if not ctx.is_widget and content_type in _VIEW_CONTENT:
        from . import views
        views.apply_view(content_type, {})

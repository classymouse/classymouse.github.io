# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file videolibrary.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Read-only Kodi VideoLibrary JSON-RPC helpers.

Spike layer for library CM work  -  no writes, no strm creation, no Crew libcache.
Kodi DB is queried for identity + local playcount/resume only; Trakt mirror stays
the source of truth for addon overlays.'''

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import xbmc

from ..modules.classy import c

JsonDict = Dict[str, Any]

# Fields we need to judge join quality (strm  <->  Kodi  <->  ids).
MOVIE_PROPERTIES: Tuple[str, ...] = (
    'title',
    'originaltitle',
    'year',
    'imdbnumber',
    'uniqueid',
    'file',
    'playcount',
    'resume',
    'lastplayed',
    'dateadded',
)

TVSHOW_PROPERTIES: Tuple[str, ...] = (
    'title',
    'originaltitle',
    'year',
    'imdbnumber',
    'uniqueid',
    'episode',
    'watchedepisodes',
    'playcount',
    'dateadded',
)

EPISODE_PROPERTIES: Tuple[str, ...] = (
    'title',
    'season',
    'episode',
    'uniqueid',
    'file',
    'playcount',
    'resume',
    'lastplayed',
    'dateadded',
    'showtitle',
)


class JsonRpcError(Exception):
    def __init__(self, message: str, *, code: int = -1, data: Any = None):
        super().__init__(message)
        self.code = code
        self.data = data


# ---------------------------------------------------------------------------
# Pure helpers  -  unit-testable without Kodi
# ---------------------------------------------------------------------------

_IMDB_RE = re.compile(r'^tt\d{7,8}$', re.I)


def normalize_imdb(value: Any) -> str:
    '''Return tt######## when possible, else stripped string.'''
    if value is None:
        return ''
    text = c.to_str(value).strip()
    if not text:
        return ''
    if text.lower().startswith('tt') and _IMDB_RE.match(text):
        return text.lower()
    digits = re.sub(r'[^0-9]', '', text)
    if not digits:
        return text
    return f'tt{digits}'


def normalize_tmdb(value: Any) -> str:
    if value is None:
        return ''
    text = c.to_str(value).strip()
    if not text or text in ('0', 'None'):
        return ''
    digits = re.sub(r'[^0-9]', '', text)
    return digits or text


def extract_unique_ids(record: JsonDict) -> Dict[str, str]:
    '''Merge Kodi uniqueid dict + legacy imdbnumber.'''
    ids: Dict[str, str] = {}
    uniqueid = record.get('uniqueid')
    if isinstance(uniqueid, dict):
        for key, val in uniqueid.items():
            key_l = c.to_str(key).lower()
            if key_l == 'imdb':
                ids['imdb'] = normalize_imdb(val)
            elif key_l in ('tmdb', 'tvdb'):
                ids[key_l] = normalize_tmdb(val) if key_l == 'tmdb' else c.to_str(val).strip()
            elif val:
                ids[key_l] = c.to_str(val).strip()

    legacy_imdb = record.get('imdbnumber')
    if legacy_imdb and 'imdb' not in ids:
        ids['imdb'] = normalize_imdb(legacy_imdb)
    return ids


def _year_matches(record_year: Any, year: Any) -> bool:
    if year is None or year == '':
        return True
    try:
        return int(record_year) == int(year)
    except (TypeError, ValueError):
        return c.to_str(record_year).strip() == c.to_str(year).strip()


def _title_matches(record: JsonDict, title: str) -> bool:
    if not title:
        return True
    want = c.to_str(title).strip().casefold()
    for key in ('title', 'originaltitle', 'label', 'showtitle'):
        got = c.to_str(record.get(key, '')).strip().casefold()
        if got and got == want:
            return True
    return False


def movie_matches(
    record: JsonDict,
    *,
    imdb: Optional[str] = None,
    tmdb: Optional[str] = None,
    title: Optional[str] = None,
    year: Optional[Union[str, int]] = None,
) -> bool:
    ids = extract_unique_ids(record)
    want_imdb = normalize_imdb(imdb) if imdb else ''
    want_tmdb = normalize_tmdb(tmdb) if tmdb else ''
    if want_imdb and ids.get('imdb') == want_imdb:
        return True
    if want_tmdb and ids.get('tmdb') == want_tmdb:
        return True
    if title and _title_matches(record, title) and _year_matches(record.get('year'), year):
        return True
    return not want_imdb and not want_tmdb and not title


def tvshow_matches(
    record: JsonDict,
    *,
    imdb: Optional[str] = None,
    tmdb: Optional[str] = None,
    title: Optional[str] = None,
    year: Optional[Union[str, int]] = None,
) -> bool:
    return movie_matches(record, imdb=imdb, tmdb=tmdb, title=title, year=year)


def parse_rpc_response(raw: Union[str, bytes, JsonDict]) -> JsonDict:
    if isinstance(raw, dict):
        payload = raw
    else:
        payload = json.loads(c.to_str(raw, errors='ignore') or '{}')
    if not isinstance(payload, dict):
        raise JsonRpcError('JSON-RPC response is not an object')
    if payload.get('error'):
        err = payload['error']
        raise JsonRpcError(
            c.to_str(err.get('message', 'unknown JSON-RPC error')),
            code=int(err.get('code', -1)),
            data=err.get('data'),
        )
    return payload.get('result') or {}


def parse_library_total(result: JsonDict, list_key: str) -> int:
    '''
    Kodi returns limits.total on GetMovies/GetTVShows even when the page is empty.
    Do not use len(rows) with limits {start:0, end:0}  -  that window returns 0 rows.
    '''
    limits = result.get('limits') or {}
    total = limits.get('total')
    if total is not None:
        return int(total)
    return len(result.get(list_key) or [])


# ---------------------------------------------------------------------------
# JSON-RPC transport
# ---------------------------------------------------------------------------

def rpc_call(method: str, params: Optional[JsonDict] = None, *, request_id: str = 'classy-vl') -> JsonDict:
    payload = {
        'jsonrpc': '2.0',
        'method': method,
        'params': params or {},
        'id': request_id,
    }
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    return parse_rpc_response(raw)


def _limits(start: int = 0, end: int = 0) -> JsonDict:
    '''Inclusive start/end indices per Kodi JSON-RPC.'''
    return {'start': int(start), 'end': int(end)}


def _count_probe_limits() -> JsonDict:
    '''Minimal page  -  we only need limits.total from the response.'''
    return _limits(0, 0)


# ---------------------------------------------------------------------------
# Read API
# ---------------------------------------------------------------------------

def get_movies_result(
    *,
    properties: Sequence[str] = MOVIE_PROPERTIES,
    limits: Optional[JsonDict] = None,
    sort: Optional[JsonDict] = None,
    filter_rule: Optional[JsonDict] = None,
) -> JsonDict:
    params: JsonDict = {'properties': list(properties)}
    if limits:
        params['limits'] = limits
    if sort:
        params['sort'] = sort
    if filter_rule:
        params['filter'] = filter_rule
    return rpc_call('VideoLibrary.GetMovies', params)


def get_tvshows_result(
    *,
    properties: Sequence[str] = TVSHOW_PROPERTIES,
    limits: Optional[JsonDict] = None,
    sort: Optional[JsonDict] = None,
    filter_rule: Optional[JsonDict] = None,
) -> JsonDict:
    params: JsonDict = {'properties': list(properties)}
    if limits:
        params['limits'] = limits
    if sort:
        params['sort'] = sort
    if filter_rule:
        params['filter'] = filter_rule
    return rpc_call('VideoLibrary.GetTVShows', params)


# ---------------------------------------------------------------------------
# Read API (row helpers)
# ---------------------------------------------------------------------------

def get_movies(
    *,
    properties: Sequence[str] = MOVIE_PROPERTIES,
    limits: Optional[JsonDict] = None,
    sort: Optional[JsonDict] = None,
    filter_rule: Optional[JsonDict] = None,
) -> List[JsonDict]:
    result = get_movies_result(
        properties=properties,
        limits=limits,
        sort=sort,
        filter_rule=filter_rule,
    )
    return list(result.get('movies') or [])


def get_movie_details(movieid: int, *, properties: Sequence[str] = MOVIE_PROPERTIES) -> JsonDict:
    result = rpc_call('VideoLibrary.GetMovieDetails', {
        'movieid': int(movieid),
        'properties': list(properties),
    })
    return dict(result.get('moviedetails') or {})


def get_tvshows(
    *,
    properties: Sequence[str] = TVSHOW_PROPERTIES,
    limits: Optional[JsonDict] = None,
    sort: Optional[JsonDict] = None,
    filter_rule: Optional[JsonDict] = None,
) -> List[JsonDict]:
    result = get_tvshows_result(
        properties=properties,
        limits=limits,
        sort=sort,
        filter_rule=filter_rule,
    )
    return list(result.get('tvshows') or [])


def get_tvshow_details(tvshowid: int, *, properties: Sequence[str] = TVSHOW_PROPERTIES) -> JsonDict:
    result = rpc_call('VideoLibrary.GetTVShowDetails', {
        'tvshowid': int(tvshowid),
        'properties': list(properties),
    })
    return dict(result.get('tvshowdetails') or {})


def get_episodes(
    *,
    tvshow_title: str,
    properties: Sequence[str] = EPISODE_PROPERTIES,
    limits: Optional[JsonDict] = None,
    season: Optional[int] = None,
) -> List[JsonDict]:
    '''Kodi filters episodes by show *title string*  -  not tvshowid.'''
    filters: List[JsonDict] = [{
        'field': 'tvshow',
        'operator': 'is',
        'value': c.to_str(tvshow_title),
    }]
    if season is not None:
        filters.append({
            'field': 'season',
            'operator': 'is',
            'value': str(int(season)),
        })
    rule = filters[0] if len(filters) == 1 else {'and': filters}
    params: JsonDict = {
        'filter': rule,
        'properties': list(properties),
    }
    if limits:
        params['limits'] = limits
    result = rpc_call('VideoLibrary.GetEpisodes', params)
    return list(result.get('episodes') or [])


def get_episodes_for_show(
    tvshowid: int,
    *,
    properties: Sequence[str] = EPISODE_PROPERTIES,
    limits: Optional[JsonDict] = None,
    season: Optional[int] = None,
) -> List[JsonDict]:
    details = get_tvshow_details(tvshowid)
    title = details.get('title') or details.get('label') or details.get('originaltitle')
    if not title:
        c.log(f'[VideoLibrary] tvshowid={tvshowid} has no title for episode query', 1)
        return []
    return get_episodes(
        tvshow_title=title,
        properties=properties,
        limits=limits,
        season=season,
    )


def find_movies(
    *,
    imdb: Optional[str] = None,
    tmdb: Optional[str] = None,
    title: Optional[str] = None,
    year: Optional[Union[str, int]] = None,
    properties: Sequence[str] = MOVIE_PROPERTIES,
) -> List[JsonDict]:
    want_imdb = normalize_imdb(imdb) if imdb else ''
    if want_imdb:
        try:
            filtered = get_movies(
                properties=properties,
                filter_rule={
                    'field': 'imdbnumber',
                    'operator': 'is',
                    'value': want_imdb,
                },
            )
            if filtered:
                return filtered
        except JsonRpcError as exc:
            c.log(f'[VideoLibrary] imdb filter failed ({exc}); falling back to scan', 1)

    matches = []
    for row in get_movies(properties=properties):
        if movie_matches(row, imdb=imdb, tmdb=tmdb, title=title, year=year):
            matches.append(row)
    return matches


def find_tvshows(
    *,
    imdb: Optional[str] = None,
    tmdb: Optional[str] = None,
    title: Optional[str] = None,
    year: Optional[Union[str, int]] = None,
    properties: Sequence[str] = TVSHOW_PROPERTIES,
) -> List[JsonDict]:
    matches = []
    for row in get_tvshows(properties=properties):
        if tvshow_matches(row, imdb=imdb, tmdb=tmdb, title=title, year=year):
            matches.append(row)
    return matches


def library_counts() -> Tuple[int, int]:
    movie_result = get_movies_result(properties=['title'], limits=_count_probe_limits())
    show_result = get_tvshows_result(properties=['title'], limits=_count_probe_limits())
    return (
        parse_library_total(movie_result, 'movies'),
        parse_library_total(show_result, 'tvshows'),
    )


def summarize_item(record: JsonDict, *, kind: str) -> JsonDict:
    ids = extract_unique_ids(record)
    resume = record.get('resume') or {}
    return {
        'kind': kind,
        'id': record.get('movieid') or record.get('tvshowid') or record.get('episodeid'),
        'title': record.get('title') or record.get('showtitle') or record.get('label'),
        'year': record.get('year'),
        'season': record.get('season'),
        'episode': record.get('episode'),
        'ids': ids,
        'file': record.get('file'),
        'playcount': record.get('playcount'),
        'resume': {
            'position': resume.get('position'),
            'total': resume.get('total'),
        } if isinstance(resume, dict) else {},
    }


def probe_library(*, sample_limit: int = 5, coverage_scan_limit: int = 250) -> JsonDict:
    '''
    Read-only snapshot for dev soak / classy.log.
    Returns counts, sample rows, and identity-field coverage stats.
    '''
    movie_count, show_count = library_counts()
    movies = get_movies(
        limits=_limits(0, max(0, sample_limit - 1)),
        sort={'order': 'descending', 'method': 'dateadded'},
    )
    shows = get_tvshows(
        limits=_limits(0, max(0, sample_limit - 1)),
        sort={'order': 'descending', 'method': 'dateadded'},
    )

    sample_episodes: List[JsonDict] = []
    for show in shows[: min(3, len(shows))]:
        tvshowid = show.get('tvshowid')
        if not tvshowid:
            continue
        eps = get_episodes_for_show(int(tvshowid), limits=_limits(0, 1))
        for ep in eps:
            sample_episodes.append(summarize_item(ep, kind='episode'))
        if len(sample_episodes) >= sample_limit:
            break

    def _coverage(rows: Sequence[JsonDict], *, library_total: int) -> JsonDict:
        scanned = len(rows)
        if scanned == 0:
            return {
                'scanned': 0,
                'library_total': library_total,
                'with_imdb': 0,
                'with_tmdb': 0,
                'with_file': 0,
                'partial': library_total > 0,
            }
        with_imdb = sum(1 for r in rows if extract_unique_ids(r).get('imdb'))
        with_tmdb = sum(1 for r in rows if extract_unique_ids(r).get('tmdb'))
        with_file = sum(1 for r in rows if r.get('file'))
        return {
            'scanned': scanned,
            'library_total': library_total,
            'with_imdb': with_imdb,
            'with_tmdb': with_tmdb,
            'with_file': with_file,
            'partial': scanned < library_total,
        }

    scan_end = max(0, coverage_scan_limit - 1)
    cov_movies = get_movies(
        properties=('imdbnumber', 'uniqueid', 'file'),
        limits=_limits(0, scan_end),
    )
    cov_shows = get_tvshows(
        properties=('imdbnumber', 'uniqueid', 'file'),
        limits=_limits(0, scan_end),
    )

    return {
        'movie_count': movie_count,
        'show_count': show_count,
        'sample_movies': [summarize_item(m, kind='movie') for m in movies],
        'sample_shows': [summarize_item(s, kind='show') for s in shows],
        'sample_episodes': sample_episodes[:sample_limit],
        'coverage': {
            'movies': {
                **_coverage(cov_movies, library_total=movie_count),
                'scan_limit': coverage_scan_limit,
            },
            'shows': {
                **_coverage(cov_shows, library_total=show_count),
                'scan_limit': coverage_scan_limit,
            },
        },
        'kodi_version': getattr(c, 'kodiversion', ''),
    }

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file views.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Per-skin Kodi view mode save/restore (movies / tvshows / seasons / episodes).'''

from __future__ import annotations

import sqlite3 as database

from ..modules import control
from ..modules.classy import c

_VIEW_TYPES = frozenset({'movies', 'tvshows', 'seasons', 'episodes'})
_SQL_ADD = (
    'CREATE TABLE IF NOT EXISTS views '
    '(skin TEXT, view_type TEXT, view_id TEXT, UNIQUE(skin, view_type));'
)


def _load_view_id(content, view_dict=None):
    view_dict = view_dict or {}
    skin = control.skin
    with database.connect(control.viewsFile) as dbcon:
        dbcur = dbcon.cursor()
        dbcur.execute(_SQL_ADD)
        dbcur.execute('SELECT * FROM views WHERE skin = ? AND view_type = ?', (skin, content))
        row = dbcur.fetchone()
    if row and len(row) > 2 and row[2]:
        return str(row[2]).strip()
    try:
        return str(view_dict[skin]).strip()
    except KeyError:
        return ''


def apply_view(content, view_dict=None) -> bool:
    '''Apply stored view mode after endOfDirectory.

    Kodi paints the skin default first; SetViewMode after close switches view and
    the skin may animate that (Aeon Nox fade). No reliable way to avoid from a plugin.
    '''
    content = (content or '').strip().lower()
    if content not in _VIEW_TYPES:
        return False

    view_id = _load_view_id(content, view_dict)
    if not view_id or not view_id.isdigit():
        return False

    control.sleep(50)
    control.execute(f'Container.SetViewMode({view_id})')
    c.log(
        f'[views.apply_view] content={content} view_id={view_id} skin={control.skin}',
        1,
    )
    return True


def set_view(content, view_dict=None) -> bool:
    '''Alias for apply_view  -  kept for Crew-shaped call sites.'''
    return apply_view(content, view_dict)


def add_view(content) -> None:
    '''Persist the current container view mode for this skin + content type.'''
    content = (content or '').strip().lower()
    if content not in _VIEW_TYPES:
        c.log(f'[views.add_view] unsupported content={content!r}', 1)
        control.finish_dialog_route()
        return
    try:
        control.idle()
        skin = control.skin
        view_id = str(control.getCurrentViewId())
        view_name = control.infoLabel('Container.Viewmode')
        record = (skin, content, view_id)
        control.makeFile(control.dataPath)
        with database.connect(control.viewsFile) as dbcon:
            dbcur = dbcon.cursor()
            dbcur.execute(_SQL_ADD)
            dbcur.execute('DELETE FROM views WHERE skin = ? AND view_type = ?', (skin, content))
            dbcur.execute('INSERT INTO views VALUES (?, ?, ?)', record)

        c.log(
            f'[views.add_view] saved content={content} view_id={view_id} '
            f'view_name={view_name!r} skin={skin}',
            1,
        )
        skin_name = control.addon(skin).getAddonInfo('name')
        skin_icon = control.addon(skin).getAddonInfo('icon')
        message = view_name or view_id
        control.infoDialog(message, heading=skin_name, sound=True, icon=skin_icon)
    except database.Error as exc:
        c.log(f'[views.add_view] database error: {exc}', 1)
    except Exception as exc:
        c.log(f'[views.add_view] error: {exc}', 1)
    finally:
        control.finish_dialog_route()
        control.schedule_busy_dismiss((0.5, 2.0))

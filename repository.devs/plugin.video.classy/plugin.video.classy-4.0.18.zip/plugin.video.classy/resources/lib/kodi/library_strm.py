# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file library_strm.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Parse Crew-style .strm files for library spike cross-checks.

Read-only  -  walks folders, extracts ids from strm play URLs, does not write.'''

from __future__ import annotations

import os
from typing import Any, Dict, Iterator, List, Optional, Tuple
from urllib.parse import parse_qsl, urlparse

import xbmcvfs

from ..modules.classy import c
from .videolibrary import normalize_imdb, normalize_tmdb

StrmRecord = Dict[str, Any]

_VFS_PREFIXES = ('special://', 'plugin://', 'sources://', 'rss://')


def path_candidates(path: str) -> List[str]:
    '''All URI forms worth trying for listdir (Kodi VFS is inconsistent on exists()).'''
    text = c.to_str(path).strip().replace('\\', '/')
    if not text:
        return []

    def _add(bucket: List[str], value: str) -> None:
        value = c.to_str(value).strip().replace('\\', '/').rstrip('/')
        if value and value not in bucket:
            bucket.append(value)

    out: List[str] = []
    _add(out, text)
    try:
        _add(out, xbmcvfs.translatePath(text))
    except Exception:
        pass
    if text.lower().startswith(_VFS_PREFIXES):
        # Some builds only list via translated local paths.
        try:
            _add(out, xbmcvfs.translatePath(text.rstrip('/') + '/'))
        except Exception:
            pass
    return out


def vfs_io_path(path: str) -> str:
    '''Prefer the original setting URI; callers resolve via path_candidates().'''
    text = c.to_str(path).strip().replace('\\', '/')
    if not text:
        return ''
    if text.lower().startswith(_VFS_PREFIXES):
        return text.rstrip('/')
    return c.to_str(xbmcvfs.translatePath(text)).replace('\\', '/').rstrip('/')


def display_vfs_path(path: str) -> str:
    '''Human-readable path for logs only.'''
    text = c.to_str(path).strip()
    if not text:
        return ''
    return c.to_str(xbmcvfs.translatePath(text)).replace('\\', '/')


def normalize_vfs_path(path: str) -> str:
    '''Alias for vfs_io_path (back-compat with probe tooling).'''
    return vfs_io_path(path)


def join_vfs_path(base: str, name: str) -> str:
    base = c.to_str(base).strip().replace('\\', '/').rstrip('/')
    name = c.to_str(name).strip().replace('\\', '/')
    if not base:
        return name
    return f'{base}/{name}'


def _listdir_at(root: str) -> Tuple[List[str], List[str]]:
    '''xbmcvfs.listdir first, then os.listdir for local translated paths.'''
    try:
        listing = xbmcvfs.listdir(root)
        if isinstance(listing, (list, tuple)) and len(listing) >= 2:
            dirs = [c.to_str(x) for x in (listing[0] or [])]
            files = [c.to_str(x) for x in (listing[1] or [])]
            return dirs, files
    except Exception:
        pass

    local = root
    if local.lower().startswith(_VFS_PREFIXES):
        try:
            local = c.to_str(xbmcvfs.translatePath(local)).replace('\\', '/')
        except Exception:
            local = ''
    if local and os.path.isdir(local):
        try:
            names = os.listdir(local)
            dirs = [
                n for n in names
                if os.path.isdir(os.path.join(local, n))
            ]
            files = [
                n for n in names
                if os.path.isfile(os.path.join(local, n))
            ]
            return dirs, files
        except Exception:
            pass
    return [], []


def resolve_listable_root(path: str) -> str:
    '''
    Pick the first path variant we can actually list.
    Crew never gates on xbmcvfs.exists  -  listdir (or os.listdir) is the truth.
    '''
    for cand in path_candidates(path):
        dirs, files = _listdir_at(cand)
        if dirs or files:
            return cand
        # Empty directory is still a valid root (Movies may have subfolders only).
        local = cand
        if cand.lower().startswith(_VFS_PREFIXES):
            try:
                local = c.to_str(xbmcvfs.translatePath(cand)).replace('\\', '/')
            except Exception:
                local = ''
        if local and os.path.isdir(local):
            return cand
        try:
            xbmcvfs.listdir(cand)
            return cand
        except Exception:
            continue
    return ''


def _read_text(path: str) -> str:
    try:
        f = xbmcvfs.File(path)
        try:
            raw = f.read()
        finally:
            f.close()
        return c.to_str(raw).strip()
    except Exception:
        pass
    local = path
    if local.lower().startswith(_VFS_PREFIXES):
        local = display_vfs_path(local)
    with open(local, 'r', encoding='utf-8', errors='replace') as handle:
        return handle.read().strip()


def parse_strm_content(content: str) -> Optional[StrmRecord]:
    '''Parse a strm line (plugin URL with query params).'''
    text = c.to_str(content).strip()
    if not text:
        return None
    query = ''
    if '?' in text:
        query = text.split('?', 1)[1]
    else:
        parsed = urlparse(text)
        query = parsed.query
    if not query:
        return None
    params = dict(parse_qsl(query, keep_blank_values=True))
    season = params.get('season')
    episode = params.get('episode')
    tvshowtitle = params.get('tvshowtitle') or params.get('show')
    kind = 'episode' if season and episode else 'movie'
    return {
        'kind': kind,
        'path': '',
        'title': params.get('title') or params.get('name') or tvshowtitle,
        'tvshowtitle': tvshowtitle,
        'year': params.get('year'),
        'imdb': normalize_imdb(params.get('imdb')),
        'tmdb': normalize_tmdb(params.get('tmdb')),
        'season': int(season) if season and str(season).isdigit() else None,
        'episode': int(episode) if episode and str(episode).isdigit() else None,
        'action': params.get('action') or 'play',
    }


def _listdir(root: str) -> Tuple[List[str], List[str]]:
    return _listdir_at(root)


def iter_strm_files(root: str) -> Iterator[str]:
    working = resolve_listable_root(root)
    if not working:
        tried = ', '.join(path_candidates(root)) or root
        c.log(
            f'[LibraryStrm] cannot list library root (tried: {tried})',
            1,
        )
        return

    def _walk(current: str) -> Iterator[str]:
        dirs, files = _listdir_at(current)
        for name in files:
            if name.lower().endswith('.strm'):
                yield join_vfs_path(current, name)
        for name in dirs:
            yield from _walk(join_vfs_path(current, name))

    yield from _walk(working)


def scan_strm_folder(root: str, *, limit: int = 50) -> List[StrmRecord]:
    working = resolve_listable_root(root)
    rows: List[StrmRecord] = []
    for path in iter_strm_files(root):
        try:
            parsed = parse_strm_content(_read_text(path))
            if not parsed:
                continue
            parsed['path'] = path
            rows.append(parsed)
            if len(rows) >= limit:
                break
        except Exception as exc:
            c.log(f'[LibraryStrm] skip {path}: {exc}', 1)
    if not rows and root:
        tried = ', '.join(path_candidates(root))
        c.log(
            f'[LibraryStrm] 0 strm files under {working or root} (tried: {tried})',
            1,
        )
    return rows


def cross_check_strm_records(
    records: List[StrmRecord],
    *,
    find_movies,
    find_tvshows,
    get_episodes_for_show,
) -> List[Dict[str, Any]]:
    '''
    For each strm record, attempt Kodi lookup by ids.
    Inject videolibrary find_* funcs to keep this module testable offline.
    '''
    report: List[Dict[str, Any]] = []
    for rec in records:
        entry: Dict[str, Any] = {
            'strm': rec,
            'kodi_match': None,
            'status': 'unknown',
        }
        try:
            if rec.get('kind') == 'movie':
                matches = find_movies(
                    imdb=rec.get('imdb'),
                    tmdb=rec.get('tmdb'),
                    title=rec.get('title'),
                    year=rec.get('year'),
                )
                if matches:
                    entry['kodi_match'] = matches[0]
                    entry['status'] = 'found'
                else:
                    entry['status'] = 'missing'
            else:
                matches = find_tvshows(
                    imdb=rec.get('imdb'),
                    tmdb=rec.get('tmdb'),
                    title=rec.get('tvshowtitle') or rec.get('title'),
                    year=rec.get('year'),
                )
                if not matches:
                    entry['status'] = 'show_missing'
                else:
                    show = matches[0]
                    entry['kodi_match'] = show
                    tvshowid = show.get('tvshowid')
                    if tvshowid and rec.get('season') and rec.get('episode'):
                        eps = get_episodes_for_show(int(tvshowid), season=int(rec['season']))
                        hit = [
                            e for e in eps
                            if int(e.get('episode', -1)) == int(rec['episode'])
                        ]
                        entry['status'] = 'found' if hit else 'episode_missing'
                    else:
                        entry['status'] = 'show_found'
        except Exception as exc:
            entry['status'] = 'error'
            entry['error'] = c.to_str(exc)
        report.append(entry)
    return report


def guess_crew_library_paths() -> Dict[str, str]:
    '''Best-effort read of Crew library folders (for cross-check only).'''
    paths: Dict[str, str] = {}
    for addon_id in ('plugin.video.thecrew', 'script.module.thecrew'):
        try:
            import xbmcaddon
            addon = xbmcaddon.Addon(addon_id)
            for key in ('library.movie', 'library.tv'):
                if key in paths:
                    continue
                val = addon.getSetting(key)
                if val:
                    paths[key] = val
        except Exception:
            pass
    return paths

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file video_listitem.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Single Kodi exit for video rows  -  InfoTag video only.'''

import xbmcgui

from ..metadata import extract
from ..metadata.video_row import VideoRow
from ..modules.unaired import display_label, is_unaired, show_unaired_enabled
from ..play.trailer import trailer_url_for_row
from .context_menus import apply_context_menu


_VIDEO_INFO_KEYS = frozenset({
    'title', 'originaltitle', 'tvshowtitle', 'sorttitle', 'plot', 'plotoutline',
    'tagline', 'year', 'season', 'episode', 'premiered', 'aired', 'status',
    'genre', 'country', 'studio', 'mpaa', 'rating', 'userrating', 'votes',
    'duration', 'director', 'writer', 'trailer', 'mediatype', 'playcount',
    'dateadded', 'lastplayed', 'imdbnumber',
})

_LIST_KEYS = frozenset({'genre', 'country', 'studio', 'director', 'writer'})

# Crew / Aeon convention: 6 = unwatched (resume arrow when setResumePoint set), 7 = watched.
OVERLAY_UNWATCHED = 6
OVERLAY_WATCHED = 7


def tagdata_clean(meta):
    if not meta:
        return {}
    clean = {}
    for key, value in meta.items():
        if key not in _VIDEO_INFO_KEYS:
            continue
        if value is None or value == '':
            continue
        if key in _LIST_KEYS:
            clean[key] = extract.split_to_list(value)
        else:
            clean[key] = value
    return clean


class VideoListItem:
    def __init__(self, row, *, is_widget=None, include_context_menu=True):
        self.row = row if isinstance(row, VideoRow) else VideoRow.from_dict(row)
        if self.row.mediatype == 'episode' and not self.row.title:
            self.row.title = (
                f'Episode {int(self.row.episode)}' if self.row.episode else 'Episode'
            )
        label = display_label(self.row)
        self._li = xbmcgui.ListItem(label=label)
        if self.row.mediatype == 'episode' and self.row.tvshowtitle:
            self._li.setLabel2(self.row.tvshowtitle)
        elif self.row.mediatype in ('movie', 'tvshow') and (self.row.genre or '').strip():
            self._li.setLabel2(str(self.row.genre).strip())
        self._apply_art()
        self._apply_info()
        if include_context_menu:
            apply_context_menu(self._li, self.row, is_widget=is_widget)

    @classmethod
    def from_row(cls, row, **kwargs):
        return cls(row, **kwargs)

    def listitem(self):
        return self._li

    def _apply_art(self):
        poster = self.row.poster or self.row.thumb or ''
        fanart = self.row.fanart or ''
        thumb = self.row.thumb or poster
        art = {}
        if poster:
            art['poster'] = poster
            art['icon'] = poster
            if self.row.mediatype == 'tvshow':
                art['tvshow.poster'] = poster
        if thumb:
            art['thumb'] = thumb
        if fanart:
            art['fanart'] = fanart
        if art:
            self._li.setArt(art)
        if fanart:
            self._li.setProperty('Fanart_Image', fanart)

    def _apply_info(self):
        episode_title = self.row.title
        if self.row.mediatype == 'episode' and not episode_title:
            episode_title = (
                f'Episode {int(self.row.episode)}' if self.row.episode else 'Episode'
            )

        meta = tagdata_clean({
            'title': episode_title,
            'originaltitle': self.row.originaltitle or episode_title,
            'tvshowtitle': self.row.tvshowtitle,
            'plot': self.row.plot,
            'tagline': self.row.tagline,
            'year': int(self.row.year) if str(self.row.year).isdigit() else 0,
            'season': int(self.row.season or 0),
            'episode': int(self.row.episode or 0),
            'premiered': self.row.premiered,
            'aired': self.row.premiered,
            'status': self.row.status,
            'genre': self.row.genre,
            'studio': self.row.studio or self.row.network,
            'mpaa': self.row.mpaa,
            'rating': float(self.row.rating or 0),
            'votes': int(self.row.votes or 0),
            'duration': int(self.row.duration or 0),
            'director': self.row.director,
            'writer': self.row.writer,
            'trailer': self.row.trailer,
            'mediatype': self.row.mediatype or 'video',
            'playcount': int(self.row.playcount or 0),
        })
        info_tag = self._li.getVideoInfoTag()
        if meta.get('mediatype'):
            info_tag.setMediaType(str(meta.pop('mediatype')))
        if self.row.mediatype == 'episode':
            info_tag.setTitle(str(episode_title))
            meta.pop('title', None)
            if self.row.tvshowtitle:
                info_tag.setTvShowTitle(str(self.row.tvshowtitle))
                meta.pop('tvshowtitle', None)
            if self.row.season:
                info_tag.setSeason(int(self.row.season))
                meta.pop('season', None)
            if self.row.episode:
                info_tag.setEpisode(int(self.row.episode))
                meta.pop('episode', None)
        elif meta.get('title'):
            info_tag.setTitle(str(meta.pop('title')))
        if meta.get('plot'):
            info_tag.setPlot(str(meta.pop('plot')))
        if meta.get('tvshowtitle') and self.row.mediatype != 'tvshow':
            info_tag.setTvShowTitle(str(meta.pop('tvshowtitle')))
        elif meta.get('tvshowtitle'):
            meta.pop('tvshowtitle')
        if meta.get('season') and self.row.mediatype in ('episode', 'season'):
            info_tag.setSeason(int(meta.pop('season')))
        elif meta.get('season'):
            meta.pop('season')
        if meta.get('episode') and self.row.mediatype == 'episode':
            info_tag.setEpisode(int(meta.pop('episode')))
        elif meta.get('episode'):
            meta.pop('episode')
        if meta.get('premiered'):
            info_tag.setPremiered(str(meta.pop('premiered')))
        year_val = meta.pop('year', None)
        if year_val:
            try:
                info_tag.setYear(int(year_val))
            except (TypeError, ValueError):
                pass
        rating_val = meta.pop('rating', None)
        votes_val = int(meta.pop('votes', 0) or 0)
        if rating_val:
            try:
                # Matrix+: setRating(rating, type='', votes=0, default=True)
                info_tag.setRating(float(rating_val), votes=votes_val)
            except TypeError:
                info_tag.setRating(float(rating_val))
                if votes_val and hasattr(info_tag, 'setVotes'):
                    try:
                        info_tag.setVotes(votes_val)
                    except Exception:
                        pass
        if meta.get('genre'):
            info_tag.setGenres(meta.pop('genre'))
        duration_val = int(meta.pop('duration', 0) or 0)
        if duration_val > 0:
            try:
                info_tag.setDuration(duration_val)
            except Exception:
                pass
        if meta.get('director'):
            info_tag.setDirectors(meta.pop('director'))
        if meta.get('writer'):
            info_tag.setWriters(meta.pop('writer'))
        if meta.get('studio'):
            info_tag.setStudios(meta.pop('studio'))
        trailer_prop = trailer_url_for_row(self.row)

        if trailer_prop:
            info_tag.setTrailer(trailer_prop)
        playcount = int(self.row.playcount or 0)
        if playcount:
            try:
                info_tag.setPlaycount(playcount)
            except Exception:
                pass
        unique = {}
        if self.row.imdb:
            unique['imdb'] = str(self.row.imdb)
        if self.row.tmdb:
            unique['tmdb'] = str(self.row.tmdb)
        if self.row.tvdb:
            unique['tvdb'] = str(self.row.tvdb)
        if unique:
            info_tag.setUniqueIDs(unique)
        self._apply_watch_overlay(info_tag)
        self._apply_resume(info_tag)
        if self.row.castwiththumb:
            try:
                from xbmc import Actor
                cast = [
                    Actor(name=c.get('name', ''), role=c.get('role', ''),
                          thumbnail=c.get('thumbnail', ''))
                    for c in self.row.castwiththumb
                ]
                info_tag.setCast(cast)
            except Exception:
                pass

    def _apply_watch_overlay(self, info_tag):
        '''Crew-style overlay: 7 when fully watched, 6 otherwise.'''
        overlay = int(self.row.overlay or 0)
        if not overlay:
            if int(self.row.playcount or 0) > 0:
                overlay = OVERLAY_WATCHED
            elif float(self.row.resume_point or 0) > 0:
                overlay = OVERLAY_UNWATCHED
        if not overlay:
            return
        try:
            if hasattr(info_tag, 'setOverlay'):
                info_tag.setOverlay(overlay)
        except Exception:
            pass

    def _apply_resume(self, info_tag):
        progress = float(self.row.resume_point or 0)
        if progress <= 0:
            return
        total = int(self.row.duration or 0)
        if total <= 0:
            return
        resume_secs = (total * progress) / 100.0
        if resume_secs <= 0:
            return
        try:
            info_tag.setDuration(total)
        except Exception:
            pass
        try:
            info_tag.setResumePoint(resume_secs, total)
        except Exception:
            try:
                info_tag.setResumePoint(resume_secs)
            except Exception:
                pass

# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file api.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew (cm)
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*

Orion API wrapper  -  install/auth/tools + scrape helpers for Classy 4.x.

Uses script.module.orion when present (runtime detect only; not in addon.xml).'''

import json
import os
import sys
import time
import traceback
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcgui
import xbmcvfs
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..modules import keys, source_utils
from ..modules.client import addon_data_path
from ..modules.crewruntime import c

_TIER_CACHE_FILE = 'orion_tier.json'
_TIER_CACHE_TTL = 86400  # 24h  -  quota fields; package name kept if live read fails

_ORION_MODULE_AVAILABLE = False
Orion = None

try:
    _orion_lib_path = xbmcvfs.translatePath('special://home/addons/script.module.orion/lib')
    if os.path.isdir(_orion_lib_path) and _orion_lib_path not in sys.path:
        sys.path.insert(0, _orion_lib_path)
    from orion import Orion

    _ORION_MODULE_AVAILABLE = True
except ImportError:
    pass


def _orion_enabled_setting():
    value = c.get_setting('orion.enabled')
    if value is None or value == '':
        return True
    return str(value).lower() not in ('false', '0', 'no', 'off')


class OrionApi:
    '''Lean Orion wrapper  -  scrape, tier limits, and Tools menu actions.'''

    def __init__(self):
        self.app_key = keys.orion_key
        self.base_url = 'https://api.orionoid.com'
        self.session = requests.Session()
        self.session.mount(self.base_url, HTTPAdapter(max_retries=Retry(total=3, backoff_factor=0.5)))
        self.orion = None
        if _ORION_MODULE_AVAILABLE:
            try:
                self.orion = Orion(self.app_key)
            except Exception:
                self.orion = None

    def __del__(self):
        if hasattr(self, 'session'):
            try:
                self.session.close()
            except Exception:
                pass

    def is_orion_installed(self):
        return bool(xbmc.getCondVisibility('System.HasAddon(script.module.orion)'))

    def module_ready(self):
        return self.orion is not None

    def get_credentials_info(self):
        try:
            if self.orion is None:
                return False
            return bool(self.orion.userEnabled() and self.orion.userValid())
        except (AttributeError, TypeError):
            return False

    def scrape_allowed(self):
        if not _orion_enabled_setting():
            return False
        if not self.is_orion_installed() or self.orion is None:
            return False
        return self.get_credentials_info()

    def _tier_cache_path(self):
        return os.path.join(addon_data_path(), _TIER_CACHE_FILE)

    def _load_tier_cache(self):
        path = self._tier_cache_path()
        try:
            if not os.path.isfile(path):
                return {}
            with open(path, 'r', encoding='utf-8') as handle:
                payload = json.load(handle)
            if not isinstance(payload, dict):
                return {}
            saved_at = payload.get('saved_at', 0)
            if saved_at and (time.time() - float(saved_at)) > _TIER_CACHE_TTL:
                return {}
            tier = payload.get('tier')
            return tier if isinstance(tier, dict) else {}
        except (OSError, ValueError, TypeError) as exc:
            c.log(f'[Orion] tier cache read failed: {exc}', 2)
            return {}

    def _save_tier_cache(self, tier_info):
        if not isinstance(tier_info, dict) or not tier_info.get('package'):
            return
        path = self._tier_cache_path()
        try:
            profile = addon_data_path()
            if not os.path.isdir(profile):
                os.makedirs(profile)
            payload = {'saved_at': time.time(), 'tier': tier_info}
            with open(path, 'w', encoding='utf-8') as handle:
                json.dump(payload, handle)
        except OSError as exc:
            c.log(f'[Orion] tier cache write failed: {exc}', 2)

    def _clear_tier_cache(self):
        path = self._tier_cache_path()
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass

    @staticmethod
    def _tier_int(value, default=0):
        if value is None:
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _parse_tier_from_user_data(self, user_data):
        if not user_data or not isinstance(user_data, dict):
            return {}

        # Legacy API envelope (Crew 3.x shape).
        nested = user_data.get('result', {})
        if isinstance(nested, dict) and nested.get('data'):
            data = nested.get('data') or {}
            limits = data.get('limit', {}).get('link', {})
            package = data.get('package', {})
            tier = {
                'package': package.get('name', 'Unknown') if isinstance(package, dict) else str(package or 'Unknown'),
                'link_limit': self._tier_int(limits.get('total')),
                'link_used': self._tier_int(limits.get('used')),
                'link_remaining': self._tier_int(limits.get('remaining')),
            }
            if tier['package'] != 'Unknown':
                return tier

        # Flat OrionUser mData (script.module.orion default).
        subscription = user_data.get('subscription') or {}
        package_info = subscription.get('package') if isinstance(subscription, dict) else {}
        streams = (user_data.get('requests') or {}).get('streams') or {}
        daily = streams.get('daily') if isinstance(streams, dict) else {}
        if not isinstance(daily, dict):
            daily = {}
        if not isinstance(package_info, dict):
            package_info = {}

        return {
            'package': package_info.get('name', 'Unknown'),
            'link_limit': self._tier_int(daily.get('limit')),
            'link_used': self._tier_int(daily.get('used')),
            'link_remaining': self._tier_int(daily.get('remaining')),
        }

    def _fetch_tier_live(self):
        if self.orion is None or not self.get_credentials_info():
            return {}

        # Same source as Orion's user dialog (OrionUser instance).
        try:
            from orion.modules.orionuser import OrionUser

            user = OrionUser.instance()
            package = user.subscriptionPackageName()
            m_data = user.data() if hasattr(user, 'data') else {}
            if not isinstance(m_data, dict):
                m_data = {}
            streams = (m_data.get('requests') or {}).get('streams') or {}
            daily = streams.get('daily') if isinstance(streams, dict) else {}
            if not isinstance(daily, dict):
                daily = {}

            tier = {
                'package': package or 'Unknown',
                'link_limit': self._tier_int(daily.get('limit')),
                'link_used': self._tier_int(daily.get('used')),
                'link_remaining': self._tier_int(daily.get('remaining')),
            }
            if tier['package'] != 'Unknown':
                return tier
        except (ImportError, AttributeError, KeyError, TypeError) as exc:
            c.log(f'[Orion] tier live (OrionUser) failed: {exc}', 1)

        try:
            user_data = self.orion.user()
            tier = self._parse_tier_from_user_data(user_data)
            if tier.get('package') and tier.get('package') != 'Unknown':
                return tier
        except (AttributeError, KeyError, TypeError) as exc:
            c.log(f'[Orion] tier live (user dict) failed: {exc}', 1)

        return {}

    def get_user_tier_info(self, use_cache=True):
        if self.orion is None or not self.get_credentials_info():
            self._clear_tier_cache()
            return {}

        live = self._fetch_tier_live()
        if live and live.get('package') and live.get('package') != 'Unknown':
            live['source'] = 'live'
            self._save_tier_cache({k: live[k] for k in ('package', 'link_limit', 'link_used', 'link_remaining')})
            return live

        c.log('[Orion] tier info live read failed  -  checking cache', 1)
        if not use_cache:
            return {}

        cached = self._load_tier_cache()
        if cached:
            cached = dict(cached)
            cached['source'] = 'cache'
            c.log(
                f'[Orion] tier info from cache: {cached.get("package")} '
                f'({cached.get("link_remaining", 0)}/{cached.get("link_limit", 0)} remaining)',
                0,
            )
            return cached

        c.log('[Orion] tier info unavailable (live + cache)', 1)
        return {}

    def get_smart_limit(self):
        tier_info = self.get_user_tier_info()
        if not tier_info:
            c.log('[Orion] smart limit=25 (no tier info)', 1)
            return 25

        package = tier_info.get('package', '').lower()
        remaining = tier_info.get('link_remaining', 0)
        total_limit = tier_info.get('link_limit', 0)
        source = tier_info.get('source', 'live')
        percent_remaining = (remaining / total_limit) * 100 if total_limit > 0 else 0

        if 'expert' in package or 'premium' in package:
            if percent_remaining > 50:
                limit = 250
            elif percent_remaining > 25:
                limit = 150
            elif percent_remaining > 10:
                limit = 100
            else:
                limit = 50
        elif 'basic' in package or 'standard' in package:
            if percent_remaining > 50:
                limit = 100
            elif percent_remaining > 25:
                limit = 75
            else:
                limit = 50
        elif percent_remaining > 50:
            limit = 50
        elif percent_remaining > 25:
            limit = 35
        else:
            limit = 25

        c.log(
            f'[Orion] smart limit={limit} (tier={tier_info.get("package")}, source={source})',
            0,
        )
        return limit

    def get_movie(self, imdb, limit=None):
        if self.orion is None:
            return []
        limit_count = limit if limit is not None else self.orion.FilterSettings
        results = self.orion.streams(
            type=self.orion.TypeMovie,
            idImdb=imdb,
            limitCount=limit_count,
        )
        return results if isinstance(results, list) else []

    def get_episode(self, imdb=0, tmdb=0, title='', season=0, episode=0, limit=None):
        if self.orion is None:
            return []
        limit_count = limit if limit is not None else self.orion.FilterSettings

        if imdb and imdb != 0:
            results = self.orion.streams(
                type=self.orion.TypeShow,
                idImdb=imdb,
                numberSeason=season,
                numberEpisode=episode,
                limitCount=limit_count,
            )
        elif tmdb and tmdb != 0:
            results = self.orion.streams(
                type=self.orion.TypeShow,
                idTmdb=tmdb,
                numberSeason=season,
                numberEpisode=episode,
                limitCount=limit_count,
            )
        elif title:
            results = self.orion.streams(
                type=self.orion.TypeShow,
                query=title,
                limitCount=limit_count,
            )
        else:
            return []

        return results if isinstance(results, list) else []

    def do_orion_scrape(self, data, scrape_type='movie'):
        try:
            if not isinstance(data, list):
                if data:
                    c.log(f'[Orion] unexpected payload type: {type(data)}', 1)
                return []
            if not data:
                return []

            sources = []
            for index, item in enumerate(data):
                try:
                    links = item.get('links', [])
                    url = next((link for link in links if link.startswith('magnet:')), '')
                    if not url:
                        continue

                    fileinfo = item.get('file', {})
                    name = fileinfo.get('name', '')
                    path = fileinfo.get('path', '')
                    size = fileinfo.get('size', 0)
                    pack = fileinfo.get('pack')
                    display_name = path or name
                    if not name:
                        continue

                    video = item.get('video', {})
                    audio = item.get('audio', {})
                    stream_info = item.get('stream', {})
                    quality, info = source_utils.get_release_quality(display_name)

                    if video:
                        codec = video.get('codec', '')
                        if codec:
                            codec_map = {
                                'h264': 'H.264', 'h265': 'HEVC', 'hevc': 'HEVC',
                                'x264': 'H.264', 'x265': 'HEVC',
                            }
                            codec_display = codec_map.get(codec.lower(), codec.upper())
                            if codec_display and codec_display not in ' '.join(info):
                                info.append(codec_display)

                    if audio:
                        channels = audio.get('channels', '')
                        codec = audio.get('codec', '')
                        if codec:
                            audio_map = {
                                'dd': 'DD', 'ddp': 'DD+', 'dts': 'DTS',
                                'atmos': 'ATMOS', 'truehd': 'TrueHD',
                            }
                            audio_display = audio_map.get(codec.lower(), codec.upper())
                            if audio_display and audio_display not in ' '.join(info):
                                info.append(audio_display)
                        if channels and str(channels) not in ' '.join(info):
                            info.append(f'{channels}CH')

                    if stream_info:
                        source_type = stream_info.get('source', '')
                        if source_type:
                            source_map = {
                                'webrip': 'WEB-DL', 'webdl': 'WEB-DL',
                                'bluray': 'BluRay', 'brrip': 'BRRip',
                            }
                            source_display = source_map.get(source_type.lower(), source_type)
                            if source_display and source_display not in ' '.join(info):
                                info.append(source_display)

                    try:
                        dsize, isize = source_utils.file_size(size)
                    except Exception:
                        dsize, isize = 0.0, ''
                        info.insert(0, isize)

                    row = {
                        'provider': 'Orion',
                        'source': 'Torrent',
                        'quality': quality,
                        'language': 'en',
                        'url': url,
                        'info': ' | '.join(info) if isinstance(info, list) else info,
                        'direct': False,
                        'debridonly': True,
                        'size': dsize,
                        'name': display_name,
                    }
                    if scrape_type != 'movie' and pack:
                        row['package'] = pack
                    sources.append(row)
                except Exception as item_error:
                    c.log(f'[Orion] item {index} failed: {item_error}', 1)
                    if c.devmode:
                        c.log(traceback.format_exc(), 1)
            return sources
        except Exception as exc:
            c.log(f'[Orion] scrape parse failed: {exc}', 1)
            return []

    def authorize_orion(self):
        try:
            if self.orion is None:
                xbmcgui.Dialog().ok(
                    '[B][COLOR lightskyblue]Orion[/COLOR][/B]',
                    'Orion is not installed.[CR][CR]Use [B]Install / Setup[/B] first.',
                )
                return False
            ok = bool(self.orion.userLogin())
            if ok:
                self.get_user_tier_info(use_cache=False)
            return ok
        except (AttributeError, RuntimeError) as exc:
            c.log(f'[Orion] authorize failed: {exc}', 1)
            return False

    def register_orion(self):
        try:
            if self.orion is None:
                return
            self.orion.userRegister()
        except (AttributeError, RuntimeError) as exc:
            c.log(f'[Orion] register failed: {exc}', 1)

    def settings_orion(self):
        self._orion_ui_action('settingsLaunch')

    def settings_orion_filters(self):
        '''Per-app filter tab (Classy / Crew app key in Orion settings).'''
        self._orion_ui_action('settingsFilters', app=True)

    def global_filters_orion(self):
        '''Universal filters tab  -  settingsFiltersGlobal() is only a getter in Orion.'''
        self._orion_ui_action('settingsFilters', app=None)

    def server_orion(self):
        self._orion_ui_action('serverDialog')

    def user_info_orion(self):
        self._orion_ui_action('userDialog')

    def _orion_ui_action(self, method_name, **kwargs):
        try:
            if self.orion is None:
                xbmcgui.Dialog().ok(
                    '[B][COLOR lightskyblue]Orion[/COLOR][/B]',
                    'Orion is not installed or not authorized.',
                )
                return
            if not self.get_credentials_info():
                xbmcgui.Dialog().ok(
                    '[B][COLOR lightskyblue]Orion[/COLOR][/B]',
                    'Authorize your Orion account first.',
                )
                return
            method = getattr(self.orion, method_name)
            if kwargs:
                method(**kwargs)
            else:
                method()
        except (AttributeError, RuntimeError, TypeError) as exc:
            c.log(f'[Orion] {method_name} failed: {exc}', 1)

    def install_orion(self):
        try:
            dialog = xbmcgui.Dialog()
            if self.is_orion_installed():
                dialog.ok(
                    '[B][COLOR lightskyblue]Orion[/COLOR][/B] : Install / Setup',
                    'Orion is already installed.[CR][CR]'
                    'Use [B]Authorize / Login[/B] to connect your account,[CR]'
                    'or [B]Full Settings[/B] to configure it.',
                )
                return

            if not dialog.yesno(
                '[B][COLOR lightskyblue]Orion[/COLOR][/B] : Install / Setup',
                'Orion is [B]not installed[/B]. The installation has a few steps:[CR][CR]'
                '[B]Step 1[/B]  -  Add Orion repository source [COLOR lawngreen](automatic)[/COLOR][CR]'
                '[B]Step 2[/B]  -  Install the Orion repository addon[CR]'
                '[B]Step 3[/B]  -  Install [B]script.module.orion[/B] from the repo[CR]'
                '[B]Step 4[/B]  -  Authorize your account[CR][CR]'
                'Continue?',
                nolabel='Cancel',
                yeslabel='Continue',
            ):
                return

            if self._add_orion_repo_source():
                dialog.ok(
                    '[B][COLOR lightskyblue]Orion[/COLOR][/B] : Step 1 Complete',
                    '[COLOR lawngreen]Repository source added:[/COLOR] https://repo.orionoid.com[CR][CR]'
                    'Click [B]OK[/B] to install the [B]Orion Repository[/B] addon.[CR]'
                    'Confirm any Kodi dialogs that appear.',
                )
            else:
                dialog.ok(
                    '[B][COLOR lightskyblue]Orion[/COLOR][/B] : Step 1',
                    'Could not add source automatically.[CR][CR]'
                    'Please add [B]https://repo.orionoid.com[/B] manually via:[CR]'
                    'Settings > File Manager > Add source',
                )

            xbmc.executebuiltin('InstallAddon(repository.orion)')
            dialog.ok(
                '[B][COLOR lightskyblue]Orion[/COLOR][/B] : Step 3',
                'If the repository installed successfully, click [B]OK[/B] to install [B]script.module.orion[/B].[CR][CR]'
                'Confirm any Kodi dialogs that appear.',
            )
            xbmc.executebuiltin('InstallAddon(script.module.orion)')
            dialog.ok(
                '[B][COLOR lightskyblue]Orion[/COLOR][/B] : Step 4',
                'Once Orion is installed, return to this menu and select[CR]'
                '[B]Authorize / Login[/B] to connect your account.[CR][CR]'
                'You may need to restart Kodi first.',
            )
        except Exception as exc:
            c.log(f'[Orion] install failed: {exc}', 1)

    def _add_orion_repo_source(self):
        try:
            orion_url = 'https://repo.orionoid.com'
            source_name = 'Orion Repository'
            sources_path = xbmcvfs.translatePath('special://userdata/sources.xml')

            if xbmcvfs.exists(sources_path):
                tree = ET.parse(sources_path)
                root = tree.getroot()
            else:
                root = ET.Element('sources')
                tree = ET.ElementTree(root)

            files_section = root.find('files')
            if files_section is None:
                files_section = ET.SubElement(root, 'files')
                ET.SubElement(files_section, 'default', pathversion='1')

            for source in files_section.findall('source'):
                path_el = source.find('path')
                if path_el is not None and path_el.text == orion_url:
                    return True

            source_el = ET.SubElement(files_section, 'source')
            ET.SubElement(source_el, 'name').text = source_name
            ET.SubElement(source_el, 'path', pathversion='1').text = orion_url
            ET.SubElement(source_el, 'allowsharing').text = 'true'

            tree.write(sources_path, encoding='utf-8', xml_declaration=True)
            return True
        except Exception as exc:
            c.log(f'[Orion] repo source failed: {exc}', 1)
            return False


api = OrionApi()

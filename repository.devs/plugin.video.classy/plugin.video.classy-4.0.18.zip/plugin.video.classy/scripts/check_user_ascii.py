#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI wrapper  -  core logic lives in resources/lib/tools/ascii_guard.py."""

from __future__ import annotations

import argparse
import os
import sys

ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, os.path.join(ADDON_ROOT, 'resources', 'lib'))

from tools.ascii_guard import run_check, run_fix  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default=ADDON_ROOT, help='Addon root (default: plugin.video.classy)')
    parser.add_argument('--fix', action='store_true', help='Apply standard ASCII replacements')
    args = parser.parse_args(argv)

    if args.fix:
        ok, lines = run_fix(args.root)
    else:
        ok, lines = run_check(args.root)

    for row in lines:
        print(row)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI wrapper  -  apply podnapisi.py-style GPL headers across Classy/Crew 4.x."""

from __future__ import annotations

import argparse
import os
import sys

ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, os.path.join(ADDON_ROOT, 'resources', 'lib'))

from tools.gpl_header import run_apply  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default=ADDON_ROOT, help='Addon root (default: plugin.video.classy)')
    parser.add_argument('--fix', action='store_true', help='Write headers (default: dry-run report only)')
    parser.add_argument(
        '--force',
        action='store_true',
        help='Refresh headers even when already on The Crew / plugin.video.thecrew template',
    )
    args = parser.parse_args(argv)

    changed, ok = run_apply(os.path.abspath(args.root), fix=args.fix, force=args.force)
    mode = 'updated' if args.fix else 'would update'
    print(f'GPL header pass ({mode}): {len(changed)} file(s), {len(ok)} already OK')
    for row in changed[:300]:
        print(row)
    if len(changed) > 300:
        print(f'... and {len(changed) - 300} more')
    return 0


if __name__ == '__main__':
    sys.exit(main())

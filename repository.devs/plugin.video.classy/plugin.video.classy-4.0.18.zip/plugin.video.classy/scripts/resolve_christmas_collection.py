# -*- coding: utf-8 -*-
'''Temp resolver: Christmas master JSON -> TMDb + WeTrakr ids.

Reads the curated master list, fills missing tmdb_id via TMDb search
(year-aware, never silent-guesses), then maps TMDb -> WeTrakr id via
GET /media/external/tmdb/{id}.

Outputs (beside --out-dir):
  christmas_resolved.json       master + tmdb_id + wetrakr_id + confidence
  christmas_needs_review.json   ambiguous / failed rows for human check
  christmas_from_items.json     VIP POST /lists/from-items body
  christmas_sync_items.json     POST /sync/lists/{id}/items body (ids.tmdb)

Not shipped. Uses keys.py + optional Classy WeTrakr token (import only).

Usage:
  python scripts/resolve_christmas_collection.py ^
    --input "D:\\Downloads\\christmas_collection_master_v0.4_250.json" ^
    --out-dir "D:\\Downloads\\christmas_resolve"

  # after review, create list on WeTrakr (VIP):
  python scripts/resolve_christmas_collection.py --import-from-items ^
    --out-dir "D:\\Downloads\\christmas_resolve" ^
    --list-name "Christmas Collection"
'''

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

TMDB_BASE = 'https://api.themoviedb.org/3'
WETRAKR_BASE = 'https://api.wetrakr.com'
UA = 'TheCrew-ChristmasResolve/1'

# Master type hint -> (primary TMDb search kind, WeTrakr type for from-items)
_TYPE_MAP = {
    'movie': ('movie', 'movie'),
    'special': ('movie', 'movie'),       # TV specials often live as movies; fallback tv
    'performance': ('movie', 'movie'),
    'series': ('tv', 'show'),
    'miniseries': ('tv', 'show'),
    'season': ('tv', 'show'),           # show-level; season number stays in notes
}


def _repo_root():
    return Path(__file__).resolve().parents[1]


def _load_keys():
    ns = {}
    path = _repo_root() / 'resources' / 'lib' / 'modules' / 'keys.py'
    exec(path.read_text(encoding='utf-8'), ns)
    return (ns.get('tmdb_key') or '').strip(), (ns.get('wetrakr_id') or '').strip()


def _read_setting(key):
    settings = Path(os.path.expandvars(
        r'%APPDATA%\Kodi\userdata\addon_data\plugin.video.classy\settings.xml'
    ))
    if not settings.is_file():
        return ''
    text = settings.read_text(encoding='utf-8')
    m = re.search(
        r'<setting id="%s">([^<]*)</setting>' % re.escape(key), text,
    )
    return (m.group(1).strip() if m else '')


def _http_json(url, *, headers=None, method='GET', body=None, timeout=20):
    hdrs = {'User-Agent': UA, 'Accept': 'application/json'}
    if headers:
        hdrs.update(headers)
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        hdrs.setdefault('Content-Type', 'application/json')
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8', 'replace')
            return resp.status, json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode('utf-8', 'replace')
        try:
            payload = json.loads(raw) if raw.strip() else {}
        except Exception:
            payload = {'_raw': raw[:300]}
        return exc.code, payload


def _year_of(date_text):
    if not date_text:
        return None
    m = re.match(r'(\d{4})', str(date_text))
    return int(m.group(1)) if m else None


_SEASON_SUFFIX = re.compile(
    r'\s*[-\u2013\u2014:]\s*season\s*\d+\s*$',
    re.IGNORECASE,
)
_PAREN_ALT = re.compile(r'\s*\([^)]*\)\s*$')
_MAKING_OF = re.compile(
    r'\b(making of|the making of|behind the scenes)\b',
    re.IGNORECASE,
)


def _norm_title(text):
    text = (text or '').casefold()
    text = text.replace('\u2019', "'").replace('\u2018', "'")
    text = text.replace('\u201c', '"').replace('\u201d', '"')
    text = text.replace('&', ' and ')
    text = re.sub(r'[^a-z0-9]+', ' ', text)
    return ' '.join(text.split())


def _search_title(title, hint=''):
    '''Strip season suffixes / trailing alt titles for TMDb query.'''
    text = (title or '').strip()
    text = _SEASON_SUFFIX.sub('', text).strip()
    # Keep primary name before em-dash alt: "Elves (Nisser)" stays; "Foo  -  Bar" keep Foo
    if '\u2014' in text or '\u2013' in text:
        text = re.split(r'\s*[\u2013\u2014]\s*', text, maxsplit=1)[0].strip()
    if hint == 'season':
        text = _PAREN_ALT.sub('', text).strip() or text
    return text


def _flatten_items(master):
    rows = []
    for section in master.get('sections') or []:
        for item in section.get('items') or []:
            if isinstance(item, dict):
                rows.append(item)
    return rows


def _tmdb_search(api_key, kind, title, year, sleep_s):
    params = {
        'api_key': api_key,
        'query': title,
        'include_adult': 'false',
    }
    if year:
        if kind == 'movie':
            params['year'] = str(year)
            params['primary_release_year'] = str(year)
        else:
            params['first_air_date_year'] = str(year)
    qs = urllib.parse.urlencode(params)
    url = f'{TMDB_BASE}/search/{kind}?{qs}'
    status, data = _http_json(url)
    time.sleep(sleep_s)
    if status != 200:
        return [], status
    return list(data.get('results') or []), status


def _pick_tmdb(results, kind, want_year, query_title):
    '''Return (result, confidence, reason). confidence: high|medium|low|none.'''
    if not results:
        return None, 'none', 'no_results'

    qn = _norm_title(query_title)
    scored = []
    for row in results:
        if kind == 'movie':
            title = row.get('title') or row.get('original_title') or ''
            alt = row.get('original_title') or ''
            date = row.get('release_date')
        else:
            title = row.get('name') or row.get('original_name') or ''
            alt = row.get('original_name') or ''
            date = row.get('first_air_date')
        y = _year_of(date)
        tn = _norm_title(title)
        an = _norm_title(alt)
        pop = float(row.get('popularity') or 0)

        score = 0
        reason = 'title_only'
        if want_year and y == want_year:
            score = 100
            reason = 'year_exact'
        elif want_year and y and abs(y - want_year) == 1:
            score = 70
            reason = 'year_off_by_1'
        elif want_year and y and abs(y - want_year) <= 3:
            score = 40
            reason = 'year_near'
        elif not want_year:
            score = 50
            reason = 'no_year_requested'
        else:
            score = 10
            reason = 'year_mismatch'

        exact = bool(qn) and (tn == qn or an == qn)
        if exact:
            score += 100
            reason = f'{reason}+title_exact'
        elif qn and (qn in tn or tn in qn or qn in an or an in qn):
            score += 25
            reason = f'{reason}+title_soft'

        # Reject "Making of X" when the query is just X
        if _MAKING_OF.search(title) and not _MAKING_OF.search(query_title or ''):
            score -= 80
            reason = f'{reason}+making_of_penalty'

        scored.append((score, pop, reason, row, title, y, exact))

    scored.sort(key=lambda t: (-t[0], -t[1], t[4].casefold()))
    best_score, _pop, reason, row, title, y, exact = scored[0]

    # Exact title + year wins even if another year_exact exists
    if exact and want_year and y == want_year:
        return row, 'high', reason

    # Ambiguous only when no exact title and top two are close
    if (
        not exact
        and len(scored) > 1
        and scored[1][0] >= best_score - 5
        and scored[1][0] >= 40
    ):
        return row, 'low', f'ambiguous_top2:{reason}'

    if best_score >= 180 or (best_score >= 100 and exact):
        return row, 'high', reason
    if best_score >= 100:
        return row, 'high', reason
    if best_score >= 70:
        return row, 'medium', reason
    if best_score >= 40:
        return row, 'low', reason
    return row, 'low', reason


def _wetrakr_from_tmdb(api_key, tmdb_id, wt_type, sleep_s):
    params = urllib.parse.urlencode({'type': wt_type})
    url = f'{WETRAKR_BASE}/media/external/tmdb/{int(tmdb_id)}?{params}'
    headers = {
        'wetrakr-api-version': '1',
        'wetrakr-api-key': api_key,
    }
    status, data = _http_json(url, headers=headers)
    time.sleep(sleep_s)
    if status != 200 or not isinstance(data, dict):
        return None, status
    wid = data.get('id')
    if wid in (None, '', 0, '0'):
        return None, status
    return int(wid), status


def resolve_item(item, tmdb_key, wetrakr_key, sleep_s, cache):
    title = (item.get('title') or '').strip()
    year = item.get('year')
    try:
        year = int(year) if year not in (None, '', 'null') else None
    except (TypeError, ValueError):
        year = None
    hint = (item.get('type') or 'movie').strip().lower()
    primary, wt_type = _TYPE_MAP.get(hint, ('movie', 'movie'))

    out = dict(item)
    out['wetrakr_type'] = wt_type
    out['resolve_confidence'] = 'none'
    out['resolve_reason'] = ''
    out['wetrakr_id'] = None
    out['tmdb_media'] = primary

    # Existing TMDb id
    existing = item.get('tmdb_id')
    tmdb_id = None
    if existing not in (None, '', 'null'):
        try:
            tmdb_id = int(existing)
            out['resolve_confidence'] = 'high'
            out['resolve_reason'] = 'provided_tmdb_id'
            out['tmdb_id'] = tmdb_id
        except (TypeError, ValueError):
            tmdb_id = None

    if tmdb_id is None:
        # Search primary, then fallback for specials/performances
        kinds = [primary]
        if primary == 'movie' and hint in ('special', 'performance'):
            kinds.append('tv')
        elif primary == 'tv' and hint in ('special', 'season'):
            kinds.append('movie')

        query = _search_title(title, hint)
        out['tmdb_query'] = query
        year_tries = [year]
        if year is not None:
            year_tries.append(None)  # retry without year on stubborn specials/seasons

        best = None
        for kind in kinds:
            for year_try in year_tries:
                cache_key = (kind, query.casefold(), year_try)
                if cache_key in cache['tmdb']:
                    results = cache['tmdb'][cache_key]
                else:
                    results, status = _tmdb_search(
                        tmdb_key, kind, query, year_try, sleep_s,
                    )
                    cache['tmdb'][cache_key] = results
                    if status != 200:
                        out['resolve_reason'] = f'tmdb_http_{status}'
                pick, conf, reason = _pick_tmdb(results, kind, year, query)
                if pick and conf in ('high', 'medium'):
                    best = (pick, conf, reason, kind)
                    break
                if pick and (best is None or (
                    conf == 'low' and best[1] == 'low'
                    and float(pick.get('popularity') or 0)
                    > float(best[0].get('popularity') or 0)
                )):
                    best = (pick, conf, reason, kind)
            if best and best[1] in ('high', 'medium'):
                break

        if not best:
            out['tmdb_id'] = None
            out['resolve_confidence'] = 'none'
            out['resolve_reason'] = out.get('resolve_reason') or 'tmdb_miss'
            return out

        pick, conf, reason, kind = best
        tmdb_id = int(pick['id'])
        out['tmdb_id'] = tmdb_id
        out['tmdb_media'] = kind
        out['resolve_confidence'] = conf
        out['resolve_reason'] = reason
        out['tmdb_matched_title'] = (
            pick.get('title') or pick.get('name')
            or pick.get('original_title') or pick.get('original_name')
        )
        out['tmdb_matched_year'] = _year_of(
            pick.get('release_date') or pick.get('first_air_date')
        )
        # WeTrakr type follows actual TMDb media kind found
        out['wetrakr_type'] = 'show' if kind == 'tv' else 'movie'

    # WeTrakr resolve
    wt_type = out['wetrakr_type']
    ck = (tmdb_id, wt_type)
    if ck in cache['wetrakr']:
        wid, status = cache['wetrakr'][ck]
    else:
        wid, status = _wetrakr_from_tmdb(wetrakr_key, tmdb_id, wt_type, sleep_s)
        cache['wetrakr'][ck] = (wid, status)
    if wid:
        out['wetrakr_id'] = wid
    else:
        out['resolve_reason'] = (
            f"{out.get('resolve_reason')}|wetrakr_http_{status}"
        )
        if out['resolve_confidence'] == 'high':
            out['resolve_confidence'] = 'medium'
    return out


def build_payloads(resolved_rows, list_name):
    from_items = []
    sync_movies = []
    sync_shows = []
    for row in resolved_rows:
        conf = row.get('resolve_confidence')
        wid = row.get('wetrakr_id')
        tid = row.get('tmdb_id')
        if conf not in ('high', 'medium') or not wid or not tid:
            continue
        wt_type = row.get('wetrakr_type') or 'movie'
        from_items.append({'type': wt_type, 'id': int(wid)})
        entry = {'ids': {'tmdb': int(tid)}}
        if wt_type == 'show':
            sync_shows.append(entry)
        else:
            sync_movies.append(entry)

    return {
        'name': list_name,
        'description': 'Crew curated Christmas Collection (auto-resolved)',
        'privacy': 'public',
        'allow_comments': True,
        'items': from_items,
    }, {
        'movies': sync_movies,
        'shows': sync_shows,
    }


def run_resolve(args):
    tmdb_key, wetrakr_key = _load_keys()
    if not tmdb_key or not wetrakr_key:
        print('Missing tmdb_key or wetrakr_id from keys.py', file=sys.stderr)
        return 2

    master = json.loads(Path(args.input).read_text(encoding='utf-8'))
    items = _flatten_items(master)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    cache = {'tmdb': {}, 'wetrakr': {}}
    resolved = []
    print(f'Resolving {len(items)} items from {args.input}')
    for idx, item in enumerate(items, 1):
        row = resolve_item(item, tmdb_key, wetrakr_key, args.sleep, cache)
        resolved.append(row)
        mark = row.get('resolve_confidence')
        print(
            f"[{idx:03d}/{len(items)}] {mark:6}  "
            f"tmdb={row.get('tmdb_id')!s:>8} wt={row.get('wetrakr_id')!s:>8}  "
            f"{row.get('title')} ({row.get('year')})  {row.get('resolve_reason')}"
        )
        if args.limit and idx >= args.limit:
            break

    # Rebuild sections with resolved rows (by collection_no)
    by_no = {r.get('collection_no'): r for r in resolved}
    new_sections = []
    for section in master.get('sections') or []:
        new_items = []
        for item in section.get('items') or []:
            no = item.get('collection_no')
            new_items.append(by_no.get(no, item))
        new_sections.append({**section, 'items': new_items, 'count': len(new_items)})

    resolved_doc = {
        **{k: v for k, v in master.items() if k != 'sections'},
        'resolved_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'resolver': 'resolve_christmas_collection.py',
        'sections': new_sections,
    }
    needs = [
        r for r in resolved
        if r.get('resolve_confidence') not in ('high', 'medium')
        or not r.get('wetrakr_id')
    ]
    from_items, sync_items = build_payloads(resolved, args.list_name)

    (out_dir / 'christmas_resolved.json').write_text(
        json.dumps(resolved_doc, indent=2, ensure_ascii=True), encoding='utf-8',
    )
    (out_dir / 'christmas_needs_review.json').write_text(
        json.dumps(needs, indent=2, ensure_ascii=True), encoding='utf-8',
    )
    (out_dir / 'christmas_from_items.json').write_text(
        json.dumps(from_items, indent=2, ensure_ascii=True), encoding='utf-8',
    )
    (out_dir / 'christmas_sync_items.json').write_text(
        json.dumps(sync_items, indent=2, ensure_ascii=True), encoding='utf-8',
    )

    ok = len(resolved) - len(needs)
    print('=' * 60)
    print(f'OK (high/medium + wetrakr id): {ok}/{len(resolved)}')
    print(f'Needs review: {len(needs)}')
    print(f'from-items payload size: {len(from_items["items"])}')
    print(f'Wrote: {out_dir}')
    return 0


def run_import(args):
    '''POST /lists/from-items using christmas_from_items.json + user token.'''
    _tmdb_key, wetrakr_key = _load_keys()
    token = _read_setting('wetrakr.token')
    if not token:
        print('No wetrakr.token in Classy settings.xml  -  authorize first', file=sys.stderr)
        return 2
    path = Path(args.out_dir) / 'christmas_from_items.json'
    body = json.loads(path.read_text(encoding='utf-8'))
    if args.list_name:
        body['name'] = args.list_name
    if not body.get('items'):
        print('from-items payload empty  -  resolve first', file=sys.stderr)
        return 2
    print(f'Importing {len(body["items"])} items as list {body.get("name")!r}')
    status, data = _http_json(
        f'{WETRAKR_BASE}/lists/from-items',
        headers={
            'wetrakr-api-version': '1',
            'wetrakr-api-key': wetrakr_key,
            'Authorization': f'Bearer {token}',
        },
        method='POST',
        body=body,
    )
    print('HTTP', status)
    print(json.dumps(data, indent=2)[:2000])
    out = Path(args.out_dir) / 'christmas_import_result.json'
    out.write_text(json.dumps({'status': status, 'data': data}, indent=2), encoding='utf-8')
    return 0 if status in (200, 201) else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        '--input',
        default=r'D:\Downloads\christmas_collection_master_v0.4_250.json',
    )
    ap.add_argument(
        '--out-dir',
        default=r'D:\Downloads\christmas_resolve',
    )
    ap.add_argument('--list-name', default='Christmas Collection')
    ap.add_argument('--sleep', type=float, default=0.25, help='Delay between API calls')
    ap.add_argument('--limit', type=int, default=0, help='Resolve only first N (smoke test)')
    ap.add_argument(
        '--import-from-items',
        action='store_true',
        help='POST resolved christmas_from_items.json to WeTrakr',
    )
    args = ap.parse_args(argv)
    if args.import_from_items:
        return run_import(args)
    return run_resolve(args)


if __name__ == '__main__':
    raise SystemExit(main())

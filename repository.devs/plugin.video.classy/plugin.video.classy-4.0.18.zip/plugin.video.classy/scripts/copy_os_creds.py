# -*- coding: utf-8 -*-
"""CLI wrapper  -  core logic lives in resources/lib/tools/os_creds_import.py."""

from __future__ import annotations

import argparse
import os
import sys

ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, os.path.join(ADDON_ROOT, 'resources', 'lib'))

from tools.os_creds_import import apply_via_settings_xml, build_report, classy_settings_path, find_creds  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    default_home = os.environ.get(
        'KODI_USERDATA',
        os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Kodi', 'userdata'),
    )
    parser.add_argument('--home', default=default_home, help='Kodi userdata folder')
    args = parser.parse_args(argv)

    merged, used = find_creds(args.home)
    dst = classy_settings_path(args.home)
    if not merged:
        for line in build_report(merged, used):
            print(line)
        return 2

    for line in apply_via_settings_xml(dst, merged, used):
        print(line)
    return 0


if __name__ == '__main__':
    sys.exit(main())

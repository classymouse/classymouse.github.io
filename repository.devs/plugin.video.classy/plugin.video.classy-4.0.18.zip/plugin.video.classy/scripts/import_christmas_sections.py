# -*- coding: utf-8 -*-
'''Temp: create 5 Christmas section lists on WeTrakr via sync API.

from-items returned 400 for every body shape we tried; Path B works:
  POST /sync/lists  ->  POST /sync/lists/{id}/items with ids.tmdb

Not shipped.
'''

import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

KEYS = Path(__file__).resolve().parents[1] / 'resources' / 'lib' / 'modules' / 'keys.py'
SETTINGS = Path(
    r'C:\Users\fvanb\AppData\Roaming\Kodi\userdata'
    r'\addon_data\plugin.video.classy\settings.xml'
)
RESOLVED = Path(r'D:\Downloads\christmas_resolve\christmas_resolved.json')
OUT = Path(r'D:\Downloads\christmas_resolve\sections\import_results.json')
BASE = 'https://api.wetrakr.com'
BATCH = 40
PROBE_LIST_DELETE = 30241  # leftover from shape probe


def _client_id():
    ns = {}
    exec(KEYS.read_text(encoding='utf-8'), ns)
    return (ns.get('wetrakr_id') or '').strip()


def _token():
    text = SETTINGS.read_text(encoding='utf-8')
    m = re.search(r'<setting id="wetrakr.token">([^<]*)</setting>', text)
    return (m.group(1).strip() if m else '')


def _request(method, path, token, client, body=None, timeout=120):
    headers = {
        'User-Agent': 'TheCrew-ChristmasResolve/1',
        'wetrakr-api-version': '1',
        'wetrakr-api-key': client,
        'Authorization': 'Bearer ' + token,
        'Accept': 'application/json',
    }
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(
        BASE + path, data=data, headers=headers, method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8', 'replace')
            return resp.status, (json.loads(raw) if raw.strip() else {})
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode('utf-8', 'replace')
        try:
            payload = json.loads(raw) if raw.strip() else {}
        except Exception:
            payload = {'_raw': raw[:500]}
        return exc.code, payload


def _chunk(seq, size):
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


def _section_rows(section):
    movies, shows = [], []
    skipped = []
    for row in section.get('items') or []:
        if row.get('resolve_confidence') not in ('high', 'medium'):
            skipped.append(row.get('title'))
            continue
        tid = row.get('tmdb_id')
        if tid in (None, '', 0, '0'):
            skipped.append(row.get('title'))
            continue
        entry = {'ids': {'tmdb': int(tid)}}
        if (row.get('wetrakr_type') or 'movie') == 'show':
            shows.append(entry)
        else:
            movies.append(entry)
    return movies, shows, skipped


def import_section(section, token, client):
    name = section.get('name') or 'Christmas'
    movies, shows, skipped = _section_rows(section)
    print(
        f'CREATE {name!r} movies={len(movies)} shows={len(shows)} '
        f'skip={len(skipped)}'
    )
    status, created = _request(
        'POST', '/sync/lists', token, client,
        body={
            'name': name,
            'description': f'Crew Christmas Collection - {name}',
            'privacy': 'public',
            'allow_comments': True,
        },
    )
    if status not in (200, 201) or not isinstance(created, dict) or not created.get('id'):
        print('  create failed', status, created)
        return {
            'section': name,
            'status': status,
            'list_id': None,
            'error': created,
            'skipped': skipped,
        }

    list_id = created['id']
    privacy = created.get('privacy')
    # If create ignored public, try update
    if privacy != 'public':
        st2, upd = _request(
            'PUT', f'/sync/lists/{list_id}', token, client,
            body={'privacy': 'public', 'name': name},
        )
        print('  privacy fix', st2, (upd or {}).get('privacy') if isinstance(upd, dict) else upd)
        if isinstance(upd, dict) and upd.get('privacy'):
            privacy = upd.get('privacy')

    added_movies = added_shows = 0
    errors = []
    # movies batches
    for batch in _chunk(movies, BATCH):
        st, data = _request(
            'POST', f'/sync/lists/{list_id}/items', token, client,
            body={'movies': batch},
        )
        if st not in (200, 201):
            errors.append({'movies_batch': st, 'data': data})
            print('  movies batch ERR', st, data)
        else:
            n = ((data or {}).get('added') or {}).get('movies') or len(batch)
            added_movies += int(n)
            print(f'  +movies {n} (http {st})')
        time.sleep(0.4)

    for batch in _chunk(shows, BATCH):
        st, data = _request(
            'POST', f'/sync/lists/{list_id}/items', token, client,
            body={'shows': batch},
        )
        if st not in (200, 201):
            errors.append({'shows_batch': st, 'data': data})
            print('  shows batch ERR', st, data)
        else:
            n = ((data or {}).get('added') or {}).get('shows') or len(batch)
            added_shows += int(n)
            print(f'  +shows {n} (http {st})')
        time.sleep(0.4)

    # refresh list meta
    st, meta = _request('GET', f'/lists/{list_id}', token, client)
    total = None
    if isinstance(meta, dict):
        total = meta.get('total_items') or meta.get('items_count')
        privacy = meta.get('privacy') or privacy

    return {
        'section': name,
        'status': 201 if not errors else 207,
        'list_id': list_id,
        'privacy': privacy,
        'added_movies': added_movies,
        'added_shows': added_shows,
        'total_items': total,
        'skipped': skipped,
        'errors': errors or None,
        'menu_url_movies': f'wetrakrpubliclist:{list_id}:movie',
        'menu_url_shows': f'wetrakrpubliclist:{list_id}:show',
    }


def main():
    client = _client_id()
    token = _token()
    if not client or not token:
        print('missing client or wetrakr.token', file=sys.stderr)
        return 2

    # cleanup probe list
    if PROBE_LIST_DELETE:
        st, data = _request(
            'DELETE', f'/sync/lists/{PROBE_LIST_DELETE}', token, client,
        )
        print('delete probe list', PROBE_LIST_DELETE, st, data)

    doc = json.loads(RESOLVED.read_text(encoding='utf-8'))
    results = []
    for section in doc.get('sections') or []:
        results.append(import_section(section, token, client))
        time.sleep(0.8)

    OUT.write_text(json.dumps(results, indent=2, ensure_ascii=True), encoding='utf-8')
    print('Wrote', OUT)
    print(json.dumps(results, indent=2, ensure_ascii=True))
    ok = all(r.get('list_id') and not r.get('errors') for r in results)
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())

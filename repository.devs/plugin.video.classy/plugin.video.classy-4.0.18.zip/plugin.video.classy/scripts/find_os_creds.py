# -*- coding: utf-8 -*-
"""Locate non-empty OpenSubtitles settings in Kodi userdata (no secret output)."""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

KODI = Path(r'c:/Users/fvanb/AppData/Roaming/Kodi')
IDS = ('OSuser', 'OSpass', 'OSapikey')
ALT_IDS = {
    'username': ('opensubtitles.username', 'os_username', 'OSuser'),
    'password': ('opensubtitles.password', 'os_password', 'OSpass'),
    'apikey': ('opensubtitles.apikey', 'opensubtitles.api_key', 'OSapikey'),
}


def check_file(path: Path):
    try:
        tree = ET.parse(path)
    except Exception:
        return None
    root = tree.getroot()
    found = {}
    for el in root.findall('setting'):
        sid = el.get('id') or ''
        text = (el.text or '').strip()
        if not text or el.get('default') == 'true':
            continue
        if sid in IDS or any(sid in group for group in ALT_IDS.values()):
            found[sid] = True
    return found or None


def main():
    hits = []
    for path in KODI.rglob('settings.xml'):
        if 'addon_data' not in str(path):
            continue
        found = check_file(path)
        if found:
            hits.append((str(path.relative_to(KODI)), sorted(found.keys())))
    if not hits:
        print('no non-empty OS-related settings found under Kodi userdata')
        return
    for rel, keys in sorted(hits):
        print('%s: %s' % (rel, ', '.join(keys)))


if __name__ == '__main__':
    main()

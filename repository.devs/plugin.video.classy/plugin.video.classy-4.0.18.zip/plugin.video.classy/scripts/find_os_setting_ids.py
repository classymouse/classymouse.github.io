# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file find_os_setting_ids.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

from pathlib import Path
import xml.etree.ElementTree as ET

KODI = Path(r'c:/Users/fvanb/AppData/Roaming/Kodi')
needles = ('opensubtitles', 'OSuser', 'OSpass', 'OSapikey')
for path in KODI.rglob('settings.xml'):
    try:
        root = ET.parse(path).getroot()
    except Exception:
        continue
    for el in root.findall('setting'):
        sid = (el.get('id') or '').lower()
        text = (el.text or '').strip()
        if not text or el.get('default') == 'true':
            continue
        if any(n.lower() in sid for n in needles):
            print('%s -> %s' % (path.relative_to(KODI), el.get('id')))

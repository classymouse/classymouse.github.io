# -*- coding: utf-8 -*-
from pathlib import Path
root = Path(r'c:/Users/fvanb/AppData/Roaming/Kodi/addons')
needles = ('OSapikey', 'opensubtitles.com/api', 'Api-Key')
for base in ('plugin.video.thecrew', 'script.module.thecrew', 'plugin.video.classy'):
    p = root / base
    if not p.is_dir():
        continue
    for f in p.rglob('*'):
        if f.suffix not in ('.py', '.xml', '.json'):
            continue
        try:
            text = f.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        if any(n in text for n in needles):
            print(str(f.relative_to(root)))

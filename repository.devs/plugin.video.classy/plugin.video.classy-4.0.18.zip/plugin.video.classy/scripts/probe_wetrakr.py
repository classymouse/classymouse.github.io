# -*- coding: utf-8 -*-
'''Ad-hoc WeTrakr API probe. Reads token from Kodi settings.xml + client_id
from keys.py. Prints status + truncated JSON key shapes only. Never prints
full tokens. Not shipped.'''

import base64
import json
import os
import sys
import urllib.request
import urllib.error

BASE = 'https://api.wetrakr.com'
SETTINGS = os.path.expandvars(
    r'%APPDATA%\Kodi\userdata\addon_data\plugin.video.classy\settings.xml'
)
KEYS = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    'resources', 'lib', 'modules', 'keys.py',
)


def _read_setting(key):
    import re
    with open(SETTINGS, 'r', encoding='utf-8') as fh:
        data = fh.read()
    m = re.search(r'<setting id="%s">([^<]*)</setting>' % re.escape(key), data)
    return (m.group(1).strip() if m else '')


def _client_id():
    ns = {}
    with open(KEYS, 'r', encoding='utf-8') as fh:
        src = fh.read()
    exec(src, ns)
    return (ns.get('wetrakr_id') or '').strip()


TOKEN = _read_setting('wetrakr.token')
REFRESH = _read_setting('wetrakr.refresh')
CLIENT_ID = _client_id()


def _mask(v):
    if not v:
        return '(empty)'
    return '%s...len=%d' % (v[:6], len(v))


print('token   =', _mask(TOKEN))
print('refresh =', _mask(REFRESH))
print('client  =', _mask(CLIENT_ID))
print('=' * 60)


def _shape(obj, depth=0):
    if isinstance(obj, dict):
        return {k: _shape(v, depth + 1) for k, v in list(obj.items())[:20]}
    if isinstance(obj, list):
        return ['list[%d]' % len(obj)] + ([_shape(obj[0], depth + 1)] if obj else [])
    if isinstance(obj, str):
        return 'str(%d)' % len(obj)
    return type(obj).__name__


def probe(method, path, body=None):
    url = BASE + path
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'TheCrew-WeTrakr-Probe/1',
        'wetrakr-api-version': '1',
    }
    if CLIENT_ID:
        headers['wetrakr-api-key'] = CLIENT_ID
    if TOKEN:
        headers['Authorization'] = 'Bearer %s' % TOKEN
    data = json.dumps(body).encode('utf-8') if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read().decode('utf-8', 'replace')
            status = resp.status
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', 'replace')
        status = e.code
    except Exception as e:
        print('%-6s %-45s ERR %s' % (method, path, e))
        return
    snippet = ''
    try:
        parsed = json.loads(raw)
        snippet = json.dumps(_shape(parsed))[:600]
    except Exception:
        snippet = raw[:200].replace('\n', ' ')
    print('%-6s %-45s %s  %s' % (method, path, status, snippet))


CANDIDATES = [
    ('GET', '/sync/last_activities'),
    ('GET', '/sync/tracking/watched/movies'),
    ('GET', '/sync/tracking/watched/shows'),
    ('GET', '/sync/tracking/watched/episodes'),
    ('GET', '/sync/tracking/playing/movies'),
    ('GET', '/sync/tracking/playing/shows'),
    ('GET', '/sync/tracking/playing/episodes'),
    ('GET', '/sync/tracking/planning/movies'),
    ('GET', '/sync/tracking/planning/shows'),
    ('GET', '/sync/watched/movies'),
    ('GET', '/sync/watched/shows'),
    ('GET', '/sync/playing/movies'),
    ('GET', '/sync/playing/shows'),
    ('GET', '/sync/planning/movies'),
    ('GET', '/sync/planning/shows'),
    ('GET', '/sync/history/movies'),
    ('GET', '/sync/history/shows'),
    ('GET', '/sync/watchlist/movies'),
    ('GET', '/sync/watchlist/shows'),
    ('GET', '/sync/playback'),
    ('GET', '/sync/playback/movies'),
    ('GET', '/sync/playback/episodes'),
    ('GET', '/account/settings'),
    ('GET', '/sync/collection/movies'),
    ('GET', '/calendar/shows?start=2026-09-29&end=2026-10-06&mode=discover&tz=UTC'),
    ('GET', '/calendar/shows?start=2026-09-29&end=2026-10-06&mode=following&tz=UTC'),
]

if __name__ == '__main__':
    extra = sys.argv[1:]
    if extra:
        probe(extra[0].upper(), extra[1])
    else:
        for m, p in CANDIDATES:
            probe(m, p)

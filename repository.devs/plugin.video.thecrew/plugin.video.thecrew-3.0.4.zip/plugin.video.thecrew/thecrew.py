# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file thecrew.py
* @package plugin.video.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import sys
import time
from urllib.parse import parse_qsl

from resources.lib.modules.crewruntime import c

_entry_started = time.perf_counter()

if c.devmode:
	c.log('[THE CREW ENTRY] thecrew.py STARTED - argv=' + str(sys.argv), trace=1)

_import_started = time.perf_counter()
from resources.lib.modules import crew
from resources.lib.modules.perf import perf_log

perf_log('import crew module', _import_started)

try:
	if c.devmode:
		c.log('[THE CREW ENTRY] crew module imported successfully', 1)
except Exception:
	pass

try:
	if c.devmode:
		c.log('[THE CREW ENTRY] Parsing params from argv[2]=' + str(sys.argv[2] if len(sys.argv) > 2 else 'MISSING'), 1)
	params = dict(parse_qsl(sys.argv[2].replace('?', ''))) if len(sys.argv) > 2 else {}
	if c.devmode:
		c.log('[THE CREW ENTRY] Parsed params=' + str(params), 1)
except Exception as e:
	if c.devmode:
		c.log('[THE CREW ENTRY] Error parsing params: ' + str(e), 1)
	params = {}

_router_started = time.perf_counter()
try:
	if c.devmode:
		c.log('[THE CREW ENTRY] Calling crew.router with params=' + str(params), 1)
	crew.router(params)
	perf_log('plugin.router action=' + str(params.get('action', '<default>')), _router_started)
	perf_log('plugin.total', _entry_started)
	if c.devmode:
		c.log('[THE CREW ENTRY] crew.router completed', 1)
except Exception as e:
	perf_log('plugin.router FAILED action=' + str(params.get('action', '<default>')), _router_started)
	perf_log('plugin.total', _entry_started)
	if c.devmode:
		c.log('[THE CREW ENTRY] crew.router FAILED: ' + str(e), 1)
		import traceback
		c.log('[THE CREW ENTRY] Traceback: ' + traceback.format_exc(), 1)
	raise
